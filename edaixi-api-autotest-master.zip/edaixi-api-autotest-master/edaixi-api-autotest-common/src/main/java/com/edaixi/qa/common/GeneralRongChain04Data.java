package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16-2-15.
 */
public class GeneralRongChain04Data {

    private Map<String, Object> generalOrderParams = null;
    private Map<String, Object> generalCouriersParams = null;
    private Map<String, Object> generalDispatchTaskParams = null;


    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public final void init(){
        this.generalOrderParams = new HashMap<String, Object>();
        this.generalCouriersParams = new HashMap<String, Object>();
        this.generalDispatchTaskParams = new HashMap<String, Object>();
        this.generalDispatchTaskParams = new HashMap<String, Object>();

    }

    public static String getYestoryDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,-1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    public static String getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrow = sdf.format(calendar.getTime());
        return tomorrow;
    }

    public static  String getTodayDate(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        return date;
    }

    /**
     * 创建订单sql
     * 必须参数:order_id,order_sn,status,status_delivery,pay_status,nextDate,washing_time,uid,old_category_id
     * 可选参数:totalprice,delivery_fee,mobile,fan_id,uid_song
     * @param generalOrderParams
     */
    public void GeneralOrder(Map<String, Object> generalOrderParams){

        String order_id = generalOrderParams.get("order_id").toString();
        String order_sn = generalOrderParams.get("order_sn").toString();
        Object status = generalOrderParams.get("status");
        Object status_delivery = generalOrderParams.get("status_delivery");
        Object pay_status = generalOrderParams.get("pay_status");
        Object nextDate = generalOrderParams.get("nextDate");
        String washing_time = generalOrderParams.get("washing_time").toString();
        Object uid = generalOrderParams.get("uid");
        Object old_category_id = generalOrderParams.get("old_category_id");

        if ( !(nextDate instanceof String) ){
            nextDate = formatDate.format(nextDate);
        }

        String totalprice = "0";
        String delivery_fee = "0";
        if (generalOrderParams.containsKey("totalprice")){
            totalprice = (String) generalOrderParams.get("totalprice");
        }

        if (generalOrderParams.containsKey("delivery_fee")){
            delivery_fee = (String) generalOrderParams.get("delivery_fee");
        }

        String mobile = "";
        if (generalOrderParams.containsKey("mobile")){
            mobile = generalOrderParams.get("mobile").toString();
        }

        String uid_song = "0";
        if (generalOrderParams.containsKey("uid_song")){
            uid_song = generalOrderParams.get("uid_song").toString();
        }

        String fan_id = "";
        if (generalOrderParams.containsKey("fan_id")){
            fan_id = generalOrderParams.get("fan_id").toString();
        }else{
            String sql = "select id from ims_fans where from_user = '21111119017' and realname = '接口测试用户' order by id desc limit 1;";
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            try {
                resultSet.beforeFirst();
                if(resultSet.next()){
                    fan_id = resultSet.getString("id");
                }else{
                    String sql_q = "select id from ims_fans order by id desc limit 1;";
                    ResultSet r2 = mysqlQaDao.execQuerySql(sql_q);
                    r2.beforeFirst();
                    if (r2.next()){
                        int last_id = r2.getInt("id");
                        Map<String, Object> map = new HashMap<String, Object>();
                        fan_id = String.valueOf(last_id+1);
                        map.put("id", fan_id);
                        map.put("mobile", mobile);
                        GeneralImsFans(map);

                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        String bagsn = "";
        if (generalOrderParams.containsKey("bagsn")){
            bagsn = generalOrderParams.get("bagsn").toString();
        }


        String wuliu_song_qianshou_time = "NULL";
        if (generalOrderParams.containsKey("wuliu_song_qianshou_time")){
            wuliu_song_qianshou_time = "'"+generalOrderParams.get("wuliu_song_qianshou_time")+"'";
        }

        Object insure_price = 0;
        if(generalOrderParams.containsKey("insure_fee")) {
            insure_price = generalOrderParams.get("insure_fee");
        }
        String city = "北京";
        if (generalOrderParams.containsKey("city")){
            city = generalOrderParams.get("city").toString();
        }

        String area = "朝阳区";
        if (generalOrderParams.containsKey("area")){
            area = generalOrderParams.get("area").toString();
        }

        String address = "大山子";
        if (generalOrderParams.containsKey("address")){
            address = generalOrderParams.get("address").toString();
        }

        String address_qu_id = "0";
        if (generalOrderParams.containsKey("address_qu_id")){
            address_qu_id = generalOrderParams.get("address_qu_id").toString();
        }

        String address_song_id = "0";
        if (generalOrderParams.containsKey("address_song_id")){
            address_song_id = generalOrderParams.get("address_song_id").toString();
        }

        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, " +
                "`remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, " +
                "`kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`,`insure_price`)\n" +
                "VALUES\n" +
                "\t(" + order_id + ", NULL, 7, '" + order_sn + "', '"+bagsn+"', 1, "+totalprice+", "+delivery_fee+", '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, " +
                "'接口测试', '" + nextDate + "', '" + washing_time + "', '', '', '接口测试用户', '"+mobile+"', '"+city+"', '"+area+"', '"+address+"', '"+city+"', '"+area+"', '"+address+"', "+ uid + ", "+uid_song+", 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, " +
                "NULL, NULL, NULL, NULL, NULL, "+wuliu_song_qianshou_time+", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, "+fan_id+", NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, " + address_qu_id + ", " + address_song_id + ", NULL, NULL, '"+order_sn.substring(order_sn.length()-6)+"', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL, " + insure_price + ");\n";
        mysqlQaDao.execUpdateSql(orderInfo);
    }

    public void GeneralCouriers(Map<String, Object> generalCouriersParams){

        String courier_id = generalCouriersParams.get("courier_id").toString();
        String tel = generalCouriersParams.get("tel").toString();
        String push_token = generalCouriersParams.get("push_token").toString();
        String kind = "1";
        if (generalCouriersParams.containsKey("kind")){
            kind = generalCouriersParams.get("kind").toString();
        }
        String is_zhongtui = "0";
        if(generalCouriersParams.containsKey("is_zhongtui")){
            is_zhongtui = generalCouriersParams.get("is_zhongtui").toString();
        }
        String kuaixi = "0";
        if(generalCouriersParams.containsKey("kuaixi")){
            kuaixi = generalCouriersParams.get("kuaixi").toString();
        }
        String is_owner = "0";
        if(generalCouriersParams.containsKey("is_owner")){
            is_owner = generalCouriersParams.get("is_owner").toString();
        }
        String is_zancun = "0";
        if(generalCouriersParams.containsKey("is_zancun")){
            is_zancun = generalCouriersParams.get("is_zancun").toString();
        }

        String city_id = "1";
        if(generalCouriersParams.containsKey("city_id")){
            city_id = generalCouriersParams.get("city_id").toString();
        }
        String city = "北京";
        if(generalCouriersParams.containsKey("city")){
            city = generalCouriersParams.get("city").toString();
        }

        String courierInfo = "INSERT INTO `ims_washing_courier` (`id`, `realname`, `password`, `tel`, `outlet_id`, `status`, `push_token`, `created_at`, `updated_at`, `city`, `kind`, `polygon_group_id`, `use_auto_schedule`, `bank_card`, `id_number`, `bank_name`, `saofen`, `shouka`, `jiedan`, `edaixi_nr`, `start_time`, `end_time`, `channel`, `luxury_logistic`, `city_id`, `zhuanyun`, `client_name`, `is_zhongtui`, `is_employee`, `close_time`, `kuaixi`, `street_name`, `gender`, `service_time_type`, `catch_reasons`, `is_zancun`, `is_owner`, `yizhan_id`, `is_van`, `songyao`, `contract_version`, `contract_version_end_time`, `hotel_id`, `is_part_time`, `is_lanshou`, `songfan`, `deposit`, `pay_deposit_state`, `jiebo`, `bank_user_name`, `tailor`, `tailor_outlet_id`, `detailed_address`, `emergency_tel`)\n" +
                "VALUES\n" +
                "\t(" + courier_id + ", '接口测试', '1234566', " + tel + ", 3, 1, '" + push_token + "', '2015-09-10 02:33:58', '2016-02-02 16:03:42', '" + city + "', " + kind + ", 476, 1, '6778550144961236', '429008198709081111', '招行', 1, 1, 1, '001001000015', '2015-09-01', '2017-03-31', 'com.15.zhongbao', 1, " + city_id + ", 1, 'android_client', " + is_zhongtui + ", 0, NULL, " + kuaixi + ", NULL, NULL, NULL, NULL, " + is_zancun + ", " + is_owner + ", NULL, NULL, 0, 1, 0, NULL, 0, NULL, 0, 0.00, 0, 0, NULL, 0, NULL, NULL, NULL);\n";
        mysqlQaDao.execUpdateSql(courierInfo);

    }

    public void GeneralDispatchTask(Map<String, Object> generalDispatchTaskParams){

        String dispatch_id = generalDispatchTaskParams.get("id").toString();
        String order_id = generalDispatchTaskParams.get("order_id").toString();
        String nextDate = generalDispatchTaskParams.get("nextDate").toString();

        String category_id = "1";
        if (generalDispatchTaskParams.containsKey("category_id")){
            category_id = generalDispatchTaskParams.get("category_id").toString();
        }

        String status = "started";
        if (generalDispatchTaskParams.containsKey("status")){
            status = generalDispatchTaskParams.get("status").toString();
        }

        String courier_id = "NULL";
        if (generalDispatchTaskParams.containsKey("courier_id")){
            courier_id = generalDispatchTaskParams.get("courier_id").toString();
        }

        String finished_at = "NULL";
        if (generalDispatchTaskParams.containsKey("finished_at")){
            finished_at = "'"+generalDispatchTaskParams.get("finished_at").toString()+"'";
        }

        String dispathchInfo = "INSERT INTO `dispatch_tasks` (`id`, `order_id`, `status`, `from_type`, `from_id`, `to_type`, `to_id`, `dispatch_type`, `courier_id`, `hope_time`, `finished_at`, `category_id`, `created_at`, `updated_at`, `type`, `ordersn`, `city_id`)\n" +
                "VALUES\n" +
                "\t(" + dispatch_id + ", " + order_id + ", '"+status+"', 'jiagongdian', NULL, 'Address', 595949, 0, "+courier_id+", '" + nextDate + "', "+finished_at+", "+category_id+", '" + formatTime.format(dt) + "', '" + formatTime.format(dt) + "', 'DispatchTask', NULL, 1);\n";
        mysqlQaDao.execUpdateSql(dispathchInfo);


    }

    /**Trans_tasks表
     * 必须参数:id,ordersn,order_id
     * 可选参数:bagsn,from_id,from_type,to_id,to_type,dead_line,status,washing_status,direction,next_task_id,trans_group_id,category_id
     * @param generalTransTasksParams
     */
    public void GeneralTransTasks(Map<String, Object> generalTransTasksParams){


        String task_id = generalTransTasksParams.get("id").toString();
        Object ordersn = generalTransTasksParams.get("ordersn");
        Object order_id = generalTransTasksParams.get("order_id");

        String bagsn = "NULL";
        if (generalTransTasksParams.containsKey("bagsn")){
            bagsn = generalTransTasksParams.get("bagsn").toString();
        }

        String from_id = "NULL";
        if (generalTransTasksParams.containsKey("from_id")){
            from_id = generalTransTasksParams.get("from_id").toString();
        }

        String from_type = "NULL";
        if (generalTransTasksParams.containsKey("from_type")){
            from_type = generalTransTasksParams.get("from_type").toString();
        }

        String to_id = "NULL";
        if (generalTransTasksParams.containsKey("to_id")){
            to_id = generalTransTasksParams.get("to_id").toString();
        }

        String to_type = "customer";
        if (generalTransTasksParams.containsKey("to_type")){
            to_type = generalTransTasksParams.get("to_type").toString();
        }

        String dead_line = getTomorrowDate();
        if (generalTransTasksParams.containsKey("dead_line")){
            dead_line = generalTransTasksParams.get("dead_line").toString();
        }

        String status = "started";
        if (generalTransTasksParams.containsKey("status")){
            status = generalTransTasksParams.get("status").toString();
        }
        String direction = "get";
        if (generalTransTasksParams.containsKey("direction")){
            direction = generalTransTasksParams.get("direction").toString();
        }
        String washing_status = "unwashed";
        if (generalTransTasksParams.containsKey("washing_status")){
            washing_status = generalTransTasksParams.get("washing_status").toString();
        }

        String next_task_id = "NULL";
        if (generalTransTasksParams.containsKey("next_task_id")){
            next_task_id = generalTransTasksParams.get("next_task_id").toString();
        }

        String transfer_task_id = "NULL";
        if (generalTransTasksParams.containsKey("transfer_task_id")){
            transfer_task_id = generalTransTasksParams.get("transfer_task_id").toString();
        }

        String trans_group_id = "NULL";
        if (generalTransTasksParams.containsKey("trans_group_id")){
            trans_group_id = generalTransTasksParams.get("trans_group_id").toString();
        }

        String category_id = "1";
        if (generalTransTasksParams.containsKey("category_id")){
            category_id = generalTransTasksParams.get("category_id").toString();
        }

        String finished_at = "NULL";
        if (generalTransTasksParams.containsKey("finished_at")){
            finished_at = "'"+generalTransTasksParams.get("finished_at").toString()+"'";
        }

        String sql_task = "insert into trans_tasks (id,bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type)" +
                "values("+
                task_id+","+bagsn+","+from_id+",'"+from_type+"',NULL,"+to_id+",'"+to_type+"',595983,"+next_task_id+","+transfer_task_id+",NULL,'"+
                dead_line+"',NULL,'"+status+"','"+direction+"',"+finished_at+",'"+getTodayDate()+"','"+getTodayDate()+"',"+category_id+","+ordersn+",'"+washing_status+"',"+order_id+","+trans_group_id+",0,0);";

        mysqlQaDao.execUpdateSql(sql_task);

    }


    public void GeneralTransGroups(Map<String, Object> generalTransGroupsParams){
        Object group_id = generalTransGroupsParams.get("id").toString();
        Object order_id = generalTransGroupsParams.get("order_id").toString();
        Object current_task_id = generalTransGroupsParams.get("current_task_id");
        Object last_task_id = generalTransGroupsParams.get("last_task_id");
        Object dispatch_task_id = generalTransGroupsParams.get("dispatch_task_id");

        String ordersn = "NULL";
        if (generalTransGroupsParams.containsKey("ordersn")){
            generalTransGroupsParams.get("ordersn").toString();
        }

        String bagsn = "NULL";
        if (generalTransGroupsParams.containsKey("bagsn")){
            bagsn = generalTransGroupsParams.get("bagsn").toString();
        }

        String created_at = getTodayDate();
        if (generalTransGroupsParams.containsKey("created_at")){
            created_at = generalTransGroupsParams.get("created_at").toString();
        }

        String updated_at = getTodayDate();
        if (generalTransGroupsParams.containsKey("updated_at")){
            updated_at = generalTransGroupsParams.get("updated_at").toString();
        }

        String sql_groups = "insert into trans_groups (id,order_id,ordersn,bagsn,current_task_id,last_task_id,order_type,order_status,status_delivery,type,created_at,updated_at,propose_outlet_id,dispatch_task_id)" +
                "values("+
                group_id+","+order_id+","+ordersn+","+bagsn+","+current_task_id+","+last_task_id+",NULL,1,NULL,'TransGroup','"+created_at+"','"+updated_at+"',NULL,"+dispatch_task_id+");";
        mysqlQaDao.execUpdateSql(sql_groups);
    }

    public void GeneralImsFans(Map<String, Object> generalImsFansParams){
        Object id = generalImsFansParams.get("id");
        Object mobile = generalImsFansParams.get("mobile");

        Object from_user = mobile;
        if (generalImsFansParams.containsKey("from_user")){
            from_user = generalImsFansParams.get("from_user");
        }

        String sql = "insert into ims_fans(id,user_type,from_user,salt,follow,createtime,realname,nickname,avatar,mobile,vip,isblacklist,push_token,user_token,courier_qu_in_process,last_order_time,frequently_address_id,first_qid,current_qid,first_courier_id,current_courier_id,created_at,updated_at,first_order_time,last_finish_order_time,huanxin_password,huanxin_name,last_order_id)" +
                "values("+id+",0,"+from_user+",'',1,1457508534,'接口测试用户','','',"+mobile+",0,0,'','',0,1457677760,595977,0,0,0,0,'2016-03-09 15:28:54','2016-03-11 14:29:20',1457508534,0,NULL,NULL,984882383);";
        mysqlQaDao.execUpdateSql(sql);
    }


    /**
     * 创建卡sql
     * 必须参数:recharge_id,weid,price,usednum,use_limit,zhenqian,kind
     * 可选参数:validity_type,charge_validity_type
     * @param generalRechargeParams
     */
    public void GeneralRecharge(Map<String, Object> generalRechargeParams){

        Object recharge_id = generalRechargeParams.get("recharge_id");
        Object weid = generalRechargeParams.get("weid");
        long current_time = System.currentTimeMillis();
        Object price = generalRechargeParams.get("price");
        Object usednum = generalRechargeParams.get("usednum");
        Object starttime = "";
        Object endtime = "";
        Object use_limit = 0;
        Object zhenqian = generalRechargeParams.get("zhenqian");
        Object kind = generalRechargeParams.get("kind");
        Object validity_type = 0;
        Object fixed_term = 0;
        Object fixed_begin_term = 0;
        Object charge_validity_type = 0;
        Object charge_fixed_term = 0;
        Object charge_fixed_begin_term = 0;
        Object charge_starttime = "";
        Object charge_endtime = "";
        Object is_actived = 1;
        Object recharge_group_id = 0;
        Object create_time = current_time/1000;

        if(generalRechargeParams.containsKey("recharge_group_id")){
            recharge_group_id = generalRechargeParams.get("recharge_group_id");
        }

        if(generalRechargeParams.containsKey("is_actived")){
            is_actived = generalRechargeParams.get("is_actived");
        }

        if(generalRechargeParams.containsKey("use_limit")){
            use_limit = generalRechargeParams.get("use_limit");
        }
        if(generalRechargeParams.containsKey("create_time")){
            create_time = generalRechargeParams.get("create_time");
        }

        if(generalRechargeParams.containsKey("validity_type")){
            validity_type = generalRechargeParams.get("validity_type").toString();
            if(Integer.parseInt((String) validity_type) == 0){
                if(generalRechargeParams.containsKey("starttime")){
                    starttime = generalRechargeParams.get("starttime");
                }else{
                    starttime = current_time/1000;
                }

                if(generalRechargeParams.containsKey("endtime")){
                    endtime = generalRechargeParams.get("endtime");
                }else{
                    endtime = CommonTools.getTimesnight()-1 + (24 * 60 * 60 * 20);
                }

            }else if (Integer.parseInt((String) validity_type) == 1){
                fixed_term = generalRechargeParams.get("fixed_term");
                fixed_begin_term = generalRechargeParams.get("fixed_begin_term");
                starttime = 0;
                endtime = 0;
            }
        }

        if(generalRechargeParams.containsKey("charge_validity_type")){
            charge_validity_type = generalRechargeParams.get("charge_validity_type").toString();
            if(Integer.parseInt((String) charge_validity_type) == 0){
                charge_starttime = current_time/1000;
                charge_endtime = CommonTools.getTimesnight()-1 + (24 * 60 * 60 * 20);
            }else if (Integer.parseInt((String) charge_validity_type) == 1){
                charge_fixed_term = generalRechargeParams.get("fixed_term");
                charge_fixed_begin_term = generalRechargeParams.get("fixed_begin_term");
            }
        }

        String rechargeInfo = "INSERT INTO `ims_recharge` (`id`, `weid`, `title`, `price`, `usednum`, `starttime`, `endtime`, `create_time`, `use_limit`, `zhenqian`, `apply_department`, `applicant`, `city`, `product_good_id`, `created_at`, `updated_at`, `kind`, " +
                "`stock_id`, `recharge_group_id`, `is_hidden`, `is_actived`, `validity_type`, `fixed_term`, `fixed_begin_term`, `charge_validity_type`, `charge_fixed_term`, `charge_fixed_begin_term`, `charge_starttime`, `charge_endtime`, `minimum_stock_amount`, `restock_amount`)\n" +
                "VALUES\n" +
                "\t(" + recharge_id + ", " + weid + ", '" + current_time + "', " + price + ", " + usednum +  ", "+ starttime +", " + endtime + ", "+ create_time +", " + use_limit + ", " + zhenqian + ", 'api_autotest', 'api_autotest', '北京', NULL, '" + CommonTools.getToday("yyyy-MM-dd HH:mm:ss") + "', '" + CommonTools.getToday("yyyy-MM-dd HH:mm:ss") + "', " + kind + ", " +
                "1, " + recharge_group_id + ", 0, " + is_actived + ", " + validity_type + ", " + fixed_term + ", " + fixed_begin_term + ", " + charge_validity_type + ", " + charge_fixed_term + ", " + charge_fixed_begin_term + ", " + charge_starttime +  ", " + charge_endtime + ", 0, 0);\n";
        mysqlQaDao.execUpdateSql(rechargeInfo);
    }

    /**
     * 生成卡sql
     * 必须参数:recharge_sncode_id,rid,sncode,from_user,user_type,card_type,price,zhenqian
     * 可选参数:used
     * @param generalRechargeSnParams
     */
    public void GeneralRechargeSncode(Map<String, Object> generalRechargeSnParams){

        Object recharge_sncode_id = generalRechargeSnParams.get("recharge_sncode_id");
        Object rid = generalRechargeSnParams.get("rid");
        long current_time = System.currentTimeMillis();
        String sncode = (String) generalRechargeSnParams.get("sncode");
        String from_user = (String) generalRechargeSnParams.get("from_user");
        Object usetime = 0;
        Object user_type = generalRechargeSnParams.get("user_type");
        Object card_type = generalRechargeSnParams.get("card_type");
        Object price = generalRechargeSnParams.get("price");
        Object zhenqian = generalRechargeSnParams.get("zhenqian");
        Object used = 0;
        Object fan_id= generalRechargeSnParams.get("fan_id");
        Object starttime = 0;
        Object endtime = 0;
        Object corp_id = "NULL";
        String create_time = String.valueOf(current_time/1000);
        String draw_time = "0";
        if(generalRechargeSnParams.containsKey("draw_time")){
            draw_time = generalRechargeSnParams.get("draw_time").toString();
            if(draw_time.length() != 0){
                if(generalRechargeSnParams.containsKey("starttime")){
                    starttime = generalRechargeSnParams.get("starttime");
                }else{
                    starttime= current_time/1000 - 24 * 60 * 60 * 5;

                }

                if(generalRechargeSnParams.containsKey("endtime")){
                    endtime = generalRechargeSnParams.get("endtime");
                }else{
                    endtime = CommonTools.getTimesnight()-1 + (24 * 60 * 60 * 20);
                }

            }
        }

        if(generalRechargeSnParams.containsKey("used")){
            used = generalRechargeSnParams.get("used").toString();
            if(Integer.parseInt((String) used) == 1){
                usetime = current_time/1000 - 24 * 60 * 60 * 2;
            }
        }

        if(generalRechargeSnParams.containsKey("corp_id")){
            corp_id = generalRechargeSnParams.get("corp_id").toString();
        }

        String rechargeInfo = "INSERT INTO `ims_recharge_sncode` (`id`, `rid`, `sncode`, `from_user`, `user_type`, `card_type`, `price`, `zhenqian`, `used`, `usetime`, `create_time`, `fan_id`, `good_item_id`, `courier_id`, `created_at`, `updated_at`, `starttime`, `endtime`, `corp_id`, `draw_time`)\n" +
                "VALUES\n" +
                "\t(" + recharge_sncode_id + ", " + rid + ", '" + sncode + "', " + from_user + ", " + user_type + ", " + card_type + ", " + price + ", " + zhenqian + ", " + used + ", " + usetime + ", " + create_time + "," + fan_id + ", NULL, NULL, '" + CommonTools.getToday("yyyy-MM-dd HH:mm:ss") + "', '" + CommonTools.getToday("yyyy-MM-dd HH:mm:ss") + "', " + starttime + ", " + endtime + ", " + corp_id + ", " + draw_time + ");\n";
        mysqlQaDao.execUpdateSql(rechargeInfo);
    }

    /**
     * 创建E卡限制的sql
     * 必须参数:id
     * 可选参数:used,category_id,city_id,allow_coupon,allow_mall,support_store
     * @param generalEcardLimitParams
     */
    public void GeneralEcardLimit(Map<String, Object> generalEcardLimitParams){

        Object rid = generalEcardLimitParams.get("id");
        Object category_id = 1;
        Object city_id = 1;
        Object allow_coupon = 1;
        Object allow_mall = 1;
        Object support_store = 1;
        long current_time = System.currentTimeMillis();
        String create_time = String.valueOf(current_time/1000);

        if(generalEcardLimitParams.containsKey("category_id")){
            category_id = generalEcardLimitParams.get("category_id").toString();
        }

        if(generalEcardLimitParams.containsKey("city_id")){
            city_id = generalEcardLimitParams.get("city_id").toString();
        }

        if(generalEcardLimitParams.containsKey("allow_coupon")){
            allow_coupon = generalEcardLimitParams.get("allow_coupon").toString();
        }

        if(generalEcardLimitParams.containsKey("allow_mall")){
            allow_mall = generalEcardLimitParams.get("allow_mall").toString();
        }

        if(generalEcardLimitParams.containsKey("support_store")){
            support_store = generalEcardLimitParams.get("support_store").toString();
        }


        String ecardLimitInfo = "INSERT INTO `ims_ecard_limit` (`id`, `category_id`, `city_id`, `allow_coupon`, `allow_mall`, `support_store`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + rid + ", '" + category_id + "', '" + city_id + "', " + allow_coupon + ", " + allow_mall + ", '" + support_store + "', " + create_time + ", " + create_time + ");\n";

        mysqlQaDao.execUpdateSql(ecardLimitInfo);
    }


    /**
     * 创建icard_card限制的sql
     * 必须参数:id,card_number,coin,money,updatetime,dateline,fan_id,zhenqian
     * 可选参数:rcard_sn
     * @param generalEcardCardParams
     */
    public void GeneralEcardCard(Map<String, Object> generalEcardCardParams){

        Object icard_id = generalEcardCardParams.get("id");
        Object card_number = generalEcardCardParams.get("card_number");
        Object coin = generalEcardCardParams.get("coin");
        Object money = generalEcardCardParams.get("money");
        Object updatetime = generalEcardCardParams.get("updatetime");
        Object dateline = generalEcardCardParams.get("dateline");
        Object fan_id = generalEcardCardParams.get("fan_id");
        Object zhenqian = generalEcardCardParams.get("zhenqian");
        Object rcard_sn = "NULL";

        if(generalEcardCardParams.containsKey("rcard_sn")){
            rcard_sn = generalEcardCardParams.get("rcard_sn").toString();
        }

        String insertIcardCard = "INSERT INTO `ims_icard_card` (`id`, `cardpre`, `cardno`, `coin`, `money`, `updatetime`, `dateline`, `fan_id`, `zhenqian`, `rcard_sn`)\n" +
                "VALUES\n" +
                "\t("+ icard_id + ", '', " + card_number + ", " + coin + ", " + money + ", " + updatetime + ", " + dateline + ", "+ fan_id + ", " + zhenqian + ", " + rcard_sn + ");\n";
        mysqlQaDao.execUpdateSql(insertIcardCard);
    }

    /**
     * 创建icoupon_list的sql
     * 必须参数:id,coupon_price,totalnum,usednum,least_price
     * 可选参数:
     * @param generalIcouponListParams
     */

    public void GeneralIcouponList(Map<String, Object> generalIcouponListParams){
        Object icoupon_id = generalIcouponListParams.get("id");
        Object weid = 0;
        if(generalIcouponListParams.containsKey("weid")){
            weid = generalIcouponListParams.get("weid");
        }
        String title = String.valueOf(CommonTools.getRandomInt(8));
        Object card_type = "CASH";
        if(generalIcouponListParams.containsKey("card_type")){
            card_type = generalIcouponListParams.get("card_type");
        }
        Object use_limit = 0;
        if(generalIcouponListParams.containsKey("use_limit")){
            use_limit = generalIcouponListParams.get("use_limit");
        }
        Object coupon_price = generalIcouponListParams.get("coupon_price");
        Object totalnum = generalIcouponListParams.get("totalnum");
        Object usednum = generalIcouponListParams.get("usednum");
        Object least_price = generalIcouponListParams.get("least_price");
        Object coupon_type = 0;
        if(generalIcouponListParams.containsKey("coupon_type")){
            coupon_price = generalIcouponListParams.get("coupon_type");
        }
        Object discount_type = 1;
        if(generalIcouponListParams.containsKey("discount_type")){
            discount_type = generalIcouponListParams.get("discount_type");
        }
        Object discount_price = 50;
        if(generalIcouponListParams.containsKey("discount_price")){
            discount_price = generalIcouponListParams.get("discount_price");
        }

        Object starttime = CommonTools.getTimesnight()-1-24*60*60;
        if(generalIcouponListParams.containsKey("starttime")){
            starttime = generalIcouponListParams.get("starttime");
        }

        Object endtime = CommonTools.getTimesnight()-1-24*60*60;
        if(generalIcouponListParams.containsKey("endtime")){
            endtime = generalIcouponListParams.get("endtime");
        }

        Object create_time = CommonTools.getTimesnight()-1-24*60*60;
        if(generalIcouponListParams.containsKey("create_time")){
            create_time = generalIcouponListParams.get("create_time");
        }

        Object category_id = 0;
        if(generalIcouponListParams.containsKey("category_id")){
            category_id = generalIcouponListParams.get("category_id");
        }

        Object clothes_id = "";
        if(generalIcouponListParams.containsKey("clothes_id")){
            clothes_id = generalIcouponListParams.get("clothes_id");
        }

        Object city_id = 0;
        if(generalIcouponListParams.containsKey("city_id")){
            city_id = generalIcouponListParams.get("city_id");
        }

        Object is_actived = 1;
        if(generalIcouponListParams.containsKey("is_actived")){
            is_actived = generalIcouponListParams.get("is_actived");
        }

        Object user_types = "";
        if(generalIcouponListParams.containsKey("user_types")){
            user_types = generalIcouponListParams.get("user_types");
        }

        Object exclusive_channels = 0;
        if(generalIcouponListParams.containsKey("exclusive_channels")){
            exclusive_channels = generalIcouponListParams.get("exclusive_channels");
        }

        Object title_alias = "title_alias";
        if(generalIcouponListParams.containsKey("title_alias")){
            title_alias = generalIcouponListParams.get("title_alias");
        }

        String insertIcouponList = "INSERT INTO `ims_icoupon_list` (`id`, `weid`, `card_id`, `title`, `sub_title`, `card_type`, `use_limit`, `use_custom_code`, `bind_openid`, `can_share`, `notice`, `description`, `coupon_price`, `totalnum`, `usednum`, `least_price`, `coupon_type`, `discount_type`, `discount_price`, `limit_count`, `starttime`, `endtime`, `content`, `create_time`, `validity_type`, `fixed_term`, `fixed_begin_term`, `is_kefu_faquan`, `coupon_message_id`, `apply_department`, `applicant`, `coupon_group_id`, `exclusive_channels`, `title_alias`, `product_good_id`, `category_id`, `clothes_id`, `channel`, `user_types`, `city_id`, `is_zongbu_chengdan`, `is_actived`, `early_warning`)\n" +
                "VALUES\n" +
                "\t(" + icoupon_id + ", " + weid + ", '', '" + title + "', '', '" + card_type + "', " + use_limit + ", 0, 0, 0, '', NULL, " +  coupon_price + ", " + totalnum + ", " + usednum + ", " + least_price + ", " + coupon_type + ", " + discount_type + ", " + discount_price + ", 0, " + starttime + ", " + endtime +  ", '', " + create_time + ", 0, 0, 0, 0, 1, 'apply_department', 'applicant', 0, '" + exclusive_channels + "', '" + title_alias + "', NULL, '" + category_id + "', '" + clothes_id + "', NULL, '" + user_types + "', " + city_id + ", 0, " + is_actived + ", 0);\n";
        mysqlQaDao.execUpdateSql(insertIcouponList);
    }


    /**
     * 创建ims_icoupon_sncode限制的sql
     * 必须参数:id,cid,sncode,money,updatetime,dateline,fan_id,zhenqian
     * 可选参数:rcard_sn
     * @param generalIcouponSncodeParams
     */
    public void GeneralIcouponSncode(Map<String, Object> generalIcouponSncodeParams){
        long current_time = System.currentTimeMillis();
        Object icard_id = generalIcouponSncodeParams.get("id");
        Object cid = generalIcouponSncodeParams.get("cid");
        Object sncode = generalIcouponSncodeParams.get("sncode");
        Object create_time = CommonTools.getTimesnight()-1;
        Object coupon_type = 0;

        if(generalIcouponSncodeParams.containsKey("coupon_type")){
            coupon_type = generalIcouponSncodeParams.get("coupon_type").toString();
        }
        Object order_sn = "";
        if(generalIcouponSncodeParams.containsKey("order_sn")){
            order_sn = generalIcouponSncodeParams.get("order_sn");
        }
        Object minus_money = "";
        if(generalIcouponSncodeParams.containsKey("minus_money")){
            minus_money = generalIcouponSncodeParams.get("minus_money");
        }
        Object total_money = "";
        if(generalIcouponSncodeParams.containsKey("total_money")){
            total_money = generalIcouponSncodeParams.get("total_money");
        }
        Object charge_id = 0;
        if(generalIcouponSncodeParams.containsKey("charge_id")){
            charge_id = generalIcouponSncodeParams.get("charge_id");
        }
        Object used = 0;
        Object usetime = 0;
        Object lingqu_time = "NULL";
        Object fan_id = "NULl";
        if(generalIcouponSncodeParams.containsKey("fan_id")){
            fan_id = generalIcouponSncodeParams.get("fan_id");
            if(fan_id.equals(0)){
                fan_id = "NULL";
            }
        }
        if(generalIcouponSncodeParams.containsKey("used")){
            used = generalIcouponSncodeParams.get("used");
            if( Integer.parseInt(String.valueOf(used)) == 1){
                usetime = CommonTools.getTimesnight()-1-24*60*60;
                lingqu_time = CommonTools.getTimesnight()-1 - (24 * 60 * 60 * 3);

            }
        }
        Object starttime = "NULL";
        Object endtime = "NULL";


        if(generalIcouponSncodeParams.containsKey("starttime")){
            starttime = generalIcouponSncodeParams.get("starttime");
        }else{
            starttime= current_time/1000 - 24 * 60 * 60 * 5;

        }

        if(generalIcouponSncodeParams.containsKey("endtime")){
            endtime = generalIcouponSncodeParams.get("endtime");
        }else{
            endtime = CommonTools.getTimesnight()-1 + (24 * 60 * 60 * 20);
        }

        String insertIcouponSncode = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `charge_id`,`usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + icard_id + ", " + coupon_type + ", " + cid + ", '" + sncode + "', '" + order_sn + "', NULL, '" + minus_money + "', '" + total_money + "', " + used + ", 0, " + charge_id + "," + usetime + ", " + create_time +", " + fan_id + ", " +  starttime + ", " + endtime + ", " + lingqu_time + ", NULL, '2015-03-14 14:33:03', '2015-03-14 14:33:03');\n";
        mysqlQaDao.execUpdateSql(insertIcouponSncode);
    }

    public void GeneralPfCharge(Map <String, Object> generalPfCharge){
        long current_time = System.currentTimeMillis();
        Object business_id = 11;
        Object pf_charge_id = generalPfCharge.get("id");
        if(generalPfCharge.containsKey("business_id")){
            business_id = generalPfCharge.get("business_id");
        }
        Object type = 0;
        if(generalPfCharge.containsKey("type")){
            type = generalPfCharge.get("type");
        }
        Object fan_id = generalPfCharge.get("fan_id");
        Object fee = 0.00;
        if(generalPfCharge.containsKey("fee")){
            fee = generalPfCharge.get("fee");
        }
        Object coupon_fee = 0.00;
        if(generalPfCharge.containsKey("coupon_fee")){
            coupon_fee = generalPfCharge.get("coupon_fee");
        }
        Object ecard_fee = 0.00;
        if(generalPfCharge.containsKey("ecard_fee")){
            ecard_fee = generalPfCharge.get("ecard_fee");
        }
        Object icard_fee = 0.00;
        if(generalPfCharge.containsKey("icard_fee")){
            icard_fee = generalPfCharge.get("icard_fee");
        }
        Object transfer_fee = 0.00;
        if(generalPfCharge.containsKey("transfer_fee")){
            transfer_fee = generalPfCharge.get("transfer_fee");
        }
        Object pay_fee = 0.00;
        if(generalPfCharge.containsKey("pay_fee")){
            pay_fee = generalPfCharge.get("pay_fee");
        }
        Object paylog_id = 0;
        if(generalPfCharge.containsKey("paylog_id")){
            paylog_id = generalPfCharge.get("paylog_id");
        }
        Object status = 0;
        if(generalPfCharge.containsKey("status")){
            status = generalPfCharge.get("status");
        }
        Object user_type = 0;
        if(generalPfCharge.containsKey("user_type")){
            user_type = generalPfCharge.get("user_type");
        }
        Object create_time = current_time/1000 - 2 * 60 * 60;
        if(generalPfCharge.containsKey("create_time")){
            create_time = generalPfCharge.get("create_time");
        }
        Object update_time = current_time/1000 - 2 * 60 * 60;
        if(generalPfCharge.containsKey("update_time")){
            update_time = generalPfCharge.get("update_time");
        }

        String insertPfCharge = "INSERT INTO `pf_charge` (`id`, `business_id`, `type`, `channel`, `fan_id`, `fee`, `coupon_fee`, `ecard_fee`, `icard_fee`, `transfer_fee`, `pay_fee`, `activity_fee`, `paylog_id`, `status`, `user_type`, `create_time`, `update_time`, `remark`)\n" +
                "VALUES\n" +
                "\t(" + pf_charge_id + ", " + business_id + ", " + type + ", 0, " + fan_id + ", " + fee + ", " + coupon_fee + ", " + ecard_fee + ", " + icard_fee + ", " + transfer_fee + ", " + pay_fee + ", 0.00, " + paylog_id + ", " + status + ", " + user_type + ", " + create_time + ", " + update_time + ", '');\n";
        mysqlQaDao.execUpdateSql(insertPfCharge);
    }


    public void GeneralPfDetailCharge(Map <String, Object> generalPfDetailCharge){
        long current_time = System.currentTimeMillis();
        Object business_id = 11;
        Object pf_charge_detail_id = generalPfDetailCharge.get("id");
        if(generalPfDetailCharge.containsKey("business_id")){
            business_id = generalPfDetailCharge.get("business_id");
        }
        Object business_order = 0;
        if(generalPfDetailCharge.containsKey("business_order")){
            business_order = generalPfDetailCharge.get("business_order");
        }
        Object fan_id = generalPfDetailCharge.get("fan_id");
        Object fee = 0.00;
        if(generalPfDetailCharge.containsKey("fee")){
            fee = generalPfDetailCharge.get("fee");
        }
        Object coupon_fee = 0.00;
        if(generalPfDetailCharge.containsKey("coupon_fee")){
            coupon_fee = generalPfDetailCharge.get("coupon_fee");
        }
        Object ecard_fee = 0.00;
        if(generalPfDetailCharge.containsKey("ecard_fee")){
            ecard_fee = generalPfDetailCharge.get("ecard_fee");
        }
        Object icard_fee = 0.00;
        if(generalPfDetailCharge.containsKey("icard_fee")){
            icard_fee = generalPfDetailCharge.get("icard_fee");
        }
        Object transfer_fee = 0.00;
        if(generalPfDetailCharge.containsKey("transfer_fee")){
            transfer_fee = generalPfDetailCharge.get("transfer_fee");
        }
        Object pay_fee = 0.00;
        if(generalPfDetailCharge.containsKey("pay_fee")){
            pay_fee = generalPfDetailCharge.get("pay_fee");
        }
        Object charge_id = 0;
        if(generalPfDetailCharge.containsKey("charge_id")){
            charge_id = generalPfDetailCharge.get("charge_id");
        }
        Object status = 0;
        if(generalPfDetailCharge.containsKey("status")){
            status = generalPfDetailCharge.get("status");
        }
        Object create_time = current_time/1000 - 2 * 60 * 60;
        if(generalPfDetailCharge.containsKey("create_time")){
            create_time = generalPfDetailCharge.get("create_time");
        }
        Object update_time = current_time/1000 - 2 * 60 * 60;
        if(generalPfDetailCharge.containsKey("update_time")){
            update_time = generalPfDetailCharge.get("update_time");
        }

        String insertPfDetailCharge = "INSERT INTO `pf_charge_detail` (`id`, `business_id`, `business_order`, `fan_id`, `fee`, `coupon_fee`, `ecard_fee`, `icard_fee`, `transfer_fee`, `pay_fee`, `charge_id`, `status`, `create_time`, `update_time`, `remark`)\n" +
                "VALUES\n" +
                "\t(" + pf_charge_detail_id + ", " + business_id + ", " + business_order + ", " + fan_id + ", " + fee + ", " + coupon_fee + ", " + ecard_fee + ", " + icard_fee + ", " + transfer_fee + ", " + pay_fee + ", " + charge_id + ", " + status + ", " + create_time + ", " + update_time + ", '');\n";
        mysqlQaDao.execUpdateSql(insertPfDetailCharge);
    }

    public void GeneralImsPaylog(Map <String, Object> generalImsPaylog){
        Object plid = generalImsPaylog.get("plid");
        Object type = 0;
        if(generalImsPaylog.containsKey("type")){
            type = generalImsPaylog.get("type");
        }
        Object weid = 0;
        if(generalImsPaylog.containsKey("weid")){
            weid = generalImsPaylog.get("weid");
        }
        Object fan_id = generalImsPaylog.get("fan_id");
        Object openid = "NULL";
        if(generalImsPaylog.containsKey("openid")){
            openid = generalImsPaylog.get("openid");
        }
        Object tid = 0.00;
        if(generalImsPaylog.containsKey("tid")){
            tid = generalImsPaylog.get("tid");
        }        Object fee = 0.00;
        if(generalImsPaylog.containsKey("fee")){
            fee = generalImsPaylog.get("fee");
        }
        Object courier_id = "NULL";
        if(generalImsPaylog.containsKey("courier_id")){
            courier_id = generalImsPaylog.get("courier_id");
        }

        Object status = 0;
        if(generalImsPaylog.containsKey("status")){
            status = generalImsPaylog.get("status");
        }
        Object createtime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalImsPaylog.containsKey("createtime")){
            createtime = generalImsPaylog.get("createtime");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalImsPaylog.containsKey("update_at")){
            update_at = generalImsPaylog.get("update_at");
        }

        String insertImsPayLog = "INSERT INTO `ims_paylog` (`plid`, `type`, `weid`, `openid`, `tid`, `fee`, `status`, `api_status`, `module`, `tag`, `createtime`, `fan_id`, `worker_id`, `courier_id`, `activity_info_id`, `updated_at`, `corp_id`)\n" +
                "VALUES\n" +
                "\t(" + plid + ", '" + type + "', " + weid + ", " + openid + ", '" + tid + "', " + fee + ", " + status + ", NULL, 'washing', '', '" + createtime + "', " + fan_id + ", NULL, " + courier_id + ", 0, '" + update_at + "', NULL);\n";

         mysqlQaDao.execUpdateSql(insertImsPayLog);
    }

    public void GeneralPfOrderDetail(Map <String, Object> generalPforderDetailParam){
        Object id = generalPforderDetailParam.get("id");
        Object order_id = 0;
        if(generalPforderDetailParam.containsKey("order_id")){
            order_id = generalPforderDetailParam.get("order_id");
        }
        Object cloth_id = 0;
        if(generalPforderDetailParam.containsKey("cloth_id")){
            cloth_id = generalPforderDetailParam.get("cloth_id");
        }
        Object cloth_order_id = generalPforderDetailParam.get("cloth_order_id");
        Object cloth_name = "NULL";
        if(generalPforderDetailParam.containsKey("cloth_name")){
            cloth_name = generalPforderDetailParam.get("cloth_name");
        }
        Object fee = 0.00;
        if(generalPforderDetailParam.containsKey("fee")){
            fee = generalPforderDetailParam.get("fee");
        }
        Object coupon_fee = 0.00;
        if(generalPforderDetailParam.containsKey("coupon_fee")){
            coupon_fee = generalPforderDetailParam.get("coupon_fee");
        }
        Object coupon_status = 1;
        if(generalPforderDetailParam.containsKey("coupon_status")){
            coupon_status = generalPforderDetailParam.get("coupon_status");
        }
        Object ecard_fee = 0.00;
        if(generalPforderDetailParam.containsKey("ecard_fee")){
            ecard_fee = generalPforderDetailParam.get("ecard_fee");
        }
        Object ecard_status = 1;
        if(generalPforderDetailParam.containsKey("ecard_status")){
            ecard_status = generalPforderDetailParam.get("ecard_status");
        }
        Object icard_fee = 0.00;
        if(generalPforderDetailParam.containsKey("icard_fee")){
            icard_fee = generalPforderDetailParam.get("icard_fee");
        }
        Object icard_status = 1;
        if(generalPforderDetailParam.containsKey("icard_status")){
            icard_status = generalPforderDetailParam.get("icard_status");
        }
        Object third_fee = 0.00;
        if(generalPforderDetailParam.containsKey("third_fee")){
            third_fee = generalPforderDetailParam.get("third_fee");
        }
        Object third_status = 1;
        if(generalPforderDetailParam.containsKey("third_status")){
            third_status = generalPforderDetailParam.get("third_status");
        }
        Object create_at = CommonTools.getTimesnight()-1-2*60*60;
        if(generalPforderDetailParam.containsKey("create_at")){
            create_at = generalPforderDetailParam.get("create_at");
        }
        Object update_at = CommonTools.getTimesnight()-1-2*60*60;
        if(generalPforderDetailParam.containsKey("update_at")){
            update_at = generalPforderDetailParam.get("update_at");
        }

        String insertPfOrderDetail = "INSERT INTO `pf_order_detail` (`id`, `order_id`, `cloth_id`, `cloth_order_id`, `cloth_name`, `fee`, `coupon_fee`, `coupon_status`, `ecard_fee`, `ecard_status`, `icard_fee`, `icard_status`, `third_fee`, `third_status`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + order_id + ", " + cloth_id + ", " + cloth_order_id + ", '" + cloth_name + "', " + fee + ", " + coupon_fee + ", " + coupon_status + ", " + ecard_fee + ", " + ecard_status + ", " + icard_fee + ", " + icard_status + ", " + third_fee + ", " + third_status + ", " + create_at + ", " + update_at + ");\n";
        mysqlQaDao.execUpdateSql(insertPfOrderDetail);
    }


    public void GeneralVouchers(Map <String, Object> generalVouchersParam){
        Object id = generalVouchersParam.get("id");
        Object direction = 0;
        if(generalVouchersParam.containsKey("direction")){
            direction = generalVouchersParam.get("direction");
        }
        Object zhenqian = 0.00;
        if(generalVouchersParam.containsKey("zhenqian")){
            zhenqian = generalVouchersParam.get("zhenqian");
        }
        Object jiaqian = "NULL";
        if(generalVouchersParam.containsKey("jiaqian")){
            jiaqian = generalVouchersParam.get("jiaqian");
        }
        Object voucherable_id = 0.00;
        if(generalVouchersParam.containsKey("voucherable_id")){
            voucherable_id = generalVouchersParam.get("voucherable_id");
        }
        Object voucherable_type = 0.00;
        if(generalVouchersParam.containsKey("voucherable_type")){
            voucherable_type = generalVouchersParam.get("voucherable_type");
        }
        Object card_id = 0.00;
        if(generalVouchersParam.containsKey("card_id")){
            card_id = generalVouchersParam.get("card_id");
        }
        Object card_type = 0.00;
        if(generalVouchersParam.containsKey("card_type")){
            card_type = generalVouchersParam.get("card_type");
        }
        Object combine_type = 0.00;
        if(generalVouchersParam.containsKey("combine_type")){
            combine_type = generalVouchersParam.get("combine_type");
        }
        Object combine_vouchers_id = 0.00;
        if(generalVouchersParam.containsKey("combine_vouchers_id")){
            combine_vouchers_id = generalVouchersParam.get("combine_vouchers_id");
        }
        Object pf_charge_id = 0.00;
        if(generalVouchersParam.containsKey("pf_charge_id")){
            pf_charge_id = generalVouchersParam.get("pf_charge_id");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalVouchersParam.containsKey("create_at")){
            create_at = generalVouchersParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalVouchersParam.containsKey("update_at")){
            update_at = generalVouchersParam.get("update_at");
        }
        Object relation_id = 0;
        if(generalVouchersParam.containsKey("relation_id")){
            relation_id = generalVouchersParam.get("relation_id");
        }

        Object relation_status = 0;
        if(generalVouchersParam.containsKey("relation_status")){
            relation_status = generalVouchersParam.get("relation_status");
        }

        String insertPfOrderDetail = "INSERT INTO `vouchers` (`id`, `direction`, `zhenqian`, `jiaqian`, `voucherable_id`, `voucherable_type`, `card_id`, `card_type`, `combine_type`, `combine_vouchers_id`, `pf_charge_id`, `created_at`, `updated_at`,`relation_id`, `relation_status`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + direction + ", " + zhenqian + ", " + jiaqian + ", " + voucherable_id + ", '" + voucherable_type + "', " + card_id + ", '" + card_type +"', " + combine_type + ", " + combine_vouchers_id + ", " + pf_charge_id + ", '" + create_at + "', '" + update_at + "'," + relation_id + "," + relation_status + ");\n";
        mysqlQaDao.execUpdateSql(insertPfOrderDetail);
    }

    public void GeneralPaylog(Map<String, Object> generalParams){
        Object id = generalParams.get("id");
        Object type = generalParams.get("type");
        if(generalParams.containsKey("type")){
            type = generalParams.get("type");
        }
        Object tid = "m" + CommonTools.getRandomInt(4) + "p" +CommonTools.getRandomInt(3) +"hlpzmh";
        Object fee = generalParams.get("fee");
        if(generalParams.containsKey("fee")){
            fee = generalParams.get("fee");
        }

        Object status = generalParams.get("status");
        if(generalParams.containsKey("status")){
            status = generalParams.get("status");
        }

        Object module = generalParams.get("module");
        if(generalParams.containsKey("module")){
            module = generalParams.get("module");
        }
        Object create_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParams.containsKey("create_time")){
            create_time = generalParams.get("create_time");
        }
        Object fan_id = 0;
        if(generalParams.containsKey("fan_id")){
            fan_id = generalParams.get("fan_id");
        }
        Object relation_fan_id = 0;
        if(generalParams.containsKey("relation_fan_id")){
            relation_fan_id = generalParams.get("relation_fan_id");
        }
        Object updated_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParams.containsKey("updated_at")){
            updated_at = generalParams.get("updated_at");
        }

        String insertImsPaylog = "INSERT INTO `ims_paylog` (`plid`, `type`, `weid`, `openid`, `tid`, `fee`, `status`, `api_status`, `module`, `tag`, `createtime`, `fan_id`, `relation_fan_id`, `worker_id`, `courier_id`, `activity_info_id`, `total_money`, `updated_at`, `corp_id`)\n" +
                "VALUES\n" +
                "\t(" + id + ", '" + type + "', 0, NULL, '" + tid + "', " + fee + ", " + status + ", NULL, '" + module + "', '', '"+ create_time +"', " + fan_id + ", " + relation_fan_id + ", NULL, NULL, 0, 0.00, '" + updated_at + "', NULL);\n";
        mysqlQaDao.execUpdateSql(insertImsPaylog);
    }


    public void GeneralOrderClothesLists(Map<String, Object> generalParams){
        Object id = generalParams.get("id");
        Object order_id = generalParams.get("order_id");
        Object order_sn = generalParams.get("order_sn");
        Object status = 10;
        if(generalParams.containsKey("status")){
            status = generalParams.get("status");
        }
        Object courier_id = generalParams.get("courier_id");
        Object clothes_id = 7;
        if(generalParams.containsKey("clothes_id")){
            clothes_id = generalParams.get("clothes_id");
        }

        Object clothes_name = "衬衫";
        if(generalParams.containsKey("clothes_name")){
            clothes_name = generalParams.get("clothes_name");
        }
        Object courier_price_id = 233;
        if(generalParams.containsKey("courier_price_id")){
            courier_price_id = generalParams.get("courier_price_id");
        }

        Object courier_price = 12;
        if(generalParams.containsKey("courier_price")){
            courier_price = generalParams.get("courier_price");
        }

        Object created_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParams.containsKey("created_at")){
            created_at = generalParams.get("created_at");
        }

        Object updated_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParams.containsKey("updated_at")){
            updated_at = generalParams.get("updated_at");
        }

        String insertOrderClothesLists = "INSERT INTO `order_clothes_lists` (`id`, `order_id`, `order_sn`, `bag_sn`, `status`, `courier_id`, `outlet_id`, `clothes_id`, `clothes_name`, `courier_price_id`, `outlet_price_id`, `courier_price`, `outlet_price`, `flaw`, `color`, `grid`, `brand`, `wash_result`, `can_rewash`, `can_wash`, `cannot_wash_reason`, `rewash_reason`, `primary_rewash_flaw`, `primary_rewash_operation`, `secondary_rewash_flaw`, `secondary_rewash_operation`, `washing_barcode`, `original_barcode`, `outlet_sort_time`, `outlet_report_time`,  `created_at`, `updated_at`, `rewash`, `type`, `undeal_flaw`, `rewash_operation_id`, `courier_sort_time`, `is_bargain`, `suit_id`, `verify_code`, `undeal_stain_position`, `undeal_stain`, `insurance_id`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + order_id + ", '" + order_sn + "', '', " + status + ", " + courier_id + ", NULL, " + clothes_id + ", '" + clothes_name + "', " + courier_price_id + ", NULL, " + courier_price + ", NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '" + created_at + "', '" + updated_at + "', 0, 'OrderClothesList', NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL);\n";
        mysqlQaDao.execUpdateSql(insertOrderClothesLists);


    }
}


