package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by he_yi on 16/3/31.
 */
public final class CreateOrderByStatus {
    private static GeneralRongChain04Data rongChain04Data = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static int courier_id = CommonTools.get_courierId(mysqlQaDao);
    private static int fan_id = CommonTools.getFanId(mysqlQaDao);
    private static int jiagongdian_id=16;

    private int order_id=0;
    private String order_sn="0";
    private String bagsn = "00041921043";
    private int dispath_id=0;
    private int transTask_id=0;
    private int last_transTask_id=0;
    private int transGroup_id=0;
    private int workingTasks_id=0;
    private int last_workingTasks_id=0;

    public void setCourierId(int id){
        this.courier_id = id;
    }

    public void setFanId(int id){
        this.fan_id = id;
    }

    public void setBagsn(String bagsn){
        this.bagsn = bagsn;
    }

    public int getCourierId(){
        return courier_id;
    }

    public int getFanId(){
        return fan_id;
    }

    public String getBagsn(){
        return bagsn;
    }

    public int getOrderId(){
        return order_id;
    }

    public String getOrderSn(){
        return order_sn;
    }

    public enum orderStatus{
        newOrder(1),
        qu_paidan(2),
        qu_yiqu(3),
        jiagongdian_qianshou(4),
        jiagongdian_fenjian(5),
        jiagongdian_shangjia(6),
        jiagongdian_dabao(7),
        song_paidan(8);
//        song_qianshou(9),
//        kehu_qianshou(10);

        private int value=0;
        private orderStatus(int v){
            this.value = v;
        }

        public int getValue(){
            return value;
        }
    }

    public int getOrderByStatus(orderStatus enum_orderStatus){
        int type = enum_orderStatus.value;
        if (type>0 && type<11){
            createOrder_new();
            if (type == orderStatus.newOrder.getValue()){
                return order_id;
            }

            diaodu_qu_paidan();
            if (type == orderStatus.qu_paidan.getValue()){
                return order_id;
            }

            qu_yiqu();
            if (type == orderStatus.qu_yiqu.getValue()){
                return order_id;
            }

            jiagongdian_qianshou();
            if (type == orderStatus.jiagongdian_qianshou.getValue()){
                return order_id;
            }

            jiagongdian_fenjian();
            if (type == orderStatus.jiagongdian_fenjian.getValue()){
                return order_id;
            }

            jiagongdian_shangjia();
            if (type == orderStatus.jiagongdian_shangjia.getValue()){
                return order_id;
            }

            jiagongdian_dabao();
            if (type == orderStatus.jiagongdian_dabao.getValue()){
                return order_id;
            }

            diaodu_song_paidan();
            if (type == orderStatus.song_paidan.getValue()){
                return order_id;
            }


        }
        return order_id;
    }

    private void createOrder_new(){
        order_id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1;
        order_sn = CommonTools.getOrdersn(String.valueOf(order_id));

        Map<String, Object> orderMap = new HashMap<String, Object>();
        orderMap.put("order_id", order_id);
        orderMap.put("order_sn", order_sn);
        orderMap.put("status", 1);
        orderMap.put("status_delivery", 11);
        orderMap.put("pay_status", 0);
        orderMap.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        orderMap.put("washing_time", "22:00-24:00");
        orderMap.put("old_category_id", 1);
        rongChain04Data.GeneralOrder(orderMap);

        dispath_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao)+1;
        Map<String, Object> dispathMap = new HashMap<String, Object>();
        dispathMap.put("id", dispath_id);
        dispathMap.put("order_id", order_id);
        dispathMap.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        rongChain04Data.GeneralDispatchTask(dispathMap);
    }

    private void diaodu_qu_paidan(){

        String orderSql = "update ims_washing_order set status_delivery=9, courier_qu="+courier_id+
                ", qujian_paidan_time='"+String.valueOf(System.currentTimeMillis()).substring(0,10)+"'"+
                ",diaodu_queren_time='"+String.valueOf(System.currentTimeMillis()).substring(0,10)+"'"+
                " where id="+order_id;
        mysqlQaDao.execUpdateSql(orderSql);

        transTask_id = CommonTools.getLastId("select id from trans_tasks order by id desc limit 1;", mysqlQaDao)+1;
        Map<String, Object> transTasksMap = new HashMap<String, Object>();
        transTasksMap.put("id", transTask_id);
        transTasksMap.put("order_id", order_id);
        transTasksMap.put("order_sn", order_sn);
        transTasksMap.put("from_id", courier_id);
        transTasksMap.put("from_type", "zhongbao");
        rongChain04Data.GeneralTransTasks(transTasksMap);

        transGroup_id = CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao)+1;
        Map<String, Object> transGroupMap = new HashMap<String, Object>();
        transGroupMap.put("id", transGroup_id);
        transGroupMap.put("order_id", order_id);
        transGroupMap.put("ordsn", order_sn);
        transGroupMap.put("current_task_id", transTask_id);
        transGroupMap.put("last_task_id", transTask_id);
        rongChain04Data.GeneralTransGroups(transGroupMap);

        String transTaskSql = "update trans_tasks set trans_group_id="+transGroup_id;
        mysqlQaDao.execUpdateSql(transTaskSql);

        String dispatchSql = "update dispatch_tasks set courier_id="+courier_id+", updated_at='"+CommonTools.getToday("yyyy-MM-dd HH:mm:ss")+"' "+
                " where id="+dispath_id;
        mysqlQaDao.execUpdateSql(dispatchSql);
    }

    private void qu_yiqu(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String orderSql = "update ims_washing_order set totalprice=49, delivery_fee=5, pay_status=1 where id="+order_id;
        mysqlQaDao.execUpdateSql(orderSql);

        String updateOrderSql = "UPDATE `ims_washing_order` SET `bagsn` = '"+bagsn+"', `logistics_remark` = '', `qujian_time` = '"+String.valueOf(System.currentTimeMillis()).substring(0,10)+"', `wuliu_qu_yiqu_time` = '"+String.valueOf(System.currentTimeMillis()).substring(0,10)+"', `status_delivery` = 1, `updated_at` = '"+CommonTools.getToday("yyyy-MM-dd HH:mm:ss")+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(updateOrderSql);

        String updateTransGroupSql = "UPDATE `trans_groups` SET `bagsn` = '"+bagsn+"', `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` ="+transGroup_id;
        mysqlQaDao.execUpdateSql(updateTransGroupSql);

        String sql = "UPDATE `trans_tasks` SET `bagsn` = '"+bagsn+"', `status` = 'finished', `finished_at` = '"+nowTime+"', `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+transTask_id;
        mysqlQaDao.execUpdateSql(sql);


        sql = "INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `city_id`, `created_at`, `dead_line`, `direction`, `from_id`, `from_type`, " +
                "`order_id`, `ordersn`, `status`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) " +
                "VALUES ('"+bagsn+"', 1, 1, '"+nowTime+"', '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",1)+"', 'send', "+courier_id+", 'zhongbao', " +
                order_id+" , '"+order_sn+"', 'started', 'outlet', "+transGroup_id+", 1, '"+nowTime+"', 'unwashed')";
        mysqlQaDao.execUpdateSql(sql);
        last_transTask_id = CommonTools.getLastId("select id from trans_tasks where order_id="+order_id, mysqlQaDao);

        sql="UPDATE `trans_tasks` SET `next_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` ="+transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `city_id`, `created_at`, `direction`, `from_type`, `order_id`, `ordersn`, `status`, `to_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) " +
                "VALUES ('"+bagsn+"', 1, 1, '"+nowTime+"', 'get', 'outlet', "+order_id+", '"+order_sn+"', 'started', "+courier_id+", 'zhongbao', "+transGroup_id+", 1, '"+nowTime+"', 'unwashed')";
        mysqlQaDao.execUpdateSql(sql);
        transTask_id = last_transTask_id;
        last_transTask_id = CommonTools.getLastId("select id from trans_tasks where order_id="+order_id, mysqlQaDao);

        sql = "UPDATE `trans_tasks` SET `next_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql = "UPDATE `trans_groups` SET `current_task_id` = "+last_transTask_id+", `last_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` ="+transGroup_id;
        mysqlQaDao.execUpdateSql(sql);

        sql = "UPDATE `dispatch_tasks` SET `status` = 'finished', `finished_at` = '"+nowTime+"', `updated_at` = '"+nowTime+"' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` = "+dispath_id;
        mysqlQaDao.execUpdateSql(sql);
    }

    private void jiagongdian_qianshou(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");

        String sql = "UPDATE `trans_tasks` SET `from_type` = 'jiagongdian', `from_id` = "+jiagongdian_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` ="+last_transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `trans_tasks` SET `to_type` = 'jiagongdian', `to_id` = "+jiagongdian_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `trans_tasks` SET `status` = 'finished', `finished_at` = '"+nowTime+"', `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+last_transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `trans_tasks` SET `status` = 'finished', `finished_at` = '"+nowTime+"', `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `ims_washing_order` SET `qianshoudian_id` = "+jiagongdian_id+", `jiagongdian_qianshou_time` = "+nowUnix+", `status_delivery` = 4, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `working_tasks` (`category_id`, `city_id`, `created_at`, `finished_at`, `order_id`, `ordersn`, `outlet_id`, `status`, `updated_at`, `uploaded_at`, `working_type`) " +
                "VALUES (1, 1, '"+nowTime+"', '"+nowTime+"', "+order_id+", '"+order_sn+"', 16, 'finished', '"+nowTime+"', '"+nowTime+"', 'qianshou')";
        mysqlQaDao.execUpdateSql(sql);
        workingTasks_id = CommonTools.getLastId("select id from working_tasks where order_id="+order_id, mysqlQaDao);

        sql="INSERT INTO `working_tasks` (`category_id`, `city_id`, `created_at`, `order_id`, `ordersn`, `status`, `updated_at`, `working_type`) " +
                "VALUES (1, 1, '"+nowTime+"', "+order_id+", '"+order_sn+"', 'started', '"+nowTime+"', 'fenjian')";
        mysqlQaDao.execUpdateSql(sql);
        last_workingTasks_id = CommonTools.getLastId("select id from working_tasks where order_id="+order_id, mysqlQaDao);

//        sql="UPDATE `trans_groups` SET `last_process_deadline` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `full_process_deadline` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` ="+transGroup_id;
//        mysqlQaDao.execUpdateSql(sql);

        sql = "UPDATE `working_tasks` SET `dead_line` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `updated_at` = '"+nowTime+"' WHERE `working_tasks`.`id` ="+last_transTask_id;
        mysqlQaDao.execUpdateSql(sql);

    }

    private void jiagongdian_fenjian(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");

        String sql = "UPDATE `ims_washing_order` SET `jiagongdian_id` = "+jiagongdian_id+", `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `ims_washing_order_bags_clothing` (`bagsn`, `cloth_id`, `created_at`, `dsdj`, `order_id`, `ordersn`, `pp`, `real_created_at`, `shdid`, `shmxid`, `sjjg`, `updated_at`, `xc`, `xhxg`, `ywcl`, `ywdc`, `ywmc`, `ywtmh`, `ywwg`, `ywys`) " +
                "VALUES ('"+bagsn+"', 3, '"+nowTime+"', 39.0, "+order_id+", '"+order_sn+"', '', '"+nowTime+"', 'e10999', 42803, 19.0, '"+nowTime+"', '', '', 'e袋洗', '普通', '风衣', '"+nowUnix+"', '', '靛青')";
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `ims_washing_order` SET `actual_price` = 24.0, `washing_duration` = 24, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql = "UPDATE `ims_washing_order` SET `jiagongdian_fenjian_time` = "+nowUnix+", `status_delivery` = 5, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `working_tasks` SET `status` = 'finished', `finished_at` = '"+nowTime+"', `outlet_id` = 458, `updated_at` = '"+nowTime+"' WHERE `working_tasks`.`id` = "+last_workingTasks_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `working_tasks` (`category_id`, `city_id`, `created_at`, `order_id`, `ordersn`, `outlet_id`, `status`, `updated_at`, `working_type`) " +
                "VALUES (1, 1, '"+nowTime+"', "+order_id+", '"+order_sn+"', 458, 'started', '"+nowTime+"', 'dabao')";
        mysqlQaDao.execUpdateSql(sql);
        workingTasks_id = last_workingTasks_id;
        last_workingTasks_id = CommonTools.getLastId("select id from working_tasks where order_id="+order_id, mysqlQaDao);

//        sql = "UPDATE `trans_groups` SET `last_process_deadline` = '2016-04-01 15:00:00', `full_process_deadline` = '', `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id`"+transGroup_id;

//                sql="UPDATE `working_tasks` SET `dead_line` = '2016-04-01 17:59:28', `updated_at` = '2016-03-31 17:59:28' WHERE `working_tasks`.`id` = "+last_workingTasks_id;

    }

    private void jiagongdian_shangjia(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String sql = "UPDATE `ims_washing_order` SET `jiagongdian_shangjia_time` = "+nowUnix+", `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` = "+order_id;
        mysqlQaDao.execUpdateSql(sql);
    }

    private void jiagongdian_dabao(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");

        String sql="UPDATE `ims_washing_order` SET `jiagongdian_shangjia_time` = "+nowUnix+", `status_delivery` = 6, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` ="+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql = "UPDATE `working_tasks` SET `status` = 'finished', `finished_at` = '"+nowTime+"', `updated_at` = '"+nowTime+"' WHERE `working_tasks`.`id` = "+last_workingTasks_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `ims_washing_order` SET `send_date` = '"+CommonTools.getToday("yyyy-MM-dd")+"', `send_time` = '22:00-23:00', `song_from_time_mod` = 118, `song_to_time_mod` = 119, `song_week_nr` = 2413, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` ="+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `trans_tasks` SET `dead_line` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` = "+last_transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `dispatch_tasks` (`category_id`, `created_at`, `dispatch_type`, `order_id`, `type`, `updated_at`) " +
                "VALUES (1, '"+nowTime+"', 1, "+order_id+", 'DispatchTask', '"+nowTime+"')";
        mysqlQaDao.execUpdateSql(sql);
        dispath_id = CommonTools.getLastId("select id from dispatch_tasks where order_id="+order_id, mysqlQaDao);

        sql="UPDATE `dispatch_tasks` SET `status` = 'started', `hope_time` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `from_type` = 'jiagongdian', `from_id` = 458, `to_type` = 'Address', `to_id` = 595748, `city_id` = 1, `updated_at` = '"+nowTime+"' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` ="+dispath_id;
        mysqlQaDao.execUpdateSql(sql);
    }

    private void diaodu_song_paidan(){
        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0,10);
        String nowTime = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");

        String sql="UPDATE `ims_washing_order` SET `courier_song` = "+courier_id+", `auto_dispatched_song_at` = '"+nowTime+"', `diaodu_song_paidan_time` = "+nowUnix+", `status_delivery` = 15, `updated_at` = '"+nowTime+"' WHERE `ims_washing_order`.`id` ="+order_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `trans_groups` SET `last_process_deadline` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `full_process_deadline` = '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` ="+transGroup_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `city_id`, `created_at`, `dead_line`, `direction`, `from_id`, `from_type`, `order_id`, `ordersn`, `status`, `to_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) " +
                "VALUES ('"+bagsn+"', 1, 1, '"+nowTime+"', '"+CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1)+"', 'send', "+jiagongdian_id+", 'jiagongdian', "+order_id+", '"+order_sn+"', 'started', "+courier_id+", 'zhongbao', "+transGroup_id+", 2, '"+nowTime+"', 'washed')";
        mysqlQaDao.execUpdateSql(sql);
        transTask_id = last_transTask_id;
        last_transTask_id = CommonTools.getLastId("select id from trans_tasks where order_id="+order_id, mysqlQaDao);

        sql="UPDATE `trans_tasks` SET `next_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` ="+transTask_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `city_id`, `created_at`, `direction`, `from_id`, `from_type`, `order_id`, `ordersn`, `status`, `to_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) " +
                "VALUES ('"+bagsn+"', 1, 1, '"+nowTime+"', 'get', "+courier_id+", 'zhongbao', "+order_id+", '"+order_sn+"', 'started', "+jiagongdian_id+", 'jiagongdian', "+transGroup_id+", 2, '"+nowTime+"', 'washed')";
        mysqlQaDao.execUpdateSql(sql);
        transTask_id = last_transTask_id;
        last_transTask_id = CommonTools.getLastId("select id from trans_tasks where order_id="+order_id, mysqlQaDao);

        sql="UPDATE `trans_tasks` SET `next_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` ="+transTask_id;
        mysqlQaDao.execUpdateSql(sql);


        sql="INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `city_id`, `created_at`, `dead_line`, `direction`, `from_id`, `from_type`, `order_id`, `ordersn`, `status`, `to_address_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) " +
                "VALUES ('"+bagsn+"', 1, 1, '"+nowTime+"', '"+nowTime+"', 'send', "+courier_id+", 'zhongbao', "+order_id+", '"+order_sn+"', 'init', 595748, 'customer', "+transGroup_id+", 3, '"+nowTime+"', 'washed')";
        mysqlQaDao.execUpdateSql(sql);
        transTask_id = last_transTask_id;
        last_transTask_id = CommonTools.getLastId("select id from trans_tasks where order_id="+order_id, mysqlQaDao);

        sql="UPDATE `trans_tasks` SET `next_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_tasks`.`id` ="+transTask_id;
        mysqlQaDao.execUpdateSql(sql);


        sql="UPDATE `trans_groups` SET `last_task_id` = "+last_transTask_id+", `updated_at` = '"+nowTime+"' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` = "+transGroup_id;
        mysqlQaDao.execUpdateSql(sql);

        sql="UPDATE `dispatch_tasks` SET `status` = 'dispatched', `courier_id` = "+courier_id+", `updated_at` = '"+nowTime+"' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` = "+dispath_id;
        mysqlQaDao.execUpdateSql(sql);
    }




}
