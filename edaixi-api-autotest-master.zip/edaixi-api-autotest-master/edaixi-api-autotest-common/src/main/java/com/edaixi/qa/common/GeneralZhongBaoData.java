package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

/**
 * Created by ningzhao on 16-2-15.
 */
public class GeneralZhongBaoData {

    Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public final void init(){
        
    }

    public static String getYestoryDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,-1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    public static String getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrow = sdf.format(calendar.getTime());
        return tomorrow;
    }

    public static  String getTodayDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        return date;
    }


    public void GeneralBonusGroups(MysqlQaDao mysqlQaDao,Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object city_id = generalParam.get("city_id");
        Object role = generalParam.get("role");
        Object status = generalParam.get("status");
        Object effect_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("effect_time")){
            effect_time = generalParam.get("effect_time");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        String bonus_group_info = "INSERT INTO `bonus_groups` (`id`, `city_id`, `role`, `status`, `effect_time`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + city_id + ", '" + role + "', " + status + ", '" + effect_time + "', '" + create_at + "', '" + update_at + "');\n";
        mysqlQaDao.execUpdateSql(bonus_group_info);
    }

    public void GeneralCardBonus(MysqlQaDao mysqlQaDao,Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object amount = generalParam.get("amount");
        Object pay_type = "%";
        Object effect_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("effect_time")){
            effect_time = generalParam.get("effect_time");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        Object bonus_group_id = generalParam.get("bonus_group_id");
        Object pay_base = generalParam.get("pay_base");
        String card_bonus_info = "INSERT INTO `card_bonus` (`id`, `city_id`, `role`, `recharge_list_id`, `amount`, `pay_type`, `effect_time`, `created_at`, `updated_at`, `bonus_group_id`, `pay_base`)\n" +
                "VALUES\n" +
                "\t(" + id + ", NULL, NULL, NULL, " + amount + ", '" + pay_type + "', '" + effect_time + "', '" + create_at + "', '" + update_at + "', " + bonus_group_id + ", '" + pay_base + "');\n";
        mysqlQaDao.execUpdateSql(card_bonus_info);
    }

    public void GeneralTransferBonus(MysqlQaDao mysqlQaDao, Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object operation_type = generalParam.get("operation_type");
        Object amount = generalParam.get("amount");
        Object pay_type = "元";
        if(generalParam.containsKey("pay_type")){
            pay_type = generalParam.get("pay_type");
        }
        Object effect_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("effect_time")){
            effect_time = generalParam.get("effect_time");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        Object category_id = generalParam.get("category_id");
        Object bonus_group_id = generalParam.get("bonus_group_id");
        Object status = 1;
        if(generalParam.containsKey("status")){
            status = generalParam.get("status");
        }
        String transfer_bonus_info = "INSERT INTO `transfer_bonus` (`id`, `role`, `operation_type`, `amount`, `pay_type`, `effect_time`, `created_at`, `updated_at`, `city_id`, `category_id`, `bonus_group_id`, `status`)\n" +
                "VALUES\n" +
                "\t(" + id + ", NULL, '" + operation_type + "', " + amount + ", '" + pay_type + "', '" + effect_time + "', '" + create_at + "', '" + update_at + "', NULL, " + category_id + ", " + bonus_group_id + ", " + status + ");\n";
        mysqlQaDao.execUpdateSql(transfer_bonus_info);
    }

    public void GeneralRewardBonus(MysqlQaDao mysqlQaDao, Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object operation_type = generalParam.get("operation_type");
        Object amount = generalParam.get("amount");
        Object pay_type = "元";
        if(generalParam.containsKey("pay_type")){
            pay_type = generalParam.get("pay_type");
        }
        Object rating = 5;
        if(generalParam.containsKey("rating")){
            rating = generalParam.get("rating");
        }
        Object effect_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("effect_time")){
            effect_time = generalParam.get("effect_time");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        Object category_id = generalParam.get("category_id");
        Object bonus_group_id = generalParam.get("bonus_group_id");
        Object status = 1;
        if(generalParam.containsKey("status")){
            status = generalParam.get("status");
        }
        String reward_bonus_info = "INSERT INTO `reward_bonus` (`id`, `role`, `operation_type`, `amount`, `pay_type`, `rating`, `effect_time`, `created_at`, `updated_at`, `city_id`, `category_id`, `status`, `bonus_group_id`)\n" +
                "VALUES\n" +
                "\t(" + id + ", NULL, '" + operation_type + "', " + amount + ", '" + pay_type + "', " + rating + ", '" + effect_time + "', '" + create_at + "', '" + update_at + "', NULL, " + category_id + ", " + status + ", " + bonus_group_id + ");\n";
        mysqlQaDao.execUpdateSql(reward_bonus_info);
    }

    public void GeneralTimeTransferBonus(MysqlQaDao mysqlQaDao, Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object amount = generalParam.get("amount");
        Object start_time = generalParam.get("start_time");
        Object end_time = generalParam.get("end_time");
        Object pay_type = "元";
        if(generalParam.containsKey("pay_type")){
            pay_type = generalParam.get("pay_type");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        Object category_id = generalParam.get("category_id");
        Object bonus_group_id = generalParam.get("bonus_group_id");

        String time_transfer_bonus_info = "INSERT INTO `time_transfer_bonus` (`id`, `amount`, `bonus_group_id`, `category_id`, `pay_type`, `start_time`, `end_time`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + amount + ", " + bonus_group_id +  ", " + category_id +  ", '" + pay_type + "', " + start_time + ", " + end_time +  ", '" + create_at + "', '" + update_at + "');\n";
        mysqlQaDao.execUpdateSql(time_transfer_bonus_info);
    }

    public void GeneralPromotionBonus(MysqlQaDao mysqlQaDao, Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object amount = generalParam.get("amount");
        Object pay_limit = generalParam.get("pay_limit");
        Object pay_type = "%";
        Object pay_base = "真钱";
        if(generalParam.containsKey("pay_base")){
            pay_base = generalParam.get("pay_base");
        }
        Object effect_time = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("effect_time")){
            effect_time = generalParam.get("effect_time");
        }
        Object create_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("create_at")){
            create_at = generalParam.get("create_at");
        }
        Object update_at = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        if(generalParam.containsKey("update_at")){
            update_at = generalParam.get("update_at");
        }
        Object category_id = generalParam.get("category_id");
        Object bonus_group_id = generalParam.get("bonus_group_id");

        String promotion_bonus_info = "INSERT INTO `promotion_bonus` (`id`, `city_id`, `role`, `category_id`, `pay_limit`, `amount`, `pay_type`, `effect_time`, `created_at`, `updated_at`, `bonus_group_id`, `pay_base`)\n" +
                "VALUES\n" +
                "\t(" + id + ", NULL, NULL, '" + category_id + "', '" + pay_limit +  "', " + amount + ", '" + pay_type + "', '" + effect_time + "', '" + create_at + "', '" + update_at + "', " + bonus_group_id +  ", '" + pay_base + "');\n";
        mysqlQaDao.execUpdateSql(promotion_bonus_info);
    }


}


