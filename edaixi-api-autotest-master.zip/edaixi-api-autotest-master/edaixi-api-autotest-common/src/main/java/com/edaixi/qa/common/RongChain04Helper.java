package com.edaixi.qa.common;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by he_yi on 16/11/10.
 */
public class RongChain04Helper {

    public static String getCreateDispatchTasksSql(Map<String, Object> fieldMap){
        return getCreateSql("dispatch_tasks", fieldMap);
    }
    public static String getCreateOrderSql(Map<String, Object> fieldMap){
        return getCreateSql("ims_washing_order", fieldMap);
    }

    public static String getCreateTransTasks(Map<String, Object> fieldMap){
        return getCreateSql("trans_tasks", fieldMap);
    }

    public static String getCreateTransTransGroups(Map<String, Object> fieldMap){
        return getCreateSql("trans_groups",  fieldMap);
    }

    private static String getCreateSql(String tableName, Map<String, Object> fieldMap){
        String sql = "INSERT INTO `"+tableName+"`(";
        String sql2 = "VALUES(";
        for (Map.Entry<String, Object> entry:fieldMap.entrySet()){
            String key = entry.getKey();
            Object value = entry.getValue();
            String fvalue = "";
            if ( value instanceof String && !value.equals("NULL")){
                if ( !((String) value).startsWith("'")  ){
                        value = "'"+value+"'";
                }

            }
            fvalue = String.valueOf(value);


            sql += "`"+key+"`"+", ";
            sql2 += fvalue+", ";
        }

        sql = sql.substring(0, sql.length()-2);
        sql = sql+")";
        sql2 = sql2.substring(0, sql2.length()-2);
        sql2 = sql2+");";
        return sql+sql2;
    }



    public static Map<String, Object> getTransTransGroupsField(){
        Map<String, Object> map = new HashMap<>();
        map.put("order_id", 1);
        map.put("ordersn", "1134123441234");
        map.put("bagsn", "NULL");
        map.put("current_task_id", 0);
        map.put("last_task_id", 0);
        map.put("order_type", "NULL");
        map.put("order_status", 1);
        map.put("status_delivery", "NULL");
        map.put("type", "TransGroup");
        map.put("created_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("updated_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("propose_outlet_id", "NULL");
        map.put("dispatch_task_id", 0);

        return map;
    }

    public static Map<String, Object> getTransTasksTableField(){
        Map<String, Object> map = new HashMap<>();
        map.put("bagsn", "NULL");
        map.put("from_id", "NULL");
        map.put("from_type", "zhongbao");
        map.put("from_address_id", "NULL");
        map.put("to_id", "NULL");
        map.put("to_type", "customer");
        map.put("next_task_id", "NULL");
        map.put("transfer_task_id", "NULL");
        map.put("transferred_by", "NULL");
        map.put("dead_line", "2016-05-15 12:00:00");
        map.put("prority", "NULL");
        map.put("status", "started");
        map.put("direction", "get");
        map.put("finished_at", "NULL");
        map.put("created_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("updated_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("category_id", 1);
        map.put("ordersn", "16110738043841");
        map.put("washing_status", "unwashed");
        map.put("order_id", 1);
        map.put("trans_group_id", 0);
        map.put("trans_ttl", 0);
        map.put("trans_type", 0);

        return map;
    }

    public static Map<String, Object> getDispatchTasksTableField(){
        Map<String, Object> map = new HashMap<>();
        map.put("order_id", 1);
        map.put("status", "started");
        map.put("from_type", "jiagongdian");
        map.put("from_id", "NULL");
        map.put("to_type", "Address");
        map.put("to_id", 595949);
        map.put("dispatch_type", 0);
        map.put("courier_id", 1);
        map.put("hope_time", CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        map.put("finished_at", "NULL");
        map.put("category_id", 1);
        map.put("created_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("updated_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("type", "DispatchTask");
        map.put("ordersn", "NULL");
        map.put("city_id", 1);

        return map;
    }

    public static Map<String, Object> getOrderTableBasicField(){
        Map<String, Object> map = new HashMap<>();
        map.put("from_user", "");
        map.put("user_type", 7);
        map.put("ordersn", "16110738043841");
        map.put("bagsn", "");
        map.put("totalnum", 1);
        map.put("totalprice", 0);
        map.put("delivery_fee", 0);
        map.put("coupon_sn", "");
        map.put("coupon_paid", 0.00);
        map.put("money_paid", 0.00);
        map.put("receivables_paid", 0.00);
        map.put("status", 1);
        map.put("status_delivery", 11);
        map.put("back_reason", "");
        map.put("logistics_remark", "NULL");
        map.put("pay_status", "0");
        map.put("paytype", 3);
        map.put("remark", "接口测试");
        map.put("washing_date", CommonTools.getToday("yyyy-MM-dd"));
        map.put("washing_time", "22:00-24:00");
        map.put("send_date", "");
        map.put("send_time", "");
        map.put("username", "接口测试用户");
        map.put("tel", "21111119017");
        map.put("city", "北京");
        map.put("area", "朝阳区");
        map.put("address", "大山子");
        map.put("city_song", "北京");
        map.put("area_song", "朝阳区");
        map.put("address_song", "大山子");
        map.put("courier_qu", 1);
        map.put("courier_song", 0);
        map.put("shoukuan_kuaidi", 0);
        map.put("shoukuan_kuaidi_time", "NULL");
        map.put("shoukuan_store", 0);
        map.put("shoukuan_store_time", "NULL");
        map.put("shoukuan_caiwu", 0);
        map.put("shoukuan_caiwu_time", "NULL");
        map.put("createtime", CommonTools.timeStrToUnix("yyyy-MM-dd HH:mm:ss",  CommonTools.getToday("yyyy-MM-dd HH:mm:ss")));
        map.put("qujian_paidan_time", 0);
        map.put("qujian_time", 0);
        map.put("songhui_paidan_time", 0);
        map.put("songhui_time", 0);
        map.put("is_xianxia", 0);
        map.put("kehu_song_shouyidian_time", "NULL");
        map.put("shouyidian_qu_id", "NULL");
        map.put("dingdan_quxiao_time", "NULL");
        map.put("jiagongdian_qianshou_time", "NULL");
        map.put("jiagongdian_id", "NULL");
        map.put("wuliu_song_qianshou_time", "NULL");
        map.put("shouyidian_song_qianshou_time", "NULL");
        map.put("shouyidian_song_id", "NULL");
        map.put("kehu_qianshou_time", "NULL");
        map.put("wuliu_qu_tuihui_time", "NULL");
        map.put("wuliu_song_tuihui_time", "NULL");
        map.put("wuliu_qu_yiqu_time", "NULL");
        map.put("jiagongdian_fenjian_time", "NULL");
        map.put("jiagongdian_shangjia_time", "NULL");
        map.put("back_reason_qu", "NULL");
        map.put("back_reason_song", "NULL");
        map.put("created_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("updated_at", CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        map.put("caiwu_status", 0);
        map.put("diaodu_queren_time", CommonTools.timeStrToUnix("yyyy-MM-dd HH:mm:ss",  CommonTools.getToday("yyyy-MM-dd HH:mm:ss")));
        map.put("actual_price", 0);
        map.put("xianjin_shoukuan", 0);
        map.put("diaodu_song_paidan_time", "NULL");
        map.put("is_fanxi", 0);
        map.put("yuandingdan_id", 0);
        map.put("fanxidan_id", 0);
        map.put("fan_id", 1);
        map.put("order_commented_at", "NULL");
        map.put("good_id", 18);
        map.put("qu_week_nr", 2402);
        map.put("qu_from_time_mod", 138);
        map.put("qu_to_time_mod", 139);
        map.put("song_week_nr", "NULL");
        map.put("song_from_time_mod", "NULL");
        map.put("song_to_time_mod", "NULL");
        map.put("qianshoudian_id", 0);
        map.put("address_qu_id", "NULL");
        map.put("address_song_id", "NULL");
        map.put("auto_dispatched_qu_at", "NULL");
        map.put("auto_dispatched_song_at", "NULL");
        map.put("last_six_ordersn", "043841");
        map.put("category_id", 1);
        map.put("cannot_wash", 0);
        map.put("cannot_wash_reason", "NULL");
        map.put("client_id", "NULL");
        map.put("discount", 0.00);
        map.put("original_order_id", "NULL");
        map.put("fanxi_count", "NULL");

        return map;
    }
}
