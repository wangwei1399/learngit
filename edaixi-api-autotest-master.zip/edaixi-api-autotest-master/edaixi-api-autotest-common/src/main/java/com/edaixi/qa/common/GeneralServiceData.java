package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16-2-15.
 */
public class GeneralServiceData {

    private Map<String, Object> generalOrderParams = null;
    private Map<String, Object> generalCouriersParams = null;
    private Map<String, Object> generalDispatchTaskParams = null;


    Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public final void init(){
        this.generalOrderParams = new HashMap<String, Object>();
        this.generalCouriersParams = new HashMap<String, Object>();
        this.generalDispatchTaskParams = new HashMap<String, Object>();

    }

    public static String getYestoryDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,-1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    public static String getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrow = sdf.format(calendar.getTime());
        return tomorrow;
    }

    public static  String getTodayDate(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = sdf.format(new Date());
        return date;
    }


    public void GeneralServiceCityBanner(Map<String, Object> generalParams,  String dbData){
        if((dbData.isEmpty())){
            dbData = "jdbc.properties";
        }
        MysqlQaDao mysqlQaDao = new MysqlQaDao(dbData);
        String cityBannerId = generalParams.get("cityBannerId").toString();
        Object page = generalParams.get("page");
        Object isAvailable = generalParams.get("isAvailable");
        Object bannerChannel = generalParams.get("bannerChannel");
        Object updateAt = generalParams.get("updateAt");
        Object cityId = (generalParams.get("cityId").equals(""))?'1':generalParams.get("cityId");
        Object startTime = generalParams.get("startTime").toString();
        Object endTime = generalParams.get("endTime").toString();
        Object dataTime = (generalParams.get("dataTime").equals(""))?'1':generalParams.get("dataTime");
        Object bannerId = (generalParams.get("bannerId").equals(""))? "16" :generalParams.get("bannerId");


        String cityBannerInfo = "INSERT INTO `share_city_banner` (`id`, `city_id`, `banner_id`, `appid`, `page`, `position`, `banner_order`, `default_color`, `active_color`, `is_available`, `created_at`, `updated_at`, `banner_channel`, `start_time`, `end_time`, `data_time`)\n" +
                "VALUES\n" +
                "\t(" + cityBannerId + ", " + cityId + ", " + bannerId + ", 'xiyi', " + page + ", 0, 0, '', '', " + isAvailable + ", '2016-02-23 16:05:44', '" + updateAt + "', " + bannerChannel + ", '" + startTime + "', '" + endTime + "', " + dataTime + ");\n";
        mysqlQaDao.execUpdateSql(cityBannerInfo);
    }

    public void GeneralServiceShareUser(Map<String, Object> generalParams,  String dbData){
        MysqlQaDao mysqlQaDao = new MysqlQaDao(dbData);

        Object userId = generalParams.get("userId");
        String mobile = generalParams.get("mobile").toString();
        String open_id = generalParams.get("open_id").toString();
        String init_share_user = "INSERT INTO share_user (id, tel, open_id, created_at, updated_at)VALUES ("+ userId + ", " + mobile + ",'" + open_id + "', '2015-11-26 00:00:00', '2015-11-26 00:00:00');";
        mysqlQaDao.execUpdateSql(init_share_user);

    }

    public void GeneralShareUserClients(Map<String, Object> generalParams,  String dbData){
        MysqlQaDao mysqlQaDao = new MysqlQaDao(dbData);
        Object userId = generalParams.get("userId");
        String userToken = generalParams.get("userToken").toString();
        String pushToken = generalParams.get("pushToken").toString();
        String from_user = generalParams.get("from_user").toString();
        Object user_type = (generalParams.get("user_type").equals(""))?'1':generalParams.get("user_type");
        Object bind = (generalParams.get("bind").equals(""))?'1':generalParams.get("bind");


        String initUserClients = "INSERT INTO `share_user_clients` (`user_id`, `from_user`, `user_token`, `user_type`, `bind`, `created_at`, `updated_at`, `push_token`, `user_session`)\n" +
                "VALUES\n" +
                "\t("+ userId + ", '" + from_user + "', '" + userToken + "', " + user_type + ", " + bind + ", '2015-12-28 11:51:22', '2015-12-28 11:51:22', '" + pushToken + "', '3e3de32542d5cefb9899528369b713a1');\n";
        mysqlQaDao.execUpdateSql(initUserClients);
    }
}
