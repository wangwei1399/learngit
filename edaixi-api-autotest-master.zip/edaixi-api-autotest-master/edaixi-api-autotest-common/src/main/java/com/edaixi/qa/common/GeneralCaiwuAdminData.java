package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by ningzhao on 16-2-15.
 */
public class GeneralCaiwuAdminData {


    MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc-caiwu04.properties");

    Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public final void init(){

    }

    public static String getYestoryDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,-1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    public static String getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrow = sdf.format(calendar.getTime());
        return tomorrow;
    }

    public static  String getTodayDate(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        return date;
    }


    public void GeneralCompany(Map <String, Object> generalPforderDetailParam){
        Object id = generalPforderDetailParam.get("id");
        Object company_id = 11;
        if(generalPforderDetailParam.containsKey("company_id")){
            company_id = generalPforderDetailParam.get("company_id");
        }
        Object earnest = 10000;
        if(generalPforderDetailParam.containsKey("earnest")){
            earnest = generalPforderDetailParam.get("earnest");
        }
        Object advance = 10000;
        if(generalPforderDetailParam.containsKey("advance")){
            advance = generalPforderDetailParam.get("advance");
        }
        Object wallet = 0.00;
        if(generalPforderDetailParam.containsKey("wallet")){
            wallet = generalPforderDetailParam.get("wallet");
        }
        Object wallet_realmoney = 0.00;
        if(generalPforderDetailParam.containsKey("wallet_realmoney")){
            wallet_realmoney = generalPforderDetailParam.get("wallet_realmoney");
        }

        String insertPfOrderDetail = "INSERT INTO `company` (`id`, `company_id`, `earnest`, `advance`, `wallet`, `wallet_realmoney`, `notice`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + id + ", " + company_id + ", " + earnest + ", " + advance + ", " + wallet + ", " + wallet_realmoney + ", '', '" + CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1) + "', '" + CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1) + "');\n";
        mysqlQaDao.execUpdateSql(insertPfOrderDetail);
    }



}


