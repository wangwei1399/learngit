package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by he_yi on 16/8/31.
 */
public class CreateCoupon {
    private boolean entityCoupon = true;
    private boolean discountCoupon = false;
    private String snCode = "";
    private int listId = 0;
    private int couponId = 0;
    private MysqlQaDao mysqlQaDao = null;
    private List<Map<String, Integer>> clearDataList = new ArrayList<>();

    private String fullTimeFormatStr = "yyyy-MM-dd HH:mm:ss";
    private String strStartTime = "";
    private String strEndTime = "";
    private long startTime = 0;
    private long endTime = 0;
    private String couponName = "接口测试优惠券";
    private int totalNum = 10;
    private int price = 100;
    private int discountPrice = 80;
    private int fanId = 0;






    public CreateCoupon(MysqlQaDao mysqlQaDao, boolean entityCoupon, boolean discountCoupon){
        this(mysqlQaDao);
        this.entityCoupon = entityCoupon;
        this.discountCoupon = discountCoupon;
    }

    public int getId(){
        return couponId;
    }

    public int getSuperId(){
        return listId;
    }

    public CreateCoupon(MysqlQaDao  mysqlQaDao){
        this.mysqlQaDao = mysqlQaDao;
        strStartTime = CommonTools.getToday(fullTimeFormatStr);
        strEndTime = CommonTools.getAfterDate(fullTimeFormatStr, 3);
        startTime = CommonTools.timeStrToUnix(fullTimeFormatStr,strStartTime);
        endTime = CommonTools.timeStrToUnix(fullTimeFormatStr, strEndTime);
    }

    public void createCoupon(){
        if (listId == 0){
            createCouponList();
        }
    }

    public void getCoupon(int fanId){
        createCoupon();
        this.fanId = fanId;
        createCouponSnCode();
    }

    public String getSnCode(){
        createCoupon();
        if (snCode.equals("")){
            createCouponSnCode();
        }
        return snCode;
    }


    private void createCouponList(){
        listId = CommonTools.getNewIdByTableName("ims_icoupon_list", mysqlQaDao);
        int couponType = entityCoupon?0:1;
        int discountType = discountCoupon?2:1;
        String sql = "insert into ims_icoupon_list(id,weid,card_id,title,sub_title,card_type,use_limit,use_custom_code,bind_openid,can_share,notice,description,coupon_price,totalnum,usednum,least_price,coupon_type,discount_type,discount_price,limit_count,starttime,endtime,content,create_time,validity_type,fixed_term,fixed_begin_term,is_kefu_faquan,coupon_message_id,apply_department,applicant,coupon_group_id,exclusive_channels,title_alias,product_good_id,category_id,clothes_id,channel,user_types,city_id,benefit_limit,is_zongbu_chengdan,is_actived,create_type,early_warning) " +
                "values("+listId+", 0, '', '"+couponName+"', '', 'CASH',0,0,0,0,'',NULL,"+price+","+totalNum+", 0,0,"+couponType
                +","+discountType+","+discountPrice+",0,'"+startTime+"','"+endTime+"','','"+startTime+"',0,0,0,0,1,'测试','测试',0,'','"+couponName+"',NULL," +
                "'','',3345,'','1,',0,0,1,0,0);";
        System.out.println(sql);
        mysqlQaDao.execUpdateSql(sql);
        addDeleteData("ims_icoupon_list", listId);
    }

    private void createCouponSnCode(){
        couponId = CommonTools.getNewIdByTableName("ims_icoupon_sncode", mysqlQaDao);
        int couponType = entityCoupon?0:1;
        int discountType = discountCoupon?2:1;
        String tmpCode = "";
        ResultSet resultSet = null;
        try {
            do {
                tmpCode = CommonTools.getRandomNumberToString(10);
                String sql = "select id from ims_icoupon_sncode where sncode="+tmpCode;
                resultSet = mysqlQaDao.execQuerySqlAllRet(sql);
            }while (resultSet.next());
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql = "insert into ims_icoupon_sncode(id,coupon_type,cid,sncode,order_sn,from_user,minus_money,total_money,used,charge_id,consume,usetime,create_time,fan_id,starttime,endtime,lingqu_time,good_item_id,channel_id,created_at,updated_at)" +
                "values("+couponId+","+couponType+","+listId+",'"+tmpCode+"',NULL, NULL,0.00,0.00,0,'',0,0,'"+startTime+"',"
                +fanId+",'"+startTime+"','"+endTime+"',NULL,NULL,0,'"+strStartTime+"','"+strEndTime+"');";
        System.out.println(sql);
        mysqlQaDao.execUpdateSql(sql);
        snCode = tmpCode;
        addDeleteData("ims_icoupon_sncode", couponId);

    }

    private void addDeleteData(String tableName, int id){
        Map<String, Integer> map = new HashMap<>();
        map.put(tableName, id);
        clearDataList.add(map);
    }

    public void deleteTestData(){
        for (Map<String, Integer> map:clearDataList){
            String key = map.entrySet().iterator().next().getKey();
            int value = map.get(key);
            String sql = "delete from "+key+" where id = "+value;
            System.out.println(sql);
            mysqlQaDao.execUpdateSql(sql);
        }
    }


    public void setFanId(int fanId){
        this.fanId = fanId;
    }

    public int getFanId(){
        return fanId;
    }

    public void setName(String name){
        couponName = name;
    }

    public String getName(){
        return couponName;
    }

    public String getStartTime(){
        return strStartTime;
    }

    public String getEndTIme(){
        return strEndTime;
    }

    public void setStartTime(String time){
        try {
            startTime = strTimeToUnix(time);
            strStartTime = time;
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println("请使用yyyy-MM-dd HH:mm:ss格式的时间");
        }

    }

    public void setEndTime(String time){
        try {
            endTime = strTimeToUnix(time);
            strEndTime = time;
        } catch (ParseException e) {
            e.printStackTrace();
            System.out.println("请使用yyyy-MM-dd HH:mm:ss格式的时间");
        }
    }

    private long strTimeToUnix(String time) throws ParseException {
        new SimpleDateFormat(fullTimeFormatStr).parse(time);
        return CommonTools.timeStrToUnix(fullTimeFormatStr, time);
    }



}
