package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

/**
 * Created by he_yi on 16/3/16.
 */
public class CommonTools {

    /**根据指定位数,生成随机数
     * @param number 生成随机数的位数
     * @return 随机数int类型
     */
    public static int getRandomInt(int number){
        Random random = new Random();
        String mins ="1";
        String maxs = "9";

        for(int i=0;i<number-1;i++){
            mins+="1";
            maxs+="9";
        }

        int min = Integer.parseInt(mins);
        int max = Integer.parseInt(maxs);

        int s = random.nextInt(max) % (max - min +1)+min;
        return s;
    }

    public static String getRandomNumberToString(int number){
        String tmp = "";
        int middle = 2;
        int times = 1;
        int value = 0;
        int difference = 0;

        if (number<9){
            tmp = String.valueOf(getRandomInt(number));
        }else {
            do {
                value = number/middle;
                times++;
                middle+=1;
            }while (value>9);

            for (int i=0;i<times;i++){
                tmp += String.valueOf(getRandomInt(value));
            }

            difference = number - value*times;
            if (difference>0){
                tmp += String.valueOf(getRandomInt(difference));
            }

        }
        return tmp;
    }

    public static int getNewIdByTableName(String tableName, MysqlQaDao mysqlQaDao){
        String sql = "select id from "+tableName+" order by id desc limit 1;";
        return getLastId(sql, mysqlQaDao)+1;
    }

    public static int getOrderIdNew(MysqlQaDao mysqlQaDao){
        String sql = "select id from ims_washing_order order by id desc limit 1;";
        return getLastId(sql, mysqlQaDao)+1;
    }

    /**根据指定查询sql,返回查询结果最后的一个ID
     * @param sql 查询sql语句,查询字段必须包含id
     * @param mysqlQaDao MysqlQaDao的对象
     * @return 查询结果的最后一个ID,若结果为空则返回0
     */
    public static int getLastId(String sql, MysqlQaDao mysqlQaDao){
        int lastId =0;
        ResultSet r1 = mysqlQaDao.execQuerySql(sql);
        try {
            r1.beforeFirst();
            if (r1.next()){
                r1.last();
                lastId = r1.getInt("id");
            }
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
//        mysqlQaDao.close();
        return lastId;
    }

    public static int getCourierCityId(int courierId, MysqlQaDao mysqlQaDao){
        int cityId = 0;
        String sql = "select city_id from ims_washing_courier where id = "+courierId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            cityId = resultSet.getInt("city_id");
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cityId;
    }

    /**获得测试小e的ID,没有则创建,有则返回小e的ID
     * @param mysqlQaDao MysqlQaDao对象
     * @return 返回小e的ID,int类型
     */
    public static int get_courierId(MysqlQaDao mysqlQaDao){
        String sql_get_lastId = "select id from ims_washing_courier where tel=21111112222 order by id DESC limit 1;";

//        ResultSet result_last_id = mysqlQaDao.execQuerySql(sql_get_lastId);
        int id = getLastId(sql_get_lastId, mysqlQaDao);
        if (id >0 ){
            return id;
        }else{
            String now_id = String.valueOf(getLastId("select id from ims_washing_courier order by id desc limit 1;", mysqlQaDao)+1);
            String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
            String sql =
                    "insert into ims_washing_courier(id,realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,edaixi_nr,start_time,end_time,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,deposit,pay_deposit_state,jiebo,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel) " +
                    "values("+ now_id+",'接口自动化测试','000000',21111112222,0,1,'332a4cb08505866c8a85c37dff128a28','"+time+"','"+time+"','北京',1,NULL,1,62258810454536652,110105199885523652,'工商银行',1,1,1,'EZB-0010-000"+now_id+"',NULL,NULL,'com."+now_id+".zhongbao',1,1,1,'android_client',0,0,NULL,0,NULL,'男',NULL,NULL,0,0,NULL,NULL,0,1457432520,1489043736,NULL,0,NULL,0,0,1,0,'接口自动化测试',0,NULL,'个把',21111112222);";
            mysqlQaDao.execUpdateSql(sql);

            /*因为jdbc配置问题,无法使用GeneralRongChain04Data
            Map<String, Object> tmp = new HashMap<String, Object>();
            tmp.put("courier_id", now_id);
            tmp.put("tel", "18881112222");
            tmp.put("push_token", "332a4cb08505866c8a85c37dff128a28");
            GeneralRongChain04Data.GeneralCouriers(tmp);
            */
            return get_courierId(mysqlQaDao);
        }
    }

    /**获得测试时要使用的用户id,没有则新建,有则返回.
     * @param mysqlQaDao MysqlQaDao对象
     * @return 用户id,int类型
     */
    public static int getFanId(MysqlQaDao mysqlQaDao){
        String sql = "select id from ims_fans where from_user = '21111119017' and realname = '接口测试用户' order by id desc limit 1;";
        int fan_id = 0;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()) {
                fan_id = resultSet.getInt("id");
            } else {
                String sql_q = "select id from ims_fans order by id desc limit 1;";
                int lastId = getLastId(sql_q, mysqlQaDao)+1;
                String insert_sql = "insert into ims_fans(id,user_type,from_user,salt,follow,createtime,realname,nickname,avatar,mobile,vip,isblacklist,push_token,user_token,courier_qu_in_process,last_order_time,frequently_address_id,first_qid,current_qid,first_courier_id,current_courier_id,created_at,updated_at,first_order_time,last_finish_order_time,huanxin_password,huanxin_name,last_order_id)" +
                        "values("+lastId+",0,'21111119017','',1,1457508534,'接口测试用户','','','21111119017',0,0,'','',0,1457677760,595977,0,0,0,0,'2016-03-09 15:28:54','2016-03-11 14:29:20',1457508534,0,NULL,NULL,984882383);";
                mysqlQaDao.execUpdateSql(insert_sql);
                fan_id = lastId;

            }
            resultSet.close();
        } catch (SQLException e) {
        e.printStackTrace();
        }

        return fan_id;
    }

    /**根据指定日期格式,和指定之后的天数,返回时间.
     * 比如获得明天时间,获得后天时间
     * @param simpleDateFormat 日期格式,例如yyyy-MM-dd HH:mm:ss,String类型
     * @param afterDateNumber 当前日期之后的天数int类型
     * @return 日期时间String类型
     */
    public static String getAfterDate(String simpleDateFormat, int afterDateNumber){
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());
        c.add(Calendar.DAY_OF_YEAR, afterDateNumber);
        return new SimpleDateFormat(simpleDateFormat).format(c.getTime());
//        return new SimpleDateFormat(simpleDateFormat).format(System.currentTimeMillis() + afterDateNumber * 24 * 60 * 60 * 1000);
    }

    public static String getBeforDate(String simpleDateFormat, int beforeDateNumber){
        return getAfterDate(simpleDateFormat, -beforeDateNumber);
    }

    /**根据指定日期格式,返回当前系统时间
     * @param simpleDateFormat 日期格式,例如yyyy-MM-dd HH:mm:ss,String类型
     * @return 日期String类型
     */
    public static String getToday(String simpleDateFormat){
        return getAfterDate(simpleDateFormat, 0);
    }

    /**计算订单sn
     * @param orderId 订单ID,String类型
     * @return ordersn,String类型
     */
    public static String getOrdersn(String orderId){
        String order_sn = new SimpleDateFormat("yyMMdd").format(System.currentTimeMillis())+orderId+getRandomInt(1);
        return order_sn;
    }

    public static int getCurrentHour(Date date) {
        Calendar calender = Calendar.getInstance();
        calender.setTime(date);
        return calender.get(calender.HOUR_OF_DAY);
    }

    //获得当天24点时间
    public static int getTimesnight(){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 24);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return (int) (cal.getTimeInMillis()/1000);
    }

    /**计算订单sn
     * @param orderId 订单ID,int类型
     * @return ordersn,String类型
     */
    public static String getOrdersn(int orderId){
        String order_sn = new SimpleDateFormat("yyMMdd").format(System.currentTimeMillis())+orderId+getRandomInt(1);
        return order_sn;
    }


    /**判断两个时间的差额,是否在给定的预期时间差范围内
     * @param time1 时间1,yyyy-MM-dd HH:mm:ss格式String类型
     * @param time2 时间1,yyyy-MM-dd HH:mm:ss格式String类型
     * @param difference_minute 预期时间差额,分钟
     * @return boolean类型
     */
    public static boolean judgeTimeDifference(String time1, String time2, int difference_minute){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        boolean flag = false;
        try {
            long t1 = sdf.parse(time1).getTime();
            long t2 = sdf.parse(time2).getTime();

            if ( (Math.abs(t1 - t2) / (1000*60) ) <= difference_minute){
                flag = true;
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return flag;
    }

    /**MD5加密方法
     * @param str
     * @return
     * @throws NoSuchAlgorithmException
     * @throws UnsupportedEncodingException
     */
    public static String string2MD5UTF8(String str) throws NoSuchAlgorithmException,UnsupportedEncodingException {
        MessageDigest messageDigest = null;
        messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.reset();
        messageDigest.update(str.getBytes("UTF-8"));
        byte[] byteArray = messageDigest.digest();
        StringBuffer md5StrBuff = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)
                md5StrBuff.append("0").append(
                        Integer.toHexString(0xFF & byteArray[i]));
            else
                md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
        }
        return md5StrBuff.toString();
    }


    /**字符串时间转时间戳
     * @param dataFormat
     * @param dateTime
     * @return
     */
    public static long timeStrToUnix(String dataFormat, String dateTime){
        Date date = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat(dataFormat);
        try {
            date = dateFormat.parse(dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long time = date.getTime()/1000; //java时间是毫秒级别,时间戳是秒级别
        return time;
    }


    /**时间戳转字符串时间
     * @param dataFormat
     * @param unix
     * @return
     */
    public static String unixToStr(String dataFormat, long unix){
        Date date = new Date(unix*1000);
        return new SimpleDateFormat(dataFormat).format(date).toString();
    }


    /**随机生成0-9 a-z的字符串
     * @param size
     * @return
     */
    public static String getRandomString(int size){
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < size; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }


}
