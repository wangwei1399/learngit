package com.edaixi.qa.common;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

/**
 * Created by ningzhao on 16-2-15.
 */
public class GeneralCaiwu04Data {

    Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public final void init(){
        
    }

    public static String getYestoryDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,-1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String yestoday = sdf.format(calendar.getTime());
        return yestoday;
    }

    public static String getTomorrowDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrow = sdf.format(calendar.getTime());
        return tomorrow;
    }

    public static  String getTodayDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String date = sdf.format(new Date());
        return date;
    }


    public void GeneralUsualSalaryRecords(MysqlQaDao mysqlQaDao,Map <String, Object> generalParam){
        Object id = generalParam.get("id");
        Object data_id = generalParam.get("data_id");
        Object courier_id = generalParam.get("courier_id");
        Object user_id = generalParam.get("user_id");
        Object event_type = generalParam.get("event_type");
        Object money = generalParam.get("money");
        Object bonus_rule_id = generalParam.get("bonus_rule_id");
        Object is_calculated = generalParam.get("is_calculated");
        Object city_id = 1;
        if(generalParam.containsKey("city_id")){
            city_id = generalParam.get("city_id");
        }

        String insertUsualSalaryDetail = "INSERT INTO `wuliu_usual_salary_records` (`id`, `data_id`, `courier_id`, `user_id`, `event_type`, `money`, `bonus_rule_id`, `is_calculated`, `created_at`, `updated_at`,`city_id`,`event_time`)\n" +
                "VALUES\n" +
                "\t("+ id +", " + data_id + ", " + courier_id + ", " + user_id + ", " + event_type + ", " + money + ", " + bonus_rule_id + ", " + is_calculated + ", '" + CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1) + "', '" + CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1) + "','" + city_id + "','" + CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1) + "');\n";
        mysqlQaDao.execUpdateSql(insertUsualSalaryDetail);
    }


}


