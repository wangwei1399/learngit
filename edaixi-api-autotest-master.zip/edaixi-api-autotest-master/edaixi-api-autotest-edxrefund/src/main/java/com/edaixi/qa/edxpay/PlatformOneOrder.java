package com.edaixi.qa.edxpay;

/**
 * Created by he_yi on 16/7/20.
 */
public class PlatformOneOrder {
}
