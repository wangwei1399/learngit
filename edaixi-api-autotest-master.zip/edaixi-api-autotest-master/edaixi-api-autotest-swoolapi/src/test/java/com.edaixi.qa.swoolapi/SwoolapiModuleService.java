package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class SwoolapiModuleService {
	private static Logger logger = LoggerFactory.getLogger(SwoolapiModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	private RestService dmServiceActive = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;

	public SwoolapiModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.globalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.globalConf.getProperty("swoolapi.addr"));

		dmServiceActive = (RestService) this.baseServiceFactory.getService();
		dmServiceActive.init(globalConf.getProperty("third.add"));
	}

	public JSONObject CallActiveCreate(String queryParam){
		String method = "post";
		return this.dmService.callApi2JsonByQueryStr(this.globalConf.getProperty("api.swoolapi.active.create"), method,"", queryParam);
	}
    public JSONObject CallActiveupdate(String queryParam){
        String method = "post";
        return this.dmService.callApi2JsonByQueryStr(this.globalConf.getProperty("api.swoolapi.active.update"), method,"", queryParam);
    }
	public JSONObject CallActiveShareRecode(Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.globalConf.getProperty("api.swoolapi.user.activeShareRecode"), method,"", queryParam);
	}

	public JSONObject CallThirdGiftPacks(Map<String, Object> queryParam){
		String method = "post";
		return this.dmServiceActive.callApi2Json(this.globalConf.getProperty("api.third.active.giftpacks"), method, "", queryParam);
	}

	public JSONObject CallAddPPoints(Map<String, Object> queryParams){
		String method = "post";
		return this.dmServiceActive.callApi2Json(this.globalConf.getProperty("usercredit.add.points"), method,"",queryParams);
	}

}
