package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class SwoolapiActiveCreateTest {

	private static Logger logger = LoggerFactory
			.getLogger(SwoolapiActiveCreateTest.class);
	private SwoolapiModuleService swoolapiModuleService = new SwoolapiModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
	}

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * @author ningyao.zn
     *
     * 生成一个链接红包类型的活动，active_type=1&相对有效期&发放的是优惠券
     *
	 */
	public void testActiveCreate() throws SQLException{
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        int id = (int)(currentTime % 10000);
        int active_type = 1;

		this.queryParams.put("title","title" + id);
        this.queryParams.put("descript","descript" + id);
        this.queryParams.put("template_id",id);
        this.queryParams.put("operator_id",id);
        this.queryParams.put("volidity",1);
        this.queryParams.put("relative_data","30");
        this.queryParams.put("active_type",active_type);
        this.queryParams.put("category",1);
        this.queryParams.put("share_title","share_title" + id);
        this.queryParams.put("share_img","share_img" + id);
        this.queryParams.put("share_desc","share_desc" + id);
        this.queryParams.put("total_nub","10000");
        this.couponParams.put("new",id + 1);
        this.couponParams.put("new_nub",1);
        this.couponParams.put("old",id + 2);
        this.couponParams.put("old_nub",1);
        this.queryParams.put("less","1");
        this.queryParams.put("more","10000");
        this.queryParams.put("coupon",this.couponParams);

        JSONObject result = this.swoolapiModuleService.CallActiveCreate(this.queryParams.toString());
		// 验证接口返回的数据
		logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回的值不符合预期","1",body.getString("code"));
        int active_list_id = body.getJSONObject("data").getInteger("active_list_id");

        //验证表active_entity表中的数据正确性
        String queryActiveEntity = "select active_list_id,uuid,total_nub,start_time,end_time,is_delete,channel_id,active_type from active_entity where active_list_id = " + active_list_id +"";
        ResultSet resQueryActiveEntity = mysqlQaDao.execQuerySql(queryActiveEntity);
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("total_nub"),body.getJSONObject("data").getString("total_nub"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("is_delete"),body.getJSONObject("data").getString("is_delete"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("uuid"),body.getJSONObject("data").getString("uuid"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("start_time"),body.getJSONObject("data").getString("start_time"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("end_time"),body.getJSONObject("data").getString("end_time"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("channel_id"),body.getJSONObject("data").getString("channel_id"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("active_type"),body.getJSONObject("data").getString("active_type"));

    }


    @Test
    /**
     *
     * @author ningyao.zn
     *
     * 生成一个物流活动类型的活动，active_type=4&相对有效期&发放的是优惠券
     *
     */
    public void testActiveCreateWuliu() throws SQLException{
        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        int id = (int)(currentTime % 10000);
        int active_type = 4;

        this.queryParams.put("title","title" + id);
        this.queryParams.put("descript","descript" + id);
        this.queryParams.put("template_id",id);
        this.queryParams.put("operator_id",id);
        this.queryParams.put("volidity",1);
        this.queryParams.put("relative_data","30");
        this.queryParams.put("active_type",active_type);
        this.queryParams.put("category",1);
        this.queryParams.put("share_title","share_title" + id);
        this.queryParams.put("share_img","share_img" + id);
        this.queryParams.put("share_desc","share_desc" + id);
        this.queryParams.put("total_nub","10000");
        this.couponParams.put("new",id + 1);
        this.couponParams.put("new_nub",1);
        this.couponParams.put("old",id + 2);
        this.couponParams.put("old_nub",1);
        this.queryParams.put("less","1");
        this.queryParams.put("more","10000");
        this.queryParams.put("coupon",this.couponParams);

        JSONObject result = this.swoolapiModuleService.CallActiveCreate(this.queryParams.toString());
        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回的值不符合预期","1",body.getString("code"));
        int active_list_id = body.getJSONObject("data").getInteger("active_list_id");

        //验证表active_entity表中的数据正确性
        String queryActiveEntity = "select active_list_id,uuid,total_nub,start_time,end_time,is_delete,channel_id,active_type from active_entity where active_list_id = " + active_list_id +"";
        ResultSet resQueryActiveEntity = mysqlQaDao.execQuerySql(queryActiveEntity);
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("total_nub"),body.getJSONObject("data").getString("total_nub"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("is_delete"),body.getJSONObject("data").getString("is_delete"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("uuid"),body.getJSONObject("data").getString("uuid"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("start_time"),body.getJSONObject("data").getString("start_time"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("end_time"),body.getJSONObject("data").getString("end_time"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("channel_id"),body.getJSONObject("data").getString("channel_id"));
        Assert.assertEquals("返回的值不符合预期",resQueryActiveEntity.getString("active_type"),body.getJSONObject("data").getString("active_type"));

    }


}
