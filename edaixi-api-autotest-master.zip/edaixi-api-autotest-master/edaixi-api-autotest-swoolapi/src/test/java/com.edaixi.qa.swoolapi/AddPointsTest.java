package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16/11/1.
 */
public class AddPointsTest {
    private static Logger logger = LoggerFactory.getLogger(AddPointsTest.class);
    private SwoolapiModuleService swoolapiModuleService = new SwoolapiModuleService();
    private JSONObject queryParam = new JSONObject();
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testAddPonits() throws SQLException{

    }


}
