package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class SwoolapiActiveUpdateTest {

	private static Logger logger = LoggerFactory
			.getLogger(SwoolapiActiveUpdateTest.class);
	private SwoolapiModuleService swoolapiModuleService = new SwoolapiModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
	}

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 *
	 * @author ningyao.zn
     *
     * 生成一个链接红包类型的活动，active_type=1&相对有效期&发放的是优惠券
     *
	 */
	public void testActiveUpdate() throws SQLException{
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        int id = (int)(currentTime % 10000);
        int uuid = (int)(currentTime % 1000000000);
        String  channel = String.valueOf((int)(currentTime % 1000000000) + 'a');

        int active_type = 1;//链接红包
        int is_delete = 0;

        String initActieEntity = "INSERT INTO `active_entity` (`id`, `active_list_id`, `uuid`, `total_nub`, `start_time`, `end_time`, `is_delete`, `channel_id`, `created_at`, `updated_at`, `active_type`)\n" +
                "VALUES\n" +
                "\t("+ id +", "+ id +", '" + uuid +"', 10000, '1449727361', '1452319361', " + is_delete + ", " + id + ", '2015-12-10 14:02:41', '2015-12-10 14:02:41', " + active_type + ");\n";
        String initActiveRule = "INSERT INTO `active_rule` (`id`, `title`, `descript`, `active_type`, `category`, `template_id`, `is_delete`, `start_time`, `end_time`, `volidity`, `relative_data`, `share_title`, `share_desc`, `share_img`, `operator_id`, `created_at`, `updated_at`, `child_active_type`, `less`, `more`)\n" +
                "VALUES\n" +
                "\t("+ id +", 'title"+ id +"', 'descript" + id +"', " + active_type +", 1, 1862, " + is_delete + ", NULL, NULL, 1, 30, 'share_title" + id + "', 'share_desc" + id + "', 'share_img"+ id +"', " + id +", '2015-12-10 14:02:41', '2015-12-10 14:02:41', 0, 1, 10000);\n";

        String initChannelList = "INSERT INTO `channel_list` (`id`, `channel`, `channel_name`, `channel_desc`, `created_at`, `channel_group`, `channel_group_desc`, `isdisplay_bychannel`, `updated_at`)\n" +
                "VALUES\n" +
                "\t("+ id +", '" + channel +"', '', 'title" + id +"', 1449727361, 9, '链接红包', NULL, '2015-12-10 14:02:41');\n";

        String initActiveCouponRule = "INSERT INTO `active_coupon_rule` (`id`, `active_list_id`, `coupon_cid`, `is_delete`, `is_new`, `chance`)\n" +
                "VALUES\n" +
                "\t(" + id +", " + id +", " + id +", " + is_delete +  ", 1, 1);\n";
        String initActiveCouponRule1 = "INSERT INTO `active_coupon_rule` (`id`, `active_list_id`, `coupon_cid`, `is_delete`, `is_new`, `chance`)\n" +
                "VALUES\n" +
                "\t(" + id +1+", " + id +", " + id +1+", " + is_delete +  ", 0, 1);\n";
        mysqlQaDao.execUpdateSql(initActieEntity);
        mysqlQaDao.execUpdateSql(initActiveRule);
        mysqlQaDao.execUpdateSql(initChannelList);
        mysqlQaDao.execUpdateSql(initActiveCouponRule);
        mysqlQaDao.execUpdateSql(initActiveCouponRule1);

        this.queryParams.put("id",id);
		this.queryParams.put("title","title" + id);
        this.queryParams.put("descript","descript" + id);
        this.queryParams.put("template_id",id);
        this.queryParams.put("operator_id",id);
        this.queryParams.put("volidity",1);
        this.queryParams.put("relative_data","60");//修改相对有效期的时间
        this.queryParams.put("active_type",1);
        this.queryParams.put("category",1);
        this.queryParams.put("share_title","share_title" + id);
        this.queryParams.put("share_img","share_img" + id);
        this.queryParams.put("share_desc","share_desc" + id);
        this.queryParams.put("total_nub","10000");
        this.couponParams.put("new",id);
        this.couponParams.put("new_nub",1);
        this.couponParams.put("old",id + 1);
        this.couponParams.put("old_nub",1);
        this.queryParams.put("less","1");
        this.queryParams.put("more","10000");
        this.queryParams.put("coupon",this.couponParams);

        JSONObject result = this.swoolapiModuleService.CallActiveupdate(this.queryParams.toString());
		// 验证接口返回的数据
		logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));

	}


}
