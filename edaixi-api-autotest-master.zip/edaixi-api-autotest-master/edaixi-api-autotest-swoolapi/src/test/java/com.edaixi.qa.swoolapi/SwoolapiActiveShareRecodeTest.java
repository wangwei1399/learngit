package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class SwoolapiActiveShareRecodeTest {

	private static Logger logger = LoggerFactory
			.getLogger(SwoolapiActiveShareRecodeTest.class);
	private SwoolapiModuleService swoolapiModuleService = new SwoolapiModuleService();
    private Map<String, Object> queryParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc.rongchain04.properties");

    @Before
	public void setUp() {
        this.queryParams = new HashMap<String, Object>();

    }

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * @author ningyao.zn
     *
     *
     *
	 */
	public void testActiveShareRecode() throws SQLException{
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        int share_user_id = (int)(currentTime % 10000);
        int from_user_id = 0;

		this.queryParams.put("share_user_id",share_user_id);
        this.queryParams.put("share_active_id",0);
        this.queryParams.put("type",4);
        this.queryParams.put("depth",1);
        this.queryParams.put("is_fail",0);
        this.queryParams.put("from_user_id",from_user_id);
        this.queryParams.put("from_active_id",0);

        JSONObject result = this.swoolapiModuleService.CallActiveShareRecode(this.queryParams);
		// 验证接口返回的数据
		logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回的值不符合预期","1",body.getString("code"));

        String queryRecode = "select id,share_user_id,share_active_id,type,depth,is_fail,from_user_id,from_active_id,created_at,updated_at from active_share_recode where id = " + body.getIntValue("data") + "";
        ResultSet queryRecodeRet = mysqlQaDao.execQuerySql(queryRecode);

        Assert.assertEquals("返回值不符合预期", share_user_id,queryRecodeRet.getInt("share_user_id"));
        Assert.assertEquals("返回值不符合预期", 0,queryRecodeRet.getInt("share_active_id"));
        Assert.assertEquals("返回值不符合预期", 4,queryRecodeRet.getInt("type"));
        Assert.assertEquals("返回值不符合预期", 1,queryRecodeRet.getInt("depth"));
        Assert.assertEquals("返回值不符合预期", 0,queryRecodeRet.getInt("is_fail"));
        Assert.assertEquals("返回值不符合预期", 0,queryRecodeRet.getInt("from_user_id"));
        Assert.assertEquals("返回值不符合预期", 0,queryRecodeRet.getInt("from_active_id"));
        Assert.assertTrue("返回值不符合预期", queryRecodeRet.getString("created_at").contains(GeneralRongChain04Data.getTodayDate()));
        Assert.assertTrue("返回值不符合预期", queryRecodeRet.getString("updated_at").contains(GeneralRongChain04Data.getTodayDate()));

    }


}
