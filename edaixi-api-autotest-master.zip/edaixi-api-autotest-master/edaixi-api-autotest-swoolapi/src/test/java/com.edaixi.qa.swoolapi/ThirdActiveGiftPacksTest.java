package com.edaixi.qa.swoolapi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by he_yi on 16/8/29.
 */
public class ThirdActiveGiftPacksTest {
    private static Logger logger = LoggerFactory.getLogger(ThirdActiveGiftPacksTest.class);
    private static MysqlQaDao mysqlQaDao = null;
    private static SwoolapiModuleService apiModuleService = new SwoolapiModuleService();

    private String appKey = "";
    private String partnerId = "youku";
    private String version = "1.0";
    private String activeKey = "";
    private String phone = "";
    private String time = "";

    private int fanId = 0;
    private double price = 0.0;
    private double zhenqian = 0.0;
    private double jiaqian = 0.0;

    private int ruleId = 0;
    private int sonId = 0;

    private List<Map<String, Integer>> clearDataList = new ArrayList<>();

    @Before
    public void before() throws SQLException {
        mysqlQaDao = new MysqlQaDao("jdbc.rongchain04.properties");
        time = String.valueOf(System.currentTimeMillis()).substring(0, 10);
    }

    @After
    public void after(){
        deleteTestData();
        mysqlQaDao.close();
        mysqlQaDao = null;
    }

    @Test
    public void onlyBalance(){
        price = 120;
        zhenqian = 60;
        jiaqian = 60;
        phone = "18611369742";
        fanId = getFanId(phone);

        double[] balance = getBalance();
        double expectZhenqian = balance[0]+zhenqian;
        double expectCoin = balance[1]+jiaqian;

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 0, refundJson.getIntValue("code"));
        Assert.assertEquals("失败 msg", "success", refundJson.getString("msg"));
        Assert.assertEquals("电话号码不正确", phone,  refundJson.getJSONObject("body").getString("phone"));
        balance = getBalance();
        double actualZhenqian = balance[0];
        double actualCoin = balance[1];
        Assert.assertEquals("数据库zhenqian不正确", expectZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库coin不正确", expectCoin, actualCoin, 0.0);
    }

    @Test
    public void onlyCoupon(){
        price = 12;
        phone = "18611369742";
        fanId = getFanId(phone);


        int couponSum = 3;
        List<Integer> couponList = new ArrayList<>();
        for (int i=0;i<couponSum;i++) {
            int couponId = createCoupon(10, 3);
            couponList.add(couponId);
        }

        createRule("土豆测试", price, 0.0, 0.0, couponList, null);
        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 0, refundJson.getIntValue("code"));
        Assert.assertEquals("失败 msg", "success", refundJson.getString("msg"));
        Assert.assertEquals("电话号码不正确", phone,  refundJson.getJSONObject("body").getString("phone"));

        for (int id:couponList){
            String sql = "select count(*) from ims_icoupon_sncode where cid = "+id+" and fan_id = "+fanId;
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            int tmpSum = 0;
            try {
                tmpSum = resultSet.getInt(1);
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            Assert.assertEquals("cid:"+id+" 的优惠券数量不正确", 1, tmpSum);
        }
    }

    @Test
    public void fullAndNewUser() throws SQLException {
        price = 101;
        zhenqian = 30;
        jiaqian = 40;
        int times = 10;
        while (true){
            phone = "10"+CommonTools.getRandomInt(9);
            String sql = "select id from ims_fans where mobile = '"+phone+"';";
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            resultSet.beforeFirst();
            if (!resultSet.next()){
                break;
            }

            if (times <= 0){
                try {
                    throw new Exception("尝试超过"+times+"次,未能找到新手机号");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            times--;
        }

        List<Integer> couponList = new ArrayList<>();
        for (int i=0;i<3;i++){
            int couponId = createCoupon(10, 3);
            couponList.add(couponId);
        }




        createRule("土豆测试", price, zhenqian, jiaqian, couponList, "由于您太帅了,所以获得一张优惠券");
        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 0, refundJson.getIntValue("code"));
        Assert.assertEquals("失败 msg", "success", refundJson.getString("msg"));
        Assert.assertEquals("电话号码不正确", phone,  refundJson.getJSONObject("body").getString("phone"));
        fanId = getFanId(phone);

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);

        for (int id:couponList){
            String sql = "select count(*) from ims_icoupon_sncode where cid = "+id+" and fan_id = "+fanId;
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            int tmpSum = 0;
            tmpSum = resultSet.getInt(1);
            resultSet.close();
            Assert.assertEquals("cid:"+id+" 的优惠券数量不正确", 1, tmpSum);
        }
    }

    @Test
    public void signNotTrue(){
        price = 101;
        zhenqian = 30;
        jiaqian = 40;

        phone = "18611369742";
        fanId = getFanId(phone);

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        Map<String, Object> queryParam = getQueryParam();
        queryParam.put("sign", "11111");
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 3, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }

    @Test
    public void invalidPhoneNumber(){
        price = 100;
        zhenqian = 10;
        jiaqian = 70;
        phone = "28611369742";


        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));
        fanId = getFanId(phone);

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 4, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }

    @Test
    public void endActiveRule(){
        price = 100;
        zhenqian = 20;
        jiaqian = 70;

        phone = "18611369742";
        fanId = getFanId(phone);

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        String beforeDay = CommonTools.getBeforDate("yyyy-MM-dd", 3);
        String sql = "update active_new_rule set end_time='"+beforeDay+"', end_time_int = '"+CommonTools.timeStrToUnix("yyyy-MM-dd", beforeDay)+"' where id="+ruleId;
        mysqlQaDao.execUpdateSql(sql);

        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 2, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }

    @Test
    public void notStartActiveRule(){
        price = 100;
        zhenqian = 20;
        jiaqian = 10;

        phone = "18611369742";
        fanId = getFanId(phone);

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        String afterDay = CommonTools.getAfterDate("yyyy-MM-dd", 3);
        String sql = "update active_new_rule set start_time='"+afterDay+"', start_time_int = '"+CommonTools.timeStrToUnix("yyyy-MM-dd", afterDay)+"' where id="+ruleId;
        mysqlQaDao.execUpdateSql(sql);

        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 2, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }

    @Test
    public void closeActiveRule(){
        price = 100;
        zhenqian = 20;
        jiaqian = 20;

        phone = "18611369742";
        fanId = getFanId(phone);

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        String sql = "update active_new_rule set is_close=1 where id="+ruleId;
        mysqlQaDao.execUpdateSql(sql);

        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 2, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }

    @Test
    public void deleteActiveRule(){
        price = 100;
        zhenqian = 20;
        jiaqian = 30;

        phone = "18611369742";
        fanId = getFanId(phone);

        createRule("优惠洗衣大礼包", price, zhenqian, jiaqian, null, null);
        String afterDay = CommonTools.getAfterDate("yyyy-MM-dd", 3);
        String sql = "update active_new_rule set is_delete=1 where id="+ruleId;
        mysqlQaDao.execUpdateSql(sql);

        Map<String, Object> queryParam = getQueryParam();
        JSONObject jsonObject = apiModuleService.CallThirdGiftPacks(queryParam);
        JSONObject refundJson = JSON.parseObject(jsonObject.getString("httpBody"));

        logger.info("result json:"+refundJson.toJSONString());
        Assert.assertEquals("失败 code", 2, refundJson.getIntValue("code"));

        double[] balance = getBalance();
        double actualZhenqian = balance[0];
        double actualJiaqian = balance[1];
        Assert.assertEquals("数据库真钱不正确", actualZhenqian, actualZhenqian, 0.0);
        Assert.assertEquals("数据库价钱不正确", actualJiaqian, actualJiaqian, 0.0);
    }



















    private double[] getBalance(){
        String sql = "select coin, zhenqian from ims_icard_card  where fan_id = "+fanId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        double zhenqian = 0.0;
        double coin = 0.0;
        try {
            zhenqian = resultSet.getDouble("zhenqian");
            coin = resultSet.getDouble("coin");
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        double[] balance = {zhenqian, coin};
        return balance;
    }

    private int getFanId(String mobile){
        String sql = "select id from ims_fans where mobile = "+mobile;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            fanId = resultSet.getInt(1);
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return fanId;
    }


    private Map<String, Object> getQueryParam(){
        Map<String, Object> queryParam = new HashMap<>();
        queryParam.put("partnerId", partnerId);
        queryParam.put("version", version);
        queryParam.put("activeKey", activeKey);
        queryParam.put("phone", phone);
        queryParam.put("time", time);
        String sign = getSign();
        queryParam.put("sign", sign);
        System.out.println(sign);
        return queryParam;
    }

    private int createCoupon(int money, int sum){
        int id = CommonTools.getNewIdByTableName("ims_icoupon_list", mysqlQaDao);
        long start = strToUnix(CommonTools.getBeforDate("yyyy-MM-dd HH:mm:ss", 1));
        long end = strToUnix(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 3));
        String sql = "insert into ims_icoupon_list values("+id+", 0, '', '临时电子优惠券', '', 'CASH',0,0,0,0,'',NULL,"+money+","+sum+", 0,0,1,1,0,0,'"+start+"','"+end+"','','"+start+"',0,0,0,0,1,'测试','测试',0,'','临时电子优惠券',NULL," +
                "'','',3345,'','1,',0,0,1,0,0);";
        System.out.println(sql);
        mysqlQaDao.execUpdateSql(sql);
        addDeleteData("ims_icoupon_list", id);
        return id;
    }

    private void createRule(String name, double price, double zhenqian, double jiaqian, List<Integer> couponIdList, String mess){
        String today = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        int channelId = CommonTools.getNewIdByTableName("active_new_channel", mysqlQaDao);
        appKey = getRandomString(33);
        String sql_channel = "insert into active_new_channel values("+channelId+",'"+name+"','','"+appKey+"',86,'测试用户',0,0,'"+today+"','"+today+"');";
        System.out.println(sql_channel);
        mysqlQaDao.execUpdateSql(sql_channel);
        addDeleteData("active_new_channel", channelId);

        ruleId = CommonTools.getNewIdByTableName("active_new_rule", mysqlQaDao);
        activeKey = getRandomString(8);
        String sql_rule = "insert into active_new_rule values("+ruleId+",'"+activeKey+"','接口自动化测试"+ruleId+"','北京',196,'"
                +CommonTools.getToday("yyyy-MM-dd")+"','"+CommonTools.timeStrToUnix("yyyy-MM-dd", CommonTools.getToday("yyyy-MM-dd"))+"','"
                +CommonTools.getAfterDate("yyyy-MM-dd", 5)+"','"
                +CommonTools.timeStrToUnix("yyyy-MM-dd", CommonTools.getAfterDate("yyyy-MM-dd", 5))
                +"',"+price+","+channelId+",86,'测试用户',0,0,'"+today+"','"+today+"');";
        mysqlQaDao.execUpdateSql(sql_rule);
        addDeleteData("active_new_rule", ruleId);

        sonId = CommonTools.getNewIdByTableName("active_new_rule_son", mysqlQaDao);
        if (zhenqian != 0.0 || jiaqian != 0.0){
            String sql = "insert into active_new_rule_son values("+sonId+","+ruleId+",'direct_recharge',"+jiaqian+","+zhenqian+",NULL,NULL,NULL,0,0,'"+today+"','"+today+"');";
            mysqlQaDao.execUpdateSql(sql);
            addDeleteData("active_new_rule_son", sonId);
            sonId++;
        }

        if (mess != null  &&  !mess.equals("")){
            String sql = "insert into active_new_rule_son values("+sonId+","+ruleId+",'mess',NULL,NULL,NULL,NULL,'"+mess+"',0,0,'"+today+"','"+today+"');";
            mysqlQaDao.execUpdateSql(sql);
            addDeleteData("active_new_rule_son", sonId);
            sonId++;
        }

        if (couponIdList != null){
            for (int id:couponIdList){
                String sql = "insert into active_new_rule_son values("+sonId+","+ruleId+",'coupon',NULL,NULL,NULL,"+id+",NULL,0,0,'"+today+"','"+today+"');";
                System.out.println(sql);
                mysqlQaDao.execUpdateSql(sql);
                addDeleteData("active_new_rule_son", sonId);
                sonId++;
            }
        }
        sonId --;
    }

    private void deleteTestData(){
        for (Map<String, Integer> map:clearDataList){
            String key = map.entrySet().iterator().next().getKey();
            int value = map.get(key);
            if (key.equals("ims_icoupon_list")){
                String sql = "delete from ims_icoupon_sncode where cid="+value;
                mysqlQaDao.execUpdateSql(sql);

                sql = "delete from "+key+" where id = "+value;
                mysqlQaDao.execUpdateSql(sql);
            }else{
                //            String sql = "delete from "+key+" where id = "+value;
//            mysqlQaDao.execUpdateSql(sql);

                String sql = "update "+key+" set is_delete = 1, is_close = 1 where id = "+value;
                System.out.println(sql);
                mysqlQaDao.execUpdateSql(sql);
            }



        }
    }

    private void addDeleteData(String tableName, int id){
        Map<String, Integer> map = new HashMap<>();
        map.put(tableName, id);
        clearDataList.add(map);
    }


    private long strToUnix(String dateTime){
        return CommonTools.timeStrToUnix("yyyy-MM-dd HH:mm:ss", dateTime);
    }


    private String getRandomString(int size){
        return CommonTools.getRandomString(size);
    }




    private String getSign(){
        List<String> list = new ArrayList<>();
        list.add("partnerId="+partnerId);
        list.add("version"+version);
        list.add("activeKey"+activeKey);
        list.add("phone"+phone);
        list.add("time"+time);

        //对key键值按字典升序排序
        Collections.sort(list);
        String sign = "";
        for (String s:list){
            s = s.replace("=","");
            sign += s;
        }

        try {
            sign = CommonTools.string2MD5UTF8(sign+appKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        sign = sign.toUpperCase();

        return sign;
    }


}
