package com.edaixi.qa.open;
import com.alibaba.fastjson.JSONObject;

import java.sql.SQLException;
import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


/**
 * Created by cherry on 2016/1/4.
 */
public class AuthorizationTest {

    /***

     * @param httpUrl    sign url
     * @param httpParams Hash Params
     * @return
     */

    public static String signHttpUrl( String httpUrl, HashMap<String, Object> httpParams) throws SQLException {
        //private Map<String, Object> orderParams = null;
        //BindHttpUser bindUser = new BindHttpUser();
        String myToken ="";
        if(httpParams.containsKey("user_id")){
            myToken =BindHttpUser.testBindHttpUser();
        }

        String signHttpUrlString = "";
        httpParams.put("app_key", "http_client");

        List<String> paramsList = new ArrayList<String>();
        for (String key : httpParams.keySet()) {
            paramsList.add(key + "=" + httpParams.get(key));
        }
        Collections.sort(paramsList);

        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : paramsList) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);


        String string2md5 = string2MD5(addString + "FO5Z6BIWV9"
                + (httpParams.containsKey("user_id") ? myToken : ""));

        return string2md5;
//        paramsList.add("sign=" + string2md5);
//
//        StringBuilder sbStringBuilder = new StringBuilder();
//        for (String paramsListString : paramsList) {
//            sbStringBuilder.append(paramsListString);
//            sbStringBuilder.append("&");
//        }
//
//        String add2String = sbStringBuilder.substring(0, sbStringBuilder.length() - 1);
//        signHttpUrlString = httpUrl + add2String;
//        return signHttpUrlString;
    }

    public static String string2MD5(String inStr) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        md.update(inStr.getBytes());
        byte[] bs = md.digest();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < bs.length; i++) {
            sb.append(String.format("%02x", bs[i] & 0xff));
        }
        return sb.toString();
    }

}
