package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
/**
 * Created by cherry on 2015/12/29.
 */
public class UserCenterInfoTest {

    private static Logger logger = LoggerFactory.getLogger(UserCenterInfoTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testUserCenterInfo() throws SQLException{

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
        orderParams.put("user_id","623652");
        orderParams.put("user_type","1");

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("user_center_info");




        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallUserCenterInfo("", orderParams);
            logger.info(result.toJSONString());
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        } catch (Exception e) {
            e.printStackTrace();
        }



    }
}
