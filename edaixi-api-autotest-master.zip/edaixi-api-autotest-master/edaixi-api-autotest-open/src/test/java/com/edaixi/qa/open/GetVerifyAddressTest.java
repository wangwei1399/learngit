package com.edaixi.qa.open;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by huangwei on 16/2/17.
 */
public class GetVerifyAddressTest {
    private static Logger logger = LoggerFactory.getLogger(GetVerifyAddressTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testGetVerifyAddress() throws SQLException {

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

        String queryaddress="select id,city,area from ims_washing_address where deleted='0' and type='Address';";
        ResultSet queryResult=mysqlQaDao.execQuerySql(queryaddress);
        String id=queryResult.getString("id");
        String city=queryResult.getString("city");
        String area=queryResult.getString("area");
        String[] id1=new String[]{"1","2","3","4","5"};
		String category_id="";
		int index=(int)(Math.random()*id1.length);
        category_id=id1[index];
        logger.info("--------"+id);

        orderParams.put("user_id","623652");
        //orderParams.put("address_id",id);
        orderParams.put("city_id",1);
        orderParams.put("area_id",1);
        orderParams.put("category_id",category_id);
        orderParams.put("flag","0");


        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_verify_address");



        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallGetVerifyAddress("", orderParams);
            logger.info(result.toJSONString());

            //验证第一种方法
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data = JSON.parseObject(body.getString("data"));
            System.out.println("--------"+data);
            String queryaddressInfo="select username,city,area,fan_id,tel,deleted,city_id,type from ims_washing_address where id="+id;
            ResultSet queryResult1=mysqlQaDao.execQuerySql(queryaddressInfo);

            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            Assert.assertEquals(true, result.getString("httpStatus").contains("200"));
//            Assert.assertEquals("返回值不符合预期",queryResult.getString("id"),data.getString("address_id"));//如果值不相同,返回Message
//            Assert.assertEquals("返回值不符合预期",queryResult1.getString("username"),data.getString("username"));
//            Assert.assertEquals("返回值不符合预期",queryResult1.getString("tel"),data.getString("tel"));
//            Assert.assertEquals("返回值不符合预期",queryResult1.getString("city"),data.getString("city"));
//            Assert.assertEquals("返回值不符合预期",queryResult1.getString("area"),data.getString("area"));
//            Assert.assertEquals("返回值不符合预期","Address",queryResult1.getString("type"));
//            Assert.assertEquals("返回值不符合预期",queryResult1.getString("city_id"),data.getString("city_id"));
            Assert.assertEquals("返回值不符合预期","true",data.getString("on_service"));



        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
