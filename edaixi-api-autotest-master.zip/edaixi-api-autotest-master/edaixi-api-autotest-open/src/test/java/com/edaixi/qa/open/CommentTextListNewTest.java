package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2015/12/25.
 */

public class CommentTextListNewTest {

    private static Logger logger = LoggerFactory.getLogger(CommentTextListNewTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    //新评论列表
    public void testCommentTextListNew() throws SQLException{

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("comment_text_list_new");



        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);//591429042
            JSONObject result= shareOpenModuleService.CallCommentTextListNew("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data = JSON.parseObject(body.getString("data"));
            logger.info("test:"+data);
            String dataString = data.getString("top");
            List<AppraiseBeanTest> AppraiseBeanList = JSON.parseArray(dataString,AppraiseBeanTest.class);

            logger.info("AppraiseBeanList:"+AppraiseBeanList.size());
            for(int i = 0;i < AppraiseBeanList.size();i++){
                logger.info("AppraiseBeanList:"+AppraiseBeanList.get(i).getComment());
            }
            //String dataString1 = data.getString("option");
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));


        } catch (Exception e) {
            e.printStackTrace();
        }


    }


}
