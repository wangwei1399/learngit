package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;
/**
 * Created by cherry on 2016/3/21.
 */

public class CaclulateOrderPriceTest {

    private static Logger logger = LoggerFactory.getLogger(CaclulateOrderPriceTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    @Before
    public void setUp() {

        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testCaclulateOrderPrice() throws SQLException{
//获取折扣券订单价格
        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
        String querycid="SELECT id FROM ims_icoupon_sncode WHERE fan_id='623652'and used=0;";
        ResultSet queryResult = mysqlQaDao.execQuerySql(querycid);
        String coupon_id = queryResult.getString("id");
        AllCreateOrderTest createorder=new AllCreateOrderTest();
        String id=createorder.testCreateOrder();
        String upateid="UPDATE ims_washing_order SET `status`='1',status_delivery='9',totalprice='50'WHERE id= "+id;
        Boolean updateResult=mysqlQaDao.execUpdateSql(upateid);
//        String queryid="SELECT id FROM ims_washing_order WHERE fan_id='623652' AND status_delivery='9' AND pay_status='0';";
//        ResultSet queryResult1 = mysqlQaDao.execQuerySql(queryid);
//        String id = queryResult1.getString("id");

        orderParams.put("user_id", "623652");
        orderParams.put("order_id", id);
        orderParams.put("paytype", "1");
        orderParams.put("coupon_id", coupon_id);
        orderParams.put("activity_info_id", "1");
        orderParams.put("city_id", "1");
        orderParams.put("mark", "1");

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("caclulate_order_price");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallCaclulateOrderPrice("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body=JSON.parseObject(result.getString("httpBody"));
            JSONObject data=JSON.parseObject(body.getString("data"));
            String coupon_discount_price=data.getString("coupon_discount_price");
            String queryicouponInfo="select cid from ims_icoupon_sncode where id="+coupon_id;
            ResultSet queryResult1=mysqlQaDao.execQuerySql(queryicouponInfo);
            String cid=queryResult1.getString("cid");
            String queryicouponInfo1="select coupon_price from ims_icoupon_list where id="+cid;
            ResultSet queryResult2=mysqlQaDao.execQuerySql(queryicouponInfo1);
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            Assert.assertEquals("与预期结果不一致",queryResult2.getString("coupon_price") ,data.getString("coupon_discount_price"));

        } catch (Exception e) {
            e.printStackTrace();
        }



    }
}
