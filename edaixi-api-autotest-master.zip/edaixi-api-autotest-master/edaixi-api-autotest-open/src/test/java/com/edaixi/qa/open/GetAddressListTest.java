package com.edaixi.qa.open;

/**
 * Created by cherry on 2015/12/25.
 */
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;


public class GetAddressListTest {

    private static Logger logger = LoggerFactory.getLogger(GetAddressListTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testGetAddressList() throws SQLException{
        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
        String[] id = new String[]{"1","2","3","4","5"};
        String category_id="";
        int i=(int) (Math.random()*id.length);
        category_id=id[i];

        orderParams.put("user_id","623652");
        orderParams.put("category_id",category_id);

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_address_list");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallGetAddressList("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body= JSON.parseObject(result.getString("httpBody"));
            String data=body.getString("data");
            logger.info("-----"+data);
            //String dataString = data.getString("top");
            List<AppraiseBeanTest> AppraiseBeanList = JSON.parseArray(data,AppraiseBeanTest.class);
            logger.info("AppraiseBeanList:"+AppraiseBeanList.size());
            ArrayList<String> a=new ArrayList<String>();
            for(int j = 0;j < AppraiseBeanList.size();j++){
                logger.info("AppraiseBeanList:"+AppraiseBeanList.get(j).getAddress_id());
                a.add(AppraiseBeanList.get(j).getAddress_id());
               // logger.info("数组a"+a);
            }
            String queryaddress="SELECT id FROM ims_washing_address WHERE (hotel_id IS NULL) AND fan_id='623652' AND deleted='0';;";
            ResultSet queryResult=mysqlQaDao.execQuerySqlAllRet(queryaddress);
            ArrayList<String> b =new ArrayList<String>();
            while (queryResult.next())
            {
                b.add(queryResult.getString("id"));

                System.out.println("--数组b-"+b);
            }
            System.out.println(a.containsAll(b));
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
          //  Assert.assertEquals("返回结果不符合预期",true,a.containsAll(b));

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
