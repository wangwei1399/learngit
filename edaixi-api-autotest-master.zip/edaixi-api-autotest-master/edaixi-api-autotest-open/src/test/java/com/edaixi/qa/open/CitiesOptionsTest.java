package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by cherry on 2015/12/28.
 */

public class CitiesOptionsTest {
    private static Logger logger = LoggerFactory.getLogger(CitiesOptionsTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testCitiesOptions() throws SQLException {

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("cities_options");



        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallCitiesOptions("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data = JSON.parseObject(body.getString("data"));
            logger.info("test:"+data);
            String city = data.getString("cities");
            logger.info("test:"+city);


            String querycity="select name from cities where is_show='1';";
            ResultSet queryResult1=mysqlQaDao.execQuerySqlAllRet(querycity);
            ArrayList<String> b=new ArrayList<String>();
            while (queryResult1.next()){
                String aa=queryResult1.getString("name");
                //
                b.add(aa.toString()+"");
                System.out.println("---数组b---"+b);
            }
//            System.out.println("-------cityIdlist1-------"+cityIdlist1.size());
//            for(int i=0;i<cityIdlist1.size();i++)
//            {
//
//                System.out.println(i);
//            }
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
           // Assert.assertEquals("不符合预期结果","保定",queryResult.getString("name"));




        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
