package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;



public class IcardRechargeTest {

	private static Logger logger = LoggerFactory.getLogger(IcardRechargeTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testIcardRecharge() throws SQLException{
	//在线充值
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

		orderParams.put("user_id", "623652");
		orderParams.put("paytype", "1");
		orderParams.put("fee", "1");
		orderParams.put("activity_info_id", "1");
		orderParams.put("city_id", "1");
		orderParams.put("mark", "1");

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("icard_recharge");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallIcardRecharge("", orderParams);
			logger.info(result.toJSONString());
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));



		} catch (Exception e) {
			e.printStackTrace();
		}







		
	
		
	}

}
