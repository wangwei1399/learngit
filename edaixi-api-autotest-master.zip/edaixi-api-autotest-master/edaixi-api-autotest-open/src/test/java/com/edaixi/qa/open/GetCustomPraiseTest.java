package com.edaixi.qa.open;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2016/1/7.
 */
public class GetCustomPraiseTest {

    private static Logger logger = LoggerFactory.getLogger(GetCustomPraiseTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testGetCustomPraise() throws SQLException{
    //首页好评展示
        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

        orderParams.put("page","1");
        orderParams.put("per_page","3");
        orderParams.put("random","1");//random=1,返回随机的，0就是不随机正常翻页

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_custom_praise");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallGetCustomPraise("", orderParams);
            logger.info(result.toJSONString());
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            JSONObject body = JSON.parseObject(result.getString("httpBody"));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }



}
