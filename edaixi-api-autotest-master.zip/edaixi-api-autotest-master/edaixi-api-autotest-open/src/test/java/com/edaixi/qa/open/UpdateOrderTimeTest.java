package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by huangwei on 16/3/12.
 */

public class UpdateOrderTimeTest {
    private static Logger logger = LoggerFactory.getLogger(UpdateOrderTimeTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testUpdateOrderTimeTest() throws SQLException {

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

//        String queryaddress="select id from ims_washing_order where status='0' and status_delivery='11'and pay_status=0 and totalprice=0;";
//        ResultSet queryResult=mysqlQaDao.execQuerySql(queryaddress);
//        String id=queryResult.getString("id");
//        logger.info("--------"+id);
        AllCreateOrderTest CreateOrderTest=new AllCreateOrderTest();
        String id=CreateOrderTest.testCreateOrder();

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        calendar.add(Calendar.DAY_OF_YEAR, 2);
        Date order_date = calendar.getTime();
        System.out.println("order_date is:"+date.format(order_date));

        String[] time = new String[]{"10:00-11:00","11:00-12:00","12:00-13:00",
                "13:00-14:00","14:00-15:00","15:00-16:00","16:00-17:00","17:00-18:00","18:00-19:00","19:00-20:00",
        "20:00-21:00","21:00-22:00"};
        String order_time="";
        int index=(int) (Math.random()*time.length);
        order_time=time[index];

        orderParams.put("user_id","623652");
        orderParams.put("order_id",id);
        orderParams.put("new_date",date.format(order_date));
        orderParams.put("new_time",order_time);
        //orderParams.put("asap",true);
        orderParams.put("flag","qu");


        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("update_order_time");



        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallUpdateOrderTimeTest("", orderParams);
            logger.info(result.toJSONString());


            //验证方法
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data = JSON.parseObject(body.getString("data"));
            System.out.println("--------"+data);
            String queryaddressInfo="select washing_date,washing_time from ims_washing_order where id="+id;
            ResultSet queryResult1=mysqlQaDao.execQuerySql(queryaddressInfo);

            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            Assert.assertEquals(true, result.getString("httpStatus").contains("201"));
           // Assert.assertEquals("返回值不符合预期",queryResult.getString("id"),data.getString("order_id"));//如果值不相同,返回Message
            Assert.assertEquals("返回值不符合预期",queryResult1.getString("washing_date"),date.format(order_date));
            Assert.assertEquals("返回值不符合预期",queryResult1.getString("washing_time"),order_time);
            Assert.assertEquals("返回值不符合预期",id,data.getString("order_id"));
            Assert.assertEquals("返回值不符合预期","您最多可修改3次时间",data.getString("cannot_change_qu_time_reason"));
           // Assert.assertEquals("返回值不符合预期","true",data.getString("asap"));



        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
