package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2015/12/30.
 */
public class GetQrcodeOrderInfoTest {

    private static Logger logger = LoggerFactory.getLogger(GetQrcodeOrderInfoTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test

    public void testGetQrcodeOrderInfo() throws SQLException{
        //获取最近未计价的订单信息
        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();


        orderParams.put("user_id","623652");
        orderParams.put("qrcode_order_id","2155803728841");

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_qrcode_order_info");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result= shareOpenModuleService.CallGetQrcodeOrderInfo("", orderParams);
            logger.info(result.toJSONString());
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
