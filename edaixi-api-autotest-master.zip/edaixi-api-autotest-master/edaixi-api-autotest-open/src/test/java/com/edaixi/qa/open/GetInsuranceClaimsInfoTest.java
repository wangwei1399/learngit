package com.edaixi.qa.open;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * Created by cherry on 2016/1/5.
 */


public class GetInsuranceClaimsInfoTest {

    private static Logger logger = LoggerFactory.getLogger(GetInsuranceClaimsInfoTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testGetInsuranceClaimsInfo() throws SQLException{
    //保险理赔弹窗控制
        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
        String[] city=new String[]{"1","2","3","4","5","6","7","8","9","10","11"};
        String city_id="";
        int i=(int) (Math.random()*city.length);
        city_id=city[i];
        orderParams.put("city_id",city_id);

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_insurance_claims_info");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallGetInsuranceClaimsInfo("", orderParams);
            logger.info(result.toJSONString());
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            JSONObject body = JSON.parseObject(result.getString("httpBody"));

        } catch (Exception e) {
            e.printStackTrace();
        }



    }

}
