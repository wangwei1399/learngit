package com.edaixi.qa.open;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

/**
 * Created by cherry on 2016/3/16.
 */
public class LuxuryDescriptionTest {

    private static Logger logger = LoggerFactory.getLogger(GetPriceByCategoryTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    @Before
    public void setUp() {

        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testLuxuryDescription() throws SQLException{

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

        String[] id=new String[]{"4","5"};
        String category_id="";
        int i=(int) Math.random()*id.length;
        category_id=id[i];
        orderParams.put("category_id",category_id);

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("luxury_description");

        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallLuxuryDescription("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body= JSON.parseObject(result.getString("httpBody"));
            JSONObject data=JSON.parseObject(body.getString("data"));
            JSONObject service_flow=JSON.parseObject(data.getString("service_flow"));
            logger.info(service_flow.toJSONString());
            JSONObject superiority=JSON.parseObject(data.getString("superiority"));
            logger.info(superiority.toJSONString());
            JSONObject maintenance_flow=JSON.parseObject(data.getString("maintenance_flow"));
            logger.info(maintenance_flow.toJSONString());
            JSONObject contrasting_case=JSON.parseObject(data.getString("contrasting_case"));
            logger.info(contrasting_case.toJSONString());

            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            Assert.assertEquals(true,result.getString("httpStatus").contains("200"));
            Assert.assertEquals("与预期结果不符","服务流程",service_flow.getString("title"));
            Assert.assertEquals("与预期结果不符","[\"暂无image_url.jpg\"]",service_flow.getString("image"));
            Assert.assertEquals("与预期结果不符","服务特色",superiority.getString("title"));
            Assert.assertEquals("与预期结果不符","[\"暂无1\",\"暂无2\",\"暂无3\",\"暂无4\"]",superiority.getString("text"));
            Assert.assertEquals("与预期结果不符","养护流程",maintenance_flow.getString("title"));
            Assert.assertEquals("与预期结果不符","[\"暂无image_url.jpg\"]",maintenance_flow.getString("image"));
            Assert.assertEquals("与预期结果不符","经典案例",contrasting_case.getString("title"));
            Assert.assertEquals("与预期结果不符","[\"暂无image_url.jpg\",\"暂无image_url.jpg\"]",contrasting_case.getString("image"));
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
