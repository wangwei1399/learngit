package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class BindRechargeTest {

	private static Logger logger = LoggerFactory.getLogger(BindRechargeTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testBindRecharge() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

		String queryId="SELECT sncode FROM ims_recharge_sncode WHERE used='0'and rid='295'";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryId);
		String sncode = queryResult.getString("sncode");

		orderParams.put("user_id","623652");
		orderParams.put("sncode",sncode);

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("bind_recharge");

		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallBindRecharge("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body= JSON.parseObject(result.getString("httpBody"));
			JSONObject data=JSON.parseObject(body.getString("data"));
			logger.info("------result------"+data);
			//验证数据库sncode状态,验证充值卡金额，验证充值类型，验证账户假钱是否和coin值相符
			String querysncodeInfo="select used,fan_id from ims_recharge_sncode where sncode="+sncode;
			ResultSet queryResult1 = mysqlQaDao.execQuerySql(querysncodeInfo);
			String queryrechargeInfo="select price from ims_recharge where id='295';";
			ResultSet queryResult2 = mysqlQaDao.execQuerySql(queryrechargeInfo);
			String queryicardInfo="select id,coin from ims_icard_card where fan_id='623652';";
			ResultSet queryResult3 = mysqlQaDao.execQuerySql(queryicardInfo);
			String cardId=queryResult3.getString("id");
			String queryvouchersInfo="select sum(jiaqian) from vouchers where card_id="+cardId;;
			ResultSet queryResult4 = mysqlQaDao.execQuerySql(queryvouchersInfo);
			String aa=queryResult4.getString("sum(jiaqian)");
			logger.info("totolprice:"+aa);
			String queryvouchersInfo1="select voucherable_type from vouchers where card_id="+cardId;;
			ResultSet queryResult5 = mysqlQaDao.execQuerySql(queryvouchersInfo1);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals(true, result.getString("httpStatus").contains("201"));
			Assert.assertEquals("返回值不符合预期", 1,queryResult1.getInt("used"));
			Assert.assertEquals("返回值不符合预期", 623652,queryResult1.getInt("fan_id"));
			Assert.assertEquals("返回值不符合预期", 100,queryResult2.getInt("price"));
			Assert.assertEquals("返回值不符合预期", "RechargeSncode",queryResult5.getString("voucherable_type"));
			Assert.assertEquals("返回值不符合预期", "1",data.getString("card_type"));
			Assert.assertEquals("返回值不符合预期", "充值成功，充值余额100元",data.getString("content"));
			//Assert.assertEquals("返回值不符合预期", queryResult3.getString("coin"),queryResult4.getString("sum(jiaqian)"));


		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

}
