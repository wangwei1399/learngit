package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

import java.util.Properties;

public class ShareOPenModuleService {
	private static Logger logger = LoggerFactory.getLogger(ShareOPenModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;
	private Properties openGlobalConf = null;
	private Properties payGlobalConf=null;

	public ShareOPenModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.openGlobalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.openGlobalConf.getProperty("edaixiopen"));
		//dmService.init(this.payGlobalConf.getProperty("edxpay"));
	}


	public JSONObject CallOrderCreate(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("create_order"), method, authorization, queryParam);

	}
	public JSONObject CallBindCoupon(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("bind_coupon"), method, authorization, queryParam);
	}

	public JSONObject CallBindHttpUser(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("bind_http_user"), method, authorization, queryParam);
	}

	public JSONObject CallBindMemberCard(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("bind_member_card"), method, authorization, queryParam);
	}
	public JSONObject CallBindRecharge(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("bind_recharge"), method, authorization, queryParam);
	}

	public JSONObject CallBindUser(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("bind_user"), method, authorization, queryParam);
	}
	public JSONObject CallCancelOrder(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("cancel_order"), method, authorization, queryParam);
	}

	public JSONObject CallCreateAddress(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("create_address"), method, authorization, queryParam);
	}
	public JSONObject CallCreateOrderComment(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("create_order_comment"), method, authorization, queryParam);
	}
	public JSONObject CallCreateQrcodeOrder(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("create_qrcode_order"), method, authorization, queryParam);
	}
	public JSONObject CallDeleteAddress(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("delete_address"), method, authorization, queryParam);
	}

	public JSONObject CallIcardRecharge(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("icard_recharge"), method, authorization, queryParam);
	}

	public JSONObject CallOrderEnvelopeIsShare(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_envelope_is_share"), method, authorization, queryParam);
	}

	public JSONObject CallPayOrder(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("pay_order2"), method, authorization, queryParam);
	}

	public JSONObject CallSendSms(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("send_sms"), method, authorization, queryParam);
	}

	public JSONObject CallSetFeedback(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("set_feedback"), method, authorization, queryParam);
	}

	public JSONObject CallSetOrderComplaints(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("set_order_complaints"), method, authorization, queryParam);
	}

	public JSONObject CallUpdateAddress(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("update_address"), method, authorization, queryParam);
	}

	public JSONObject CallVerifyAddress(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("verify_address"), method, authorization, queryParam);
	}

	public JSONObject CallOrderCancelReasons(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_cancel_reasons"), method, authorization, queryParam);
	}

	public JSONObject CallGetProductList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_product_list"), method, authorization, queryParam);
	}

	public JSONObject CallGetProduct(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_product"), method, authorization, queryParam);
	}

	public JSONObject CallGetAddressList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_address_list"), method, authorization, queryParam);
	}

	public JSONObject CallGetOrderList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_order_list"), method, authorization, queryParam);
	}

	public JSONObject CallGetBannerList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_banner_list"), method, authorization, queryParam);
	}

	public JSONObject CallGetFuncButtonList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_func_button_list"), method, authorization, queryParam);
	}

	public JSONObject CallCommentTextListNew(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("comment_text_list_new"), method, authorization, queryParam);
	}

	public JSONObject CallGetOrder(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_order"), method, authorization, queryParam);
	}
	public JSONObject CallOrderPayInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_pay_info"), method, authorization, queryParam);
	}
	public JSONObject CallOrderClothing(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_clothing"), method, authorization, queryParam);
	}
	public JSONObject CallOrderDeliveryStatusList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_delivery_status_list"), method, authorization, queryParam);
	}

	public JSONObject CallIcardDetails(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("icard_details"), method, authorization, queryParam);
	}

	public JSONObject CallGetCouponInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_coupon_info"), method, authorization, queryParam);
	}

	public JSONObject CallGetCoupons(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_coupons"), method, authorization, queryParam);
	}

	public JSONObject CallGetTwoCoupons(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_two_coupons"), method, authorization, queryParam);
	}

	public JSONObject CallGetCouponOutdatedTime(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_coupon_outdated_time"), method, authorization, queryParam);
	}
	public JSONObject CallGetIcard(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_icard"), method, authorization, queryParam);
	}

	public JSONObject CallGetExtraAccounts(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_extra_accounts"), method, authorization, queryParam);
	}

	public JSONObject CallGetKuaixiArea(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_kuaixi_area"), method, authorization, queryParam);
	}

	public JSONObject CallRechargeSettings(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("recharge_settings"), method, authorization, queryParam);
	}

	public JSONObject CallCitiesOptions(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("cities_options"), method, authorization, queryParam);
	}

	public JSONObject CallGetPaylog(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_paylog"), method, authorization, queryParam);
	}

	public JSONObject CallGetClients(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_clients"), method, authorization, queryParam);
	}
	public JSONObject CallGetCitys(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_citys"), method, authorization, queryParam);
	}

	public JSONObject CallGetCityDeliveryFee(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_city_delivery_fee"), method, authorization, queryParam);
	}

	public JSONObject CallGetBannerButtonList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_banner_button_list"), method, authorization, queryParam);
	}
	public JSONObject CallGetCategoryButtons(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_category_buttons"), method, authorization, queryParam);
	}
	public JSONObject CallGetDealDetail(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_deal_detail"), method, authorization, queryParam);
	}

	public JSONObject CallGetOrderComplain(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_order_complain"), method, authorization, queryParam);
	}

	public JSONObject CallSetOrderComplain(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("set_order_complain"), method, authorization, queryParam);
	}

	public JSONObject CallGetMallUrl(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_mall_url"), method, authorization, queryParam);
	}

	public JSONObject CallActivityPromotions(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("activity_promotions"), method, authorization, queryParam);
	}

	public JSONObject CallUserCenterInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("user_center_info"), method, authorization, queryParam);
	}

	public JSONObject CallGetQuickOrderInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_quick_order_info"), method, authorization, queryParam);
	}

	public JSONObject CallGetQrcodeOrderInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_qrcode_order_info"), method, authorization, queryParam);
	}

	public JSONObject CallGetServiceTime(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_service_time"), method, authorization, queryParam);
	}


	public JSONObject CallUsableCouponInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("usable_coupon_info"), method, authorization, queryParam);
	}

	public JSONObject CallGetDefaultPaytype(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_default_paytype"), method, authorization, queryParam);
	}

	public JSONObject CallGetCouponDescription(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_coupon_description"), method, authorization, queryParam);
	}

	public JSONObject CallSearchHotel(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("search_hotel"), method, authorization, queryParam);
	}

	public JSONObject CallGetFeedbackTypes(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_feedback_types"), method, authorization, queryParam);
	}

	public JSONObject CallGetInsuranceClaimsInfo(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_insurance_claims_info"), method, authorization, queryParam);
	}
	public JSONObject CallGetCustomPraise(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_custom_praise"), method, authorization, queryParam);
	}

	public JSONObject CallCreateOrderPage(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("create_order_page"), method, authorization, queryParam);
	}

	public JSONObject CallIcard(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("icard"), method, authorization, queryParam);
	}
	public JSONObject CallGetRechargeAmount(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_recharge_amount"), method, authorization, queryParam);
	}
	public JSONObject CallGetVerifyAddress(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_verify_address"), method, authorization, queryParam);
	}
	public JSONObject CallUpdateOrderTimeTest(String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("update_order_time"), method, authorization, queryParam);
	}
	public JSONObject CallGetPriceByCategory(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_price_by_category"), method, authorization, queryParam);
	}
	public JSONObject CallLuxuryDescription(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("luxury_description"), method, authorization, queryParam);
	}
	public JSONObject CallGetClothesByType(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_clothes_by_type"), method, authorization, queryParam);
	}
	public JSONObject CallCaclulateOrderPrice(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("caclulate_order_price"), method, authorization, queryParam);
	}
	public JSONObject CallOrderDiscount(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("order_discount"), method, authorization, queryParam);
	}
	public JSONObject CallGetWashingPrice(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_washing_price"), method, authorization, queryParam);
	}
	public JSONObject CallUserEcardList(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("user_ecard_list"), method, authorization, queryParam);
	}
	public JSONObject CallWallet(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("wallet"), method, authorization, queryParam);
	}
	public JSONObject CallHybridOrderPage(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("hybrid_order_page"), method, authorization, queryParam);
	}
	public JSONObject CallGetPromotionalOffers(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_promotional_offers"), method, authorization, queryParam);
	}

	public JSONObject CallGetNormalCategoriesPrice(String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("get_normal_categories_price"), method, authorization, queryParam);
	}
}
