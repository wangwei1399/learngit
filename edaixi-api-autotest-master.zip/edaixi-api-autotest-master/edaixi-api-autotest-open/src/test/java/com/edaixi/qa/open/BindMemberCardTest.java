package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;



public class BindMemberCardTest {

	private static Logger logger = LoggerFactory.getLogger(BindMemberCardTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testBindMemberCard() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String updateInfo="update ims_icard_card set rcard_sn='0' where fan_id='623652';";
		Boolean queryResult4 = mysqlQaDao.execUpdateSql(updateInfo);
		String queryfanid="SELECT fan_id FROM ims_clients;";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryfanid);
		String fan_id = queryResult.getString("fan_id");

		String querycode="SELECT sn_code FROM ims_rcard_members WHERE rid='11' AND icardid='0';";
		ResultSet queryResult1 = mysqlQaDao.execQuerySql(querycode);
		String sn_code = queryResult1.getString("sn_code");

		String querypassword="SELECT sn_password FROM ims_rcard_members WHERE sn_code="+sn_code;
		ResultSet queryResult2 = mysqlQaDao.execQuerySql(querypassword);
		String sn_password = queryResult2.getString("sn_password");

		orderParams.put("user_id","623652");
		orderParams.put("sn_code",sn_code);
		orderParams.put("sn_password",sn_password);

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("bind_member_card");



		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result =shareOpenModuleService.CallBindMemberCard("", orderParams);
			logger.info(result.toJSONString());
			String queryicardInfo="select rcard_sn from ims_icard_card where fan_id='623652';";
			ResultSet queryResult3 = mysqlQaDao.execQuerySql(queryicardInfo);
			JSONObject body = JSON.parseObject(result.getString("httpBody"));
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("返回值不符合预期",queryResult3.getString("rcard_sn"),queryResult1.getString("sn_code"));

		} catch (Exception e) {
			e.printStackTrace();
		}




	}




		
	
		

}
