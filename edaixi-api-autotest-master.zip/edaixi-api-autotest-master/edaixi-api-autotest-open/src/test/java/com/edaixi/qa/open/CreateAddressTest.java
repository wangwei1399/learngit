package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2015/12/28.
 */

public class CreateAddressTest {

	private static Logger logger = LoggerFactory.getLogger(CreateAddressTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testCreateAddress() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
//		String[] id=new String[]{"1","2","3","4","5"};
//		String category_id="";
//		int index=(int)(Math.random()*id.length);
//        category_id=id[index];
		String[] name1=new String[]{"北京","上海","深圳","天津","武汉","西安","南京","杭州","苏州","宁波","成都","广州","青岛","福州","无锡","重庆","石家庄","厦门","南宁","沈阳","长沙","徐州","常州","哈尔滨","株洲","佛山","银川"};
		String cityname;
		int j=(int)(Math.random()*name1.length);
		cityname=name1[j];
		String queryArea="select name,id from areas where is_show='1'and city_name=\'"+cityname+"\'";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryArea);
		String area = queryResult.getString("name");
		String area_id=queryResult.getString("id");
		String queryAreasCategories="select service_category_id from areas_service_categories where is_shown='1'and area_id="+area_id;
		ResultSet queryResult3=mysqlQaDao.execQuerySql(queryAreasCategories);
		String category_id=queryResult3.getString("service_category_id");
		orderParams.put("user_id","623652");
		orderParams.put("user_type","1");
		//orderParams.put("client_id","1");
		//orderParams.put("province","北京");
		//参数可选
		orderParams.put("username","刘美婷");
//		orderParams.put("category_id",category_id);
		orderParams.put("city","北京");
		orderParams.put("area","朝阳区");
		orderParams.put("city_id",1);
		orderParams.put("area_id",1);
		orderParams.put("tel","13400000000");
		orderParams.put("gender","女士");
		orderParams.put("address_line_1","天涯海角");
		orderParams.put("address_line_2","月坛17号");
//		orderParams.put("customer_lng","月坛17号");
//		orderParams.put("customer_lat","1");
//参数可选
		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("create_address");



		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallCreateAddress("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body = JSON.parseObject(result.getString("httpBody"));
			String data = body.getString("data");
			String queryaddressInfo="select fan_id,deleted,city_id,city,type from ims_washing_address where id="+data;
			ResultSet queryResult2 = mysqlQaDao.execQuerySql(queryaddressInfo);
			String querycityInfo="select id from cities where name='"+cityname+"\'";
			ResultSet queryResult1 = mysqlQaDao.execQuerySql(querycityInfo);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("不符合预期结果",623652,queryResult2.getInt("fan_id"));
			Assert.assertEquals("不符合预期结果",cityname,queryResult2.getString("city"));
			Assert.assertEquals("不符合预期结果",queryResult1.getInt("id"),queryResult2.getInt("city_id"));
			Assert.assertEquals("不符合预期结果",0,queryResult2.getInt("deleted"));
			Assert.assertEquals("不符合预期结果","Address",queryResult2.getString("type"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		



		
	}

}
