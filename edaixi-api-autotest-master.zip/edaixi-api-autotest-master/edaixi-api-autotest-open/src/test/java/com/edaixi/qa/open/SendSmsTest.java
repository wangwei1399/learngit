package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;



public class SendSmsTest {

	private static Logger logger = LoggerFactory.getLogger(SearchHotelTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();


	public void testSendSms() throws SQLException{
		this.openGlobalConf = GlobalConfig.getProperties();
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String deletecode="delete from ims_washing_mobile where mobile='13400000000';";
		mysqlQaDao.execUpdateSql(deletecode);
		orderParams.put("user_id", "623652");
		orderParams.put("phone", "13400000000");

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("send_sms");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallSendSms("", orderParams);
			logger.info(result.toJSONString());
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			//Assert.assertEquals(true, result.getString("httpBody").contains("\"data\":\"true\""));

		} catch (Exception e) {
			e.printStackTrace();
		}

		

	}

}
