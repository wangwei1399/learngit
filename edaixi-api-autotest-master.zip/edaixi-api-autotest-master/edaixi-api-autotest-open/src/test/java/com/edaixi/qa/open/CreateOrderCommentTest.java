package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2015/12/28.
 */


public class CreateOrderCommentTest {


	private static Logger logger = LoggerFactory.getLogger(CreateOrderCommentTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testCreateOrderComment() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		AllCreateOrderTest CreateOrder=new AllCreateOrderTest();
		String order_id=CreateOrder.testCreateOrder();
		String updateAddress = "UPDATE ims_washing_order SET `status`='7',status_delivery='3' WHERE id="+order_id;
		mysqlQaDao.execUpdateSql(updateAddress);
//		String queryId="SELECT id FROM ims_washing_order WHERE fan_id='623652' AND `status`='7' AND status_delivery='3';";
//		ResultSet queryResult = mysqlQaDao.execQuerySql(queryId);
//		String id = queryResult.getString("id");
		String queryicard="select coin from ims_icard_card where fan_id='623652';";
		ResultSet queryResult1=mysqlQaDao.execQuerySql(queryicard);
		String coin=queryResult1.getString("coin");
		logger.info("money-------------------------:"+coin);
		orderParams.put("user_id", "623652");
		orderParams.put("order_id", order_id);
		orderParams.put("total_score", "1");
		orderParams.put("washing_score", "1");
		orderParams.put("logistics_score", "1");
		orderParams.put("service_score", "1");
		orderParams.put("comment", "1");
		orderParams.put("city_id", "1");
		orderParams.put("comment_fetch_option", "1");
		orderParams.put("comment_carry_option", "1");

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("create_order_comment");



		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallCreateOrderComment("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body = JSON.parseObject(result.getString("httpBody"));
			JSONObject data=JSON.parseObject(body.getString("data"));
			logger.info("------"+data);
			String money=data.getString("money");
			String queryorder="select ordersn from ims_washing_order where id="+order_id;
			ResultSet queryResult2=mysqlQaDao.execQuerySql(queryorder);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals(true, result.getString("httpStatus").contains("201"));
			Assert.assertEquals("不符合预期结果", queryResult2.getString("ordersn"),data.getString("ordersn"));



		} catch (Exception e) {
			e.printStackTrace();
		}

	}



}
