package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class UpdateAddressTest {

	private static Logger logger = LoggerFactory.getLogger(UpdateAddressTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testUpdateAddress() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

		String queryId="SELECT id,deleted FROM ims_washing_address WHERE fan_id='623652';";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryId);
		String id = queryResult.getString("id");

		String queryName="SELECT name,id FROM areas WHERE city_name='北京'and is_show='1';";
		ResultSet queryResult3=mysqlQaDao.execQuerySql(queryName);
		String name=queryResult3.getString("name");
		String area_id=queryResult3.getString("id");
		orderParams.put("user_id", "623652");
		orderParams.put("address_id",id);
		orderParams.put("username","美美哒");
		orderParams.put("city","北京");
		orderParams.put("area",name);
		orderParams.put("city_id","1");
		orderParams.put("area_id",area_id);
		orderParams.put("tel","13400000000");
		orderParams.put("address_line_1","月坛17号");
		orderParams.put("address_line_2","月坛17号");


		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("update_address");

		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallUpdateAddress("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body = JSON.parseObject(result.getString("httpBody"));
			JSONObject data=JSON.parseObject(body.getString("data"));
			logger.info("-----result"+data);
			String querydeleted="SELECT id,deleted FROM ims_washing_address WHERE id="+id;
			ResultSet queryResult4 = mysqlQaDao.execQuerySql(querydeleted);
			String address_new=data.getString("address_id");
			String querydeleted1="SELECT deleted FROM ims_washing_address WHERE id="+address_new;
			ResultSet queryResult5 = mysqlQaDao.execQuerySql(querydeleted1);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("不符合预期结果","1",queryResult4.getString("deleted"));
			Assert.assertEquals("不符合预期结果","0",queryResult5.getString("deleted"));
			Assert.assertEquals("不符合预期结果","美美哒",data.getString("username"));

		} catch (Exception e) {
			e.printStackTrace();
		}









	}



}
