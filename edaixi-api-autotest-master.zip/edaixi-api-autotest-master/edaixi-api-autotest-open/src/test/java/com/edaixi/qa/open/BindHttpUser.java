package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;
//ca30a785

	public class BindHttpUser {




		public static String testBindHttpUser() {
			//public static void main(String[] args){

			HashMap<String, Object> orderParams = new HashMap<String, Object>();
			ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();

			orderParams.put("user_type", "1");
			orderParams.put("from_user", "13400000000");
			String getTokenUrl = " http://open07.edaixi.cn:81/client/v1/bind_http_user?";

			try {
				String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
				orderParams.put("sign", signUrl);
				System.out.println("--signUrlbinderuser-----" + signUrl);
				JSONObject result;
				result = shareOpenModuleService.CallBindHttpUser("", orderParams);
				System.out.println("--signUrlbinderesult-----"+result);
				//Logger.info(result.toJSONString());
				//Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

				JSONObject body = JSON.parseObject(result.getString("httpBody"));
				JSONObject data = JSON.parseObject(body.getString("data"));
				String user_token = data.getString("user_token");
				System.out.println("----user_token----"+user_token);
				return user_token;

			} catch (Exception e) {
				e.printStackTrace();
			}
			return "";
			}


	}

