package com.edaixi.qa.open;

/**
 * Created by cherry on 2016/2/26.
 */
    public class AppraiseBeanTest {
    public AppraiseBeanTest() {

    }

    String level;

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    String comment;


    String address_id;

    public String getAddress_id(){

        return  address_id;
    }
    public void setAddress_id(String address_id){
        this.address_id=address_id;
    }



}