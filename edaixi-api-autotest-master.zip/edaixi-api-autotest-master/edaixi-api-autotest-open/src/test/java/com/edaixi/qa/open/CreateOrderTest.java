package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.text.SimpleDateFormat;



/**
 * Created by cherry on 2015/12/28.
 */

public class CreateOrderTest {

	private static Logger logger = LoggerFactory.getLogger(CreateOrderTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testCreateOrder() throws SQLException{
		//public String testCreateOrder() throws SQLException{
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		long currentTime = System.currentTimeMillis();
		int fan_id=623652;
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		Date order_date = calendar.getTime();
		System.out.println("order_date is:"+date.format(order_date));

		String[] time = new String[]{"10:00-11:00;[40,44]","11:00-12:00;[44,48]","12:00-13:00;[48,52]",
				"13:00-14:00;[52,56]","14:00-15:00;[56,60]","15:00-16:00;[60,64]","16:00-17:00;[64,68]","17:00-18:00;[68,72]","18:00-19:00;[72,76]","19:00-20:00;[76,80]",
				"20:00-21:00;[76,80]","21:00-22:00;[80,84]"};
		String order_time="";
		int index=(int) (Math.random()*time.length);
		order_time=time[index];
		System.out.println("order_time is:"+order_time);
		String a[]=order_time.split(";");
		String order_time1=a[0];
		String time_range=a[1];
		//System.out.println("----fenge---"+order_time1);
		String[] id = new String[]{"1","2","3"};
		String category_id="";
		int i=(int) (Math.random()*id.length);
		category_id=id[i];
		System.out.println("category_id is:"+category_id);
		String queryaddressInfo="select id from ims_washing_address where fan_id='623652';";
		ResultSet queryResult=mysqlQaDao.execQuerySql(queryaddressInfo);
		String address_id=queryResult.getString("id");
//		String inserttAddress = "INSERT INTO ims_washing_address(id,fan_id,username,city,area,address,tel,city_id,type) VALUES ( "
//				+ address_id + ", '623652', '刘美婷', '北京', '昌平区', '美丽的海角七号', '17788888888', '1', 'Address');";

		orderParams.put("user_id","623652");
		orderParams.put("user_type","1");
		orderParams.put("category_id",category_id);
		orderParams.put("address_id",address_id);
		orderParams.put("order_date",date.format(order_date));
		orderParams.put("order_time",order_time1);
		orderParams.put("time_range",time_range);
		orderParams.put("comment","remark1111111");
		orderParams.put("take_soon",false);

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("create_order");

		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallOrderCreate("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body=JSON.parseObject(result.getString("httpBody"));
			//String data=body.getString("data");
			JSONArray data=JSON.parseArray(body.getString("data"));
			System.out.println("----"+data.get(0));

			String queryorderInfo="select fan_id,`status`,status_delivery,pay_status from ims_washing_order where id="+data.get(0);
			ResultSet queryResult1 = mysqlQaDao.execQuerySql(queryorderInfo);
			Assert.assertEquals("不符合预期结果","true",body.getString("ret"));
			Assert.assertEquals("不符合预期结果",623652,queryResult1.getInt("fan_id"));
			Assert.assertEquals("不符合预期结果",0,queryResult1.getInt("status"));
			Assert.assertEquals("不符合预期结果",11,queryResult1.getInt("status_delivery"));
			Assert.assertEquals("不符合预期结果",0,queryResult1.getInt("pay_status"));



		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}