package com.edaixi.qa.open;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by cherry on 2016/4/13.
 */
public class AllGetId {

     public static void main(String[] args) throws SQLException {
         MysqlQaDao mysqlQaDao = new MysqlQaDao();
         String queryId="select id from dispatch_tasks order by id DESC limit 1;";
         ResultSet Result=mysqlQaDao.execQuerySql(queryId);
         int id1= 0;
         AllCreateOrderTest CreateOrder=new AllCreateOrderTest();
         String order_id=CreateOrder.testCreateOrder();
         try {
             id1 = Result.getInt("id");
             System.out.println("----id1是----"+id1);
             int id2=id1+1;
             System.out.println("-----id2是---"+id2);
             String sql = "insert into dispatch_tasks(id,order_id,status,from_type,from_id,to_type,to_id,dispatch_type,courier_id,hope_time,finished_at,category_id,created_at,updated_at,type,ordersn,city_id,extra_type) " +
                           "values("+ id2+","+ order_id+",'dispatched','jiagongdian',NULL,'Address',596281,0,15,'2016-04-13 19:00:00',NULL,1,'2016-04-13 14:03:31','2016-04-13 14:04:27','DispatchTask',NULL,1,0);";
             Boolean sqlResult = mysqlQaDao.execUpdateSql(sql);
         } catch (SQLException e) {
             e.printStackTrace();
         }

     }
}
//        return lastId;
//    }
//    public static int get_dispatch(MysqlQaDao mysqlQaDao) throws SQLException {
//        String sql_get_lastId = "select id from dispatch_tasks order by id DESC limit 1;";
//
//
//
//            String now_id = String.valueOf(getLastId("select id from dispatch_tasks order by id DESC limit 1;", mysqlQaDao)+1);
//            String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
//            AllCreateOrderTest CreateOrder=new AllCreateOrderTest();
//
////            String order_id;
////            String sql =
////                    "insert into dispatch_tasks(id,order_id,status,from_id,to_type,to_id,dispatch_type,courier_id,hope_time,finished_at,category_id,created_at,updated_at,type,ordersn,city_id,extra_type) " +
////                            "values("+ now_id+","+ order_id+",'000000',18881112222,0,1,'332a4cb08505866c8a85c37dff128a28','"+time+"','"+time+"','北京',1,NULL,1,62258810454536652,110105199885523652,'工商银行',1,1,1,'EZB-0010-000"+now_id+"',NULL,NULL,'com."+now_id+".zhongbao',1,1,1,'android_client',0,0,NULL,0,NULL,'男',NULL,NULL,0,0,NULL,NULL,0,1457432520,1489043736,NULL,0,NULL,0,0,1,0,'接口自动化测试',0,NULL,'个把',12566365425);";
////            mysqlQaDao.execUpdateSql(sql);
////            return get_dispatch(mysqlQaDao);
//        }
//    }




