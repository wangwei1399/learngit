package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Created by cherry on 2016/6/23.
 */
public class WalletTest {
    private static Logger logger = LoggerFactory.getLogger(WalletTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.openGlobalConf = GlobalConfig.getProperties();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testWallet() throws SQLException {

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();


        orderParams.put("user_id", "623652");


        String getTokenUrl = this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("wallet");


        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallWallet("", orderParams);
            logger.info(result.toJSONString());
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data=JSON.parseObject(body.getString("data"));
           // String querynum="select count from ims_icoupon_sncode where fan_id='623652' and used='0';";
            String queryamount="select coin from ims_icard_card where fan_id='623652';";
            ResultSet queryresult=mysqlQaDao.execQuerySql(queryamount);
            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
//            Assert.assertEquals("不符合预期结果",data.getString("address_id"),data.getString("coupon_num"));
//            Assert.assertEquals("不符合预期结果",data.getString("address_id"),data.getString("ecard_num"));
            Assert.assertEquals("不符合预期结果",queryresult.getString("coin"),data.getString("icard_amount"));
            Assert.assertEquals("不符合预期结果","623652",data.getString("user_id"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
