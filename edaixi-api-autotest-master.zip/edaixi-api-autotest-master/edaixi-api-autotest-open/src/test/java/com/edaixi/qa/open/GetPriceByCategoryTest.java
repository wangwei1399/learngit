package com.edaixi.qa.open;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by cherry on 2016/3/15.
 */


public class GetPriceByCategoryTest {

    private static Logger logger = LoggerFactory.getLogger(GetPriceByCategoryTest.class);
    private Properties openGlobalConf = null;
    private Map<String, Object> orderParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    @Before
    public void setUp() {

        this.openGlobalConf = GlobalConfig.getProperties();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test

    public void testGetPriceByCategory() throws SQLException{

        HashMap<String, Object> orderParams = new HashMap<String, Object>();
        ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
        String querycityInfo="select id from cities where is_show=1;";
        ResultSet queryResult=mysqlQaDao.execQuerySqlAllRet(querycityInfo);
        ArrayList<String> list =new ArrayList<String>();
        while (queryResult.next()) {
               // System.out.println("---one----"+queryResult.getString("id"));
            list.add(queryResult.getString("id"));
            }
        System.out.println(list.size());


//        if(list != null && list.size() > 0) {
//
//
//        }
        Random random = new Random();
        int randomIndex = random.nextInt(list.size());
        String city_id = list.get(randomIndex);
        System.out.println("city_id:" + city_id);
        String querycategory = "select service_category_id from category_cities where city_id=" + city_id;
        ResultSet queryResult1 = mysqlQaDao.execQuerySql(querycategory);
        String category_id = queryResult1.getString("service_category_id");
        orderParams.put("city_id", city_id);
        orderParams.put("category_id", category_id);

        String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("get_price_by_category");

        try {
            String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
            orderParams.put("sign", signUrl);//签名
            System.out.println("--signUrl-----" + signUrl);
            JSONObject result = shareOpenModuleService.CallGetPriceByCategory("", orderParams);
            System.out.println(result.toJSONString());
            JSONObject body = JSON.parseObject(result.getString("httpBody"));
            JSONObject data = JSON.parseObject(body.getString("data"));
            String querycategories="select name,description from service_categories where id="+category_id;
            ResultSet queryResult2=mysqlQaDao.execQuerySql(querycategories);
            String description=queryResult2.getString("description");
            ArrayList<String> list1=new ArrayList<String>();
            list1.add(data.getString("descriptions"));
            List<String> descList = JSON.parseArray(data.getString("descriptions"),String.class);
            System.out.println("------------this is descList------------");
            for(int i = 0; i < descList.size();i++){
               System.out.println(descList.get(i));

            }

            String[] strarry=description.split(";;");
            System.out.println("------------fenge------------");
            for(int j=0;j<strarry.length;j++){

                System.out.println(strarry[j]);
            }



//            ArrayList<String> list2=new ArrayList<String>();
//            list2.add(queryResult2.getString("description"));
//            System.out.println("------------this is descList1------------after");
//            for(int j = 0; j < list2.size();j++){
//
//                Object obj=list2.get(j);
//                System.out.println(obj);
//            }


            Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
            Assert.assertEquals(true, result.getString("httpStatus").contains("200"));
            Assert.assertEquals("与预期结果不符", queryResult1.getString("service_category_id"),data.getString("category_id"));
            Assert.assertEquals("与预期结果不符", queryResult2.getString("name"),data.getString("categotry_name"));
         //   Assert.assertEquals("与预期结果不符", strarry[j],descList.get(i));

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
