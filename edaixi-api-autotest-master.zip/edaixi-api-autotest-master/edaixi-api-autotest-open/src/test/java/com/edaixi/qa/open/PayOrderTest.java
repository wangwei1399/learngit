package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import static java.lang.System.*;

public class PayOrderTest {

	private static Logger logger = LoggerFactory.getLogger(PayOrderTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testPayOrder() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String querycid="SELECT id FROM ims_icoupon_sncode WHERE fan_id='623652'and used=0;";
		ResultSet queryResult = mysqlQaDao.execQuerySql(querycid);
		String coupon_id = queryResult.getString("id");
		AllCreateOrderTest createorder=new AllCreateOrderTest();
		String id=createorder.testCreateOrder();
		String upateid="UPDATE ims_washing_order SET `status`='1',status_delivery='9',totalprice='50'WHERE id= "+id;
		Boolean updateResult=mysqlQaDao.execUpdateSql(upateid);
		AllBindCouponTest BindCoupon=new AllBindCouponTest();
		BindCoupon.testBindCoupon();

		orderParams.put("user_id", "623652");
		orderParams.put("order_id", id);
		orderParams.put("paytype", "1");
		orderParams.put("coupon_id", coupon_id);
		orderParams.put("activity_info_id", "1");
		orderParams.put("city_id", "1");
		//orderParams.put("mark", "1");

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("order_clothing");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallPayOrder("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body= JSON.parseObject(result.getString("httpBody"));
			JSONObject data=JSON.parseObject(body.getString("data"));
			String data1=data.getString("data");
			logger.info(data1);
			String queryorderInfo="select ordersn from ims_washing_order where id="+id;
			ResultSet queryResult1=mysqlQaDao.execQuerySql(queryorderInfo);
			String queryicouponInfo="select order_sn,used from ims_icoupon_sncode where id="+coupon_id;
			ResultSet queryResult2=mysqlQaDao.execQuerySql(queryicouponInfo);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("与预期结果不一致", "true",data.getString("data"));
			Assert.assertEquals("与预期结果不一致", queryResult2.getString("order_sn"),queryResult1.getString("ordersn"));
			Assert.assertEquals("与预期结果不一致", "1",queryResult2.getString("used"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	

	}

}
