package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class BindUserTest {

	private static Logger logger = LoggerFactory.getLogger(BindUserTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testBindUser() throws SQLException{
		SendSmsTest send=new SendSmsTest();
		send.testSendSms();
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String querycode="SELECT code FROM ims_washing_mobile WHERE mobile='13400000000';";
		ResultSet queryResult = mysqlQaDao.execQuerySql(querycode);
		String code = queryResult.getString("code");

		orderParams.put("phone","13400000000");
		orderParams.put("code",code);
		orderParams.put("user_type","20");

		String getTokenUrl1=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("bind_user");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl1, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallBindUser("", orderParams);
			logger.info(result.toJSONString());
			JSONObject body = JSON.parseObject(result.getString("httpBody"));
			JSONObject data=JSON.parseObject(body.getString("data"));
			System.out.println("-----"+data);
			//验证用户信息是否正确
			String queryUserInfo="select fan_id,id from ims_clients where mobile='13400000000';";
			ResultSet queryResult1 = mysqlQaDao.execQuerySql(queryUserInfo);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("返回值不符合预期","201",result.getString("httpStatus"));
			Assert.assertEquals("返回值不符合预期", queryResult1.getString("fan_id"),data.getString("user_id"));
			Assert.assertEquals("返回值不符合预期", queryResult1.getString("id"),data.getString("client_id"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	 }


}
