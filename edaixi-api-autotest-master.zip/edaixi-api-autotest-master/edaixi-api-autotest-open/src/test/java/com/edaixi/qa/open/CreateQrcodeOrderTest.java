package com.edaixi.qa.open;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;



public class CreateQrcodeOrderTest {

	private static Logger logger = LoggerFactory.getLogger(CreateQrcodeOrderTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testCreateQrcodeOrder() throws SQLException{
    	//扫码揽收创建订单
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
		calendar.add(Calendar.DAY_OF_YEAR, 1);
		Date order_date = calendar.getTime();
		System.out.println("order_date is:"+date.format(order_date));

		String[] time = new String[]{"10:00-12:00","12:00-14:00","14:00-16:00",
				"16:00-18:00","18:00-20:00","20:00-22:00","22:00-24:00"};
		String order_time="";
		int index=(int) (Math.random()*time.length);
		order_time=time[index];
		System.out.println("order_time is:"+order_time);

		String[] id1 = new String[]{"1","2","3","4","5"};
		String category_id="";
		int i=(int) (Math.random()*id1.length);
		category_id=id1[i];
		System.out.println("category_id is:"+category_id);

		String queryOpenId="SELECT id FROM ims_washing_address;";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryOpenId);
		String id = queryResult.getString("id");

//		String queryqrcid="SELECT qrcid FROM ims_qrcode_temporary;";
//		ResultSet queryResult = mysqlQaDao.execQuerySql(queryqrcid);
//		String qrcid = queryResult.getString("qrcid");
		long currentTime = System.currentTimeMillis();
		int qrcid = (int)(currentTime % 1000);

		orderParams.put("user_id","623652");
		orderParams.put("user_type","1");
		orderParams.put("totalnum","1");
		orderParams.put("paytype","1");
		orderParams.put("comment","1");
		orderParams.put("order_date",order_date);
		orderParams.put("order_time",order_time);
		orderParams.put("address_id",id);
		orderParams.put("good","1112");
		orderParams.put("coupon_id","1112");
		orderParams.put("skip_quota_check",true);
		orderParams.put("is_lanshou",true);
		orderParams.put("qrcode_order_id","215580372885");
		orderParams.put("category_id",category_id);
		orderParams.put("back_type","1");//1是扫码揽收，2是自提
		orderParams.put("tel","13000000000");
		orderParams.put("mark","123456");



		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("create_qrcode_order");



		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallCreateQrcodeOrder("", orderParams);
			logger.info(result.toJSONString());
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			JSONObject body = JSON.parseObject(result.getString("httpBody"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		

	


		
	}
	
	
	

}
