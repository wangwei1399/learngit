package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


public class SetOrderComplaintsTest {

	private static Logger logger = LoggerFactory.getLogger(SetOrderComplaintsTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testSetOrderComplaints() throws SQLException{
    //投诉
		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String queryId="SELECT id FROM ims_washing_order WHERE fan_id='623652';";
		ResultSet queryResult = mysqlQaDao.execQuerySql(queryId);
		String id = queryResult.getString("id");
		orderParams.put("user_id", "623652");
		orderParams.put("order_id", id);
		orderParams.put("complaint", "服务挺好的");

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("set_order_complaints");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallSetOrderComplaints("", orderParams);
			logger.info(result.toJSONString());
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

		} catch (Exception e) {
			e.printStackTrace();
		}
		

		
	
		
	}

}
