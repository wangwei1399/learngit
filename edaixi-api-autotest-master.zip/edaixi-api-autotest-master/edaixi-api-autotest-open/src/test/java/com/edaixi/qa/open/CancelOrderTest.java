package com.edaixi.qa.open;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class CancelOrderTest {

	private static Logger logger = LoggerFactory.getLogger(CancelOrderTest.class);
	private Properties openGlobalConf = null;
	private Map<String, Object> orderParams = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

	@Before
	public void setUp() {
		this.openGlobalConf = GlobalConfig.getProperties();
	}
	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testCancelOrder() throws SQLException{

		HashMap<String, Object> orderParams = new HashMap<String, Object>();
		ShareOPenModuleService shareOpenModuleService = new ShareOPenModuleService();
		String[] reason=new String[]{"1","2","3","4","5"};
		String reason_id="";
		int i=(int) (Math.random()*reason.length);
		reason_id=reason[i];
		AllCreateOrderTest CreateOrder=new AllCreateOrderTest();
		String id=CreateOrder.testCreateOrder();

		orderParams.put("user_id","623652");
		orderParams.put("order_id",id);
		orderParams.put("reason",reason_id);
//		orderParams.put("city_id","1");
//		orderParams.put("mark","1");//可不用，扩展使用

		String getTokenUrl=this.openGlobalConf.getProperty("edaixiopen") + this.openGlobalConf.getProperty("cancel_order");


		try {
			String signUrl = AuthorizationTest.signHttpUrl(getTokenUrl, orderParams);
			orderParams.put("sign", signUrl);//签名
			System.out.println("--signUrl-----" + signUrl);
			JSONObject result = shareOpenModuleService.CallCancelOrder("", orderParams);
			logger.info(result.toJSONString());
			String queryorderInfo="select `status`,pay_status,fan_id from ims_washing_order where id="+id;
			ResultSet queryResult1 = mysqlQaDao.execQuerySql(queryorderInfo);
			Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
			Assert.assertEquals("不符合预期结果","-1",queryResult1.getString("status"));
			Assert.assertEquals("不符合预期结果","0",queryResult1.getString("pay_status"));
			Assert.assertEquals("不符合预期结果","623652",queryResult1.getString("fan_id"));


		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

	

}
