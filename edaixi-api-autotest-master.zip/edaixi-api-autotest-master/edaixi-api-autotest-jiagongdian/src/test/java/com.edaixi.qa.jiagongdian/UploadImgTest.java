package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class UploadImgTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testUploadImg() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("jiagongdian_id", "458");
        this.queryParams.put("ordersn", "16021740003865");
        this.queryParams.put("bagsn","00065280928");

        long currentTime = System.currentTimeMillis();
        String ywtmh = (Long.toString(currentTime)).substring(1, 9);

        String strdata = "[{\"ywtmh\":\"" + ywtmh + "\",\"images\":[{\"url\":\"http://jiagd-10005075.image.myqcloud.com/16030198504224-000026518-%E8%A2%96%E5%8F%A3%E7%A3%A8%E6%8D%9F-0\", \"index\":\"0\",\"width\":\"1440\", \"height\":\"900\", \"xiaci\":\"袖口磨损\"}]}]";

        this.queryParams.put("data",strdata);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallUploadImg("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
    }
}