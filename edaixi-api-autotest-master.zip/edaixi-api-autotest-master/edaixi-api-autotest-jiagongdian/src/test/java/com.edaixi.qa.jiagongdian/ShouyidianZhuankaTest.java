package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ShouyidianZhuankaTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testShouyidianZhuanka() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        String num = (Long.toString(currentTime)).substring(4, 13);

        this.queryParams.put("app_key", "jiagongdian_app");

        this.queryParams.put("card_type", "单店卡");
        this.queryParams.put("shop_id", "1695");
        this.queryParams.put("num", num);
        this.queryParams.put("money", "0.01");
        this.queryParams.put("tel", "13681057539");
        this.queryParams.put("discount", "0.58");
        this.queryParams.put("bianma", "y10167");
        this.queryParams.put("machine_code", "7D09899A");
        //this.queryParams.put("jiagongdian_id", "458");
        //this.queryParams.put("mame", "");
        //this.queryParams.put("cus_id", "");
        //this.queryParams.put("date_from", "");
        //this.queryParams.put("date_to", "");
        //this.queryParams.put("use", "");
        //this.queryParams.put("discount_again", "");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallShouyidianZhuanka("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("personal_balance"));
        Assert.assertEquals(true, result.getString("httpBody").contains("expired_time"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"user_phone\":\"13681057539\""));
    }
}