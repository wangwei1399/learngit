package com.edaixi.qa.jiagongdian;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by guolaidong on 2016/5/11.
 */
public class OrderDabao {
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    /**
     * 数据准备
     */
    long currentTime = System.currentTimeMillis();
    long unixTimestamp =currentTime/1000;
    String a = "4";
    //订单号
    long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
    //封签号
    String bagsn = (Long.toString(currentTime)).substring(2, 13);

    public String creatOrderDabao() throws SQLException {

        //当前日期
        String todayTime = (new SimpleDateFormat("yyyy-MM-dd")).format(new Date());
        String dateTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        String lastSixordersn = (Long.toString(ordersn)).substring(8, 14);


        //插入数据库新订单
        //ims_washing_order订单表里插入数据
        String strChukuOrder = "insert into ims_washing_order (from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid,status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time,createtime,qujian_paidan_time," +
                "qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time,jiagongdian_qianshou_time,jiagongdian_id," +
                "wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time,wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time," +
                "jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status,diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi," +
                "yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id," +
                "address_song_id,auto_dispatched_qu_at,auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count," +
                "washing_duration,model_version) " +
                "values" +
                "(NULL,'3','"+ordersn+"','"+bagsn+"','1','25.00','10.00','','0.00','25.00','25.00','1','6','','','1','1','','"+todayTime+"','18:00-20:00','','','郭来东','13681057539','北京','平谷区','世纪广场','北京','平谷区','世纪广场','3425','0','0',NULL,'0',NULL,'0',NULL,'"+unixTimestamp+"','"+unixTimestamp+"','"+unixTimestamp+"','0','0','0',NULL,NULL,NULL,'"+unixTimestamp+"','458',NULL,NULL,NULL,NULL,NULL,NULL,'"+unixTimestamp+"','"+unixTimestamp+"','"+unixTimestamp+"',NULL,NULL,'"+dateTime+"','"+dateTime+"','0','"+unixTimestamp+"','29','0',NULL,'0','0','0','623419',NULL,'18','2411','138','139',NULL,NULL,NULL,'458','595723','595723',NULL,NULL,'"+lastSixordersn+"','1','0',NULL,'1339874','0.00',NULL,NULL,'24','0');";
        mysqlQaDao.execUpdateSql(strChukuOrder);

        String strOrder = "select id from ims_washing_order where bagsn = '" + bagsn + "'";
        ResultSet resOrderid = mysqlQaDao.execQuerySql(strOrder);
        String orderId = resOrderid.getString(1);

        /**
         *   //ims_washing_order_bags_clothing衣物明细表里插入数据
         String stryiwu = "insert into `ims_washing_order_bags_clothing` (`ordersn`, `bagsn`, `shmxid`, `shdid`, `ywtmh`, `ywmc`, `ywdc`, `ywcl`, `ywys`, `ywwg`, `dsdj`, " +
         "`sjjg`, `pp`, `xc`, `xhxg`, `order_id`, `can_wash`, `created_at`, `updated_at`, `cannot_fanxi`, `cloth_id`, `rewash_reason`, `rewash`, `verify_code`, `yywtmh`, " +
         "`primary_fanxi_xc`, `primary_op`, `secondary_fanxi_xc`, `secondary_op`, `cannot_wash_reason`, `real_created_at`) " +
         "values" +
         "('"+ordersn+"','"+bagsn+"','42803','e10999','"+ywtmh+"','风衣','普通','e袋洗','靛青','','39.00','19.00','','','','"+orderId+"','1','"+dateTime+"','"+dateTime+"'," +
         "'0','3','','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'"+dateTime+"');";
         mysqlQaDao.execUpdateSql(stryiwu);
         */

        //做交接单数据
        //dispatch_tasks表里插入数据
        String strdispatch = "insert into dispatch_tasks (order_id, status, from_type, from_id, to_type, to_id, dispatch_type, courier_id, hope_time, finished_at, category_id, created_at, updated_at, type, ordersn, city_id) values('"+orderId+"','finished','jiagongdian',NULL,'Address','595723','0','3425','"+dateTime+"','"+dateTime+"','1','"+dateTime+"','"+dateTime+"','DispatchTask',NULL,'1');";
        mysqlQaDao.execUpdateSql(strdispatch);

        //数据准备
        String strTrans = "select max(id),max(trans_group_id) from trans_tasks";
        ResultSet resMaxid =  mysqlQaDao.execQuerySql(strTrans);
        int max_id = Integer.parseInt(resMaxid.getString(1));
        int max_id1 = max_id + 1;
        int max_id2 = max_id + 2;
        int max_id3 = max_id + 3;
        int max_id4 = max_id + 4;
        int max_id5 = max_id + 5;
        int max_id6 = max_id + 6;
        int max_id7 = max_id + 7;
        int max_group_id = Integer.parseInt(resMaxid.getString(2)) + 1;

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrowTime = sdf.format(calendar.getTime());

        //trans_group表里插入数据(1)找出dispatch_task_id
        String strDispatchid = "SELECT id FROM dispatch_tasks WHERE order_id = '"+orderId+"'";
        ResultSet resDispatchid = mysqlQaDao.execQuerySql(strDispatchid);
        String dispatch_task_id = resDispatchid.getString(1);

        //trans_group表里插入数据(2)执行
        String strTrangroup = "insert into `trans_groups` (`order_id`, `ordersn`, `bagsn`, `current_task_id`, `last_task_id`, `order_type`, `order_status`, `status_delivery`, `type`, `created_at`, `updated_at`, `propose_outlet_id`, `dispatch_task_id`) values('"+orderId+"',NULL,'"+bagsn+"','"+max_id7+"','"+max_id7+"',NULL,'1',NULL,'TransGroup','"+dateTime+"','"+dateTime+"',NULL,'"+dispatch_task_id+"');";
        mysqlQaDao.execUpdateSql(strTrangroup);

        //working_tasks表里插入数据
        /**
         String strWorktask1 = "insert into `working_tasks` (`order_id`, `ordersn`, `working_type`, `status`, `outlet_id`, `category_id`, `city_id`, `dead_line`, `finished_at`, `uploaded_at`, `created_at`, `updated_at`) values('"+orderId+"','"+ordersn+"','qianshou','finished','458','1','1',NULL,'"+dateTime+"','"+dateTime+"','"+dateTime+"','"+dateTime+"');";
         String strWorktask2 = "insert into `working_tasks` (`order_id`, `ordersn`, `working_type`, `status`, `outlet_id`, `category_id`, `city_id`, `dead_line`, `finished_at`, `uploaded_at`, `created_at`, `updated_at`) values('"+orderId+"','"+ordersn+"','fenjian','finished','458','1','1','"+dateTime+"',NULL,NULL,'"+dateTime+"','"+dateTime+"');";
         String strWorktask3 = "insert into `working_tasks` (`order_id`, `ordersn`, `working_type`, `status`, `outlet_id`, `category_id`, `city_id`, `dead_line`, `finished_at`, `uploaded_at`, `created_at`, `updated_at`) values('"+orderId+"','"+ordersn+"','dabao','finished','458','1','1','"+tomorrowTime+"',NULL,NULL,'"+dateTime+"','"+dateTime+"');";
         mysqlQaDao.execUpdateSql(strWorktask1);
         mysqlQaDao.execUpdateSql(strWorktask2);
         mysqlQaDao.execUpdateSql(strWorktask3);
         */


        //trans_tasks表里插入数据
        String strTransTask1 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','3425','zhongbao',NULL,NULL,'customer','595723','" + max_id2 + "',NULL,NULL,'"+dateTime+"',NULL,'finished','get','" + dateTime + "','" + dateTime + "','" + dateTime + "','1','" + ordersn + "','unwashed','" + orderId + "','"+max_group_id+"','0','0','1');";
        String strTransTask2 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','3425','zhongbao',NULL,'67','wangdian',NULL,'" + max_id3 + "',NULL,NULL,'"+tomorrowTime+"',NULL,'finished','send','"+ dateTime + "','" + dateTime + "','" + dateTime + "','1','" + ordersn + "','unwashed','" + orderId + "','"+max_group_id+"','1','0','1');";
        String strTransTask3 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','67','wangdian',NULL,'3425','zhongbao',NULL,'"+max_id4+"',NULL,NULL,NULL,NULL,'finished','get','" + dateTime + "','" + dateTime + "','" + dateTime + "','1','" + ordersn + "','unwashed','" + orderId + "','"+max_group_id+"','1','0','1');";
        String strTransTask4 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','67','wangdian',NULL,'458','jiagongdian',NULL,'"+max_id5+"',NULL,NULL,'"+dateTime+"',NULL,'finished','send','" + dateTime + "','" + dateTime + "','" + dateTime + "','1','" + ordersn + "','unwashed','" + orderId + "','"+max_group_id+"','2','0','1');";
        String strTransTask5 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','458','jiagongdian',NULL,'67','wangdian',NULL,'"+max_id6+"',NULL,NULL,NULL,NULL,'finished','get','" + dateTime + "','" + dateTime + "','" + dateTime + "','1','" + ordersn + "','unwashed','" + orderId + "','"+max_group_id+"','2','0','1');";
        String strTransTask6 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','458','jiagongdian',NULL,'67','wangdian',NULL,'"+max_id7+"',NULL,NULL,NULL,NULL,'started','send',NULL,'" + dateTime + "','" + dateTime + "','1','" + ordersn + "','washed','" + orderId + "','"+max_group_id+"','3','0','1');";
        String strTransTask7 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('" + bagsn + "','67','wangdian',NULL,'458','jiagongdian',NULL,NULL,NULL,NULL,NULL,NULL,'started','get',NULL,'" + dateTime + "','" + dateTime + "','1','" + ordersn + "','washed','" + orderId + "','"+max_group_id+"','3','0','1');";
        mysqlQaDao.execUpdateSql(strTransTask1);
        mysqlQaDao.execUpdateSql(strTransTask2);
        mysqlQaDao.execUpdateSql(strTransTask3);
        mysqlQaDao.execUpdateSql(strTransTask4);
        mysqlQaDao.execUpdateSql(strTransTask5);
        mysqlQaDao.execUpdateSql(strTransTask6);
        mysqlQaDao.execUpdateSql(strTransTask7);

        return orderId;
    }
}
