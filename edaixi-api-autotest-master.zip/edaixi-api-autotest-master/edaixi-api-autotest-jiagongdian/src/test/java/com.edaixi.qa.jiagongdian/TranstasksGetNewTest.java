package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class TranstasksGetNewTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testTranstasksGetNew() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("last_updated_at","0" );
        this.queryParams.put("per_page","50");
        //this.queryParams.put("finish_time","2015-12-31 23:59:59");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign =parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallTranstasksGetNew("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":20921"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"bagsn\":\"00065281154\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_id\":458"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_type\":\"jiagongdian\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_address_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_id\":3425"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_type\":\"zhongbao\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_address_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"next_task_id\":21075"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"transfer_task_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"transferred_by\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"dead_line\":1457020800"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"prority\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"status\":\"finished\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"direction\":\"get\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"finished_at\":1456984907"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"created_at\":1456984807"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"updated_at\":1458031473"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_id\":7"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ordersn\":\"16030340004317\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"washing_status\":\"unwashed\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"order_id\":4000431"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_group_id\":309"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_ttl\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_type\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"city_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("from_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"[加工店] 测试专用\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"tel\":\"15652915887\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"address\":\"朝阳区 北京市朝阳区酒仙桥电子城IT产业园\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("to_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"[众包] 外包测试账号\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"tel\":\"13681057539\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"address\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_name\":\"袋洗\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("order_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"VIP\":\"#8D329B\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"q_date\":\"2016-03-03\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"q_time\":\"18:00-20:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"s_date\":\"2016-03-03\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"s_time\":\"22:00-24:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"remark\":\" 部分不能洗\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"username\":\"郭来东\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"tel\":\"13681057539\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"address_song\":\"朝阳区 dd\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"status_delivery\":15"));
    }
}