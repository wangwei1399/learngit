package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class DabaoTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * （1）正常打包
     * （2）已经打包，再次打包
     * （3）没有分拣记录，直接打包
     * （4）没有这条订单记录，直接打包，订单号封签号找不到记录
     */
    @Test
    //（1）正常打包
    public void testDabao1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException, InterruptedException {
        OrderFenjian fenjianOrder = new OrderFenjian();
        String orderId = fenjianOrder.createFenjianOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",fenjianOrder.bagsn);
        this.queryParams.put("ordersn",fenjianOrder.ordersn);
        this.queryParams.put("data","[]");
        this.queryParams.put("sj",fenjianOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);

        Thread.sleep(5000);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        String strOrder = "select * from ims_washing_order where ordersn = '" + fenjianOrder.ordersn + "'";
        ResultSet retOrder = mysqlQaDao.execQuerySql(strOrder);

        Assert.assertNotNull(retOrder.getString("song_week_nr"));
        Assert.assertNotNull(retOrder.getString("song_from_time_mod"));
        Assert.assertNotNull(retOrder.getString("song_to_time_mod"));

        String strTranstasks = "select * from trans_tasks where order_id = '" + orderId + "'";
        ResultSet retTranstasks = mysqlQaDao.execQuerySql(strTranstasks);
        retTranstasks.last();
        int rowcount = retTranstasks.getRow();
        Assert.assertEquals(6, rowcount);

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //（2）已经打包再次打包
    public void testDabao2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {
        OrderFenjian fenjianOrder = new OrderFenjian();
        String orderId = fenjianOrder.createFenjianOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",fenjianOrder.bagsn);
        this.queryParams.put("ordersn",fenjianOrder.ordersn);
        this.queryParams.put("data","[]");
        this.queryParams.put("sj",fenjianOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result1 = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);
        JSONObject result2 = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 验证接口返回的数据
        logger.info(result2.toJSONString());
        Assert.assertTrue(result2.getString("httpStatus").equals("201"));
        JSONObject body = JSON.parseObject(result2.getString("httpBody"));
        Assert.assertEquals(true, result2.getString("httpBody").contains("\"ret\":false"));
        Assert.assertEquals(true, result2.getString("httpBody").contains("error"));
        Assert.assertEquals(true, result2.getString("httpBody").contains("加工店不能上架"));
        Assert.assertEquals(true, result2.getString("httpBody").contains("\"error_code\":0"));
//
//        String strOrder = "select * from ims_washing_order where ordersn = '" + fenjianOrder.ordersn + "'";
//        ResultSet retOrder = mysqlQaDao.execQuerySql(strOrder);
//
//        Assert.assertNotNull(retOrder.getString("song_week_nr"));
//        Assert.assertNotNull(retOrder.getString("song_from_time_mod"));
//        Assert.assertNotNull(retOrder.getString("song_to_time_mod"));
//
//        String strTranstasks = "select * from trans_tasks where order_id = '" + orderId + "'";
//        ResultSet retTranstasks = mysqlQaDao.execQuerySql(strTranstasks);
//        retTranstasks.last();
//        int rowcount = retTranstasks.getRow();
//        Assert.assertEquals(6, rowcount);

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //（3）没有分拣记录，直接打包
    public void testDabao3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException, InterruptedException {
        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId = qianshouOrder.createQianshouOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",qianshouOrder.bagsn);
        this.queryParams.put("ordersn",qianshouOrder.ordersn);
        this.queryParams.put("data","[]");
        this.queryParams.put("sj",qianshouOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);

        Thread.sleep(5000);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("201"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":false"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"error\":\"加工店不能上架，状态：加工店已签收\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"error_code\":0"));



//
//        String strOrder = "select * from ims_washing_order where ordersn = '" + qianshouOrder.ordersn + "'";
//        ResultSet retOrder = mysqlQaDao.execQuerySql(strOrder);

//        Assert.assertNotNull(retOrder.getString("song_week_nr"));
//        Assert.assertNotNull(retOrder.getString("song_from_time_mod"));
//        Assert.assertNotNull(retOrder.getString("song_to_time_mod"));
//
//        String strTranstasks = "select * from trans_tasks where order_id = '" + orderId + "'";
//        ResultSet retTranstasks = mysqlQaDao.execQuerySql(strTranstasks);
//        retTranstasks.last();
//        int rowcount = retTranstasks.getRow();
//        Assert.assertEquals(6, rowcount);

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //（4）没有这条订单记录，直接打包，订单号封签号找不到记录
    public void testDabao4() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException, InterruptedException {

        long currentTime = System.currentTimeMillis();
        long unixTimestamp =currentTime/1000;
        String a = "4";
        //订单号
        long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
        //封签号
        String bagsn = (Long.toString(currentTime)).substring(2, 13);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("data","[]");
        this.queryParams.put("sj",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);

        Thread.sleep(5000);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        //Assert.assertTrue(result.getString("httpStatus").equals("200"));
        //JSONObject body = JSON.parseObject(result.getString("httpBody"));
        //Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertFalse(false);


    }

}