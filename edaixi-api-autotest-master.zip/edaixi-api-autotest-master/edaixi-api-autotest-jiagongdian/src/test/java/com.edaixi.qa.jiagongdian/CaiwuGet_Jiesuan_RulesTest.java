package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/6.
 */
public class CaiwuGet_Jiesuan_RulesTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * 结算规则
     * （1）冒烟测试
     * （2）区间内没有结算规则
     * （3）加工店id传成了编码
     */

    @Test
    //（1）冒烟测试
    public void testCaiwuGet_Jiesuan_Rules1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-09-29");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("start_time","2015-07-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_Rules("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("jiagongdian_id"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":97"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"jiagongdian_id\":458"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_id\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"price_type\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"discount\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"auto\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"start_time\":\"2014-10-31\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"end_time\":\"2016-11-29\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"rule_type\":1"));
    }

    @Test
    //（2）区间内没有结算规则
    public void testCaiwuGet_Jiesuan_Rules2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-07-2");
        this.queryParams.put("jiagongdian_id","6");
        this.queryParams.put("start_time","2015-07-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_Rules("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

    }

    @Test
    //（3）加工店id传成了编码
    public void testCaiwuGet_Jiesuan_Rules3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-09-2");
        this.queryParams.put("jiagongdian_id","e10999");
        this.queryParams.put("start_time","2015-07-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_Rules("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

    }


}
