package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CardCanZhuankaTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * 卡是否能转
     * （1）冒烟测试（联网卡）
     * （2）单店卡
     * （3）shop_id传成了编码
     * （4）卡号错误（不全是数据）
     */

    @Test
    //（1）冒烟测试（联网卡）
    public void testCardCanZhuanKar1() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("card_type","联网卡" );
        this.queryParams.put("card_sn","123456");
        this.queryParams.put("discount","1");
        this.queryParams.put("shop_id","10167");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallCardCanZhuanka("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ts"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version"));
        Assert.assertEquals(true, result.getString("httpBody").contains("data"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));
    }


    @Test
    //（2）单店卡
    public void testCardCanZhuanKar2() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("card_type","单店卡" );
        this.queryParams.put("card_sn","123456");
        this.queryParams.put("discount","1");
        this.queryParams.put("shop_id","10167");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallCardCanZhuanka("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ts"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version"));
        Assert.assertEquals(true, result.getString("httpBody").contains("data"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));
    }

    @Test
    //（3）shop_id传成了编码
    public void testCardCanZhuanKar3() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("card_type","单店卡" );
        this.queryParams.put("card_sn","123456");
        this.queryParams.put("discount","1");
        this.queryParams.put("shop_id","y10167");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallCardCanZhuanka("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ts"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version"));
        Assert.assertEquals(true, result.getString("httpBody").contains("data"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));
    }

    @Test
    //（4）卡号错误（不全是数据）
    public void testCardCanZhuanKar4() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {

        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("card_type","联网卡" );
        this.queryParams.put("card_sn","aa123456");
        this.queryParams.put("discount","1");
        this.queryParams.put("shop_id","10167");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallCardCanZhuanka("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ts"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version"));
        Assert.assertEquals(true, result.getString("httpBody").contains("data"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));
    }
}