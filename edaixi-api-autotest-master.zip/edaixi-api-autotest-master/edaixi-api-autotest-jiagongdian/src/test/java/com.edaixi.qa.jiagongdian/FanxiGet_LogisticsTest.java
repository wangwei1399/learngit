package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/5.
 */
public class FanxiGet_LogisticsTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testFanxiGet_Logistics() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        //TODO 做订单数据，不再依赖现有数据。把测试数据直接插到库里去

        String signBeforyMd5="app_key=jiagongdian_app&bagsn=00065281352&type=fanxiRNn40Iu1kd";
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(signBeforyMd5);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn","00065281352");
        this.queryParams.put("type","fanxi");
        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Logistics("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ordersn"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"id\":4000666"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"ordersn\":\"16032840006668\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"status_delivery\":\"加工店已签收\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"username\":\"郭来东\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"tel\":\"13681057539\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"city\":\"北京\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"area\":\"东城区\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"address\":\"马杓胡同甲27号\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"remark\":\" [ 棉服 青色]\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"logistics_remark\":\"\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"small_amount\":0"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"middle_amount\":0"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"large_amount\":0"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"package_amount\":0"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"is_fanxi\":true"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"category_id\":1"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"cannot_wash\":0"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"jiagongdian_id\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"order_details\":[]"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"kuaidi_qu\":\"外包测试账号\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("返洗"));

        Assert.assertEquals(true,result.getString("httpBody").contains("VIP"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"yuan_jiagongdian_tel\":\"15652915887\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"yuan_jiagongdian_title\":\"测试专用\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"yuan_jiagongdian_bianma\":\"e10999\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("fanxi_details"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"id\":8922356"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"ordersn\":\"16032840006668\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"bagsn\":\"\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"shmxid\":1"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"shdid\":\"e10999\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywtmh\":\"000042956\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywmc\":\"棉服\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywdc\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywcl\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywys\":\"青色\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"ywwg\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"dsdj\":\"-39.0\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"sjjg\":\"-29.0\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"pp\":\"\""));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"xc\":\"\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"xhxg\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"order_id\":4000666"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"can_wash\":true"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"created_at\":\"2016-03-28T10:57:30.000+08:00\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"updated_at\":\"2016-03-28T10:57:59.000+08:00\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"cannot_fanxi\":false"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"cloth_id\":null"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"rewash_reason\":\"没洗干净 测试\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"rewash\":1"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"verify_code\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"yywtmh\":null"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"primary_fanxi_xc\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"primary_fanxi_xc\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"primary_op\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"secondary_fanxi_xc\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"secondary_op\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"cannot_wash_reason\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"real_created_at\":\"2016-03-28T10:57:30.000+08:00\""));
    }
}