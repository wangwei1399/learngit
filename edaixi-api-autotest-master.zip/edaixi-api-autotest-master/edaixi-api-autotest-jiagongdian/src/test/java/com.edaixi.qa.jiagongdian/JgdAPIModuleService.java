package  com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class JgdAPIModuleService {
	private static Logger logger = LoggerFactory.getLogger(JgdAPIModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;
	private Properties openGlobalConf = null;

	public JgdAPIModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.openGlobalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.openGlobalConf.getProperty("jiagongdian.addr"));
	}


	public JSONObject CallQianShou(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.qianshou"), method, authorization, queryParam);
	}

	public JSONObject CallJiamubiaos(String access_token,String authorization, Map<String, Object> queryParam) {
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.jiamubiaos"), method, authorization, queryParam);
	}

	public JSONObject CallJiamubiao_history(String access_token,String authorization, Map<String, Object> queryParam) {
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.jiamubiao_history"), method, authorization, queryParam);
	}

	public JSONObject CallCategories(String access_token,String authorization, Map<String, Object> queryParam) {
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.categories"), method, authorization, queryParam);
	}

	public JSONObject CallGet_city_by_jiagongdian(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_city_by_jiagongdian"), method, authorization, queryParam);
	}

	public JSONObject CallVersions(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.versions"), method, authorization, queryParam);
	}

	public JSONObject CallXiacis(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.xiacis"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Time(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_time"), method, authorization, queryParam);
	}

	public JSONObject CallXiaoGuos(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.xiaoguos"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Outlet_Info(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_outlet_info"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Logistics(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_logistics"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Logistics_List(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_logistics_list"), method, authorization, queryParam);
	}

	public JSONObject CallFenJian_Index(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.fenjian_index"), method, authorization, queryParam);
	}

	public JSONObject CallGet_ReturnReasons(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_return_reasons"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Trans_Tasks(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_trans_tasks"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Fanxi_Deduction(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_fanxi_deduction"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Phone_Call_Records(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_phone_call_records"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Jiesuan_Rules(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_jiesuan_rules"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Jiesuan_List(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_jiesuan_list"), method, authorization, queryParam);
	}

	public JSONObject CallGet_Extra_Jiesuan_Detail(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_extra_jiesuan_detail"), method, authorization, queryParam);
	}

	public JSONObject CallTrans_Tasks_Get_All(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.trans_tasks_get_all"), method, authorization, queryParam);
	}

	public JSONObject CallCardCanZhuanka(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.card_can_zhuanka"), method, authorization, queryParam);

	}

	public JSONObject CallGet_JixiaoStats(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_jixiao_stats"), method, authorization, queryParam);

	}

	public JSONObject CallTranstasksGetNew(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.trans_tasks/get_new"), method, authorization, queryParam);

	}

	public JSONObject CallGetNotifications(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_notifications"), method, authorization, queryParam);

	}

	public JSONObject CallGetPingjiaList(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_pingjia_list"), method, authorization, queryParam);

	}

	public JSONObject CallGetPingjiaStats(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_pingjia_stats"), method, authorization, queryParam);

	}

	public JSONObject CallGetUpdateInfo(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.get_update_info"), method, authorization, queryParam);

	}

	public JSONObject CallWuliuStatusIndex(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.wuliustatusindex"), method, authorization, queryParam);

	}

	public JSONObject CallWuliuFenjianIndex(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.wuliufenjianindex"), method, authorization, queryParam);

	}

	public JSONObject CallUploadImg(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.uploadimg"), method, authorization, queryParam);

	}

	public JSONObject CallShouyidianZhuanka(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.shouyidianzhuanka"), method, authorization, queryParam);

	}

	public JSONObject CallShouyidianBindMachine(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.shouyidianbindmachine"), method, authorization, queryParam);

	}

	public JSONObject CallSendSms(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.sendsms"), method, authorization, queryParam);

	}

	public JSONObject CallMakePhoneCall(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.makephonecall"), method, authorization, queryParam);

	}

	public JSONObject CallFenjian(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.fenjian"), method, authorization, queryParam);

	}

	public JSONObject CallDabao(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.dabao"), method, authorization, queryParam);

	}

	public JSONObject CallShangjia(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.shangjia"), method, authorization, queryParam);

	}

	public JSONObject CallOrderAllCannotWash(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callorderallcannotwash"), method, authorization, queryParam);

	}

	public JSONObject CallOrderPortionCannotWash(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callorderportioncannotwash"), method, authorization, queryParam);

	}

	public JSONObject CallChuku(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callchuku"), method, authorization, queryParam);

	}

	public JSONObject CallClothesList(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callclotheslist"), method, authorization, queryParam);

	}

	public JSONObject CallAccessoryList(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callaccessorylist"), method, authorization, queryParam);

	}

	public JSONObject CallSort(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callSort"), method, authorization, queryParam);

	}

	public JSONObject CallRack(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callRack"), method, authorization, queryParam);

	}

	public JSONObject CallGetRewashDeduction(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callGetRewashDeduction"), method, authorization, queryParam);

	}

	public JSONObject CallVersionsV4(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callversions"), method, authorization, queryParam);

	}

	public JSONObject CallRewashOperationList(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.jiagongdian.token.callRewashOperationList"), method, authorization, queryParam);

	}


}
