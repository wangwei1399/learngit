package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class GetJixiaoStatsTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testGetJixiaoStats() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {
        this.queryParams.put("app_key","jiagongdian_app");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("category_id","1" );
        this.queryParams.put("start_time","2015-12-01 00:00:00");
        this.queryParams.put("finish_time","2015-12-31 23:59:59");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign =parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallGet_JixiaoStats("", "", this.queryParams);


        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        Assert.assertEquals(true, result.getString("httpBody").contains("ts"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version"));
        Assert.assertEquals(true, result.getString("httpBody").contains("data"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_count"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_count"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fanxi_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("qianshou_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("yanchi_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_yanchi"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_weigui"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tousu_count"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tousu_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("chaping_count"));
        Assert.assertEquals(true, result.getString("httpBody").contains("chaping_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("warning"));
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"start_date\":\"2015-02-01\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"city_id\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_id\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fanxi_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("qianshou_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("yanchi_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_yanchi"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fenjian_weigui"));
        Assert.assertEquals(true, result.getString("httpBody").contains("chaping_rate"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));

    }

}