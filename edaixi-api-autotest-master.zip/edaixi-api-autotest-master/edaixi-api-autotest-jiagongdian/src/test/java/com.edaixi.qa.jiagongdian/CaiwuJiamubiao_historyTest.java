package  com.edaixi.qa.jiagongdian;

/**
 * Created by guolaidong on 2015/12/15.
 */


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class CaiwuJiamubiao_historyTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * 历史价目表
     * （1）冒烟测试
     * （2）城市id和加工店id不对应
     * （3）加工店id传成了编码
     */

    @Test
    //（1）冒烟测试
    public void testCaiwuJiamubiao_history1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("city_id", "1");
        this.queryParams.put("jiagongdian_id", "271");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallJiamubiao_history("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_level"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_operation"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_price"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_yuanjia"));
        Assert.assertEquals(true, result.getString("httpBody").contains("created_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("updated_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("category_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("city_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("enable_time"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_chang"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_dian"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ori_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_deleted"));
        Assert.assertEquals(true, result.getString("httpBody").contains("smart_key"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fanxi_price_type"));

    }


    @Test
    //（2）城市id和加工店id不对应
    public void testCaiwuJiamubiao_history2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("city_id", "2");
        this.queryParams.put("jiagongdian_id", "271");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallJiamubiao_history("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_level"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_operation"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_price"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_yuanjia"));
        Assert.assertEquals(true, result.getString("httpBody").contains("created_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("updated_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("category_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("city_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("enable_time"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_chang"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_dian"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ori_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_deleted"));
        Assert.assertEquals(true, result.getString("httpBody").contains("smart_key"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fanxi_price_type"));

    }

    @Test
    //（2）加工店id传成了编码
    public void testCaiwuJiamubiao_history3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("city_id", "2");
        this.queryParams.put("jiagongdian_id", "e10999");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallJiamubiao_history("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_level"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_operation"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_price"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cloth_yuanjia"));
        Assert.assertEquals(true, result.getString("httpBody").contains("created_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("updated_at"));
        Assert.assertEquals(true, result.getString("httpBody").contains("category_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("city_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("enable_time"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_chang"));
        Assert.assertEquals(true, result.getString("httpBody").contains("wash_deadline_dian"));
        Assert.assertEquals(true, result.getString("httpBody").contains("ori_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_deleted"));
        Assert.assertEquals(true, result.getString("httpBody").contains("smart_key"));
        Assert.assertEquals(true, result.getString("httpBody").contains("fanxi_price_type"));

    }
}