package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/5.
 */
public class FenjianXiaoGuosTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testFenjianXiaoGuos() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        String signBeforyMd5="app_key=jiagongdian_appRNn40Iu1kd";
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(signBeforyMd5);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallXiaoGuos("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
    }
}
