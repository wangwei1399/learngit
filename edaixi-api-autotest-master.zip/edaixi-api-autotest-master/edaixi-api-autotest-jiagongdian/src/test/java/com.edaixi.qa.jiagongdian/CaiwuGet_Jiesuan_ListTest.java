package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/6.
 */
public class CaiwuGet_Jiesuan_ListTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * 财务扣项列表
     * （1）冒烟测试
     * （2）搜索时间内没有记录
     * （3）加工店id传成编码
     *
     */

    @Test
    //（1）冒烟测试
    public void testCaiwuGet_Jiesuan_List1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-09-29");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("start_time","2015-07-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_List("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        //Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":32"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"outlet_id\":458"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_price\":\"-4292.5\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"extra_total_price\":\"-4400.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_total_price\":\"215.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_discount_price\":\"107.5\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_order_count\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_cloth_count\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"start_time\":\"2015-07-01\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"end_time\":\"2015-07-31\""));

    }


    @Test
    //（2）搜索时间内没有记录
    public void testCaiwuGet_Jiesuan_List2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2016-04-01");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("start_time","2016-04-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_List("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        //Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":32"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"outlet_id\":458"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_price\":\"-4292.5\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"extra_total_price\":\"-4400.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_total_price\":\"215.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_discount_price\":\"107.5\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_order_count\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"total_cloth_count\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"start_time\":\"2015-07-01\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"end_time\":\"2015-07-31\""));


    }

    @Test
    //（3）加工店id传成了加工店编码
    public void testCaiwuGet_Jiesuan_List3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2016-04-01");
        this.queryParams.put("jiagongdian_id","e10999");
        this.queryParams.put("start_time","2016-04-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Jiesuan_List("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("400"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"error\":\"jiagongdian_id is invalid\""));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        //Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":32"));


    }
}
