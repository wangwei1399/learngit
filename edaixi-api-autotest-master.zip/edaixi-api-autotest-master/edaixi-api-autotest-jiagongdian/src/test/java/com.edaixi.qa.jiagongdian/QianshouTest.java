package  com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class QianshouTest {

	private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
	private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
	private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
	}

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}

	@Test
	public void testQianshou() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

		long currentTime = System.currentTimeMillis();
		long unixTimestamp =currentTime/1000;
		String a = "4";
		//订单号
		long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
		//封签号
		String bagsn = (Long.toString(currentTime)).substring(2, 13);
		//今天
		String dateTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
		//明天
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE,+1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String tomorrowTime = sdf.format(calendar.getTime());
		//订单后六位
		String lastSixordersn = (Long.toString(ordersn)).substring(8, 14);

		//插入数据库新订单
		//ims_washing_order订单表里插入数据
		String strQianshouOrder = "insert into ims_washing_order (from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid,status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time,createtime,qujian_paidan_time,qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time,jiagongdian_qianshou_time,jiagongdian_id,wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time,wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time,jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status,diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi,yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id,address_song_id,auto_dispatched_qu_at,auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count,washing_duration,model_version) " +
				"values" +
				"(NULL,'7','"+ordersn+"','"+bagsn+"','1','35.00','5.00','','0.00','35.00','35.00','1','1','','','1','1','','2016-03-22','18:00-20:00','','','测试员','13681057539','北京','东城区','马杓胡同甲27号','北京','东城区','马杓胡同甲27号','3425','0','0',NULL,'0',NULL,'0',NULL,'"+unixTimestamp+"','"+unixTimestamp+"','"+unixTimestamp+"','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'"+unixTimestamp+"',NULL,NULL,NULL,NULL,'"+dateTime+"','"+dateTime+"','0','"+unixTimestamp+"','0','0',NULL,'0','0','0','623419',NULL,'18','2412','42','43',NULL,NULL,NULL,'458','595735','595735',NULL,NULL,'"+lastSixordersn+"','1','0',NULL,NULL,'0.00',NULL,NULL,NULL,'0');";
		mysqlQaDao.execUpdateSql(strQianshouOrder);

		//做交接单数据
		//数据准备
		String strTrans = "select max(id),max(trans_group_id) from trans_tasks";
		ResultSet resMaxid =  mysqlQaDao.execQuerySql(strTrans);
		int max_id = Integer.parseInt(resMaxid.getString(1));
		int max_id1 = max_id + 1;
		int max_id2 = max_id + 2;
		int max_id3 = max_id + 3;
		int max_group_id = Integer.parseInt(resMaxid.getString(2)) + 1;

		String strOrder = "select id from ims_washing_order where bagsn = '" + bagsn + "'";
		ResultSet resOrderid = mysqlQaDao.execQuerySql(strOrder);
		String orderId = resOrderid.getString(1);

		//trans_tasks表里插入数据
		String strTransTask1 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('"+bagsn+"','3425','zhongbao',NULL,NULL,'customer','595735','"+max_id2+"',NULL,NULL,'"+tomorrowTime+"',NULL,'finished','get','"+dateTime+"','"+dateTime+"','"+dateTime+"','1','"+ordersn+"','unwashed','"+orderId+"','"+max_group_id+"','0','0','1');";
        String strTransTask2 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id)values('"+bagsn+"','3425','zhongbao',NULL,NULL,'outlet',NULL,'"+max_id3+"',NULL,NULL,'"+tomorrowTime+"',NULL,'started','send',NULL,'"+dateTime+"','"+dateTime+"','1','"+ordersn+"','unwashed','"+orderId+"','"+max_group_id+"','1','0','1');";
		String strTransTask3 = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values('"+bagsn+"',NULL,'outlet',NULL,'3425','zhongbao',NULL,NULL,NULL,NULL,NULL,NULL,'started','get',NULL,'"+dateTime+"','"+dateTime+"','1','"+ordersn+"','unwashed','"+orderId+"','"+max_group_id+"','1','0','1');";
		mysqlQaDao.execUpdateSql(strTransTask1);
		mysqlQaDao.execUpdateSql(strTransTask2);
		mysqlQaDao.execUpdateSql(strTransTask3);

		//dispatch_tasks表里插入数据
		String strDispatch = "insert into dispatch_tasks (order_id,status,from_type,from_id,to_type,to_id,dispatch_type,courier_id,hope_time,finished_at,category_id,created_at,updated_at,type,ordersn,city_id) values('"+orderId+"','finished','jiagongdian',NULL,'Address','595735','0','3425','"+dateTime+"','"+dateTime+"','1','"+dateTime+"','"+dateTime+"','DispatchTask',NULL,'1');";
		mysqlQaDao.execUpdateSql(strDispatch);

		//trans_group表里插入数据(1)找出dispatch_task_id
		String strDispatchid = "SELECT id FROM dispatch_tasks WHERE order_id = '"+orderId+"'";
		ResultSet resDispatchid = mysqlQaDao.execQuerySql(strDispatchid);
		String dispatch_task_id = resDispatchid.getString(1);

		//trans_group表里插入数据
		String strTranGroup = "insert into trans_groups (order_id,ordersn,bagsn,current_task_id,last_task_id,order_type,order_status,status_delivery,type,created_at,updated_at,propose_outlet_id,dispatch_task_id) values('"+orderId+"',NULL,'"+bagsn+"','"+max_id3+"','"+max_id3+"',NULL,'1',NULL,'TransGroup','"+dateTime+"','"+dateTime+"',NULL,'"+dispatch_task_id+"');";
		mysqlQaDao.execUpdateSql(strTranGroup);

		//构造字符串
		this.queryParams.put("app_key", "jiagongdian_app");
		this.queryParams.put("jiagongdian_id", "458");
		this.queryParams.put("bagsn",bagsn);

		//生成sign
		//map里排序
		TreeMap treemap = new TreeMap(this.queryParams);

		//遍历treemap，用&链接
		Object key = null;
		Object value = null;
		String strkeyvalue = "";

		Iterator it = treemap.keySet().iterator();
		while (it.hasNext()) {
			key = it.next();
			value = treemap.get(key);
			strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
		}
		String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

		//计算sign
		ParseMD5 parseMD5 = new ParseMD5();
		String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
		this.queryParams.put("sign", sign);

		JSONObject result = this.jgdAPIModuleService.CallDabao("", "", this.queryParams);

		// 验证接口返回的数据
		logger.info(result.toJSONString());
		Assert.assertTrue(result.getString("httpStatus").equals("200"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));
		//TODO 订单状态，交接单
	}
}
