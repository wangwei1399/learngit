package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FenjianTest {
    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testFenjian() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        logger.info(currentTime+"");
        String a = "4";
        //订单号
        long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
        //封签号
        String bagsn = (Long.toString(currentTime)).substring(2, 13);
        //水洗条码
        String ywtmh = (Long.toString(currentTime)).substring(4, 13);

        //插入数据库新订单
        String init2 = "insert into `ims_washing_order` (`from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`," +
                " `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, " +
                "`send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, " +
                "`shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, " +
                "`songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`," +
                " `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`," +
                " `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, " +
                "`xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, " +
                "`qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, " +
                "`auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`, " +
                "`washing_duration`, `model_version`) " +
                "values" +
                "(NULL,'3','" + ordersn + "','" + bagsn + "','1','25.00','10.00','','0.00','25.00','25.00','1','4','','','1','1','','2016-03-16','18:00-20:00','','','郭来东'," +
                "'13681057539','北京','平谷区','世纪广场','北京','平谷区','世纪广场','3425','0','0',NULL,'0',NULL,'0',NULL,'1458115722','1458115779','1458115848','0','0','0'," +
                "NULL,NULL,NULL,'1458115859',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1458115848',NULL,NULL,NULL,NULL,'2016-03-16 16:08:42','2016-03-16 16:10:59','0','1458115722'," +
                "'0','0',NULL,'0','0','0','623419',NULL,'18','2411','66','67',NULL,NULL,NULL,'458','595723','595723',NULL,NULL,'004844','1','0',NULL,'1339874','0.00',NULL,NULL,NULL,'0');";

        mysqlQaDao.execUpdateSql(init2);

        String strdata = "[{\"id\":3,\"shmxid\":42803,\"shdid\":\"e10999\",\"ywtmh\":\"" + ywtmh + "\",\"ywmc\":\"风衣\",\"ywdc\":\"普通\",\"ywcl\":\"e袋洗\",\"ywys\":\"靛青\",\"ywwg\":\"\",\"dsdj\":39,\"sjjg\":19,\"pp\":\"\",\"xc\":\"\",\"xhxg\":\"\",\"sj\":\"2016-03-16 16:38:03\"}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("sj","1458115722");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("data",strdata);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallFenjian("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from ims_washing_order_bags_clothing where ordersn = '"+ordersn+"'";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("shdid").contains("e10999"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("ywtmh").contains(ywtmh));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("ywmc").contains("风衣"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("ywys").contains("靛青"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("dsdj").contains("39"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("sjjg").contains("19"));
    }
}