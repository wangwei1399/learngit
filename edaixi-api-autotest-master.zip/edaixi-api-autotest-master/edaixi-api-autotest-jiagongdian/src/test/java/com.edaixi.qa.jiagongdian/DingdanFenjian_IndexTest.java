package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/5.
 */
public class DingdanFenjian_IndexTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testDingdanFenjian_Index() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {
        //TODO 手工做订单衣物明细数据，不依赖于已有数据

        String signBeforyMd5="app_key=jiagongdian_app&jiagongdian_id=458&ordersn=16032440006354RNn40Iu1kd";
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(signBeforyMd5);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("ordersn","16032440006354");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallFenJian_Index("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":8922337"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ordersn\":\"16032440006354\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"bagsn\":\"00065281338\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"shmxid\":42822"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"shdid\":\"e10999\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywtmh\":\"000042942\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywmc\":\"蓝色袋洗窗帘\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywdc\":\"普通\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywcl\":\"e袋洗\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywys\":\"深蓝灰\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywwg\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"dsdj\":\"299.0\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"sjjg\":\"299.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"pp\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"xc\":\"\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"xhxg\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"order_id\":4000635"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"can_wash\":true"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"created_at\":\"2016-03-24T17:39:46.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"updated_at\":\"2016-03-24T17:39:38.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cannot_fanxi\":false"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_id\":117"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"rewash_reason\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"rewash\":0"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"verify_code\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"yywtmh\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"primary_fanxi_xc\":null"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"primary_op\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"secondary_fanxi_xc\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"secondary_op\":null"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"cannot_wash_reason\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"real_created_at\":\"2016-03-24T17:39:38.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_title\":\"蓝色袋洗窗帘\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"color\":\"深蓝灰\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"comment\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"brand\":\"\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"original_price\":\"299.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"current_price\":\"299.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_condition\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"wash_result\":\"\""));
    }
}
