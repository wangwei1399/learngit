package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by guolaidong on 2016/1/5.
 */
public class DingdanGet_LogisticsTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testDingdanGet_Logistics() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        String a = "4";
        //订单号
        long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
        //封签号
        String bagsn = (Long.toString(currentTime)).substring(2, 13);

        String strorder = "insert into ims_washing_order(from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid," +
                "status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address," +
                "city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time," +
                "createtime,qujian_paidan_time,qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time," +
                "jiagongdian_qianshou_time,jiagongdian_id,wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time," +
                "wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time,jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status," +
                "diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi,yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr," +
                "qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id,address_song_id,auto_dispatched_qu_at," +
                "auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count)" +
                "values" +
                "(NULL,'3','" + ordersn + "','" + bagsn + "','1','53.00','5.00','','0.00','53.00','53.00','1','4','','','1','1','','2016-02-18','18:00-20:00','',''," +
                "'郭来东','13681057539','北京','朝阳区','酒仙桥酒仙桥北路将台北路电子城IT产业园，201楼D门5层501，北京壹代家庭服务有限公司。','北京','朝阳区'," +
                "'酒仙桥酒仙桥北路将台北路电子城IT产业园，201楼D门5层501，北京壹代家庭服务有限公司。','3425','0','0',NULL,'0',NULL,'0',NULL,'1455783206','1455783436','1455783900'," +
                "'0','0','0',NULL,NULL,NULL,'1455784189',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1455783900',NULL,NULL,NULL,NULL,'2016-02-18 16:13:26','2016-02-18 16:29:49','0'," +
                "'1455783206','0','0',NULL,'0','0','0','623419',NULL,'18','2407','90','91',NULL,NULL,NULL,'458','595708','595708',NULL,NULL,'003949','1','0',NULL,'1339874','0.00',NULL,NULL);";
        mysqlQaDao.execUpdateSql(strorder);

        String strorderid = "select id from ims_washing_order where bagsn = '" + bagsn + "'";
        ResultSet resorderid =  mysqlQaDao.execQuerySql(strorderid);
        String orderid = resorderid.getString(1);

        String strgooddetail = "insert into order_good_details(order_id,good_id,good_name,good_price,amount,sub_total,created_at,updated_at,is_delete) " +
                "values" +
                "('" + orderid + "','103','19元洗衣','19','1','19','2016-02-23 17:52:29','2016-02-23 17:52:29','0');";
        mysqlQaDao.execUpdateSql(strgooddetail);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",bagsn);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign =parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);
        JSONObject result = this.jgdAPIModuleService.CallGet_Logistics("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("username"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":" + orderid + ""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ordersn\":\"" + ordersn + ""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"status_delivery\":\"加工店已签收\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("username"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tel"));
        Assert.assertEquals(true, result.getString("httpBody").contains("city"));

        Assert.assertEquals(true, result.getString("httpBody").contains("area"));
        Assert.assertEquals(true, result.getString("httpBody").contains("address"));
        Assert.assertEquals(true, result.getString("httpBody").contains("remark"));
        Assert.assertEquals(true, result.getString("httpBody").contains("logistics_remark"));
        Assert.assertEquals(true, result.getString("httpBody").contains("small_amount"));

        Assert.assertEquals(true, result.getString("httpBody").contains("middle_amount"));
        Assert.assertEquals(true, result.getString("httpBody").contains("large_amount"));
        Assert.assertEquals(true, result.getString("httpBody").contains("package_amount"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_fanxi"));
        Assert.assertEquals(true, result.getString("httpBody").contains("category_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("cannot_wash"));
        Assert.assertEquals(true, result.getString("httpBody").contains("jiagongdian_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("order_details"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"order_id\":" + orderid + ""));
        Assert.assertEquals(true, result.getString("httpBody").contains("good_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"good_name\":\"19元洗衣\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"good_price\":19"));
        Assert.assertEquals(true, result.getString("httpBody").contains("amount"));
        Assert.assertEquals(true, result.getString("httpBody").contains("sub_total"));

        Assert.assertEquals(true, result.getString("httpBody").contains("unit_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("kuaidi_qu"));
        Assert.assertEquals(true, result.getString("httpBody").contains("label_group"));
        Assert.assertEquals(true, result.getString("httpBody").contains("version_sign"));

    }
}
