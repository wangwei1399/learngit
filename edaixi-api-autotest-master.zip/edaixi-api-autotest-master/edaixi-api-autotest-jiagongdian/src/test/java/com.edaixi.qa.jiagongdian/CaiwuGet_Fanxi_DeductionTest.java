package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/6.
 */
public class CaiwuGet_Fanxi_DeductionTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     * 反洗扣项查询接口
     *（1）冒烟测试
     *（2）没有记录
     *（3）加工店id传成编码了。
     */

    @Test
    //(1)冒烟测试
    public void testCaiwuGet_Fanxi_Deduction1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-12-29");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("start_time","2015-10-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Fanxi_Deduction("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":8921625"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ordersn\":\"15121140002557\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"bagsn\":\"00065279434\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"shmxid\":999999"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"shdid\":\"e10999\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywtmh\":\"509861026\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywmc\":\"运动服套\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywdc\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywcl\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywys\":\"深蓝灰\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ywwg\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"dsdj\":\"0.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"sjjg\":\"0.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"pp\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"xc\":\"刮丝划痕(返洗)\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"xhxg\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"order_id\":4000255"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"can_wash\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"created_at\":\"2015-12-11T05:09:22.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"updated_at\":\"2015-12-11T05:09:22.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cannot_fanxi\":false"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_id\":9617"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"rewash_reason\":\"没洗干净 客服\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"rewash\":3"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"verify_code\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"yywtmh\":\"509861025\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"primary_fanxi_xc\":\"刮丝划痕(返洗)\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"primary_op\":\"衣物串色处理\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"secondary_fanxi_xc\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"secondary_op\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cannot_wash_reason\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"real_created_at\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_title\":\"运动服套\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"color\":\"深蓝灰\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"comment\":\"刮丝划痕(返洗)\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"brand\":\"\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"original_price\":\"0.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"current_price\":\"0.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"cloth_condition\":\"刮丝划痕(返洗)\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"wash_result\":null"));
    }

    @Test
    //(2)没有记录
    public void testCaiwuGet_Fanxi_Deduction2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-09-02");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("start_time","2015-09-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Fanxi_Deduction("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        //Assert.assertEquals(true, result.getString("httpBody").contains(""));

    }

    @Test
    //(3)加工店不存在
    public void testCaiwuGet_Fanxi_Deduction3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("end_time","2015-11-02");
        //加工店id传成编码
        this.queryParams.put("jiagongdian_id","e10999");
        this.queryParams.put("start_time","2015-09-01");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Fanxi_Deduction("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertFalse(false);

    }
}
