package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/5/7.
 */
public class RackTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    /**
     *（1）正常上挂
     *（2）找不到订单号封签号
     *（3）没有分拣记录，直接有上挂记录
     *（4）已经上挂过了，再次上挂
     */

    @Test
    //（1）正常上挂
    public void testRack1() throws SQLException, UnsupportedEncodingException {
        OrderFenjian fenjianOrder = new OrderFenjian();
        String orderId = fenjianOrder.createFenjianOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",fenjianOrder.bagsn);
        this.queryParams.put("ordersn",fenjianOrder.ordersn);
        this.queryParams.put("sj",fenjianOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);
        JSONObject result = this.jgdAPIModuleService.CallRack("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);
    }

    @Test
    //（2）找不到订单号封签号
    public void testRack2() throws SQLException, UnsupportedEncodingException {
        String a = "4";
        //订单号
        long ordersn = Long.parseLong(a.concat(Long.toString( System.currentTimeMillis())));
        //封签号
        String bagsn = (Long.toString( System.currentTimeMillis())).substring(2, 13);
        long unixTimestamp =System.currentTimeMillis()/1000;

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("sj",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);
        JSONObject result = this.jgdAPIModuleService.CallRack("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
    }

    @Test
    //（3）没有分拣记录，直接上挂
    public void testRack3() throws SQLException, UnsupportedEncodingException {
        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId =qianshouOrder.createQianshouOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",qianshouOrder.bagsn);
        this.queryParams.put("ordersn",qianshouOrder.ordersn);
        this.queryParams.put("sj",qianshouOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);
        JSONObject result = this.jgdAPIModuleService.CallRack("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);
    }

    @Test
    //（4）已结上挂过了，再次上挂
    public void testRack4() throws SQLException, UnsupportedEncodingException {
        OrderFenjian fenjianOrder = new OrderFenjian();
        String orderId = fenjianOrder.createFenjianOrder();

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("bagsn",fenjianOrder.bagsn);
        this.queryParams.put("ordersn",fenjianOrder.ordersn);
        this.queryParams.put("sj",fenjianOrder.unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);
        JSONObject result1 = this.jgdAPIModuleService.CallRack("", "", this.queryParams);
        //再次上挂
        JSONObject result2 = this.jgdAPIModuleService.CallRack("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result2.toJSONString());
        Assert.assertTrue(result2.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result2.getString("httpBody"));
        Assert.assertEquals(true, result2.getString("httpBody").contains("\"ret\":true"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);
    }
}
