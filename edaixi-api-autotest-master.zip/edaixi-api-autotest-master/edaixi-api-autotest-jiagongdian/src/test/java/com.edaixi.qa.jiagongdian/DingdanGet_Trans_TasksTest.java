package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/5.
 */
public class DingdanGet_Trans_TasksTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testDingdanGet_Trans_Tasks() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        String signBeforyMd5="app_key=jiagongdian_app&jiagongdian_id=458&order_id=4000284RNn40Iu1kd";
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(signBeforyMd5);

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("jiagongdian_id", "458");
        this.queryParams.put("order_id", "4000284");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Trans_Tasks("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":19422"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"bagsn\":\"00065280430\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_id\":22710"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_type\":\"zhongbao\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"from_address_id\":null"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_type\":\"customer\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"to_address_id\":595617"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"next_task_id\":19423"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"transfer_task_id\":null"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"transferred_by\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"dead_line\":\"2015-12-22T14:00:00.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"prority\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"status\":\"finished\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"direction\":\"get\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"finished_at\":\"2015-12-21T22:11:45.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"created_at\":\"2015-12-21T22:10:42.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"updated_at\":\"2015-12-21T22:11:45.000+08:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_id\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ordersn\":\"15122140002847\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"washing_status\":\"unwashed\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"order_id\":4000284"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_group_id\":185"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_ttl\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"trans_type\":0"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"city_id\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"[众包] CD-ZB-HP-王佩文\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"tel\":\"18721236697\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"address\":null"));
        Assert.assertEquals(true, result.getString("httpBody").contains("from_info"));

        Assert.assertEquals(true, result.getString("httpBody").contains("to_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"[客户] 郭来东\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"tel\":\"13681057539\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("address"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"category_name\":\"洗衣\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("order_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tags"));

        Assert.assertEquals(true, result.getString("httpBody").contains("\"VIP\":\"#8D329B\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"q_date\":\"2015-12-22\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"q_time\":\"12:00-14:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"s_date\":\"2015-12-23\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"s_time\":\"22:00-24:00\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"remark\":\"用户\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"username\":\"郭来东\""));

        Assert.assertEquals(true, result.getString("httpBody").contains("address_song"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"status_delivery\":3"));
        Assert.assertEquals(true, result.getString("httpBody").contains("from_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("from_address"));
        Assert.assertEquals(true, result.getString("httpBody").contains("from_tel"));
        Assert.assertEquals(true, result.getString("httpBody").contains("to_name"));
        Assert.assertEquals(true, result.getString("httpBody").contains("to_address"));
        Assert.assertEquals(true, result.getString("httpBody").contains("to_tel"));
    }
}
