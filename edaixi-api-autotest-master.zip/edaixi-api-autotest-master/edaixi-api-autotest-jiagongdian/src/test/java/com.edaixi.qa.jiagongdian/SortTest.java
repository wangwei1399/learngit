package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by guolaidong on 2016/4/11.
 */
public class SortTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    /**
     * case1：小e分拣和加工店分拣衣物不同
     * case2：小e分拣和加工店分拣衣物一致
     * csae3：衣物条码号重复
     * case4：衣物条码号里有特殊字符---服务器未实现
     * case5：衣物id和衣物名称不对应---服务器未实现
     * case6：品牌里有特殊字符
     * case7：配件标示和衣物id衣物名称不对应
     */

    @Test
    //case1:小e分拣和加工店分拣衣物不同
    public void testSort1() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId =qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(5, 13);

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":41,\"clothes_name\":\"羊毛／绒外套\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        //Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        //Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("20"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("41"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("羊毛／绒外套"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9903"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("45.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("29.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //case2:小e分拣和加工店分拣衣物一致
    public void testSort2() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId =  qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(5, 13);

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        //Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        //Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("21"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("8"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9887"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

/**
    @Test
    //csae3：衣物条码号重复（两件衣物衣物条码号重复）
    public void testSort3() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        QianshouOrder qianshouOrder = new QianshouOrder();
        qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(5, 13);
        String orderId =  qianshouOrder.createQianshouOrder();

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0},{\"outlet_id\":458,\"washing_barcode\":\"\" + washingBarcode + \"\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
//        logger.info(result.toJSONString());
//        Assert.assertTrue(result.getString("httpStatus").equals("200"));
//        JSONObject body = JSON.parseObject(result.getString("httpBody"));
//
//        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
//        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

//        Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
//        Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //      Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("20"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("8"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9903"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));


    }
*/
/**
    @Test
    //case4：衣物条码号里有特殊字符
    public void testSort4() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        QianshouOrder qianshouOrder = new QianshouOrder();
        qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;


        String allChar = "~!@#$%^&*()_+qwertyUIOP{}:|;',.'/\\";
        Random random = new Random();
        StringBuffer buffer = new StringBuffer();
        String washingBarcode = null;
        for (int i = 0; i < 9; i++) {
            washingBarcode = String.valueOf(buffer.append(allChar.charAt(random.nextInt(allChar.length()))));
           // System.out.println("ws:"+washingBarcode);
        }



        String orderId =  qianshouOrder.createQianshouOrder();

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0},{\"outlet_id\":458,\"washing_barcode\":\"\" + washingBarcode + \"\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
//        logger.info(result.toJSONString());
//        Assert.assertTrue(result.getString("httpStatus").equals("200"));
//        JSONObject body = JSON.parseObject(result.getString("httpBody"));
//
//        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
//        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

//        Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
//        Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //      Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("20"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("8"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9903"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
//        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));


    }
*/

    @Test
    //case5:衣物id和衣物名称不对应
    public void testSort5() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId = qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(5, 13);

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":6,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        //Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        //Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("20"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("6"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9885"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //case6：品牌里有特殊字符
    public void testSort6() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId =  qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(4, 13);

        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"/a/n/t@%*&\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":0}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        //Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        //Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("21"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("8"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9887"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderClothesList"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("brand").contains("/a/n/t@%*&"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);

    }

    @Test
    //case7：配件标示和衣物id衣物名称不对应
    public void testSort7() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        OrderQianshou qianshouOrder = new OrderQianshou();
        String orderId = qianshouOrder.createQianshouOrder();
        long ordersn = qianshouOrder.ordersn;
        long unixTimestamp = qianshouOrder.unixTimestamp;
        String bagsn = qianshouOrder.bagsn;
        String washingBarcode = (Long.toString(System.currentTimeMillis())).substring(4, 13);

        //is_accessory标示改为1
        String strData = "[{\"outlet_id\":458,\"washing_barcode\":\"" + washingBarcode + "\",\"clothes_id\":8,\"clothes_name\":\"背心\",\"brand\":\"\",\"flaw\":\"%e8%b5%b7%e7%90%83+%e7%a3%a8%e6%8d%9f+%e6%8e%89%e7%bb%92+\",\"color\":\"暗灰\",\"grid\":\"\",\"wash_result\":\"\",\"is_accessory\":1}]";

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("avjfjsj","13.02");
        this.queryParams.put("bagsn",bagsn);
        this.queryParams.put("data",strData);
        this.queryParams.put("ordersn",ordersn);
        this.queryParams.put("timestamp",unixTimestamp);

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallSort("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String strCloth = "select * from order_clothes_lists where order_sn = '" + ordersn + "' and outlet_id is not null";
        ResultSet retCloth = mysqlQaDao.execQuerySql(strCloth);

        //Assert.assertEquals("返回值不符合预期",ordersn,retCloth.getLong("ordersn"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("bagsn").contains(bagsn));
        //Assert.assertEquals("返回值不符合预期", 42803, retCloth.getLong("shmxid"));

        //Assert.assertTrue("返回值不符合预期", retCloth.getString("order_id").contains(orderId));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("order_sn").contains(String.valueOf(ordersn)));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("bag_sn").contains(bagsn));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("status").contains("20"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_id").contains("458"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_id").contains("8"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("clothes_name").contains("背心"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price_id").contains("9887"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("courier_price").contains("12.00"));
        //Assert.assertTrue("返回值不符合预期", retCloth.getString("outlet_price").contains("9.00"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("color").contains("暗灰"));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("washing_barcode").contains(washingBarcode));
        Assert.assertTrue("返回值不符合预期", retCloth.getString("type").contains("OrderAccessoryList"));

        //删除测试数据
        DelData delData = new DelData();
        delData.delData(orderId);
    }
}
