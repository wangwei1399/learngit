package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by guolaidong on 2016/4/11.
 */
public class VersionsTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testVersions() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("outlet_id","458");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        String sign = parseMD5.parseStrToMd5L32(strqueryParams + "RNn40Iu1kd");
        this.queryParams.put("sign", sign);

        JSONObject result = this.jgdAPIModuleService.CallVersionsV4("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_jiamubiao"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_pinpai"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_xiaci"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_xiaoguo"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_price_list"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_accessory_list"));
        Assert.assertEquals(true,result.getString("httpBody").contains("version_rewash_operation_list"));



    }

}
