package com.edaixi.qa.jiagongdian;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

/**
 * Created by guolaidong on 2016/5/6.
 */
public class DelData {

    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    public void delData(String orderId){

        String delOrder = "delete from ims_washing_order where id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delOrder);

        String delTranstasks = "delete from trans_tasks where order_id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delTranstasks);

        String delDispatchtasks = "delete from dispatch_tasks where order_id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delDispatchtasks);

        String delTransgroups = "delete from trans_groups where order_id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delTransgroups);

        String delWorkingtasks = "delete from working_tasks where order_id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delWorkingtasks);

        String delOrderclotheslists = "delete from order_clothes_lists where order_id = '" + orderId + "'";
        mysqlQaDao.execUpdateSql(delOrderclotheslists);

    }
}
