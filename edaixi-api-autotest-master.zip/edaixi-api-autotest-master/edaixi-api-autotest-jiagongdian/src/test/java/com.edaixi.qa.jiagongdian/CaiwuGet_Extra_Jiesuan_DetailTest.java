package com.edaixi.qa.jiagongdian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by guolaidong on 2016/1/6.
 */
public class CaiwuGet_Extra_Jiesuan_DetailTest {

    private static Logger logger = LoggerFactory.getLogger(QianshouTest.class);
    private JgdAPIModuleService jgdAPIModuleService = new JgdAPIModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    //补贴明细
    public void testCaiwuGet_Extra_Jiesuan_Detail() throws SQLException, NoSuchAlgorithmException, CloneNotSupportedException, UnsupportedEncodingException {

        this.queryParams.put("app_key", "jiagongdian_app");
        this.queryParams.put("jiagongdian_id","458");
        this.queryParams.put("jiesuan_id","32");

        //取得sign值
        GetSign getSign = new GetSign();
        String sign = getSign.getSign(this.queryParams);

        this.queryParams.put("sign",sign);

        JSONObject result = this.jgdAPIModuleService.CallGet_Extra_Jiesuan_Detail("", "", this.queryParams);

        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("price"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":35"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"outlet_order_cleaning_id\":32"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"extra_id\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"price\":\"10000.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"comment\":\"耗材10000\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":36"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"extra_id\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"price\":\"5000.0\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"comment\":\"辅料5000\""));
    }
}
