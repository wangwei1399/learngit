package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Encoder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class EdxpayModuleService {
	private static Logger logger = LoggerFactory.getLogger(EdxpayModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
	private RestService service = null;

	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;
	private Map<String, Object> pfChargeParams = null;
	private Map<String, Object> pfChargeDetailParams = null;
	private Map<String, Object> couponList = null;
	private Map<String, Object> couponSncodeParams = null;
	private Map<String, Object> rechargeParams = null;
	private Map<String, Object> rechargeSn01Params = null;
	private Map<String, Object> icardCardParams = null;
	private Map<String, Object> ecardLimitParams = null;
	private Map<String, Object> orderParams = null;
	long current_time = System.currentTimeMillis();



	public EdxpayModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.pfChargeParams = new HashMap<String, Object>();
		this.pfChargeDetailParams = new HashMap<String, Object>();
		this.couponList = new HashMap<String, Object>();
		this.couponSncodeParams = new HashMap<String, Object>();
		this.rechargeParams = new HashMap<String, Object>();
		this.rechargeSn01Params = new HashMap<String, Object>();
		this.icardCardParams = new HashMap<String, Object>();
		this.ecardLimitParams = new HashMap<String, Object>();
		this.orderParams = new HashMap<String, Object>();
		this.globalConf = GlobalConfig.getProperties();

		service = (RestService) this.baseServiceFactory.getService();
		service.init(this.globalConf.getProperty("edxpay.addr"));
	}


	public static String base64Encode(byte[] bytes){
		return new BASE64Encoder().encode(bytes);
	}

	public void createPfChargeData(int pf_charge_id, int fan_id,int type, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int user_type) {
		pfChargeParams.put("id", pf_charge_id);
		pfChargeParams.put("fan_id", fan_id);
		pfChargeParams.put("type", type);
		pfChargeParams.put("status", status);
		pfChargeParams.put("fee", fee);
		pfChargeParams.put("coupon_fee", coupon_fee);
		pfChargeParams.put("ecard_fee", ecard_fee);
		pfChargeParams.put("icard_fee", icard_fee);
		pfChargeParams.put("transfer_fee", transfer_fee);
		pfChargeParams.put("pay_fee", pay_fee);
		pfChargeParams.put("user_type", user_type);
		generalRongChain04Data.GeneralPfCharge(pfChargeParams);
	};

	public void createPfChargeDetailData(int pf_charge_detail_id, int fan_id,int business_order, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int charge_id) {
		pfChargeDetailParams.put("id", pf_charge_detail_id);
		pfChargeDetailParams.put("business_order", business_order);
		pfChargeDetailParams.put("fan_id", fan_id);
		pfChargeDetailParams.put("status", status);
		pfChargeDetailParams.put("fee", fee);
		pfChargeDetailParams.put("coupon_fee", coupon_fee);
		pfChargeDetailParams.put("ecard_fee", ecard_fee);
		pfChargeDetailParams.put("icard_fee", icard_fee);
		pfChargeDetailParams.put("transfer_fee", transfer_fee);
		pfChargeDetailParams.put("pay_fee", pay_fee);
		pfChargeDetailParams.put("charge_id", charge_id);
		generalRongChain04Data.GeneralPfDetailCharge(pfChargeDetailParams);
	};

	public void createCouponData(int icoupon_id,String price,int coupon_category_id, String coupon_clothes_id, int discount_type, String coupon_exclusive_channels, int coupon_least_price, int coupon_city_id, int coupon_user_type){
		couponList.put("id", icoupon_id);
		couponList.put("coupon_price", price);
		couponList.put("totalnum", 100);
		couponList.put("discount_type",discount_type);
		couponList.put("discount_price",50);
		couponList.put("usednum", 0);
		couponList.put("category_id",coupon_category_id);
		couponList.put("clothes_id",coupon_clothes_id);
		couponList.put("exclusive_channels",coupon_exclusive_channels);
		couponList.put("least_price",coupon_least_price);
		couponList.put("city_id",coupon_city_id);
		couponList.put("user_types",coupon_user_type);
		generalRongChain04Data.GeneralIcouponList(couponList);
	}

	public void createCouponData(int icoupon_id,int price,int coupon_category_id, String coupon_clothes_id,
								 int discount_type, String coupon_exclusive_channels, int coupon_least_price,
								 int coupon_city_id, String coupon_user_type, long starttime, long endtime){
		couponList.put("id", icoupon_id);
		couponList.put("coupon_price", price);
		couponList.put("totalnum", 100);
		couponList.put("discount_type",discount_type);
		couponList.put("discount_price",50);
		couponList.put("usednum", 0);
		couponList.put("category_id",coupon_category_id);
		couponList.put("clothes_id",coupon_clothes_id);
		couponList.put("exclusive_channels",coupon_exclusive_channels);
		couponList.put("least_price",coupon_least_price);
		couponList.put("city_id",coupon_city_id);
		couponList.put("user_types",coupon_user_type);
		couponList.put("starttime", starttime);
		couponList.put("endtime", endtime);

		generalRongChain04Data.GeneralIcouponList(couponList);
	}


	public void createCouponSncdeData(int icoupon_sncode_id,int icoupon_id,String sncode,int fan_id,int used,int charge_id){
		// 模拟ims_icoupon_sncode表的数据
		couponSncodeParams.put("id",icoupon_sncode_id);
		couponSncodeParams.put("cid",icoupon_id);
		couponSncodeParams.put("sncode",sncode);
		couponSncodeParams.put("fan_id",fan_id);
		couponSncodeParams.put("used",used);
		couponSncodeParams.put("charge_id",charge_id);
		generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);
	}

	public void createChargeData(int recharge_id,Double chargePrice,int usednum,String zhenqian,int kind,int validity_type,int charge_validity_type){
		rechargeParams.put("recharge_id",recharge_id);
		rechargeParams.put("weid",0);
		rechargeParams.put("price",chargePrice);
		rechargeParams.put("usednum",usednum);
		rechargeParams.put("zhenqian",zhenqian);
		rechargeParams.put("kind",kind);
		rechargeParams.put("validity_type",validity_type);
		rechargeParams.put("charge_validity_type",charge_validity_type);
		generalRongChain04Data.GeneralRecharge(rechargeParams);
	}


	public void createChargeSncodeData(int recharge_sncode_id,int recharge_id,String sncode,int charge_user_type,int charge_card_type,Double charge_price,String zhenqian,int used,int fan_id){

		rechargeSn01Params.put("recharge_sncode_id", recharge_sncode_id);
		rechargeSn01Params.put("rid", recharge_id);
		rechargeSn01Params.put("sncode", sncode);
		rechargeSn01Params.put("from_user", "NULL");
		rechargeSn01Params.put("user_type", charge_user_type);
		rechargeSn01Params.put("card_type", charge_card_type);
		rechargeSn01Params.put("price", charge_price);
		rechargeSn01Params.put("zhenqian", zhenqian);
		rechargeSn01Params.put("used", used);
		rechargeSn01Params.put("fan_id", fan_id);
		rechargeSn01Params.put("draw_time", current_time / 1000);
		generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);
	}

	public void createChargeSncodeData(int recharge_sncode_id,int recharge_id,String sncode,int charge_user_type,int charge_card_type,
									   Double charge_price,String zhenqian,int used,int fan_id, long beginTime, long endTime){

		rechargeSn01Params.put("recharge_sncode_id", recharge_sncode_id);
		rechargeSn01Params.put("rid", recharge_id);
		rechargeSn01Params.put("sncode", sncode);
		rechargeSn01Params.put("from_user", "NULL");
		rechargeSn01Params.put("user_type", charge_user_type);
		rechargeSn01Params.put("card_type", charge_card_type);
		rechargeSn01Params.put("price", charge_price);
		rechargeSn01Params.put("zhenqian", zhenqian);
		rechargeSn01Params.put("used", used);
		rechargeSn01Params.put("fan_id", fan_id);
		rechargeSn01Params.put("draw_time", current_time / 1000);
		rechargeSn01Params.put("starttime", beginTime);
		rechargeSn01Params.put("endtime", endTime);
		generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);
	}

	public void createCardData(int icard_card_id,String sncode,double card_coin,double card_money,int fan_id,double card_zhenqian){

		icardCardParams.put("id",icard_card_id);
		icardCardParams.put("card_number",sncode);
		icardCardParams.put("coin",card_coin);
		icardCardParams.put("money",card_money);
		icardCardParams.put("updatetime",current_time/1000);
		icardCardParams.put("dateline",current_time/1000);
		icardCardParams.put("fan_id",fan_id);
		icardCardParams.put("zhenqian",card_zhenqian);
		generalRongChain04Data.GeneralEcardCard(icardCardParams);
	}

	public void createOrderData(int order_id,String order_total_price,String order_delivery_fee,int fan_id){
		orderParams.put("order_id",order_id);
		orderParams.put("order_sn",CommonTools.getOrdersn(order_id));
		orderParams.put("status",1);
		orderParams.put("status_delivery",1);
		orderParams.put("pay_status",0);
		orderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
		orderParams.put("washing_time","14:00~16:00");
		orderParams.put("old_category_id",1);
		orderParams.put("totalprice",order_total_price);
		orderParams.put("delivery_fee",order_delivery_fee);
		orderParams.put("fan_id",fan_id);
		generalRongChain04Data.GeneralOrder(orderParams);
	};

	public void createEcardLimitData(int recharge_id,int ecard_limit_category_id,int fan_id){
		ecardLimitParams.put("id",recharge_id);
		ecardLimitParams.put("category_id",ecard_limit_category_id);
		generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
		this.queryParams.put("user_id",fan_id);
	}


	public JSONObject CallIcardIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("icard.index"), method, queryParam, httpHead);
	}
	public JSONObject CallIcardOtherList(Map<String, Object> queryParam,Map<String, Object> httpHead){
		String method = "get";
		return this.service.callApi2Json(this.globalConf.getProperty("icard.other.list"), method, queryParam, httpHead);
	}
	public JSONObject CallRcardIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("rcard.index"), method, queryParam, httpHead);
	}
	public JSONObject CallRechargeCardIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("rechargecard.index"), method,queryParam,httpHead);
	}
	public JSONObject CallVouchersIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("vouchers.index"), method, queryParam, httpHead);
	}
	public JSONObject CallVouchersQueryIcard(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("vouchers.queryicard"), method,queryParam,httpHead);
	}
	public JSONObject CallBindUserCoupon(String authorization,Map<String, Object> queryParam){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("coupon.bind.user.coupon"), method, authorization,queryParam);
	}

	//请求得到优惠券返回列表
	public JSONObject CallGetCouponList(String authorization,Map<String, Object> queryParam){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("coupon.user.coupon.list"), method, authorization,queryParam);
	}

	public JSONObject CallSendCouponByCid(String authorization,Map<String, Object> queryParam){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("coupon.send.coupon.bycid"), method, authorization,queryParam);
	}
	public JSONObject CallCountUserCoupon(String authorization,Map<String, Object> queryParam){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("coupon.count.user.coupon"), method, authorization,queryParam);
	}

    public JSONObject GetDiscountPrice(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.service.callApi2Json(this.globalConf.getProperty("coupon.get.discountPrice"), method, authorization, queryParam);
    }

	public JSONObject CallUserEcardList(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("ecard.user.ecard.list"), method, queryParam, httpHead);
	}
	public JSONObject CallUserEcardListByString(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("ecard.user.ecard.list"), method, queryParam, httpHead);
	}
	public JSONObject CallWalletIndex(Map<String, Object> queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("calculate.wallet"), method,queryParam,httpHead);
	}

	public JSONObject CallGetUsableCouponList(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("couponext.getusablecouponlist"), method, queryParam, httpHead);
	}
	public JSONObject CallChargeIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("charge.index"), method, queryParam, httpHead);
	}


	public JSONObject CallPlatformIndex(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("platform.index"), method,queryParam,httpHead);
	}

	public JSONObject CallPlatformCallBack(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("platform.callback"), method,queryParam,httpHead);
	}

	public JSONObject CallChargeEdetail(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("charge.edetail"), method,queryParam,httpHead);
	}

	public JSONObject CallPlatformEpay(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("platform.epay"), method,queryParam,httpHead);
	}
	public JSONObject CallChargeCancel(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("charge.cancel"), method,queryParam,httpHead);
	}
	public JSONObject CallEcardids(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("ecard.get.by.ids"), method,queryParam,httpHead);
	}
	public JSONObject CallCreateCorpCard(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("ecard.create.corp.card"), method,queryParam,httpHead);
	}
	public JSONObject CallCompanyWalletAccount(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("company.wallet.account"), method,queryParam,httpHead);
	}
	public JSONObject CallGetCompanyInfo(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("get.company.info"), method,queryParam,httpHead);
	}
	public JSONObject CallRefundDeal(String queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2JsonByQueryStr(this.globalConf.getProperty("refund.deal"), method,queryParam,httpHead);
	}

	public JSONObject CallRefundDeal(Map<String, Object> queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.service.callApi2Json(this.globalConf.getProperty("refund.deal"), method,queryParam,httpHead);
	}

	//查询用户余额接口 by:heyi
	public JSONObject CallUserBalanceQuery(String user_id){
		String method = "get";
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("user_id", user_id);
		return service.callApi2Json(this.globalConf.getProperty("user.balance.query"), method, "", param);
	}

	//扣除用户余额接口 by:heyi
	public JSONObject CallUserBalancePayment(String user_id, String mall_order_id, String money){
		String method = "post";
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("user_id", user_id);
		param.put("mall_order_id", mall_order_id);
		param.put("fee", money);

		return service.callApi2Json(this.globalConf.getProperty("user.balance.payment"), method, "", param);
	}

	//退款接口 by:heyi
	public JSONObject CallUserBalanceRefund(String user_id, String mall_order_id, String money, int refund_type) {
		String method = "post";

		Map<String, Object> param = new HashMap<String, Object>();
		param.put("user_id", user_id);
		param.put("mall_order_id", mall_order_id);
		param.put("fee", money);
		param.put("refund_type", refund_type);

		return service.callApi2Json(this.globalConf.getProperty("user.balance.refund"), method, "", param);
	}
}
