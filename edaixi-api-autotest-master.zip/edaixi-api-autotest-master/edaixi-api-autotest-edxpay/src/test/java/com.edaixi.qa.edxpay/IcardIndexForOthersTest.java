package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class IcardIndexForOthersTest {

    private static Logger logger = LoggerFactory
            .getLogger(IcardIndexForOthersTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private JSONObject queryParams = new JSONObject();
    private Map<String, Object> queryMapParams = null;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    // 操作充值的用户
    int fan_id = 0;

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryMapParams = new HashMap<String, Object>();
        String fan_info = "select id from ims_fans order by id desc limit 1";
        fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-8-15
     * @Scenario:用户使用微信为他人充值
     *   when:支付方式为微信
     *   where:可以充值的地方
     *   how:充值100元
     *   then: 充值成功，用户的余额等于充值后的金额，为100
     */
    public void testIcardRechageForOthers() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        int user_id = 623565;
        int pay_type = 2;//微信
        String trans_type = "recharge";
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.queryParams.put("relation_user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);
        logger.info(result.toString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String retTid = loginBody.getJSONObject("data").getString("trade_no");
        String queryPayLog = "select type,weid,tid,openid,fee,status,module,fan_id,createtime,total_money, relation_fan_id from ims_paylog where tid = '" + retTid + "'";
        ResultSet queryPayLogInfo = mysqlQaDao.execQuerySql(queryPayLog);
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期","wechat",queryPayLogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期",0,queryPayLogInfo.getInt("weid"));
        Assert.assertEquals("返回值不符合预期", null,queryPayLogInfo.getString("openid"));
        Assert.assertEquals("返回值不符合预期", "100.00", queryPayLogInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0, queryPayLogInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", "icard", queryPayLogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期",623565,queryPayLogInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期",this.fan_id,queryPayLogInfo.getInt("relation_fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPayLogInfo.getString("total_money"));

    }



}
