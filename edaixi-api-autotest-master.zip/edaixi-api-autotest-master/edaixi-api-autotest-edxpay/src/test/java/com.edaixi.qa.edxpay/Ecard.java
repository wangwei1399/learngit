package com.edaixi.qa.edxpay;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by he_yi on 16/7/26.
 */
public class Ecard {
    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private int id = 0;
    private int limitId = 0;
    private int fan_id = CommonTools.getFanId(mysqlQaDao);
    private int money = 0;
    private String sncode = "";
    private long beginTime;
    private long endTime;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private int recharge_id;
    private int eCardZhenqian = 0;
    private int prices = 0;

    public Ecard(int money){
        this.money = money;
        beginTime = strToUnix(CommonTools.getBeforDate("yyyy-MM-dd HH:mm:ss", 3));
        endTime = strToUnix(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
    }

    public Ecard(int money, int fan_id){
        this(money);
        this.fan_id = fan_id;
    }

    public void create(){
        // 模拟ims_recharge数据－用户支付的时候选择E卡
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        Double chargePrice = (double) money;
        String zhenqian = String.valueOf(this.eCardZhenqian);
        int usednum = 0;
        int kind = 2;
        int validity_type = 0;
        int charge_validity_type = 0;
        edxpayModuleService.createChargeData(recharge_id, chargePrice, usednum, zhenqian, kind, validity_type, charge_validity_type);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        int charge_user_type = 3;
        int charge_card_type = 1;
        Double charge_price = (double) money;
        int used = 0;
        sncode = String.valueOf(CommonTools.getRandomInt(9));
        System.out.println("endTime:"+endTime);
        edxpayModuleService.createChargeSncodeData(id, recharge_id, sncode, charge_user_type, charge_card_type, charge_price, zhenqian, used, fan_id, beginTime, endTime);

        // 模拟ims_ecard_limit的数据
        int ecard_limit_category_id = 0;
        edxpayModuleService.createEcardLimitData(recharge_id, ecard_limit_category_id, fan_id);

    }

    public void delete(){
        String sql = "delete from ims_recharge where id = "+recharge_id;
        mysqlQaDao.execUpdateSql(sql);
        sql = "delete from ims_recharge_sncode where id = "+id;
        mysqlQaDao.execUpdateSql(sql);
        sql = "delete from ims_ecard_limit where id = "+recharge_id;
        mysqlQaDao.execUpdateSql(sql);
    }

    public int getMoney(){
        return money;
    }

    public int getId(){
        return id;
    }

    public String getSncode(){
        return sncode;
    }

    private long strToUnix(String dateTime){
        Date date = null;
        try {
            date = dateFormat.parse(dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long time = date.getTime()/1000; //java时间是毫秒级别,时间戳是秒级别
        return time;
    }

    private String unixToStr(long unix){
        Date date = new Date(unix*1000);
        return dateFormat.format(date);
    }

    public void seteCardZhenqian(int zhanqian){
        this.eCardZhenqian = zhanqian;
        if (money < eCardZhenqian){
            money = eCardZhenqian;
        }
    }


    public String getBeginTime() {
        return unixToStr(beginTime);
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = strToUnix(beginTime);
    }

    public String getEndTime() {
        return unixToStr(endTime);
    }

    public void setEndTime(String endTime) {
        this.endTime = strToUnix(endTime);
    }

    public long getBeginTimeUnix(){
        return beginTime*1000;
    }

    public long getEndTimeUnix(){
        return endTime*1000;
    }
}
