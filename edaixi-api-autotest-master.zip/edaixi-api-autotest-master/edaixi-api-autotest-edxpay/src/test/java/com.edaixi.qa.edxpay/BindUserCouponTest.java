package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class BindUserCouponTest {

    private static Logger logger = LoggerFactory
            .getLogger(BindUserCouponTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> couponList = null;
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> httpHead = null;
    private Map<String, Object> fanParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams  = new HashMap<String, Object>();
        this.couponList = new HashMap<String, Object>();
        this.fanParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();
        logger.info("in teardown!");
    }

    @Test

    public void testBindUserCoupon0() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(6)) + String.valueOf(CommonTools.getRandomInt(6));
        // 模拟优惠券的模版
        int discount_type = 1;
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "10";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "NULL";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 40; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, discount_type,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, 0, 0, 0);

        //用fan_id去绑定这个sncode
        this.queryParams.put("type", 1);
        this.queryParams.put("fan_id", fan_id);
        this.queryParams.put("sncode", sncode);
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        logger.info(this.queryParams.toString());
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用绑定接口
        JSONObject result = this.edxpayModuleService.CallBindUserCoupon(buildString,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue("返回值不符合预期", result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期", loginBody.getString("resp_code").equals("0000"));
        Assert.assertEquals("返回值不符合预期", "成功", URLDecoder.decode(loginBody.getString("resp_msg"),"UTF-8"));

    }

}
