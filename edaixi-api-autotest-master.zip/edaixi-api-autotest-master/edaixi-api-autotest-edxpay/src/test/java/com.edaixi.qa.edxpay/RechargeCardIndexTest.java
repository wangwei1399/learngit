package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

public class RechargeCardIndexTest {

    private static Logger logger = LoggerFactory
            .getLogger(RechargeCardIndexTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private JSONObject queryParams = new JSONObject();
    private JSONObject rechargeParams = new JSONObject();
    private JSONObject fanParams = new JSONObject();
    private JSONObject rechargeSn01Params = new JSONObject();
    private JSONObject rechargeSn02Params = new JSONObject();

    private JSONObject icardCardParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    Date dt = new Date();
    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值
     *   when:充值卡模版的kind=0,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:完成正常充值
     */
    public void testRechargeCardIndex() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",1,loginBody.getJSONObject("data").getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","充值成功，充值余额" + (int)price + "元",loginBody.getJSONObject("data").getString("content"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",1,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",fan_id,queryRechargeSncodeInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期",queryRechargeSncodeInfo.getString("updated_at").contains(formatDate.format(dt)));

        String queryIcardCard = "select coin,zhenqian from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期","150.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期","1280.00",queryIcardCardInfo.getString("zhenqian"));

        // 验证vouchers表中数据正确
        String queryVouchersRcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ icard_card_id + " and card_type = 'Icard'";
        ResultSet queryVouthersRcardInfo = mysqlQaDao.execQuerySql(queryVouchersRcard);
        Assert.assertEquals("返回值不符合预期",1,queryVouthersRcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","80.00",queryVouthersRcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","100.00",queryVouthersRcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",recharge_sncode_id,queryVouthersRcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","RechargeSncode",queryVouthersRcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",icard_card_id,queryVouthersRcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersRcardInfo.getString("card_type"));

    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值但是用户在icard表里面最开始没有数据
     *   when:充值卡模版的kind=0,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:完成正常充值
     */
    public void testRechargeCardNoCard() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);

        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",1,loginBody.getJSONObject("data").getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","充值成功，充值余额" + (int)price + "元",loginBody.getJSONObject("data").getString("content"));


        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",1,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",fan_id,queryRechargeSncodeInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期",queryRechargeSncodeInfo.getString("updated_at").contains(formatDate.format(dt)));

        String queryIcardCard = "select id,coin,zhenqian from ims_icard_card where fan_id = " + fan_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        int icard_card_id = queryIcardCardInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期","100.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期","80.00",queryIcardCardInfo.getString("zhenqian"));
        // 验证vouchers表中数据正确
        String queryVouchersRcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where  card_id= "+ icard_card_id + " and card_type = 'Icard'";
        ResultSet queryVouthersRcardInfo = mysqlQaDao.execQuerySql(queryVouchersRcard);
        Assert.assertEquals("返回值不符合预期",1,queryVouthersRcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","80.00",queryVouthersRcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","100.00",queryVouthersRcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",recharge_sncode_id,queryVouthersRcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","RechargeSncode",queryVouthersRcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",icard_card_id,queryVouthersRcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersRcardInfo.getString("card_type"));

    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试一个用户没有任何首充卡的记录情况下进行首充卡充值
     *   when:recharge_group_id=1
     *   where:充值首充卡
     *   then:充值成功
     */
    public void testRechargeIsShouAndUsedIs0() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "100.00";
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("recharge_group_id",1);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",1,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",fan_id,queryRechargeSncodeInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期",queryRechargeSncodeInfo.getString("updated_at").contains(formatDate.format(dt)));

        String queryIcardCard = "select coin,zhenqian from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期","150.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期","1280.00",queryIcardCardInfo.getString("zhenqian"));

        // 验证vouchers表中数据正确
        String queryVouchersRcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ icard_card_id + " and card_type = 'Icard'";
        ResultSet queryVouthersRcardInfo = mysqlQaDao.execQuerySql(queryVouchersRcard);
        Assert.assertEquals("返回值不符合预期",1,queryVouthersRcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","80.00",queryVouthersRcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","100.00",queryVouthersRcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",recharge_sncode_id,queryVouthersRcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","RechargeSncode",queryVouthersRcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",icard_card_id,queryVouthersRcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersRcardInfo.getString("card_type"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试一个用户已经使用过首充卡的记录情况下进行首充卡充值
     *   when:recharge_group_id=1
     *   where:充值首充卡
     *   then:充值不成功
     */
    public void testRechargeIsShouAndUsedIs1() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "100.00";
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("recharge_group_id",1);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",1);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第二条ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn02Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn02Params.put("rid",recharge_id);
        rechargeSn02Params.put("sncode",sncode+1);
        rechargeSn02Params.put("from_user","NULL");
        rechargeSn02Params.put("user_type",1);
        rechargeSn02Params.put("card_type",0);
        rechargeSn02Params.put("price",price);
        rechargeSn02Params.put("zhenqian",zhenqian);
        rechargeSn02Params.put("used",0);
        rechargeSn02Params.put("fan_id","NULL");
        rechargeSn02Params.put("starttime","NULL");
        rechargeSn02Params.put("endtime","NULL");
        rechargeSn02Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn02Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").contains("1100"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试用户充值的充值卡已经被使用了
     *   when:recharge_group_id=1
     *   where:充值首充卡
     *   then:充值不成功
     */
    public void testRechargeIsShouAndIsUsed() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "100.00";
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("recharge_group_id",1);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第二条ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",1);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").contains("1100"));
    }


    @Test
    /**
     *
     * @author ningyao.zn
     * 测试充值卡－is_actived = 0
     *
     */
    public void testIsActivesIs0() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "100.00";
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("recharge_group_id",1);
        rechargeParams.put("is_actived",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第二条ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").contains("1500"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值绝对有效期
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=1;
     *   where:用户端充值
     *   then:完成正常充值
     */
    public void testRechargeECardIndex() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",2,loginBody.getJSONObject("data").getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","兑换成功，兑换e卡" + (int)price + "元",loginBody.getJSONObject("data").getString("content"));

        String queryRechargeSncode = "select used,fan_id,updated_at,card_type,draw_time,starttime,endtime,price,zhenqian from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",fan_id,queryRechargeSncodeInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期",queryRechargeSncodeInfo.getString("updated_at").contains(formatDate.format(dt)));
        Assert.assertEquals("返回值不符合预期",1,queryRechargeSncodeInfo.getInt("card_type"));
        Assert.assertTrue("返回值不符合预期", (current_time/1000)-Long.parseLong(queryRechargeSncodeInfo.getString("draw_time")) < 60*3);
        Assert.assertTrue("返回值不符合预期",(current_time/1000)-Long.parseLong(queryRechargeSncodeInfo.getString("starttime")) < 60*3);
        Assert.assertEquals("返回值不符合预期",String.valueOf(CommonTools.getTimesnight()-1+24*60*60*20),queryRechargeSncodeInfo.getString("endtime"));

        String queryIcardCard = "select coin,zhenqian from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期","50.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期","1200.00",queryIcardCardInfo.getString("zhenqian"));


    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值但是充值卡已下架
     *   when:充值卡模版的kind=0,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“充值卡已下架”
     */
    public void testRechargeCardButCardIsNotActived() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("is_actived",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","0");
        rechargeSn01Params.put("endtime","0");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","充值卡已下架", URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","1500",loginBody.getString("resp_code"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("fan_id"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值但是充值卡已被使用
     *   when:充值卡模版的kind=0,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“充值卡已失效”
     */
    public void testRechargeCardButCardIsUsed() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("is_actived",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",1);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);
        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","充值卡已失效", URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","1100",loginBody.getString("resp_code"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",1,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",fan_id,queryRechargeSncodeInfo.getInt("fan_id"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值但是充值卡是空白卡
     *   when:充值卡模版的kind=0,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“充值卡已失效”
     */
    public void testRechargeCardButCardIsKong() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",0.00);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",0);
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","空白充值卡", URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","1101",loginBody.getString("resp_code"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("fan_id"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试充值卡充值但是密码错误
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“密码验证失败”
     */
    public void testRechargeCardButCardIsWorry() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long price = (long) 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "400" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",0);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",0);
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode + 1);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","密码验证失败", URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","1110",loginBody.getString("resp_code"));

        String queryRechargeSncode = "select used,fan_id,updated_at from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryRechargeSncodeInfo = mysqlQaDao.execQuerySql(queryRechargeSncode);
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期",0,queryRechargeSncodeInfo.getInt("fan_id"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是E卡的模版不存在
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:完成正常充值
     */
    public void testRechargeECardButTemplateNonExistent() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;


        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","充值卡已下架",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1500", loginBody.getString("resp_code"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是该e卡已经兑换
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“该e卡已经兑换！”
     */
    public void testRechargeECardButEcardIsUsed() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",0.00);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",1);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",CommonTools.getTimesnight()-1-24*60*60);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","该e卡已经兑换",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1600", loginBody.getString("resp_code"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是该e卡已经下架
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“该e卡已经兑换！”
     */
    public void testRechargeECardButEcardIsDownload() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("is_actived",0);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","该e卡已下架",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1601", loginBody.getString("resp_code"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是该e卡为空白e卡
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“该e卡为空白e卡”
     */
    public void testRechargeECardButEcardIsKong() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",0.00);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-24*60*60);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","该e卡为空白e卡",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1602", loginBody.getString("resp_code"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是该e卡已经过期
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“该e卡已经过期”
     */
    public void testRechargeECardButEcardIsOverDue() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1-(24*60*60*20));
        rechargeParams.put("endtime",CommonTools.getTimesnight()-1-(24*60*60*5));
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","该e卡已经过期",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1603", loginBody.getString("resp_code"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-15
     * @Scenario:测试E卡充值但是充值时间未到
     *   when:充值卡模版的kind=2,starttime<=当前时间&endtime>=当前时间;
     *        充值卡的card_type=0;
     *   where:用户端充值
     *   then:返回“该e卡已经过期”
     */
    public void testRechargeECardButEcardIsNotStarted() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        double price = 100.00;
        String zhenqian = "80.00";
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("starttime",CommonTools.getTimesnight()-1+(24*60*60*2));
        rechargeParams.put("endtime",CommonTools.getTimesnight()-1+(24*60*60*5));
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",sncode);
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id","NULL");
        rechargeSn01Params.put("starttime","NULL");
        rechargeSn01Params.put("endtime","NULL");
        rechargeSn01Params.put("draw_time","0");
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("card_user",sncode);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRechargeCardIndex(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","该e卡已经过期",URLDecoder.decode(loginBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "1603", loginBody.getString("resp_code"));

    }

}
