package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralCaiwuAdminData;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class CompanyWalletAccountTest {

    private static Logger logger = LoggerFactory
            .getLogger(CompanyWalletAccountTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private Map<String, Object> queryParams = null;
    private GeneralCaiwuAdminData generalCaiwuAdminData = new GeneralCaiwuAdminData();
    private Map<String, Object> httpHead = null;
    private Map<String, Object> companyParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc-caiwuadmin.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams  = new HashMap<String, Object>();
        this.companyParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();
        logger.info("in teardown!");
    }

    @Test

    public void testTransferIn() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String companyInfo = "select id from company order by id desc limit 1";
        ResultSet companyInfoRet = mysqlQaDao.execQuerySql(companyInfo);
        int id = companyInfoRet.getInt("id") + 1;

        String companyInfo2 = "select company_id from company order by company_id desc limit 1";
        ResultSet companyInfoRet2 = mysqlQaDao.execQuerySql(companyInfo2);
        int company_id = companyInfoRet2.getInt("company_id") + 1;

        int money = 1000;
        int realmoney = 900;
        int note = CommonTools.getRandomInt(4);
        this.companyParams.put("id",id);
        this.companyParams.put("company_id",company_id);
        generalCaiwuAdminData.GeneralCompany(this.companyParams);

        this.queryParams.put("company_id", company_id);
        this.queryParams.put("transaction_type", 1);
        this.queryParams.put("note", note);
        this.queryParams.put("money",money);
        this.queryParams.put("realmoney",realmoney);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        logger.info(this.queryParams.toString());
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用绑定接口
        JSONObject result = this.edxpayModuleService.CallCompanyWalletAccount(buildString,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue("返回值不符合预期", result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", URLDecoder.decode(loginBody.getString("resp_msg"),"UTF-8"));

        String queryCompanyInfo = "select company_id,earnest,advance,wallet,wallet_realmoney from company where id = " + id + "";
        ResultSet queryCompanyRet = mysqlQaDao.execQuerySql(queryCompanyInfo);
        Assert.assertEquals("返回值不符合预期",10000,queryCompanyRet.getInt("earnest"));
        Assert.assertEquals("返回值不符合预期",10000,queryCompanyRet.getInt("advance"));
        Assert.assertEquals("返回值不符合预期",money * 100,queryCompanyRet.getInt("wallet"));
        Assert.assertEquals("返回值不符合预期",realmoney * 100,queryCompanyRet.getInt("wallet_realmoney"));
        int percentage_record = realmoney * 10000 / money;

        String queryCompanyRecordInfo = "select type,money,account_type,note,company_id,is_confirm from company_record where company_id = " + company_id + " and note = " + note + "";
        ResultSet queryCompanyRecordRet = mysqlQaDao.execQuerySql(queryCompanyRecordInfo);
        Assert.assertEquals("返回值不符合预期",5,queryCompanyRecordRet.getInt("type"));//'1是入账，2是出账，３是转化,4是余额转出，５是余额转入';
        Assert.assertEquals("返回值不符合预期",realmoney * 100,queryCompanyRecordRet.getInt("money"));
        Assert.assertEquals("返回值不符合预期",3,queryCompanyRecordRet.getInt("account_type"));
        Assert.assertEquals("返回值不符合预期",1,queryCompanyRecordRet.getInt("is_confirm"));

        String queryCompanyWalletRecordInfo = "select transaction_type,wallet_money,percentage_record,note from company_wallet_record where company_id = " + company_id + " order by id desc limit 1";
        ResultSet queryCompanyWalletRecordRet = mysqlQaDao.execQuerySql(queryCompanyWalletRecordInfo);
        Assert.assertEquals("返回值不符合预期",1,queryCompanyWalletRecordRet.getInt("transaction_type"));
        Assert.assertEquals("返回值不符合预期",money * 100,queryCompanyWalletRecordRet.getInt("wallet_money"));
        Assert.assertEquals("返回值不符合预期",percentage_record,queryCompanyWalletRecordRet.getInt("percentage_record"));
        Assert.assertEquals("返回值不符合预期",note,queryCompanyWalletRecordRet.getInt("note"));

    }
    @Test

    public void testTransferOut() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String companyInfo = "select id from company order by id desc limit 1";
        ResultSet companyInfoRet = mysqlQaDao.execQuerySql(companyInfo);
        int id = companyInfoRet.getInt("id") + 1;

        String companyInfo2 = "select company_id from company order by company_id desc limit 1";
        ResultSet companyInfoRet2 = mysqlQaDao.execQuerySql(companyInfo2);
        int company_id = companyInfoRet2.getInt("company_id") + 1;

        int money = 1000;
        int realmoney = 900;
        int wallet = 1000000;
        int wallet_realmoney = 900000;
        int note = CommonTools.getRandomInt(4);
        this.companyParams.put("id",id);
        this.companyParams.put("company_id",company_id);
        this.companyParams.put("wallet",wallet);
        this.companyParams.put("wallet_realmoney",wallet_realmoney);
        generalCaiwuAdminData.GeneralCompany(this.companyParams);

        this.queryParams.put("company_id", company_id);
        this.queryParams.put("transaction_type", 2);
        this.queryParams.put("note", note);
        this.queryParams.put("money",money);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        logger.info(this.queryParams.toString());
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用绑定接口
        JSONObject result = this.edxpayModuleService.CallCompanyWalletAccount(buildString,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue("返回值不符合预期", result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", URLDecoder.decode(loginBody.getString("resp_msg"),"UTF-8"));

        String queryCompanyInfo = "select company_id,earnest,advance,wallet,wallet_realmoney from company where id = " + id + "";
        ResultSet queryCompanyRet = mysqlQaDao.execQuerySql(queryCompanyInfo);
        Assert.assertEquals("返回值不符合预期",10000,queryCompanyRet.getInt("earnest"));
        Assert.assertEquals("返回值不符合预期",10000,queryCompanyRet.getInt("advance"));
        int wallet_new = wallet-money * 100;
        int wallet_realmoney_new = wallet_realmoney - realmoney * 100;
        Assert.assertEquals("返回值不符合预期",wallet_new,queryCompanyRet.getInt("wallet"));
        Assert.assertEquals("返回值不符合预期",wallet_realmoney_new,queryCompanyRet.getInt("wallet_realmoney"));
        int percentage_record = wallet_realmoney_new * 100 / (wallet_new/100) ;

        String queryCompanyRecordInfo = "select type,money,account_type,note,company_id,is_confirm from company_record where company_id = " + company_id + " and note = " + note + "";
        ResultSet queryCompanyRecordRet = mysqlQaDao.execQuerySql(queryCompanyRecordInfo);
        Assert.assertEquals("返回值不符合预期",4,queryCompanyRecordRet.getInt("type"));//'1是入账，2是出账，３是转化,4是余额转出，５是余额转入';
        Assert.assertEquals("返回值不符合预期",realmoney * 100 * money / money,queryCompanyRecordRet.getInt("money"));
        Assert.assertEquals("返回值不符合预期",3,queryCompanyRecordRet.getInt("account_type"));
        Assert.assertEquals("返回值不符合预期",1,queryCompanyRecordRet.getInt("is_confirm"));

        String queryCompanyWalletRecordInfo = "select transaction_type,wallet_money,percentage_record,note from company_wallet_record where company_id = " + company_id + " order by id desc limit 1";
        ResultSet queryCompanyWalletRecordRet = mysqlQaDao.execQuerySql(queryCompanyWalletRecordInfo);
        Assert.assertEquals("返回值不符合预期",2,queryCompanyWalletRecordRet.getInt("transaction_type"));
        Assert.assertEquals("返回值不符合预期",money * 100,queryCompanyWalletRecordRet.getInt("wallet_money"));
        Assert.assertEquals("返回值不符合预期",percentage_record,queryCompanyWalletRecordRet.getInt("percentage_record"));
        Assert.assertEquals("返回值不符合预期",note,queryCompanyWalletRecordRet.getInt("note"));

    }

}
