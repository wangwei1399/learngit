package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import org.junit.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by he_yi on 16/7/26.
 */
public class RefundTest {
    private static Logger logger = LoggerFactory
            .getLogger(RefundTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private MysqlQaDao mysqlQaDao = null;
    private int fan_id, cardId;
    private Map<String, Object> httpHead = new HashMap<String, Object>();
    private DecimalFormat df = new DecimalFormat("#.00");
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private SimpleDateFormat yMd = new SimpleDateFormat("yyyy-MM-dd");
    private double couponMoney = 0;
    private double balance = 0.00;
    private double ecardMoney = 0;
    private double transferMoney = 0;
    private double thirdPartyMoney = 0.00;
    private double cashMoney = 0.00;
    private int newEcardId = 0;
    private int couponId = 0;
    private Coupons coupons;
    private Ecard ecard;
    private RefundOrder refundOrder;
    private Map<Integer, Ecard> ecardMap = new HashMap<>();
    private CreatePayOrder createPayOrder;

    @Before
    public void init(){
        couponMoney = 0.00;
        balance = 0.00;
        ecardMoney = 0.00;
        transferMoney = 0.00;
        thirdPartyMoney = 0.0;
        newEcardId = 0;
        couponId = 0;
        coupons = null;
        ecard = null;
        refundOrder = null;
        ecardMap = new HashMap<>();

        mysqlQaDao = new MysqlQaDao();
        fan_id = CommonTools.getFanId(mysqlQaDao);
        String sql = "select id from ims_icard_card where fan_id = "+fan_id;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                cardId = resultSet.getInt("id");
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    }

    @After
    public void close(){
        if (!ecardMap.isEmpty()){
            for (Map.Entry<Integer, Ecard> tmpMap: ecardMap.entrySet()){
                tmpMap.getValue().delete();
            }

        }

        if (coupons != null){
            coupons.delete();
        }

        if (createPayOrder != null){
            createPayOrder.deleteClothPrices();
        }

        mysqlQaDao.close();
        mysqlQaDao = null;
    }

    private String getRespCodeError(String resp_code){
        String code_error = "";
        switch (resp_code){
            case "0000":
                code_error = "退款成功";
                break;
            case "1001":
                code_error =" 参数错误";
                break;
            case "1720":
                code_error = "e卡付款信息有误";
                break;
            case "1721":
                code_error = "e卡已为衣物退款";
                break;
            case "1722":
                code_error = "e卡退款失败";
                break;
            case "1723":
                code_error = "e卡退款衣物不存在";
                break;
            case "1900":
                code_error = "该订单尚未支付";
                break;
            case "1901":
                code_error = "该订单已经退款";
                break;
            case "1902":
                code_error = "订单支付流水错误";
                break;
            case "1903":
                code_error = "订单优惠券退还失败";
                break;
            case "1904":
                code_error = "订单付款信息有误";
                break;
            case "1905":
                code_error = "衣物重复退款";
                break;
            case "1906":
                code_error = "退款创建失败";
                break;
            case "1907":
                code_error = "余额退款失败";
                break;
            case "1908":
                code_error = "退款详情创建失败";
                break;
            case "1909":
                code_error = "退款记录更新失败";
                break;
            case "1910":
                code_error = "保存退款记录失败";
                break;
            case "2001":
                code_error = "第三方退款超时, 请稍后再试";
                break;
            case "2002":
                code_error = "第三方退款失败";
                break;
            default:
                code_error = "未知退款异常";
                break;
        }

        return code_error;
    }


    private long strToUnix(String dateTime){
        Date date = null;
        try {
            date = dateFormat.parse(dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long time = date.getTime()/1000; //java时间是毫秒级别,时间戳是秒级别
        return time;
    }

    private String unixToStr(long unix){
        Date date = new Date(unix*1000);
        return dateFormat.format(date);
    }


    /**
     * 合并支付单,客服退款
     * 优惠券,E卡,余额支付
     */
    @Test
    public void mergeOrderBalanceAndCouponAndEcardRefundTest(){
        couponMoney = 30;
        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        double balance1 = 10;
        double transfer1 = 3;
        double ecard1Money = 10;
        double balance2 = 20;
        double transfer2 = 3;
        double ecard2Money = 20;
        double cashMoney1 = 10;

        String sql_balance = "update ims_icard_card set coin = "+(balance1+balance2)+", zhenqian = "+balance1+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);

        Ecard ecard1 = new Ecard((int)ecard1Money);
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        ecard1.setBeginTime(dateFormat.format(beforeTenDay));
        ecard1.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard1.create();



        Ecard ecard2 = new Ecard((int) ecard2Money);
        ecard2.setBeginTime(dateFormat.format(beforeTenDay));
        ecard2.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard2.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setBalanceMoney(balance1);
        createPayOrder.setEcard(ecard1);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setTransferMoney(transfer1);
        createPayOrder.setFanId(fan_id);
        createPayOrder.addOrder();

        createPayOrder.setBalanceMoney(balance2);
        createPayOrder.setEcard(ecard2);
        createPayOrder.setTransferMoney(transfer2);
        createPayOrder.addOrder();

        JSONObject jsonPayOrder = createPayOrder.payOrder();
        int orderId1 = createPayOrder.getOrderId(0);
        int orderId2 = createPayOrder.getOrderId(1);
        ecardMap.put(orderId1, ecard1);
        System.out.println(orderId1+":"+ecard1.getId());
        ecardMap.put(orderId2, ecard2);
        System.out.println(orderId2+":"+ecard2.getId());

        logger.info("支付结果:"+jsonPayOrder.toJSONString());
        Assert.assertEquals("支付异常", "0000", JSON.parseObject(jsonPayOrder.getString("httpBody")).getString("resp_code"));

        //设置优惠券和E卡全部过期
        setCouponExpire(couponId);
        setEcardExpire(ecard1.getId());
        setEcardExpire(ecard2.getId());


        //第一笔单子退款
        JSONObject jsonRefund1 = kefuRefund(orderId1);
        JSONObject jsonRefundData1 = JSON.parseObject(jsonRefund1.getString("httpBody")).getJSONObject("data");
        balance = balance1;
        transferMoney = transfer1;
        ecardMoney = ecard1Money;
        int newEcardId1 = jsonRefundData1.getIntValue("new_ecard_id");
        assertKefuRefundData(jsonRefund1, orderId1, false, true, false, false);
        assertBalanceDB(orderId1, 0.00);
        double beforeMoney = jsonRefundData1.getDoubleValue("icard_refund");

        //第二笔单子退款
        JSONObject jsonRefund2 = kefuRefund(orderId2);
        JSONObject jsonRefundData2 = JSON.parseObject(jsonRefund2.getString("httpBody")).getJSONObject("data");
        balance = balance2;
        transferMoney = transfer2;
        ecardMoney = ecard2Money;
        int newEcardId2 = jsonRefundData2.getIntValue("new_ecard_id");
        assertKefuRefundData(jsonRefund2, orderId2, true, true, false, true);
        assertBalanceDB(orderId2, beforeMoney);

    }


    /**
     * 单独订单,客服退款
     * 优惠券,E卡,余额,现金
     */
    @Test
    public void onlyOrderBalanceAndCouponAndEcardRefundTest(){
        couponMoney = 30;
        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        double balance = 10;
        double transfer = 3;
        double ecardMoney = 10;
        double cashMoney = 10;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);

        Ecard ecard = new Ecard((int)ecardMoney);
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        ecard.setBeginTime(dateFormat.format(beforeTenDay));
        ecard.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.setEcard(ecard);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transfer);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        //用于结束后删除e卡
        ecardMap.put(orderId, ecard);
        //设置优惠券和E卡过期
        setCouponExpire(couponId);
        setEcardExpire(ecard.getId());


        //退款
        JSONObject jsonRefund1 = kefuRefund(orderId);
        JSONObject jsonRefundData1 = JSON.parseObject(jsonRefund1.getString("httpBody")).getJSONObject("data");
        this.balance = balance;
        this.transferMoney = transfer;
        this.ecardMoney = ecardMoney;
        this.cashMoney = cashMoney;
        int newEcardId = jsonRefundData1.getIntValue("new_ecard_id");
        assertKefuRefundData(jsonRefund1, orderId, false, true, false, true);
        assertBalanceDB(orderId, 0.00);
    }

    /**
     * 加工店退款
     * 加工店分拣数量和价格都大于小e分拣数量和价格
     */
    @Test
    public void onlyOrderPartRefund1Test(){
        couponMoney = 10;
        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        double balance = 10;
        double transfer = 3;
        double ecardMoney = 10;
        double cashMoney = 10;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);

        Ecard ecard = new Ecard((int)ecardMoney);
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        ecard.setBeginTime(dateFormat.format(beforeTenDay));
        ecard.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.setEcard(ecard);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transfer);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        ecardMap.put(orderId, ecard);
        //修改E卡有效期过期
        setCouponExpire(couponId);
        setEcardExpire(ecard.getId());


        List<Map<String, Object>> clothList = new ArrayList<>();
        for (int i=0;i<5;i++){
            Map<String, Object> clothMap = new HashMap<>();
            String sql = "select clothes_id, price from prices  where is_deleted=0  and city_id=1 and price>25  ORDER BY RAND() limit 1;";
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            try {
                int id = resultSet.getInt(1);
                double price = resultSet.getDouble(2);

                clothMap.put("cloth_id", id);
                clothMap.put("name", "测试"+i);
                clothMap.put("cloth_order_id", 0);
                clothMap.put("fee", price);
                clothList.add(clothMap);

                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        //退款
        JSONObject jsonRefund1 = factoryPartRefund(orderId, clothList);
        this.balance = balance;
        this.transferMoney = transfer;
        this.ecardMoney = ecardMoney;
        this.cashMoney = cashMoney;

        JSONObject jsonBody = JSON.parseObject(jsonRefund1.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", jsonRefund1.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");
        Assert.assertEquals("退款总金额不正确", (balance+ecardMoney+cashMoney+couponMoney+thirdPartyMoney), jsonData.getDoubleValue("total_refund"), 0.01);
        Assert.assertEquals("优惠券退款金额不正确", (couponMoney), jsonData.getDoubleValue("coupon_refund"), 0.01);
        Assert.assertEquals("余额退款金额不正确", (balance+cashMoney), jsonData.getDoubleValue("icard_refund"), 0.01);
        Assert.assertEquals("E卡退款金额不正确", (ecardMoney), jsonData.getDoubleValue("ecard_refund"), 0.01);
        Assert.assertEquals("现金退款金额不正确", (cashMoney), jsonData.getDoubleValue("third_to_icard_money"), 0.01);

        Assert.assertEquals("数据库余额异常", (balance+cashMoney), getDBBalance(), 0.01);
        int newEcardId = jsonData.getIntValue("new_ecard_id");
        assertNewCouponData();
        assertNewEcardData(orderId, newEcardId, true);
    }



    /**
     * 加工店退款,分2次部分不能洗退款
     * 加工店分拣数量和价格都大于小e分拣数量和价格
     */
    @Test
    public void onlyOrderPartRefund3Test(){
        couponMoney = 10;
        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        double balance = 10;
        double transfer = 3;
        double ecardMoney = 10;
        double cashMoney = 10;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);

        Ecard ecard = new Ecard((int)ecardMoney);
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        ecard.setBeginTime(dateFormat.format(beforeTenDay));
        ecard.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.setEcard(ecard);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transfer);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        ecardMap.put(orderId, ecard);
        //修改E卡有效期过期
        setCouponExpire(couponId);
        setEcardExpire(ecard.getId());


        List<Map<String, Object>> clothList = new ArrayList<>();
        List<Map<String, Object>> clothList2 = new ArrayList<>();
        for (int i=0;i<2;i++){
            Map<String, Object> clothMap = new HashMap<>();
            String sql = "select clothes_id, price from prices  where is_deleted=0  and city_id=1 and price>25  ORDER BY RAND() limit 1;";
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            try {
                int id = resultSet.getInt(1);
                double price = resultSet.getDouble(2);

                clothMap.put("cloth_id", id);
                clothMap.put("name", "测试"+i);
                clothMap.put("cloth_order_id", 0);
                clothMap.put("fee", price);
                if (i==0){
                    clothList.add(clothMap);
                }else {
                    clothList2.add(clothMap);
                }


                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        //退款
        JSONObject jsonRefund1 = factoryPartRefund(orderId, clothList);
        this.balance = balance;
        this.transferMoney = transfer;
        this.ecardMoney = ecardMoney;
        this.cashMoney = cashMoney;

        JSONObject jsonBody = JSON.parseObject(jsonRefund1.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", jsonRefund1.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");
        Assert.assertEquals("退款总金额不正确", (balance+ecardMoney+cashMoney+couponMoney+thirdPartyMoney), jsonData.getDoubleValue("total_refund"), 0.01);
        Assert.assertEquals("优惠券退款金额不正确", (couponMoney), jsonData.getDoubleValue("coupon_refund"), 0.01);
        Assert.assertEquals("余额退款金额不正确", (balance+cashMoney), jsonData.getDoubleValue("icard_refund"), 0.01);
        Assert.assertEquals("E卡退款金额不正确", (ecardMoney), jsonData.getDoubleValue("ecard_refund"), 0.01);
        Assert.assertEquals("现金退款金额不正确", (cashMoney), jsonData.getDoubleValue("third_to_icard_money"), 0.01);

        Assert.assertEquals("数据库余额异常", (balance+cashMoney), getDBBalance(), 0.01);
        int newEcardId = jsonData.getIntValue("new_ecard_id");
        assertNewCouponData();
        assertNewEcardData(orderId, newEcardId, true);
    }



    /**
     * 单笔订单加工店部分退款
     * 无分拣差异
     */
    @Test
    public void onlyOrderPartRefund2Test(){
        ecardMoney = 30;
        couponMoney = 10;
        balance = 10;
        transferMoney = 3;
        thirdPartyMoney = 5;

        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        Ecard ecard = new Ecard((int) ecardMoney);
        ecard.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setFanId(fan_id);
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.setEcard(ecard);
        createPayOrder.setThirdPartyMoney(thirdPartyMoney);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setTransferMoney(transferMoney);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);
        List<Map<String, Object>> refundClothMap = createPayOrder.getRefundClothParameter(0);
        refundClothMap.remove(0);

        double expectedTotal = 0.00;
        double expectedEcardMoney = 0.00;
        double expectedBalance = 0.00;
        double expectedThirdMoney = 0.00;

        for (Map<String, Object> tmpMap:refundClothMap){
            int cloth_order_id = (int)tmpMap.get("cloth_order_id");
            String sql = "select ecard_fee, icard_fee, third_fee from pf_order_detail where order_id="+orderId+" and cloth_order_id="+cloth_order_id;
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
            try {
                double ecardFee = resultSet.getDouble("ecard_fee");
                double icardFee = resultSet.getDouble("icard_fee");
                double thirdFee = resultSet.getDouble("third_fee");

                expectedThirdMoney += thirdFee;
                expectedBalance += icardFee+thirdFee;
                expectedEcardMoney += ecardFee;
                expectedTotal += ecardFee+icardFee+thirdFee;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        ecardMap.put(orderId, ecard);
        this.setEcardExpire(ecard.getId());

        JSONObject jsonRefund = factoryPartRefund(orderId,refundClothMap);
        JSONObject jsonBody = JSON.parseObject(jsonRefund.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", jsonRefund.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");
        Assert.assertEquals("退款总金额不正确", expectedTotal, jsonData.getDoubleValue("total_refund"), 0.01);
        Assert.assertEquals("余额退款金额不正确", expectedBalance, jsonData.getDoubleValue("icard_refund"), 0.01);
        Assert.assertEquals("优惠券退款金额不正确", 0.00, jsonData.getDoubleValue("coupon_refund"), 0.00);
        Assert.assertEquals("退优惠券ID不正确",  0, jsonData.getIntValue("coupon_id"));
        Assert.assertEquals("E卡退款金额不正确", expectedEcardMoney, jsonData.getDoubleValue("ecard_refund"), 0.01);
        Assert.assertTrue("退E卡ID不正确",  jsonData.getIntValue("new_ecard_id") != 0);
        Assert.assertEquals("第三方退款金额不正确", 0.00, jsonData.getDoubleValue("third_refund"), 0.01);
        Assert.assertEquals("第三方退款转余额金额不正确", expectedThirdMoney, jsonData.getDoubleValue("third_to_icard_money"), 0.01);
        Assert.assertEquals("第三方退款类型不正确", 2, jsonData.getIntValue("third_type"));

        Assert.assertEquals("数据库余额异常", expectedBalance, getDBBalance(), 0.01);
        int newEcardId = jsonData.getIntValue("new_ecard_id");
        assertNewEcardData(orderId, newEcardId, expectedEcardMoney);


    }

    /**
     * 支付未完成订单客服退款
     */
    @Test
    public void orderWaitPayRefund(){
        balance = 10;
        cashMoney = 10;
        transferMoney = 5;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);
        createPayOrder = new CreatePayOrder();
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transferMoney);
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.payOrderNotWithCallBack();
        int orderId = createPayOrder.getOrderId(0);

        JSONObject jsonRefund = kefuRefund(orderId);
        JSONObject jsonRefundData1 = JSON.parseObject(jsonRefund.getString("httpBody"));
        Assert.assertEquals("未支付订单,不应能退款", "1900", jsonRefundData1.getString("resp_code"));
    }

    /**
     * 客服重复退单
     */
    @Test
    public void repeatedRefundTest(){
        balance = 10;
        cashMoney = 10;
        transferMoney = 5;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);
        createPayOrder = new CreatePayOrder();
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transferMoney);
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        JSONObject jsonRefund = kefuRefund(orderId);
        JSONObject jsonRefundData1 = JSON.parseObject(jsonRefund.getString("httpBody"));
        Assert.assertEquals("未支付订单,不应能退款", "0000", jsonRefundData1.getString("resp_code"));

        JSONObject jsonRefund2 = kefuRefund(orderId);
        JSONObject jsonRefundData2 = JSON.parseObject(jsonRefund2.getString("httpBody"));
        Assert.assertEquals("未支付订单,不应能退款", "1901", jsonRefundData2.getString("resp_code"));

    }


    /**
     * 一笔订单加工店全部退款
     */
    @Test
    public void onlyOrderStoreFullRefundTest(){
        couponMoney = 10;
        coupons = new Coupons((int) couponMoney);
        coupons.create();
        couponId = coupons.getId();

        double balance = 10;
        double transfer = 5;
        double ecardMoney = 10;
        double cashMoney = 10;

        String sql_balance = "update ims_icard_card set coin = "+(balance)+", zhenqian = "+balance+" where fan_id = "+fan_id;
        mysqlQaDao.execUpdateSql(sql_balance);

        Ecard ecard = new Ecard((int)ecardMoney);
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        ecard.setBeginTime(dateFormat.format(beforeTenDay));
        ecard.setEndTime(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 1));
        ecard.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setBalanceMoney(balance);
        createPayOrder.setEcard(ecard);
        createPayOrder.setCounpon(coupons);
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setTransferMoney(transfer);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        ecardMap.put(orderId, ecard);
        //修改E卡有效期过期
        setCouponExpire(couponId);
        setEcardExpire(ecard.getId());


        //退款
        JSONObject jsonRefund = factoryAllRefund(orderId);
        logger.info("加工店退款json"+jsonRefund.toJSONString());
        JSONObject jsonRefundData = JSON.parseObject(jsonRefund.getString("httpBody")).getJSONObject("data");
        this.balance = balance;
        this.transferMoney = transfer;
        this.ecardMoney = ecardMoney;
        this.cashMoney = cashMoney;
//        int newEcardId = jsonRefundData1.getIntValue("new_ecard_id");
        assertFactoryRefundData(jsonRefund, null, orderId, true, true);
        Assert.assertEquals("数据库余额不正确", balance+cashMoney, getDBBalance(), 0.01);
    }


    /**
     * 优惠券支付全部金额,客服退款
     */
    @Test
    public void fullCouponPayKefuRefundTest(){
        couponMoney = 20;
        Coupons coupons = new Coupons((int) couponMoney);
        coupons.create();

        createPayOrder = new CreatePayOrder();
        createPayOrder.setFanId(fan_id);
        createPayOrder.setCounpon(coupons);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        JSONObject jsonRefund = kefuRefund(orderId);


    }

    /**
     * 京东订单,客服退款
     */
    @Test
    public void jingdongKefuRefundTest(){
        thirdPartyMoney = 10;
        transferMoney = 3;
        createPayOrder = new CreatePayOrder();
        createPayOrder.setFanId(fan_id);
        createPayOrder.setThirdPartyMoney(thirdPartyMoney);
        createPayOrder.setTransferMoney(transferMoney);
        createPayOrder.setJingdongPay();
        createPayOrder.setUserBalance(0);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);

        JSONObject jsonRefund = kefuRefund(orderId);
        logger.info("退款结果:"+jsonRefund);
        JSONObject jsonBody = JSON.parseObject(jsonRefund.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", jsonRefund.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");
        Assert.assertEquals("退款总额不正确",  thirdPartyMoney-transferMoney, jsonData.getDoubleValue("total_refund"), 0.00);
        Assert.assertEquals("优惠券退款金额不正确",  0.00, jsonData.getDoubleValue("coupon_refund"), 0.00);
        Assert.assertEquals("退优惠券ID不正确",  0, jsonData.getIntValue("coupon_id"));
        Assert.assertEquals("E卡退款金额不正确",  0.00, jsonData.getDoubleValue("ecard_refund"), 0.00);
        Assert.assertEquals("退E卡ID不正确",  0, jsonData.getIntValue("new_ecard_id"));
        Assert.assertEquals("第三方退款金额不正确",  0.00, jsonData.getDoubleValue("third_refund"), 0.00);
        Assert.assertEquals("第三方退款转余额金额不正确", thirdPartyMoney-transferMoney, jsonData.getDoubleValue("third_to_icard_money"), 0.00);
        Assert.assertEquals("第三方退款类型不正确", 16, jsonData.getIntValue("third_type"));

        double userBalance = createPayOrder.getUserBalance();
        Assert.assertEquals("用户数据库余额不正确", thirdPartyMoney-transferMoney, userBalance, 0.00);
    }


    /**
     * 京东订单,加工店部分退款
     */
    @Test
    public void jingdongStoreRefundTest(){
        thirdPartyMoney = 10;
        cashMoney = 5;
        transferMoney = 3;
        createPayOrder = new CreatePayOrder();
        createPayOrder.setFanId(fan_id);
        createPayOrder.setThirdPartyMoney(thirdPartyMoney);
        createPayOrder.setTransferMoney(transferMoney);
        createPayOrder.setCashMoney(cashMoney);
        createPayOrder.setJingdongPay();
        createPayOrder.setUserBalance(0);
        createPayOrder.addOrder();
        createPayOrder.payOrder();
        int orderId = createPayOrder.getOrderId(0);
        List<Map<String, Object>> clothList = createPayOrder.getRefundClothParameter(0);
        List<Double> refundMoneyList = new ArrayList<>();
        for (Map<String, Object> tmpMap: clothList){
            for (Map.Entry<String, Object> t1: tmpMap.entrySet()){
                System.out.println(t1.getKey()+":"+t1.getValue());
                if (t1.getKey().toString().equals("fee")){
                    refundMoneyList.add(Double.parseDouble(String.valueOf(t1.getValue())));
                }
            }
        }
        clothList.remove(0);
        refundMoneyList.remove(0);
        JSONObject jsonRefund = factoryPartRefund(orderId, clothList);
        JSONObject jsonBody = JSON.parseObject(jsonRefund.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", jsonRefund.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");
        Assert.assertEquals("退款总额不正确",  Double.parseDouble(clothList.get(0).get("fee").toString()), jsonData.getDoubleValue("total_refund"), 0.00);
        Assert.assertEquals("优惠券退款金额不正确",  0.00, jsonData.getDoubleValue("coupon_refund"), 0.00);
        Assert.assertEquals("退优惠券ID不正确",  0, jsonData.getIntValue("coupon_id"));
        Assert.assertEquals("E卡退款金额不正确",  0.00, jsonData.getDoubleValue("ecard_refund"), 0.00);
        Assert.assertEquals("退E卡ID不正确",  0, jsonData.getIntValue("new_ecard_id"));
        Assert.assertEquals("第三方退款金额不正确",  0.00, jsonData.getDoubleValue("third_refund"), 0.00);
        Assert.assertEquals("第三方退款转余额金额不正确", Double.parseDouble(clothList.get(0).get("fee").toString()), jsonData.getDoubleValue("third_to_icard_money"), 0.00);
        Assert.assertEquals("第三方退款类型不正确", 16, jsonData.getIntValue("third_type"));

        double userBalance = createPayOrder.getUserBalance();
        double expectedRefundMoney = 0.0;
        for (Double d: refundMoneyList){
            expectedRefundMoney += d;
        }
        Assert.assertEquals("用户数据库余额不正确", expectedRefundMoney, userBalance, 0.00);
    }






    private JSONObject kefuRefund(int orderId){
        return superRefund(orderId, null, 2, 1);
    }

    public JSONObject factoryAllRefund(int orderId){
        return superRefund(orderId, null, 3, 1);
    }

    public JSONObject factoryPartRefund(int orderId, List<Map<String, Object>> refundClothQuery){
        return superRefund(orderId, refundClothQuery, 3, 1);
    }



    /**
     * 创建待退订单及操作退单接口
     * @param refundType 退款来源(1:用户 2: 客服 3: 加工店)
     * @param refundClothQuery  退单衣物String,如果整单退可以传空
     * @param transferType 退运费的类型(1: 根据具体情况可以退运费 2: 强制退运费 3:不退运费)
     * @return
     */
    private JSONObject superRefund(int orderId, List<Map<String, Object>> refundClothQuery, int refundType, int transferType){
        String clothQueryStr = "";
        int refundAll = 1;
        if (refundClothQuery != null){
            refundAll = 2;
            for (int i=0;i<refundClothQuery.size();i++){
                Map<String, Object> tmpMap = refundClothQuery.get(i);
                int id = (int) tmpMap.get("cloth_id");
                String name = String.valueOf(tmpMap.get("name"));
                int orderClothId = (int) tmpMap.get("cloth_order_id");
                String fee = String.valueOf(tmpMap.get("fee"));

                clothQueryStr += "&" + "clothes_info[" + i + "][cloth_id]=" + id + "&clothes_info[" + i + "][cloth_order_id]=" + orderClothId
                        + "&clothes_info[" + i + "][name]=" + name + "&clothes_info[" + i + "][fee]="+fee;
            }
        }

        //调用退单接口
        Map<String, Object> queryMap = new HashMap<String, Object>();
        queryMap.put("user_id", fan_id);
        queryMap.put("business_id", 11);
        queryMap.put("source", refundType);//退款来源(1:用户 2: 客服 3: 加工店)
        queryMap.put("order_id", orderId);
        queryMap.put("refund_type", refundAll);//退款类型(1: 整单退款 2: 订单部分衣物退款)
        queryMap.put("transfer_type", transferType);//退运费的类型(1: 根据具体情况可以退运费 2: 强制退运费 3:不退运费)
        queryMap.put("remark", "接口测试退单-优惠券");
        queryMap.put("insure_type", 3);//退保费参数 1 不退保费, 2 退一半保费, 3 退全部保费
        String queryStr = "";
        Object[] queryObjects = queryMap.entrySet().toArray();
        for (Object o : queryObjects){
            queryStr += o+"&";
        }
        queryStr = queryStr.substring(0, queryStr.length()-1);
        queryStr += clothQueryStr;


        JSONObject jsonRefundResult = edxpayModuleService.CallRefundDeal(queryStr, httpHead);
        logger.info("退款结果:"+jsonRefundResult);
        return jsonRefundResult;
    }

    private void setCouponExpire(int couponId){
        //修改优惠券卡有效期
        long nowTime = System.currentTimeMillis();
        long beforeTenDay = nowTime - 10*24*60*60*1000;
        String sql_time = "update ims_icoupon_sncode set endtime = "+(beforeTenDay/1000)+" where id = "+couponId;
        mysqlQaDao.execUpdateSql(sql_time);
    }

    private void setEcardExpire(int ecardId){
        //修改E卡有效期过期
        long beforeTenDay2 = System.currentTimeMillis() - 10*24*60*60*1000;
        String sql_time = "update ims_recharge_sncode set endtime = "+(beforeTenDay2/1000)+" where id = "+ecardId;
        mysqlQaDao.execUpdateSql(sql_time);
    }


    /**
     * 创建待退订单及操作退单接口
     * @param refundType 退款来源(1:用户 2: 客服 3: 加工店)
     * @param refundClothQuery  退单衣物String,如果整单退可以传空
     * @param transferType 退运费的类型(1: 根据具体情况可以退运费 2: 强制退运费 3:不退运费)
     * @return
     */
    private JSONObject refund(int refundType, String refundClothQuery, int transferType, boolean refundNewCoupon, boolean refundNewEcard){
        if (refundNewCoupon && coupons != null){
            //修改优惠券卡有效期
            long nowTime = System.currentTimeMillis();
            long beforeTenDay = nowTime - 10*24*60*60*1000;
            String sql_time = "update ims_icoupon_sncode set endtime = "+(beforeTenDay/1000)+" where id = "+coupons.getId();
            mysqlQaDao.execUpdateSql(sql_time);
        }

        if (refundNewEcard && ecard != null){
            //修改E卡有效期
            long nowTime = System.currentTimeMillis();
            long beforeTenDay = nowTime - 10*24*60*60*1000;
            String sql_time = "update ims_recharge_sncode set endtime = "+(beforeTenDay/1000)+" where id = "+ecard.getId();
            mysqlQaDao.execUpdateSql(sql_time);
        }

        int orderId = refundOrder.getOrderId();
        //调用退单接口
        Map<String, Object> queryMap = new HashMap<String, Object>();
        queryMap.put("user_id", fan_id);
        queryMap.put("business_id", 11);
        queryMap.put("source", refundType);//退款来源(1:用户 2: 客服 3: 加工店)
        queryMap.put("order_id", orderId);
        queryMap.put("refund_type", 1);//退款类型(1: 整单退款 2: 订单部分衣物退款)
        queryMap.put("transfer_type", transferType);//退运费的类型(1: 根据具体情况可以退运费 2: 强制退运费 3:不退运费)
        queryMap.put("remark", "接口测试退单-优惠券");

        String clothQuerStr = "";
        if (refundClothQuery != null && !refundClothQuery.equals("") ){
            queryMap.put("refund_type", 2);
            if (!refundClothQuery.startsWith("&")){
                refundClothQuery = "&"+refundClothQuery;

            }
            clothQuerStr = refundClothQuery;
        }

        String queryStr = "";
        Object[] queryObjects = queryMap.entrySet().toArray();
        for (Object o : queryObjects){
            queryStr += o+"&";
        }
        queryStr = queryStr.substring(0, queryStr.length()-1);
        queryStr += clothQuerStr;




        JSONObject jsonRefundResult = edxpayModuleService.CallRefundDeal(queryStr, httpHead);
        logger.info("refundJson:"+jsonRefundResult);
        return jsonRefundResult;
    }

    private JSONObject refund(int refundType, List<Map<String, Object>> refundClothQuery, int transferType, boolean refundNewCoupon, boolean refundNewEcard){
        String clothQueryStr = "";

        for (int i=0;i<refundClothQuery.size();i++){
            Map<String, Object> tmpMap = refundClothQuery.get(i);
            int id = (int) tmpMap.get("cloth_id");
            String name = String.valueOf(tmpMap.get("name"));
            int orderClothId = (int) tmpMap.get("cloth_order_id");
            String fee = String.valueOf(tmpMap.get("fee"));

            clothQueryStr += "&" + "clothes_info[" + i + "][cloth_id]=" + id + "&clothes_info[" + i + "][cloth_order_id]=" + orderClothId
                    + "&clothes_info[" + i + "][name]=" + name + "&clothes_info[" + i + "][fee]="+fee;
        }
        System.out.println(clothQueryStr);
        return refund(refundType, clothQueryStr, transferType, refundNewCoupon, refundNewEcard);
    }


    /**
     * 验证退款接口结果
     * @param refundJson 退款接口返回json
     * @param couponReissue 是否补发新优惠券
     * @param ecardReissue 是否补发新e卡
     * @param refundTransfer 是否退运费
     */
    private void assertRefundData(JSONObject refundJson, boolean couponReissue, boolean ecardReissue, boolean refundTransfer){
        JSONObject jsonBody = JSON.parseObject(refundJson.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", refundJson.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");

        if (couponReissue){
            couponId = jsonData.getIntValue("coupon_id");
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") != couponId);
            Assert.assertEquals("优惠券退款金额不正确", String.format("%.2f",couponMoney), jsonData.getString("coupon_refund"));

        }else {
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == 0);
            Assert.assertEquals("优惠券退款金额不正确", "0.00", jsonData.getString("coupon_refund"));
        }

        if (ecardReissue){
            newEcardId = jsonData.getIntValue("new_ecard_id");
            Assert.assertTrue("E卡退款ID不正确", jsonData.getIntValue("new_ecard_id") != 0);
        }else {
            Assert.assertTrue("E卡退款ID不正确", jsonData.getIntValue("new_ecard_id") == 0);
        }

        double tmpTransferMoney = transferMoney;
        if (refundTransfer){
            //如果退换运费，则支付方式退款不需要扣除运费
            tmpTransferMoney = 0;
        }
        Assert.assertEquals("退单总额不正确", String.format("%.2f",couponMoney + balance + ecardMoney +thirdPartyMoney + cashMoney - tmpTransferMoney), jsonData.getString("total_refund"));
        Assert.assertEquals("余额退款金额不正确",String.format("%.2f",
                getRefundMoney(balance,refundTransfer)
                        + getRefundMoney(thirdPartyMoney,refundTransfer) + getRefundMoney(cashMoney,refundTransfer)),
                jsonData.getString("icard_refund"));
        Assert.assertEquals("E卡退款金额不正确", String.format("%.2f",getRefundMoney(ecardMoney,refundTransfer)), jsonData.getString("ecard_refund"));

        Assert.assertEquals("第三方退款金额不正确", String.format("%.2f", getRefundMoney(thirdPartyMoney,refundTransfer)), jsonData.getString("third_refund"));
        Assert.assertEquals("第三方退款对象不正确", 1, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
    }

    private void assertFactoryRefundData(JSONObject refundJson, List<Map<String, Object>> clothParameter, int orderId, boolean couponReissue, boolean ecardReissue){
        JSONObject jsonBody = JSON.parseObject(refundJson.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", refundJson.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");

        boolean refundTransfer = true;
        double expectedCouponMoney = couponMoney;
        double expectedBalance = balance;
        double expectedEcardMoney = ecardMoney;
        double expectedThirdMoney = thirdPartyMoney;
        double expectedCashMoney = cashMoney;
        double expectedTransferMoney = 0.00;
        if (clothParameter != null){
            refundTransfer = false;
            expectedTransferMoney= transferMoney;
        }

        Assert.assertEquals("退单总额不正确", (expectedCouponMoney + expectedCashMoney + expectedBalance + expectedEcardMoney +expectedThirdMoney - expectedTransferMoney), jsonData.getDoubleValue("total_refund"), 0.01);
        //现金退余额
        Assert.assertEquals("余额退款金额不正确", ( expectedBalance + getRefundMoney(cashMoney,refundTransfer)), jsonData.getDoubleValue("icard_refund"), 0.01);
        Assert.assertEquals("E卡退款金额不正确", expectedEcardMoney, jsonData.getDoubleValue("ecard_refund"), 0.01);
        Assert.assertEquals("第三方退款金额不正确", 0.00, jsonData.getDoubleValue("third_refund"), 0.01);
        if (thirdPartyMoney != 0.00){
            Assert.assertEquals("第三方退款对象不正确", 2, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }else if (cashMoney != 0.00){
            Assert.assertEquals("第三方退款对象不正确", 3, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }else {
            Assert.assertEquals("第三方退款对象不正确", 1, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }

        ///验证退回的优惠券
        if (couponReissue){
            //优惠券过期,延长优惠券有效期30天
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == coupons.getId());
            Assert.assertEquals("优惠券退款金额不正确", expectedCouponMoney, jsonData.getDoubleValue("coupon_refund"), 0.01);
            assertNewCouponData();

        }else {
            int couponId = jsonData.getIntValue("coupon_id");
            if (couponId == 0){
                Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == 0);
                Assert.assertEquals("优惠券退款金额不正确", "0.00", jsonData.getString("coupon_refund"));
            }else {
                Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == coupons.getId());
                Assert.assertEquals("优惠券退款金额不正确", expectedCouponMoney, jsonData.getDoubleValue("coupon_refund"), 0.01);
            }

        }

        //验证退回的E卡
        if (ecardReissue){
            newEcardId = jsonData.getIntValue("new_ecard_id");
            Assert.assertTrue("E卡退款ID不正确", jsonData.getIntValue("new_ecard_id") != 0);
            assertNewEcardData(orderId, newEcardId, refundTransfer);
        }
    }


    private void assertKefuRefundData(JSONObject refundJson, int orderId, boolean couponReissue, boolean ecardReissue, boolean refundTransfer, boolean refundAll){
        JSONObject jsonBody = JSON.parseObject(refundJson.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", refundJson.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");



        double tmpTransferMoney = transferMoney;
        Map<String, Double> refundMap = getRefundMoneyMap(orderId);
        double expectedCouponMoney = 0.00;
        double expectedBalance = refundMap.get("icard");
        double expectedEcardMoney = refundMap.get("ecard");
        double expectedThirdMoney = refundMap.get("third");
        if (refundTransfer){
            //如果退换运费，则支付方式退款不需要扣除运费
            tmpTransferMoney = 0.00;

        }

        if (refundAll){
            expectedCouponMoney = refundMap.get("coupon");
        }

        Assert.assertEquals("退单总额不正确", (expectedCouponMoney + expectedBalance + expectedEcardMoney +expectedThirdMoney ), jsonData.getDoubleValue("total_refund"), 0.01);
        //现金退余额
        Assert.assertEquals("余额退款金额不正确", ( expectedBalance + getRefundMoney(cashMoney,refundTransfer)), jsonData.getDoubleValue("icard_refund"), 0.01);
        Assert.assertEquals("E卡退款金额不正确", expectedEcardMoney, jsonData.getDoubleValue("ecard_refund"), 0.01);
        Assert.assertEquals("第三方退款金额不正确", 0.00, jsonData.getDoubleValue("third_refund"), 0.01);
        if (thirdPartyMoney != 0.00){
            Assert.assertEquals("第三方退款对象不正确", 2, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }else if (cashMoney != 0.00){
            Assert.assertEquals("第三方退款对象不正确", 3, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }else {
            Assert.assertEquals("第三方退款对象不正确", 1, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
        }

        ///验证退回的优惠券
        if (couponReissue){
            //优惠券过期,延长优惠券有效期30天
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == coupons.getId());
            Assert.assertEquals("优惠券退款金额不正确", expectedCouponMoney, jsonData.getDoubleValue("coupon_refund"), 0.01);
            assertNewCouponData();

        }else {
            int couponId = jsonData.getIntValue("coupon_id");
            if (couponId == 0){
                Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == 0);
                Assert.assertEquals("优惠券退款金额不正确", "0.00", jsonData.getString("coupon_refund"));
            }else {
                Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == coupons.getId());
                Assert.assertEquals("优惠券退款金额不正确", expectedCouponMoney, jsonData.getDoubleValue("coupon_refund"), 0.01);
            }

        }

        //验证退回的E卡
        if (ecardReissue){
            newEcardId = jsonData.getIntValue("new_ecard_id");
            Assert.assertTrue("E卡退款ID不正确", jsonData.getIntValue("new_ecard_id") != 0);
            assertNewEcardData(orderId, newEcardId, false);
        }

    }

    private Map<String, Double> getRefundMoneyMap(int orderId){
        String sql = "select sum(coupon_fee) as coupon, sum(ecard_fee) as ecard, sum(icard_fee) as icard, sum(third_fee) as third from pf_order_detail where order_id ="+orderId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        Map<String, Double> map = new HashMap<>();
        try {
            double coupon = resultSet.getDouble("coupon");
            double ecard = resultSet.getDouble("ecard");
            double icard = resultSet.getDouble("icard");
            double third = resultSet.getDouble("third");

            map.put("coupon", coupon);
            map.put("ecard", ecard);
            map.put("icard", icard);
            map.put("third", third);
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return map;


    }





    private boolean judgmentBalance(double one, double two){
        boolean flag = false;
        if ( Math.abs(Math.abs(one) - Math.abs(two)) <= 0.02 ){
            flag = true;
        }

        return flag;
    }

    private void assertRefundData(JSONObject refundJson, List<Map<String, Object>> clothQuery, boolean couponReissue, boolean ecardReissue, boolean refundAll){
        JSONObject jsonBody = JSON.parseObject(refundJson.getString("httpBody"));
        Assert.assertEquals("接口状态码异常", "200", refundJson.getString("httpStatus"));
        String resp_code = jsonBody.getString("resp_code");
        Assert.assertEquals(getRespCodeError(resp_code), "0000", resp_code);
        JSONObject jsonData = jsonBody.getJSONObject("data");




        boolean noFenjian = true;
        int sumOrderId = 0;
        int tmpClothSum = 0;
        double sumRefundMoney = 0.0;
        String sql_detailEndWith = "";
        ArrayList<Integer> clothIdRefund = new ArrayList<>();
        ArrayList<Double> clothFeeRefund = new ArrayList<>();
        ArrayList<String> clothNameRefund = new ArrayList<>();
        ArrayList<Integer> clothOrderIdRefund = new ArrayList<>();

        if(clothQuery != null){

            for (int i=0; i<clothQuery.size(); i++){
                Map<String, Object> tmpMap = clothQuery.get(i);
                int id = (int) tmpMap.get("cloth_id");
                int orderId = (int) tmpMap.get("cloth_order_id");
                String name = String.valueOf(tmpMap.get("name"));
                double fee = Double.parseDouble(String.valueOf(tmpMap.get("fee")));

                sumRefundMoney += fee;
                clothFeeRefund.add(fee);
                clothIdRefund.add(id);
                clothNameRefund.add(name);
                clothOrderIdRefund.add(orderId);
            }

            sql_detailEndWith = " and cloth_order_id in(";
            String sql_pfOrderDetail = "select count(*) from pf_order_detail where order_id="+refundOrder.getOrderId()+" and cloth_order_id in(";
            for (int orderId : clothOrderIdRefund){
                sql_pfOrderDetail += orderId+",";
                sql_detailEndWith += orderId+",";
            }
            sql_pfOrderDetail = sql_pfOrderDetail.substring(0, sql_pfOrderDetail.length()-1);
            sql_pfOrderDetail = sql_pfOrderDetail+");";
            sql_detailEndWith = sql_detailEndWith.substring(0, sql_detailEndWith.length()-1);
            sql_detailEndWith = sql_detailEndWith+");";
            try {
                tmpClothSum = mysqlQaDao.execQuerySql(sql_pfOrderDetail).getInt(1);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        double expectTotal = 0.00;
        double expectIcard = 0.00;
        double expectEcard = 0.00;
        double expectCoupon = 0.00;
        double expectThird = 0.00;
        double expectCouponId = 0;

        String sql_pfOrderDetail2 = "select  sum(fee) as fee , sum(coupon_fee) as coupon_fee, " +
                "sum(ecard_fee) as ecard_fee, sum(icard_fee) as icard_fee, sum(third_fee) as third_fee" +
                " from pf_order_detail where order_id="+refundOrder.getOrderId()
                +sql_detailEndWith;
        ResultSet resultSet = mysqlQaDao.execQuerySqlAllRet(sql_pfOrderDetail2);
        try {
            while (resultSet.next()){
                expectTotal = resultSet.getDouble("fee");
                expectCoupon = resultSet.getDouble("coupon_fee");
                expectEcard = resultSet.getDouble("ecard_fee");
                expectIcard = resultSet.getDouble("icard_fee");
                expectThird = resultSet.getDouble("third_fee");

            }
        }catch (SQLException e) {
            e.printStackTrace();
        }



        double actualTotal = jsonData.getDoubleValue("total_refund");
        double actualIcard = jsonData.getDoubleValue("icard_refund");
        double actualEcard = jsonData.getDoubleValue("ecard_refund");
        double actualCoupon = jsonData.getDoubleValue("coupon_refund");
        double actualThird = jsonData.getDoubleValue("third_refund");



        System.out.println((balance+ecardMoney+cashMoney+thirdPartyMoney));
        System.out.println(actualTotal);
        System.out.println( (balance+ecardMoney+cashMoney+thirdPartyMoney) - actualTotal);
        Assert.assertTrue("退款金额大于总实际付款金额", (balance+ecardMoney+cashMoney+thirdPartyMoney) - actualTotal > 0);

        if (tmpClothSum == clothOrderIdRefund.size()) {
            //无分拣差异
            expectCouponId = couponId;
        } else{
            //有分拣差异

            if (tmpClothSum > clothFeeRefund.size()) {
                //加工店分拣数量大于小e分拣
                expectCouponId = couponId;
            } else {
                //加工店分拣数量小于小e分拣

                //不退优惠券
                expectCoupon = 0;
                expectCouponId = 0;
            }
        }



        if (couponReissue){
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") != couponId);

        }else {
            Assert.assertTrue("优惠券退款ID不正确", jsonData.getIntValue("coupon_id") == expectCouponId);
        }
        Assert.assertEquals("优惠券退款金额不正确", String.format("%.2f",expectCoupon), String.format("%.2f",actualCoupon));


        if (ecardReissue){
            newEcardId = jsonData.getIntValue("new_ecard_id");
            Assert.assertTrue("E卡退款ID不正确", jsonData.getIntValue("new_ecard_id") != 0);
        }


        logger.info("退款总额:"+expectTotal+" "+actualTotal);
        Assert.assertTrue("退款总额不正确", judgmentBalance(expectTotal, actualTotal));

        logger.info("E卡退款金额:"+expectEcard+" "+actualEcard);
        Assert.assertTrue("E卡退款金额不正确", judgmentBalance(expectEcard, actualEcard));

        logger.info("余额退款金额:"+expectIcard+" "+expectIcard);
        Assert.assertTrue("余额退款金额不正确", judgmentBalance(expectIcard, expectIcard));

        logger.info("第三方退款金额:"+expectThird+" "+actualThird);
        Assert.assertTrue("第三方退款金额不正确", judgmentBalance(expectThird, actualThird));
//        double total = 0;
//        double refundBalance = 0;
//        double refundEcard = 0;
//        if (refundAll){
//            //如果退换运费，则支付方式退款不需要扣除运费
//            total = couponMoney + balance + ecardMoney +thirdPartyMoney + cashMoney;
//            refundBalance = getRefundMoney(balance, true);
//        }else {
//            double[] clothFees = new double[clothQuery.size()];
//            for (int i=0;i<clothQuery.size();i++){
//                Map<String, Object> map = clothQuery.get(i);
//                double fee = (double) map.get("fee");
//                total += fee;
//                clothFees[i] = fee;
//            }
//
//            for (double d : clothFees){
//                refundBalance += (d / total + transferMoney ) * balance;
//                refundEcard += (d / total + transferMoney ) * ecardMoney;
//            }
//        }
//        Assert.assertEquals("退单总额不正确", String.format("%.2f",total), jsonData.getString("total_refund"));
//        Assert.assertEquals("余额退款金额不正确",String.format("%.2f", refundBalance), jsonData.getString("icard_refund"));
//        Assert.assertEquals("E卡退款金额不正确", String.format("%.2f",refundEcard, jsonData.getString("ecard_refund")));
//        Assert.assertEquals("第三方退款金额不正确", String.format("%.2f", getRefundMoney(thirdPartyMoney,refundTransfer)), jsonData.getString("third_refund"));
//        Assert.assertEquals("第三方退款对象不正确", 1, jsonData.getIntValue("third_type"));//1:余额 2: 微信 3: 现金 6:支付宝 11:百度支付
    }


    private double getRefundMoney(double money, boolean refundTransfer){
        double tmpTransfer = transferMoney;
        if (refundTransfer){
            tmpTransfer = 0;
        }

        return money - (tmpTransfer*(money/(balance+ecardMoney+thirdPartyMoney+cashMoney)));
    }

    private void assertNewEcardData(int orderId, int newEcardId, boolean refundTransfer){
        String sql = "select starttime, endtime, fan_id, zhenqian, price from ims_recharge_sncode where id="+newEcardId;
        String actualStartTime = "";
        String actualEndTime = "";
        double actualEcardPrice = 0.00;
        int actualEcardFanId = 0;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                actualEcardFanId = resultSet.getInt("fan_id");
                actualEcardPrice = resultSet.getDouble("price");
                long start = resultSet.getLong("starttime");
                long end = resultSet.getLong("endtime");
                actualStartTime = yMd.format(start*1000);
                actualEndTime = yMd.format(end*1000);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        double tmpTransferMoney = transferMoney;
        if (refundTransfer){
            tmpTransferMoney = 0;
        }
        double expectedEcardMoney = getRefundMoneyMap(orderId).get("ecard");
        if (refundTransfer){
            String sql_pfCharge = "select ecard_fee from pf_charge_detail where business_order = "+orderId;
            ResultSet resultSet1 = mysqlQaDao.execQuerySql(sql_pfCharge);
            try {
                expectedEcardMoney = resultSet1.getDouble("ecard_fee");
                resultSet1.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        Assert.assertEquals("数据中E卡开始时间不正确", yMd.format(System.currentTimeMillis()), actualStartTime);
        Assert.assertEquals("数据中E卡结束时间不正确", CommonTools.getAfterDate("yyyy-MM-dd", 30), actualEndTime);
        Assert.assertEquals("数据库E卡fanId不正确",fan_id, actualEcardFanId);
        Assert.assertEquals("数据库E卡price不正确", expectedEcardMoney, actualEcardPrice, 0.01);

    }

    public void assertNewEcardData(int orderID, int newEcardId, double expectedMoney){
        String sql = "select starttime, endtime, fan_id, zhenqian, price from ims_recharge_sncode where id="+newEcardId;
        String actualStartTime = "";
        String actualEndTime = "";
        double actualEcardPrice = 0.00;
        int actualEcardFanId = 0;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                actualEcardFanId = resultSet.getInt("fan_id");
                actualEcardPrice = resultSet.getDouble("price");
                long start = resultSet.getLong("starttime");
                long end = resultSet.getLong("endtime");
                actualStartTime = yMd.format(start*1000);
                actualEndTime = yMd.format(end*1000);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Assert.assertEquals("数据中E卡开始时间不正确", yMd.format(System.currentTimeMillis()), actualStartTime);
        Assert.assertEquals("数据中E卡结束时间不正确", CommonTools.getAfterDate("yyyy-MM-dd", 30), actualEndTime);
        Assert.assertEquals("数据库E卡fanId不正确",fan_id, actualEcardFanId);
        Assert.assertEquals("数据库E卡price不正确", expectedMoney, actualEcardPrice, 0.01);

    }

    /**
     * 验证补发的新优惠券数据
     */
    public void assertNewCouponData(){
        String sql = "select cid, starttime, endtime, fan_id  from ims_icoupon_sncode where id="+ coupons.getId();
        String actualStartTime = "";
        String actualEndTime = "";
        int actualCouponFanId = 0;
        int couponListId = 0;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                couponListId = resultSet.getInt("cid");
                actualCouponFanId = resultSet.getInt("fan_id");
                long start = resultSet.getLong("starttime");
                long end = resultSet.getLong("endtime");
                actualStartTime = yMd.format(start*1000);
                actualEndTime = yMd.format(end*1000);
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        int actualCouponPrice = 0;
        String sql_couponMoney = "select coupon_price from ims_icoupon_list where id ="+couponListId;
        ResultSet resultSet1 = mysqlQaDao.execQuerySql(sql_couponMoney);
        try {
            resultSet1.beforeFirst();
            if (resultSet1.next()){
                actualCouponPrice = resultSet1.getInt("coupon_price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        Assert.assertEquals("数据中优惠开始时间不正确", yMd.format(System.currentTimeMillis()), actualStartTime);
        Assert.assertEquals("数据中优惠券结束时间不正确", CommonTools.getAfterDate("yyyy-MM-dd", 30), actualEndTime);
        Assert.assertEquals("数据库优惠券fanId不正确",fan_id, actualCouponFanId);
        Assert.assertEquals("数据库优惠券金额不正确", (int)couponMoney, actualCouponPrice);
    }

    /**验证整单退款退余额
     * @param refundTransfer 是否退运费
     * @param balanceZhenqian 余额中的真钱
     */
    public void assertBalanceDbData(boolean refundTransfer, double balanceZhenqian){

        String sql = "select coin, zhenqian from ims_icard_card where fan_id = "+fan_id;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        Double actualZhenqian = 0.00;
        Double actualCoin = 0.00;
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                actualCoin = resultSet.getDouble("coin");
                actualZhenqian = resultSet.getDouble("zhenqian");
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


        logger.info("实际退回 真钱:"+actualZhenqian+" coin:"+actualCoin);

        double tmpTransferMoney = transferMoney;
        if (refundTransfer){
            tmpTransferMoney = 0;
        }

        double refundCashMoney = cashMoney - (tmpTransferMoney*(cashMoney/(balance+ecardMoney+thirdPartyMoney+cashMoney)));
        double refundThirdPartyMoney = thirdPartyMoney - (tmpTransferMoney*(thirdPartyMoney/(balance+ecardMoney+thirdPartyMoney+cashMoney)));

        double expectedZhenqian = balanceZhenqian - (tmpTransferMoney * (balanceZhenqian/balance) );
        expectedZhenqian = expectedZhenqian+refundCashMoney+refundThirdPartyMoney;

        double expectedCoin = balance - (tmpTransferMoney*(balance/(balance+ecardMoney+thirdPartyMoney+cashMoney)));
        expectedCoin = expectedCoin + refundCashMoney + refundThirdPartyMoney;
        Assert.assertEquals("数据中coin字段不正确", df.format(expectedCoin), df.format(actualCoin) );
        Assert.assertEquals("数据中zhenqian字段不正确", df.format(expectedZhenqian), df.format(actualZhenqian));
    }

    public void assertBalanceDB(int orderId, double beforeMoney){
        String sql = "select sum(icard_fee), sum(third_fee) from pf_order_detail where order_id = "+orderId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        double expectedBalance = 0.00;
        try {
            double tmp1 =  resultSet.getDouble(1);
            double tmp2 = 0.00;
            if (thirdPartyMoney != 0.00 || cashMoney != 0.00){
                tmp2 = resultSet.getDouble(2);
            }
            expectedBalance = tmp1 + tmp2;

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql2 = "select coin from ims_icard_card where fan_id ="+fan_id;
        double actual = 0.00;
        try {
            actual = mysqlQaDao.execQuerySql(sql2).getDouble(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println(expectedBalance+" "+beforeMoney);
        Assert.assertEquals("数据中coin字段不正确", (expectedBalance+beforeMoney), actual, 0.02);
    }

    private double getDBBalance(){
        String sql2 = "select coin from ims_icard_card where fan_id ="+fan_id;
        double actual = 0.00;
        try {
            actual = mysqlQaDao.execQuerySql(sql2).getDouble(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return actual;
    }

    /**验证部分退款余额,不退运费
     * @param refundClothInfo 退的衣物信息
     */
    private void assertBalanceDbData(List<Map<String, Object>> refundClothInfo){
        double expectedCoin = getExpectedRefundBalance(refundClothInfo);
        double expectedZhenqian = getExpectedRefundZhenqian(refundClothInfo);

        String actualZhenqian = "";
        String actualCoin = "";

        String sql = "select coin, zhenqian from ims_icard_card where fan_id = "+fan_id;
        ResultSet resultSet = mysqlQaDao.execQuerySqlAllRet(sql);
        try {
            if (resultSet.next()){
                actualCoin = resultSet.getString("coin");
                actualZhenqian = resultSet.getString("zhenqian");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }



        Assert.assertEquals("数据中coin字段不正确", df.format(expectedCoin), actualCoin );
        Assert.assertEquals("数据中zhenqian字段不正确", df.format(expectedZhenqian), actualZhenqian );
    }


    /**获得部分退单不退运费情况下,预期应退账户余额
     * @param refundClothInfo
     * @return
     */
    private double getExpectedRefundBalance(List<Map<String, Object>> refundClothInfo){
        String orderClothIdStr = "";
        for (Map<String, Object> map : refundClothInfo){
            int tmpId = (int) map.get("cloth_order_id");
            orderClothIdStr += tmpId + ",";
        }
        orderClothIdStr = orderClothIdStr.substring(0,  orderClothIdStr.length()-1);

        String sql = "select sum(icard_fee) as 'balance' from pf_order_detail where order_id = "+refundOrder.getOrderId()+" and " +
                "cloth_order_id in("+orderClothIdStr+");";
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);

        double expectedCoin = 0;
        try {
            resultSet.beforeFirst();
            while (resultSet.next()){
                expectedCoin = resultSet.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return expectedCoin;
    }

    /**获得部分退单不退运费情况下,预期应退余额中的真钱
     * @param refundClothInfo
     * @return
     */
    private double getExpectedRefundZhenqian(List<Map<String, Object>> refundClothInfo){
        double coin = getExpectedRefundBalance(refundClothInfo);
        double tmp = 0;
        String sql = "select zhenqian, jiaqian from vouchers where card_type = 'Icard' and pf_refund_id = 0 and voucherable_id = "+refundOrder.getOrderId();
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                double tmpZhenqian = Math.abs(resultSet.getDouble("zhenqian"));
                double tmpJiaqian = Math.abs(resultSet.getDouble("jiaqian"));
                tmp = coin * (tmpZhenqian / (tmpZhenqian + tmpJiaqian) );
            }
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tmp;
    }




}
