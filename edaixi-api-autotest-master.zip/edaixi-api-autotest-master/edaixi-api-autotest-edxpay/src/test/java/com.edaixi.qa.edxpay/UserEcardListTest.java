package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16-4-9.
 */
public class UserEcardListTest {
    private static Logger logger = LoggerFactory
            .getLogger(UserEcardListTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String,Object> queryParams = null;
    private Map<String,Object> OrderParams = null;
    private Map<String,Object> orderInfoParams = null;
    private Map<String,Object> orderInfoParams01 = null;
    private JSONObject rechargeParams = new JSONObject();
    private JSONObject rechargeSn01Params = new JSONObject();
    private JSONObject rechargeSn02Params = new JSONObject();
    private JSONObject rechargeSn03Params = new JSONObject();
    private JSONObject rechargeSn04Params = new JSONObject();
    private JSONObject rechargeSn05Params = new JSONObject();
    private JSONObject rechargeSn06Params = new JSONObject();
    private JSONObject rechargeSn07Params = new JSONObject();
    private JSONObject rechargeSn08Params = new JSONObject();
    private JSONObject fanParams = new JSONObject();
    private JSONObject ecardLimitParams = new JSONObject();
    private JSONArray orderInfo = new JSONArray();
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.OrderParams = new HashMap<String, Object>();
        this.orderInfoParams = new HashMap<String, Object>();
        this.orderInfoParams01 = new HashMap<String, Object>();

    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试获取E卡列表
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetUserEcardList() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id), retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试一个用户获取多张E卡列表和按照领取时间倒序排序新领取的显示在列表上方
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetMultiUserEcardList() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第二条ims_recharge_sncode的数据－还未到开始使用时间
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn02Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn02Params.put("rid",recharge_id);
        rechargeSn02Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn02Params.put("from_user","NULL");
        rechargeSn02Params.put("user_type",1);
        rechargeSn02Params.put("card_type",1);
        rechargeSn02Params.put("price",price);
        rechargeSn02Params.put("zhenqian",zhenqian);
        rechargeSn02Params.put("used",0);
        rechargeSn02Params.put("fan_id",fan_id);
        rechargeSn02Params.put("starttime",CommonTools.getTimesnight()-1 + 60*60*24);
        rechargeSn02Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn02Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);

        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",2,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_02),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", 1) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));

        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(1).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(1).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(1).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(1).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(1).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(1).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(1).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(1).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(1).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(1).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(1).getString("allow_coupon"));
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试一个用户获取多张E卡但是其中有过期的
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetMultiEcardButOverdue() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第二条ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn02Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn02Params.put("rid",recharge_id);
        rechargeSn02Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn02Params.put("from_user","NULL");
        rechargeSn02Params.put("user_type",1);
        rechargeSn02Params.put("card_type",1);
        rechargeSn02Params.put("price",price);
        rechargeSn02Params.put("zhenqian",zhenqian);
        rechargeSn02Params.put("used",0);
        rechargeSn02Params.put("fan_id",fan_id);
        rechargeSn02Params.put("draw_time",current_time/1000);
        rechargeSn02Params.put("endtime",CommonTools.getTimesnight()-1 -(24 * 60 * 60 * 2));
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn02Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",2,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));

        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_02),retBody.getJSONArray("data").getJSONObject(1).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(1).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(1).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", -2) + "", retBody.getJSONArray("data").getJSONObject(1).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(1).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(1).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "0", retBody.getJSONArray("data").getJSONObject(1).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(1).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(1).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(1).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(1).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试一个用户获取多张E卡列表.其中一张是余额是0.00
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetMultiUserEcardListButOneIsInvalid() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第二条ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn02Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn02Params.put("rid",recharge_id);
        rechargeSn02Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn02Params.put("from_user","NULL");
        rechargeSn02Params.put("user_type",1);
        rechargeSn02Params.put("card_type",1);
        rechargeSn02Params.put("price",0.00);
        rechargeSn02Params.put("zhenqian",zhenqian);
        rechargeSn02Params.put("used",0);
        rechargeSn02Params.put("fan_id",fan_id);
        rechargeSn02Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn02Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",1,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试多张E卡排序
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:按照是否可用、卡类型、领取时间三种属性排序
     *   rechargeSn01Params 可用&企业年卡&领取时间相同
     *   rechargeSn02Params 可用&企业年卡&领取次之
     *   rechargeSn03Params 可用&个人卡&领取时间与01相同
     *   rechargeSn04Params 可用&个人卡&领取时间次之
     *   rechargeSn05Params 不可用&企业年卡&领取时间与01相同
     *   rechargeSn06Params 不可用&企业年卡&领取时间次之
     *   rechargeSn07Params 不可用&个人卡&领取时间与01相同
     *   rechargeSn08Params 不可用&个人卡&领取时间次之
     */

    public void testGetMultiUserEcardListSort() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",2);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("corp_id",11);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode02 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode02,mysqlQaDao) + 1;
        rechargeSn02Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn02Params.put("rid",recharge_id);
        rechargeSn02Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn02Params.put("from_user","NULL");
        rechargeSn02Params.put("user_type",1);
        rechargeSn02Params.put("card_type",2);
        rechargeSn02Params.put("price",price);
        rechargeSn02Params.put("zhenqian",zhenqian);
        rechargeSn02Params.put("used",0);
        rechargeSn02Params.put("fan_id",fan_id);
        rechargeSn02Params.put("draw_time",current_time/1000 - 60*60);
        rechargeSn02Params.put("corp_id",11);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn02Params);


        // 模拟ims_recharge_sncode的数据
        String rechargeSncode03 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_03 = CommonTools.getLastId(rechargeSncode03,mysqlQaDao) + 1;
        rechargeSn03Params.put("recharge_sncode_id",recharge_sncode_id_03);
        rechargeSn03Params.put("rid",recharge_id);
        rechargeSn03Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn03Params.put("from_user","NULL");
        rechargeSn03Params.put("user_type",1);
        rechargeSn03Params.put("card_type",1);
        rechargeSn03Params.put("price",price);
        rechargeSn03Params.put("zhenqian",zhenqian);
        rechargeSn03Params.put("used",0);
        rechargeSn03Params.put("fan_id",fan_id);
        rechargeSn03Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn03Params);


        // 模拟ims_recharge_sncode的数据
        String rechargeSncode04 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_04 = CommonTools.getLastId(rechargeSncode04,mysqlQaDao) + 1;
        rechargeSn04Params.put("recharge_sncode_id",recharge_sncode_id_04);
        rechargeSn04Params.put("rid",recharge_id);
        rechargeSn04Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn04Params.put("from_user","NULL");
        rechargeSn04Params.put("user_type",1);
        rechargeSn04Params.put("card_type",1);
        rechargeSn04Params.put("price",price);
        rechargeSn04Params.put("zhenqian",zhenqian);
        rechargeSn04Params.put("used",0);
        rechargeSn04Params.put("fan_id",fan_id);
        rechargeSn04Params.put("draw_time",current_time/1000 - 60*60);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn04Params);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode05 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_05 = CommonTools.getLastId(rechargeSncode05,mysqlQaDao) + 1;
        rechargeSn05Params.put("recharge_sncode_id",recharge_sncode_id_05);
        rechargeSn05Params.put("rid",recharge_id);
        rechargeSn05Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn05Params.put("from_user","NULL");
        rechargeSn05Params.put("user_type",1);
        rechargeSn05Params.put("card_type",2);
        rechargeSn05Params.put("price",price);
        rechargeSn05Params.put("zhenqian",zhenqian);
        rechargeSn05Params.put("used",0);
        rechargeSn05Params.put("fan_id",fan_id);
        rechargeSn05Params.put("draw_time",current_time/1000);
        rechargeSn05Params.put("endtime",CommonTools.getTimesnight()-1 - 24*60*60*2);
        rechargeSn05Params.put("corp_id",11);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn05Params);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode06 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_06 = CommonTools.getLastId(rechargeSncode06,mysqlQaDao) + 1;
        rechargeSn06Params.put("recharge_sncode_id",recharge_sncode_id_06);
        rechargeSn06Params.put("rid",recharge_id);
        rechargeSn06Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn06Params.put("from_user","NULL");
        rechargeSn06Params.put("user_type",1);
        rechargeSn06Params.put("card_type",2);
        rechargeSn06Params.put("price",price);
        rechargeSn06Params.put("zhenqian",zhenqian);
        rechargeSn06Params.put("used",0);
        rechargeSn06Params.put("fan_id",fan_id);
        rechargeSn06Params.put("draw_time",current_time/1000 - 60*60);
        rechargeSn06Params.put("endtime",CommonTools.getTimesnight()-1 - 24*60*60*2);
        rechargeSn06Params.put("corp_id",11);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn06Params);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode07 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_07 = CommonTools.getLastId(rechargeSncode07,mysqlQaDao) + 1;
        rechargeSn07Params.put("recharge_sncode_id",recharge_sncode_id_07);
        rechargeSn07Params.put("rid",recharge_id);
        rechargeSn07Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn07Params.put("from_user","NULL");
        rechargeSn07Params.put("user_type",1);
        rechargeSn07Params.put("card_type",1);
        rechargeSn07Params.put("price",price);
        rechargeSn07Params.put("zhenqian",zhenqian);
        rechargeSn07Params.put("used",0);
        rechargeSn07Params.put("fan_id",fan_id);
        rechargeSn07Params.put("draw_time",current_time/1000);
        rechargeSn07Params.put("endtime",CommonTools.getTimesnight()-1 - 24*60*60*2);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn07Params);

        // 模拟ims_recharge_sncode的数据
        String rechargeSncode08 = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id_08 = CommonTools.getLastId(rechargeSncode08,mysqlQaDao) + 1;
        rechargeSn08Params.put("recharge_sncode_id",recharge_sncode_id_08);
        rechargeSn08Params.put("rid",recharge_id);
        rechargeSn08Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn08Params.put("from_user","NULL");
        rechargeSn08Params.put("user_type",1);
        rechargeSn08Params.put("card_type",1);
        rechargeSn08Params.put("price",price);
        rechargeSn08Params.put("zhenqian",zhenqian);
        rechargeSn08Params.put("used",0);
        rechargeSn08Params.put("fan_id",fan_id);
        rechargeSn08Params.put("draw_time",current_time/1000 - 60*60);
        rechargeSn08Params.put("endtime",CommonTools.getTimesnight()-1 - 24*60*60*2);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn08Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",8,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_02),retBody.getJSONArray("data").getJSONObject(1).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_03),retBody.getJSONArray("data").getJSONObject(2).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_04),retBody.getJSONArray("data").getJSONObject(3).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_05),retBody.getJSONArray("data").getJSONObject(4).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_06),retBody.getJSONArray("data").getJSONObject(5).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_07),retBody.getJSONArray("data").getJSONObject(6).getString("id"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id_08),retBody.getJSONArray("data").getJSONObject(7).getString("id"));


    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:测试本卡支持洗衣洗鞋品类和支持北京上海两个城市使用
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void  testGetUserEcardButMultyCategoryCity() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        ecardLimitParams.put("category_id","1,2");
        ecardLimitParams.put("city_id","1,2");
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣、洗鞋"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京、上海地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试距离过期时间3天以内的e卡在日期后面加上后天
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardDue3Days() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1 + 24*60*60*2);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",2) + "（后天）",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试距离过期时间2天以内的e卡在日期后面加上明天
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardDue2Days() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1 + 24*60*60*1);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",1) + "（明天）",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试距离过期时间1天以内的e卡在日期后面加上今天
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardDue1Days() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",0) + "（今天）",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试不支持使用优惠券的提醒
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardNotallow_coupon() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        ecardLimitParams.put("allow_coupon",0);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",20) + "",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用 不支持使用优惠券", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试不支持余额商城的提示
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardNotAllowMall() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        ecardLimitParams.put("allow_coupon",0);
        ecardLimitParams.put("allow_mall",0);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",20) + "",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用 不支持使用优惠券", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试企业年卡
     *   when:非支付的情况下请求E卡列表的接口
     *   where:我的－e卡
     *   how:点击进入
     *   then:显示我现在可用的e卡列表
     */

    public void testGetEcardIsCorporation() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",2);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("corp_id",11);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        this.queryParams.put("user_id",fan_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardList(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",retBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期",String.valueOf(recharge_sncode_id),retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期","" + CommonTools.getAfterDate("yyyy年MM月dd日",-5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日",20) + "",retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用", retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","合理企业 专享", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",2, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试下单的时候获取E卡列表
     *   when:用户在支付一个订单的时候，只选择了一张E卡
     *   then:订单满足E卡的使用要求
     */

    public void testGetEcardListByPay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        // 模拟订单表的数据-订单金额540，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery,mysqlQaDao) + 1;
        OrderParams.put("order_id",order_id);
        OrderParams.put("order_sn",CommonTools.getOrdersn(order_id));
        OrderParams.put("status",1);
        OrderParams.put("status_delivery",1);
        OrderParams.put("pay_status",0);
        OrderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
        OrderParams.put("washing_time","14:00~16:00");
        OrderParams.put("old_category_id",1);
        OrderParams.put("totalprice","585");
        OrderParams.put("delivery_fee","0");
        OrderParams.put("fan_id",fan_id);
        generalRongChain04Data.GeneralOrder(OrderParams);

        this.queryParams.put("user_id",fan_id);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("category_id",1);
        this.orderInfoParams.put("city_id",1);
        this.orderInfo.add(0,this.orderInfoParams);
        this.queryParams.put("order_info",this.orderInfo);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardListByString(URLBuilder.httpBuildQuery(this.queryParams,""), this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id), retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "1", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试两个订单合单支付的时候其中一个订单的品类与E卡的品类不匹配
     *   when:用户在支付两个订单的时候，只选择了一张E卡
     *   then:返回此E卡不可用
     */

    public void testGetEcardListByPayTwoOrder() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price",price);
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        // 模拟订单表的数据-订单金额540，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery,mysqlQaDao) + 1;
        OrderParams.put("order_id",order_id);
        OrderParams.put("order_sn",CommonTools.getOrdersn(order_id));
        OrderParams.put("status",1);
        OrderParams.put("status_delivery",1);
        OrderParams.put("pay_status",0);
        OrderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
        OrderParams.put("washing_time","14:00~16:00");
        OrderParams.put("old_category_id",1);
        OrderParams.put("totalprice","585");
        OrderParams.put("delivery_fee","0");
        OrderParams.put("fan_id",fan_id);
        generalRongChain04Data.GeneralOrder(OrderParams);

        this.queryParams.put("user_id",fan_id);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("category_id",1);
        this.orderInfoParams.put("city_id",1);
        this.orderInfoParams01.put("id", order_id + 1);
        this.orderInfoParams01.put("category_id",2);
        this.orderInfoParams01.put("city_id",1);
        this.orderInfo.add(0,this.orderInfoParams);
        this.orderInfo.add(1,this.orderInfoParams01);
        this.queryParams.put("order_info",this.orderInfo);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardListByString(URLBuilder.httpBuildQuery(this.queryParams,""), this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id), retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期",price,retBody.getJSONArray("data").getJSONObject(0).getString("balance"));
        Assert.assertTrue("返回值不符合预期",retBody.getJSONArray("data").getJSONObject(0).getString("support").contains("本卡支持 洗衣"));
        Assert.assertEquals("返回值不符合预期", "" + CommonTools.getAfterDate("yyyy年MM月dd日", -5) + " 到 " + CommonTools.getAfterDate("yyyy年MM月dd日", 20) + "", retBody.getJSONArray("data").getJSONObject(0).getString("validate_range"));
        Assert.assertEquals("返回值不符合预期", "仅限北京地区用户使用",retBody.getJSONArray("data").getJSONObject(0).getString("warning"));
        Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").getJSONObject(0).getString("price").contains("初始面值 " + price + "元"));
        Assert.assertEquals("返回值不符合预期", "0", retBody.getJSONArray("data").getJSONObject(0).getString("is_useable"));
        Assert.assertEquals("返回值不符合预期","", retBody.getJSONArray("data").getJSONObject(0).getString("corprate"));
        Assert.assertEquals("返回值不符合预期","0", retBody.getJSONArray("data").getJSONObject(0).getString("freeze"));
        Assert.assertEquals("返回值不符合预期",1, retBody.getJSONArray("data").getJSONObject(0).getIntValue("card_type"));
        Assert.assertEquals("返回值不符合预期","1", retBody.getJSONArray("data").getJSONObject(0).getString("allow_coupon"));
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-13
     * @Scenario:主要是测试下单的时候获取多张E卡排序列表
     *   when:排序的规则是按照可用、临近过期、金额小三种
     *   then:
     *   可用&过期时间是今天晚上23:59:59&100
     *   可用&过期时间是今天晚上23:59:59&110
     *   可用&过期时间是明天晚上23:59:59&100
     *   可用&过期时间是明天晚上23:59:59&110
     *   不可用的不返回
     */

    public void testWhenPaySort() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据-过期时间是当天的23:59:59,金额是100.00
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price","100.00");
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);


        // 模拟第二条ims_recharge_sncode的数据-过期时间是当天的23:59:59，金额是110.00
        int recharge_sncode_id_01 = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_01);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price","110.00");
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第三条ims_recharge_sncode的数据-过期时间是明天的23:59:59，金额是100.00
        int recharge_sncode_id_02 = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_02);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price","100.00");
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1 + 60*60*24);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第四条ims_recharge_sncode的数据-过期时间是明天的23:59:59，金额是110.00
        int recharge_sncode_id_03 = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_03);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price","110.00");
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1 + 60*60*24);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟第五条ims_recharge_sncode的数据-过期时间是昨天的23:59:59，金额是110.00
        int recharge_sncode_id_04 = CommonTools.getLastId(rechargeSncode,mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id",recharge_sncode_id_04);
        rechargeSn01Params.put("rid",recharge_id);
        rechargeSn01Params.put("sncode",String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user","NULL");
        rechargeSn01Params.put("user_type",1);
        rechargeSn01Params.put("card_type",1);
        rechargeSn01Params.put("price","110.00");
        rechargeSn01Params.put("zhenqian",zhenqian);
        rechargeSn01Params.put("used",0);
        rechargeSn01Params.put("fan_id",fan_id);
        rechargeSn01Params.put("draw_time",current_time/1000);
        rechargeSn01Params.put("endtime",CommonTools.getTimesnight()-1 - 60*60*24);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        // 模拟订单表的数据-订单金额540，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery,mysqlQaDao) + 1;
        OrderParams.put("order_id",order_id);
        OrderParams.put("order_sn",CommonTools.getOrdersn(order_id));
        OrderParams.put("status",1);
        OrderParams.put("status_delivery",1);
        OrderParams.put("pay_status",0);
        OrderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
        OrderParams.put("washing_time","14:00~16:00");
        OrderParams.put("old_category_id",1);
        OrderParams.put("totalprice","585");
        OrderParams.put("delivery_fee","0");
        OrderParams.put("fan_id",fan_id);
        generalRongChain04Data.GeneralOrder(OrderParams);

        this.queryParams.put("user_id",fan_id);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("category_id",1);
        this.orderInfoParams.put("city_id",1);
        this.orderInfo.add(0,this.orderInfoParams);
        this.queryParams.put("order_info",this.orderInfo);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallUserEcardListByString(URLBuilder.httpBuildQuery(this.queryParams,""), this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id), retBody.getJSONArray("data").getJSONObject(0).getString("id"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id_01), retBody.getJSONArray("data").getJSONObject(1).getString("id"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id_02), retBody.getJSONArray("data").getJSONObject(2).getString("id"));
        Assert.assertEquals("返回值不符合预期", String.valueOf(recharge_sncode_id_03), retBody.getJSONArray("data").getJSONObject(3).getString("id"));

    }


}
