package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.CreateOrderByStatus;
import com.edaixi.qa.common.URLBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by he_yi on 16/8/3.
 */
public class CreatePayOrder {
    public static Logger logger = LoggerFactory
            .getLogger(CreatePayOrder.class);

    private int[] orderId;
    private String[] orderSn;
    private int orderSumNumber = 0;
    private String tmpOrdersn = "";
    private int courierId, fanId, cardId, tmpOrderId;
    private double balanceMoney = 0.00;//余额
    private double cashMoney = 0.00; //现金
    private double thirdPartyMoney = 0.00; //第三方
    private double transferMoney = 0.00; //运费
    private double sumMoney = 0.00;
    private boolean couponIsUsed = false;
    private Coupons coupon = null;
    private Ecard ecard = null;
    private Map<Integer, String> clothMap = new HashMap<Integer, String>();

    private List<Map<Integer, String>> clothMapList = new ArrayList<>();
    private Map<Integer, Double> pricesMap = new HashMap<Integer, Double>();

    private List<Map> orderList = new ArrayList<>();
    private List<Integer>[] orderClotheIdListArray;
    private List<Map<String, Object>>[] orderClotheMapArray;
    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private boolean useFlag = true;
    private boolean hasThridPay = false;
    private boolean hasCash = false;

    private boolean jingdongPay = false;
    private List<Integer> deletePriceIdList = new ArrayList<>();


    public CreatePayOrder(){
        init();
    }

    private void init(){
        courierId = CommonTools.get_courierId(mysqlQaDao);
        fanId = CommonTools.getFanId(mysqlQaDao);
        String sql_cardId = "select id from ims_icard_card where fan_id = "+fanId;
        cardId = CommonTools.getLastId(sql_cardId, mysqlQaDao);
    }

    private void createWaitPayOrder(){
        CreateOrderByStatus createOrder = new CreateOrderByStatus();
        CreateOrderByStatus.orderStatus createOrderStatus = null;
        createOrderStatus = CreateOrderByStatus.orderStatus.qu_paidan;

        createOrder.setCourierId(courierId);
        createOrder.setFanId(fanId);
        createOrder.getOrderByStatus(createOrderStatus);
        tmpOrdersn = createOrder.getOrderSn();
        tmpOrderId = createOrder.getOrderId();

        if (transferMoney != 0.00){
            useFlag = false;
        }

        if (coupon != null && !couponIsUsed){
            sumMoney+=coupon.getMoney();
            createClothPrices(coupon.getMoney());
            couponIsUsed = true;
        }
        if (ecard != null){
            sumMoney+=ecard.getMoney();
            double tmp = ecard.getMoney();
            if (!useFlag){
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);
        }
        if (balanceMoney != 0.00) {
            sumMoney+=balanceMoney;
            double tmp = balanceMoney;
            if (!useFlag){
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);
//            updateBalanceMoney();
        }

        if (cashMoney != 0.00) {
            sumMoney += cashMoney;
            double tmp = cashMoney;
            if (!useFlag) {
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);

        }
//        }else {
            if (thirdPartyMoney != 0.00){
                double tmp = thirdPartyMoney;
                if (!useFlag){
                    tmp -= transferMoney;
                    useFlag = true;
                }
                sumMoney+=thirdPartyMoney;
                createClothPrices(tmp);
            }

//        }


        String sql = "update ims_washing_order set totalprice="+(sumMoney+transferMoney)+" , delivery_fee="+ transferMoney
                +"where id ="+tmpOrderId;
        mysqlQaDao.execUpdateSql(sql);

    }

    public void addOrder(){
        createWaitPayOrder();
        Map tmpOrderMap = new HashMap<>();
        tmpOrderMap.put("orderId", tmpOrderId);
        tmpOrderMap.put("orderSn", tmpOrdersn);
        tmpOrderMap.put("transferMoney", transferMoney);
        tmpOrderMap.put("sumMoney", sumMoney);
        tmpOrderMap.put("priceMap", pricesMap);
        tmpOrderMap.put("clothMap", clothMap);
        tmpOrderMap.put("ecard", ecard);
        tmpOrderMap.put("balance", balanceMoney);
        tmpOrderMap.put("cash", cashMoney);
        tmpOrderMap.put("third", thirdPartyMoney);
        orderList.add(tmpOrderMap);

        clothMapList.add(clothMap);

        tmpOrderId = 0;
        tmpOrdersn = "";
        transferMoney = 0.00;
        sumMoney = 0.00;
        pricesMap = new HashMap<>();
        clothMap = new HashMap<>();
        ecard = null;
        balanceMoney = 0.00;
        cashMoney = 0.00;
        thirdPartyMoney = 0.00;
    }

    public JSONObject payOrderNotWithCallBack(){
        if (orderList.size() == 0){
            addOrder();
        }

        //////////////////////////////取数据开始/////////////////////////////
        int sumSize = orderList.size();
        orderSumNumber = sumSize;
        orderId = new int[sumSize];
        orderSn = new String[sumSize];
        int[] orderIdArray = new int[sumSize];
        String[] orderSnArray = new String[sumSize];
        double[] transferMoneyArray = new double[sumSize];
        double[] balanceArray = new double[sumSize];
        double[] cashArray = new double[sumSize];
        double[] thirdyArray = new double[sumSize];
        double[] sumMoneyArray = new double[sumSize];
        Ecard[] ecardArray = new Ecard[sumSize];
        Map<Integer, Double>[] priceMapArray = new Map[sumSize];
        Map<Integer, String>[] clothMapArray = new Map[sumSize];
        double totalTransferMoney = 0.00;
        double totalBalance = 0.00;

        for (int i=0;i<sumSize;i++){
            Map tmpMap = orderList.get(i);
            sumMoney += (double) tmpMap.get("sumMoney");
            totalTransferMoney += (double) tmpMap.get("transferMoney");
            totalBalance += (double) tmpMap.get("balance");

            orderIdArray[i] = (int) tmpMap.get("orderId");
            orderId[i] = (int) tmpMap.get("orderId");
            orderSnArray[i] = String.valueOf(tmpMap.get("orderSn"));
            orderSn[i] = String.valueOf(tmpMap.get("orderSn"));
            transferMoneyArray[i] = (double) tmpMap.get("transferMoney");
            sumMoneyArray[i] = (double) tmpMap.get("sumMoney");
            ecardArray[i] = (Ecard) tmpMap.get("ecard");
            balanceArray[i] = (double) tmpMap.get("balance");
            cashArray[i] = (double) tmpMap.get("cash");
            thirdyArray[i] = (double) tmpMap.get("third");
            priceMapArray[i] = (Map<Integer, Double>) tmpMap.get("priceMap");
            clothMapArray[i] = (Map<Integer, String>) tmpMap.get("clothMap");
        }
        //////////////////////////////取数据结束////////////////////////////////

        /////////////////////合单运费信息/////////////////////////////////
        JSONArray subFee = new JSONArray();
        Map<String, Object>[] subFeeParamArray = new Map[sumSize];
        for (int i=0;i<sumSize;i++){
            subFeeParamArray[i] = new HashMap<>();
            subFeeParamArray[i].put("order_id", orderIdArray[i]);
            subFeeParamArray[i].put("fee", transferMoneyArray[i]);
            subFee.add(subFeeParamArray[i]);
        }

        Map<String, Object> deliveryParam = new HashMap<String, Object>();
        deliveryParam.put("total_fee", totalTransferMoney);//合单运费金额
        deliveryParam.put("sub_fee", subFee);
        /////////////////////合单运费信息/////////////////////////////////


        ////////////////////////////////orderInfo层/////////////////////
        JSONArray orderInfo = new JSONArray();
        for (int i=0;i<sumSize;i++){
            /////////////////////衣物分拣信息//////////////////
            JSONArray clothWithPrice = new JSONArray();
            int j=0;
            Object[] clothInfo = clothMapArray[i].entrySet().toArray();
            for(Map.Entry<Integer, Double> entry : priceMapArray[i].entrySet()){
                Map<String, Object> tmpMap = new HashMap<>();
                tmpMap.put("id", entry.getKey());
                tmpMap.put("num", 1);
                tmpMap.put("price", entry.getValue());


                int clothId = Integer.parseInt(clothInfo[j].toString().split("=")[0]);
                String clothNam = clothInfo[j].toString().split("=")[1];
                tmpMap.put("clothes_id", clothId);
                tmpMap.put("clothes_name", clothNam);

                clothWithPrice.add(tmpMap);
                j++;
            }
            /////////////////////衣物分拣信息//////////////////

            Map<String, Object> orderInfoParams = new HashMap<String, Object>();
            orderInfoParams.put("id", orderIdArray[i]);
            orderInfoParams.put("ordersn",orderSnArray[i]);
            orderInfoParams.put("category_id", 1);
            orderInfoParams.put("cloth_with_price", clothWithPrice);
            orderInfoParams.put("city_id", 1);
            orderInfoParams.put("price", sumMoneyArray[i]-transferMoneyArray[i]);

            orderInfo.add(orderInfoParams);

        }

        Map<String, Object> superMap = new HashMap<String, Object>();
        superMap.put("user_id", fanId);
        superMap.put("business_id", 11);
        superMap.put("user_type", 3);
        superMap.put("delivery", deliveryParam);
        superMap.put("order_info", orderInfo);
        Map<String, Object> payInfoParam = new HashMap<String, Object>();
        for (int j=0;j<sumSize;j++){
            if (balanceArray[j] != 0.00){
                payInfoParam.put("icard", 1);
                superMap.put("pay_type", 1);// 电子会员卡支付
                payInfoParam.put("icard_fee", totalBalance);
                break;
            }else{
                payInfoParam.put("icard", 0);
                superMap.put("pay_type", 2);// 微信支付
            }
        }


        if (hasThridPay){
            superMap.put("pay_type", 2);// 微信支付

        }

        if (hasCash){
            superMap.put("pay_type", 3);// 现金支付
        }


        if (jingdongPay){
            superMap.put("pay_type", 16);// 京东
        }

        JSONArray ecardJson = new JSONArray();
        for (int k=0;k<sumSize;k++){
            if (ecardArray[k] != null){
                ecardJson.add(ecardArray[k].getId());
                payInfoParam.put("ecard_ids", ecardJson);
                double ecard_money = ecardArray[k].getMoney();
                if (payInfoParam.containsKey("ecard_fee")){
                    ecard_money += (double) payInfoParam.get("ecard_fee");

                }
                payInfoParam.put("ecard_fee", ecard_money);
            }
        }

        if (coupon != null){
            payInfoParam.put("coupon_id", coupon.getId());
        }

        superMap.put("pay_info", payInfoParam);

        logger.info(superMap.toString());
        String buildString = URLBuilder.httpBuildQuery(superMap, "");
        Map<String, Object> httpHead = new HashMap<String, Object>();
        httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");



        //如果账户余额与设置余额消费不一致,则修改,保证第三方和现金可以支付
        if (getUserBalance() != totalBalance){
            setUserBalance(totalBalance);
        }

        // 调用接口
        EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
        JSONObject result = edxpayModuleService.CallPlatformIndex(buildString, httpHead);

        orderClotheIdListArray = new List[sumSize];
        orderClotheMapArray = new List[sumSize];
        for (int n=0;n<sumSize;n++) {
            orderClotheIdListArray[n] = new ArrayList<>();
            orderClotheMapArray[n] = new ArrayList<>();

            String sql_clothOrderId = "select cloth_order_id, fee from pf_order_detail where order_id=" + orderIdArray[n];
            ResultSet resultSet = mysqlQaDao.execQuerySql(sql_clothOrderId);
            try {
                resultSet.beforeFirst();
                while (resultSet.next()) {
                    int id = resultSet.getInt("cloth_order_id");
                    orderClotheIdListArray[n].add(id);

                    String fee = resultSet.getString("fee");
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", id);
                    map.put("fee", fee);
                    orderClotheMapArray[n].add(map);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

//        for (int m=0;m<sumSize;m++){
//            if (cashArray[m] != 0 || thirdyArray[m] !=0){
//                logger.info("支付结果信息:"+result);
//                JSONObject json = JSON.parseObject(result.getString("httpBody")).getJSONObject("data");
//                callBack(json.getString("trade_no"));
//                break;
//            }
//        }

        logger.info("支付结果信息:"+result);
        return result;
    }


    public void setUserBalance(double coin, double zhenqian){
        String sql_balance = "update ims_icard_card set coin = "+(coin)+", zhenqian = "+zhenqian+" where fan_id = "+fanId;
        mysqlQaDao.execUpdateSql(sql_balance);
    }

    public void setUserBalance(double coin){
        setUserBalance(coin, 0);
    }

    public double getUserBalance(){
        String sql = "select coin from ims_icard_card where fan_id="+fanId;
        double coin = 0.00;
        try {
            ResultSet resultSet  = mysqlQaDao.execQuerySql(sql);
            coin = resultSet.getDouble(1);
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return coin;
    }

    public void setJingdongPay(){
        jingdongPay = true;
    }

    public JSONObject payOrder(){
        JSONObject jsonObject = payOrderNotWithCallBack();
        if (hasThridPay || hasCash){
            logger.info("支付json"+jsonObject.toJSONString());
            JSONObject json = JSON.parseObject(jsonObject.getString("httpBody")).getJSONObject("data");
            callBack(json.getString("trade_no"));

        }

        return jsonObject;
    }

    private void callBack(String trade_no){
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = "+fanId+" and tid = '"+trade_no+"';";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        Map<String, Object> queryParams = new HashMap<>();
        int paylog_id = 0;
        try {
            paylog_id = queryImsPaylogInfo.getInt("plid");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        queryParams.put("plid",paylog_id);
        logger.info(queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(queryParams, "");
        Map<String, Object> httpHead = new HashMap<>();
        httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
        JSONObject result = edxpayModuleService.CallPlatformCallBack(buildString, httpHead);
        logger.info("第三方支付回调接口"+result.toJSONString());
    }

    private void createClothPrices(double money){
        int priceId = CommonTools.getNewIdByTableName("prices", mysqlQaDao);
        int clothId = getClothId();
        String sql = "insert into prices(id, clothes_id, city_id, price, jgd_price, smart_key, wash_deadline_dian, wash_deadline_chang, is_deleted, ori_id, is_suit, serial_index, sort_mark) " +
                "values("+priceId+", "+clothId+",1,"+money+",0.00, -1, 30, 30,0,12810,0,12810,12810);";
        mysqlQaDao.execUpdateSql(sql);
        pricesMap.put(priceId, money);

        deletePriceIdList.add(priceId); //用于删除数据
    }

    public void deleteClothPrices(){
        String sql = "delete from prices where id in(";
        for (int tmp:deletePriceIdList){
            sql += tmp+",";
        }
        sql = sql.substring(0,sql.length()-1);
        sql+=");";
        mysqlQaDao.execUpdateSql(sql);
    }

    private int getClothId(){
        String sql_cloth = "select id, name from clothes where is_deleted=0 order by rand() limit 1;";//order by rand()随机排序
        ResultSet result = mysqlQaDao.execQuerySql(sql_cloth);
        int id = 0;
        try {
            result.beforeFirst();
            while (result.next()){
                id = result.getInt("id");
                String name = result.getString("name");
                if (clothMap.containsKey(id)){
                    getClothId();
                }else{
                    clothMap.put(id, name);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    public void setFanId(int fanId){
        this.fanId = fanId;
        String sql_cardId = "select id from ims_icard_card where fan_id = "+fanId;
        cardId = CommonTools.getLastId(sql_cardId, mysqlQaDao);
    }

    public void setEcard(Ecard ecard) {
        this.ecard = ecard;
    }

    public void setBalanceMoney(double balanceMoney) {
        this.balanceMoney = balanceMoney;
    }

    public void setCashMoney(double cash) {
        this.cashMoney = cash;
        if (cash != 0.00){
            hasCash = true;
        }
    }

    public void setThirdPartyMoney(double thirdMoney) {
        this.thirdPartyMoney = thirdMoney;
        if (thirdMoney != 0.00){
            hasThridPay = true;
        }
    }

    public void setTransferMoney(double transferMoney) {
        this.transferMoney = transferMoney;
    }

    public void setCounpon(Coupons counpon) {
        if (this.coupon == null){
            this.coupon = counpon;

        }

    }

    public int[] getOrderId(){
        return orderId;
    }

    public int getOrderId(int index){
        int tmp = 0;
        if (index>=0 || index<=orderSumNumber){
            tmp =  orderId[index];
        }

        return tmp;
    }

    public String[] getOrderSn(){
        return orderSn;
    }

    public String getOrderSn(int index){
        String tmp = "";
        if (index>=0 || index<=orderSumNumber){
            tmp =  orderSn[index];
        }

        return tmp;
    }

    public Coupons getCoupon(){
        return coupon;
    }


    public Map<Integer, String> getClothInfo(int orderIndex){
        return clothMapList.get(orderIndex);
    }

    public List<Map<String, Object>> getOrderClotheMap(int orderIndex){
        return orderClotheMapArray[orderIndex];
    }

    public List<Map<String, Object>> getRefundClothParameter(int orderIndex){
        List<Map<String, Object>> list = new ArrayList<>();
        List<Map<String, Object>> orderClothMap  = getOrderClotheMap(orderIndex);
        Map<Integer, String> clothInfo = getClothInfo(orderIndex);
        int i =0;
        for (Map.Entry<Integer, String> entry : clothInfo.entrySet()) {

            int id = entry.getKey();
            String name = entry.getValue();
            Map<String, Object> clothMap = orderClothMap.get(i);
            int orderClothId = (int) clothMap.get("id");
            String fee = String.valueOf(clothMap.get("fee"));

            Map<String, Object> map = new HashMap<>();
            map.put("cloth_id", id);
            map.put("name", name);
            map.put("cloth_order_id", orderClothId);
            map.put("fee", fee);
            list.add(map);
            i++;
        }

        return list;
    }
}
