package com.edaixi.qa.edxpay;

/**
 * Created by wangting on 2016/1/29.
 * fan_id	是	int	fan_id
 * order_info	否	array	下单时需要传入的字段，包括 order_price(订单金额)， exclusive_channels（支付方式）,category_id(品类)，user_types（客户端类型），city_id(城市id)
 */
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
public class CountUserCouponTest {

    private static Logger logger = LoggerFactory
            .getLogger(CountUserCouponTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private JSONObject queryParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }

    @Test
    /**
     *
     * @author wangting
     * @function 统计的优惠券总数>1
     *
     */
    public void testCountUserCoupon1() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        long currentTime = System.currentTimeMillis();
        int sncode_id = (int)(currentTime % 10000000);
        int fan_id =(int)(currentTime%1000000);

        String insertImsIcouponSncode = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + sncode_id + ", 0, 3597, '1456449474', '', 'ouCgTwm-N2ihKxgC9yx2jX3NdWwc', '0.00', '0.00', 0, 0, 0, 1453450163, "+fan_id+", 1453478400, 1469375999, 1407048618, NULL, '2016-01-22 16:10:35','2016-01-22 16:18:32');\n";
        mysqlQaDao.execUpdateSql(insertImsIcouponSncode);

        int sncode_id1 = (int)((Math.random()*9+1)*1000000);
        String insertImsIcouponSncode1 = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + sncode_id1 + ", 0, 3597, '1456449474', '', 'ouCgTwm-N2ihKxgC9yx2jX3NdWwc', '0.00', '0.00', 0, 0, 0, 1453450163, "+fan_id+", 1453478400, 1469375999, 1407048618, NULL, '2016-01-22 16:10:35','2016-01-22 16:18:32');\n";
        mysqlQaDao.execUpdateSql(insertImsIcouponSncode1);

        this.queryParams.put("fan_id",fan_id);

        // 调用获得某fan_id的优惠券总数的接口
        JSONObject result = this.edxpayModuleService.CallCountUserCoupon("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        //httpBody的内容进行参数验证
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",loginBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "成功",loginBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "2", loginBody.getJSONObject("data").getString("count"));

    }

    @Test
    /**
     *
     * @author wangting
     * @function 统计的优惠券总数为1
     *
     */
    public void testCountUserCoupon2() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        long currentTime = System.currentTimeMillis();
        int sncode_id = (int)(currentTime % 10000000);
        int fan_id =(int)(currentTime%1000000);

        String insertImsIcouponSncode = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + sncode_id + ", 0, 3597, '1456449474', '', 'ouCgTwm-N2ihKxgC9yx2jX3NdWwc', '0.00', '0.00', 0, 0, 0, 1453450163, "+fan_id+", 1453478400, 1469375999, 1407048618, NULL, '2016-01-22 16:10:35','2016-01-22 16:18:32');\n";
        mysqlQaDao.execUpdateSql(insertImsIcouponSncode);
        this.queryParams.put("fan_id",fan_id);

        // 调用获得某fan_id的优惠券总数
        JSONObject result = this.edxpayModuleService.CallCountUserCoupon("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        //httpBody的内容进行参数验证
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").equals("0000"));
        Assert.assertTrue("返回值不符合预期", loginBody.getString("resp_msg").equals("成功"));
        Assert.assertEquals("返回值不符合预期", "1", loginBody.getJSONObject("data").getString("count"));
    }

    @Test
    /**
     *
     * @author wangting
     * @function 统计的优惠券总数=0(情景二：、对fan_id插入优惠券过期的数据)
     *
     */
    public void testCountUserCoupon4() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        long currentTime = System.currentTimeMillis();
        int sncode_id = (int)(currentTime % 10000000);
        int fan_id =(int)(currentTime%1000000);

        this.queryParams.put("fan_id",fan_id);

        String insertImsIcouponSncodeNull = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + sncode_id + ", 1 ,5, '1456449474', '0827889126286', 'oMWhZt0Ntz9D__lo7zEInyARbGzI', '0.00', '0.00', 1, 0, 1409124738, 1407048618, NULL, 1403539200, 1451577599, 1407048618, NULL, '2014-08-03 14:50:18', '2014-08-03 14:50:18');\n";

        mysqlQaDao.execUpdateSql(insertImsIcouponSncodeNull);
        // 调用获得某fan_id的优惠券总数
        JSONObject result = this.edxpayModuleService.CallCountUserCoupon("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        //httpBody的内容进行参数验证
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").equals("0000"));
        Assert.assertTrue("返回值不符合预期", loginBody.getString("resp_msg").equals("成功"));
        Assert.assertEquals("返回值不符合预期", "0", loginBody.getJSONObject("data").getString("count"));
    }

    @Test
    /**
     *
     * @author wangting
     * @function 统计的优惠券总数=0(情景三：、对fan_id插入used=1的优惠券)
     *
     */
    public void testCountUserCoupon5() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        long currentTime = System.currentTimeMillis();
        int sncode_id = (int)(currentTime % 10000000);
        int fan_id =(int)(currentTime%1000000);

        String insertImsIcouponSncode = "INSERT INTO `ims_icoupon_sncode` (`id`, `coupon_type`, `cid`, `sncode`, `order_sn`, `from_user`, `minus_money`, `total_money`, `used`, `consume`, `usetime`, `create_time`, `fan_id`, `starttime`, `endtime`, `lingqu_time`, `good_item_id`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t(" + sncode_id + ", 0, 3597, '1456449474', '', 'ouCgTwm-N2ihKxgC9yx2jX3NdWwc', '0.00', '0.00', 1, 0, 1453450163, 1453450163, "+fan_id+", 1453478400, 1469375999, 1407048618, NULL, '2016-01-22 16:10:35','2016-01-22 16:18:32');\n";
        mysqlQaDao.execUpdateSql(insertImsIcouponSncode);

        this.queryParams.put("fan_id",fan_id);

        // 调用获得某fan_id的优惠券总数
        JSONObject result = this.edxpayModuleService.CallCountUserCoupon("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        //httpBody的内容进行参数验证
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").equals("0000"));
        Assert.assertTrue("返回值不符合预期", loginBody.getString("resp_msg").equals("成功"));
        Assert.assertEquals("返回值不符合预期", "0", loginBody.getJSONObject("data").getString("count"));
    }


}
