package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 第三方支付下单接口
 * Created by ningzhao on 16-4-18.
 */
public class PlatformIndexSupportOldVersionTest {

    public static Logger logger = LoggerFactory
            .getLogger(PlatformIndexSupportOldVersionTest.class);
    public EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    public GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    public Map<String, Object> queryParams = null;
    public Map<String, Object> orderClothesListsParams01 = null;
    public Map<String, Object> orderClothesListsParams02 = null;
    public Map<String, Object> clothWithPrice0001 = null;
    public Map<String, Object> clothWithPrice0002 = null;
    public Map<String, Object> clothWithPrice0003 = null;
    public Map<String, Object> subFeeParam01 = null;
    public Map<String, Object> subFeeParam02 = null;
    public Map<String, Object> deliveryParam = null;
    public Map<String, Object> payInfoParam = null;
    public Map<String, Object> ecardLimitParams = null;
    public Map<String, Object> orderInfoParams = null;
    public Map<String, Object> orderInfoParams01 = null;
    public JSONArray orderIds = new JSONArray();
    public JSONObject fanParams = new JSONObject();
    public JSONArray orderInfo = new JSONArray();
    public JSONArray clothWithPrice = new JSONArray();
    public JSONArray subFee = new JSONArray();
    public JSONArray ecard = new JSONArray();
    public Map<String, Object> httpHead = null;

    public int fan_id = 0;
    public int icoupon_id = 0;
    public int icoupon_sncode_id = 0;
    public int recharge_id = 0;
    public int recharge_sncode_id = 0;

    public int icard_card_id = 0;

    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.orderInfoParams = new HashMap<String, Object>();
        this.orderInfoParams01 = new HashMap<String, Object>();
        this.clothWithPrice0001 = new HashMap<String, Object>();
        this.clothWithPrice0002 = new HashMap<String, Object>();
        this.clothWithPrice0003 = new HashMap<String, Object>();
        this.subFeeParam01 = new HashMap<String, Object>();
        this.subFeeParam02 = new HashMap<String, Object>();
        this.deliveryParam = new HashMap<String, Object>();
        this.payInfoParam = new HashMap<String, Object>();
        this.ecardLimitParams = new HashMap<String, Object>();
        this.orderClothesListsParams01 = new HashMap<String, Object>();
        this.orderClothesListsParams02 = new HashMap<String, Object>();

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        this.fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", this.fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");

    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario: 老版本用户支付时包含优惠券的方式，满40减10元的优惠券
     *   when: 无合并订单，只有一个订单
     *   then:pf_charge,pf_charge_detail,vouchers,ims_icoupon_sncode,ims_recharge_sncode,ims_paylog,paylog_details,ims_icard_card
     */
    public void testPayByCouponButOrderIsOne() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "10";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "NULL";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 40; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, this.fan_id, 0, 0);

        // 模拟订单表的数据-订单金额51，运费为0
        String order_total_price_01 = "51.00";
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, order_total_price_01, "0", this.fan_id);

        this.queryParams.put("user_id", this.fan_id);
        this.clothWithPrice0001.put("id", 611);
        this.clothWithPrice0001.put("num", 1);
        this.clothWithPrice0001.put("price", "39.0");
        this.clothWithPrice0001.put("clothes_id", 39);
        this.clothWithPrice0001.put("clothes_name", "羽绒服");
        this.clothWithPrice0002.put("id", 612);
        this.clothWithPrice0002.put("num", 1);
        this.clothWithPrice0002.put("price", "12.0");
        this.clothWithPrice0002.put("clothes_id", 46);
        this.clothWithPrice0002.put("clothes_name", "短裤");
        this.clothWithPrice.add(0, clothWithPrice0001);
        this.clothWithPrice.add(1, clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn", CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id", 1);
        this.orderInfoParams.put("cloth_with_price", this.clothWithPrice);
        this.orderInfoParams.put("city_id", 1);
        this.orderInfoParams.put("price", 51);
        this.orderInfo.add(0, this.orderInfoParams);
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 10);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", 10);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("coupon_fee",10);
        this.payInfoParam.put("icard", 0);
        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_info", this.orderInfo);
        this.queryParams.put("pay_type", 3);//现金支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 51, retBody.getJSONObject("data").getIntValue("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + this.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "51.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,channel,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeDetailInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",1,queryPfChargeDetailInfo.getInt("channel"));
        Assert.assertEquals("返回值不符合预期","51.00", queryPfChargeDetailInfo.getString("pay_fee"));

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + this.fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "cash", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 51.0, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 612 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        double cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 * 10.00 / 51.00));
        Assert.assertEquals("返回值不符合预期", cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double cloth01_third_fee = Double.parseDouble(String.format("%.2f", 12.00 - cloth01_coupon_fee));
        Assert.assertEquals("返回值不符合预期", cloth01_third_fee, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 611 + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        double cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 * 10.00 / 51.00));
        Assert.assertEquals("返回值不符合预期", cloth02_coupon_fee, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("icard_status"));
        double cloth02_third_fee = Double.parseDouble(String.format("%.2f", 39.00 - cloth02_coupon_fee));
        Assert.assertEquals("返回值不符合预期", cloth02_third_fee, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo.getString("operation"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用余额支付，满0减60的优惠券
     *
     * 订单info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     *   $total_fee = 10.00;
     * 支付info:
     *   $couponPrice = 80.00;优惠券金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */

    public void testPayByCouponOnlyButOrderIsOne() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 0.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        double order02_fee = 0.00;
        double order02_transfer_fee = 0.00;

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "80";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "NULL";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 0; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, this.fan_id, 0, 0);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        //接口调用参数
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", total_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 0);
        this.payInfoParam.put("ecard_ids", this.ecard);

        this.orderIds.add(0,order_id);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 3);// 微信支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
       // Assert.assertTrue("返回值不符合预期", retBody.getJSONArray("data").isEmpty());

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + this.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("type"));//当用户支付为0的时候，支付类型记为1
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,channel,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeDetailInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 61.00, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",1,queryPfChargeDetailInfo.getInt("channel"));
        Assert.assertEquals("返回值不符合预期","0.00", queryPfChargeDetailInfo.getString("pay_fee"));

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        double cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 * 51.00 / 51.00));
        Assert.assertEquals("返回值不符合预期", cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("icard_status"));
        double cloth01_third_fee = Double.parseDouble(String.format("%.2f", 12.00 - cloth01_coupon_fee));
        Assert.assertEquals("返回值不符合预期", cloth01_third_fee, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        double cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 * 51.00 / 51.00));
        Assert.assertEquals("返回值不符合预期", cloth02_coupon_fee, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("icard_status"));
        double cloth02_third_fee = Double.parseDouble(String.format("%.2f", 39.00 - cloth02_coupon_fee));
        Assert.assertEquals("返回值不符合预期", cloth02_third_fee, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("third_status"));

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用余额支付，满0减56的优惠券
     *
     * 订单info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     *   $total_fee = 61.00;
     * 支付info:
     *   $couponPrice = 56.00;优惠券金额
     *   $card_coin = 5.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */

    public void testOldVersionPayByIcard() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        int order_fee = 51;
        int order_transfer_fee = 10;
        int total_fee = 10;
        double order_cloth_01 = 39.00;
        double order_cloth_02 = 12.00;

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "56";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "NULL";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 0; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, this.fan_id, 0, 0);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order_fee), "0", this.fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 5.00;//还有多少钱
        double card_money = 10.00;//花了多少假钱
        double card_zhenqian = 2.00;//花的钱里面有多少是真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, this.fan_id, card_zhenqian);

        this.queryParams.put("user_id", this.fan_id);
        this.clothWithPrice0001.put("id", 611);
        this.clothWithPrice0001.put("num", 1);
        this.clothWithPrice0001.put("price", "39.0");
        this.clothWithPrice0001.put("clothes_id", 39);
        this.clothWithPrice0001.put("clothes_name", "羽绒服");
        this.clothWithPrice0002.put("id", 612);
        this.clothWithPrice0002.put("num", 1);
        this.clothWithPrice0002.put("price", "12.0");
        this.clothWithPrice0002.put("clothes_id", 46);
        this.clothWithPrice0002.put("clothes_name", "短裤");
        this.clothWithPrice.add(0, clothWithPrice0001);
        this.clothWithPrice.add(1, clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn", CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id", 1);
        this.orderInfoParams.put("cloth_with_price", this.clothWithPrice);
        this.orderInfoParams.put("city_id", 1);
        this.orderInfoParams.put("price", 51);
        this.orderInfo.add(0, this.orderInfoParams);
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 10);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", 10);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("coupon_fee",56.00);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("icard_fee", 5.00);
        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_info", this.orderInfo);
        this.queryParams.put("pay_type", 1);//现金支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + this.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("type"));//当用户支付为0的时候，支付类型记为1
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "56.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,channel,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeDetailInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 56.00, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 5.00, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",1,queryPfChargeDetailInfo.getInt("channel"));
        Assert.assertEquals("返回值不符合预期","0.00", queryPfChargeDetailInfo.getString("pay_fee"));

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 612 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00 , queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 611 + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00,queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("third_status"));

        //验证vouchers表中的Icard中合并订单日志记录正确
        String queryVouchersIcard = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id + "";
        ResultSet queryVouchersIcard01Info = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-2.00", queryVouchersIcard01Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-5.00", queryVouchersIcard01Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersIcard01Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersIcard01Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouchersIcard01Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouchersIcard01Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("pf_charge_id"));


    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用余额支付，满0减56的优惠券
     *
     * 订单info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     *   $total_fee = 61.00;
     * 支付info:
     *   $third = 56.00; 第三方
     *   $card_coin = 5.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */

    public void testPayByCouponAndThird() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        int order_fee = 51;
        int order_transfer_fee = 10;
        int total_fee = 10;
        double order_cloth_01 = 39.00;
        double order_cloth_02 = 12.00;

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order_fee), "0", this.fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 5.00;//还有多少钱
        double card_money = 10.00;//花了多少假钱
        double card_zhenqian = 2.00;//花的钱里面有多少是真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, this.fan_id, card_zhenqian);

        this.queryParams.put("user_id", this.fan_id);
        this.clothWithPrice0001.put("id", 611);
        this.clothWithPrice0001.put("num", 1);
        this.clothWithPrice0001.put("price", "39.0");
        this.clothWithPrice0001.put("clothes_id", 39);
        this.clothWithPrice0001.put("clothes_name", "羽绒服");
        this.clothWithPrice0002.put("id", 612);
        this.clothWithPrice0002.put("num", 1);
        this.clothWithPrice0002.put("price", "12.0");
        this.clothWithPrice0002.put("clothes_id", 46);
        this.clothWithPrice0002.put("clothes_name", "短裤");
        this.clothWithPrice.add(0, clothWithPrice0001);
        this.clothWithPrice.add(1, clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn", CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id", 1);
        this.orderInfoParams.put("cloth_with_price", this.clothWithPrice);
        this.orderInfoParams.put("city_id", 1);
        this.orderInfoParams.put("price", 51);
        this.orderInfo.add(0, this.orderInfoParams);
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 10);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", 10);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", 0);
        this.payInfoParam.put("coupon_fee",0.00);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("icard_fee", 5.00);
        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_info", this.orderInfo);
        this.queryParams.put("pay_type", 2);//现金支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 2);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + this.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("type"));//当用户支付为0的时候，支付类型记为1
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "56.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,channel,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeDetailInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 5.00, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",1,queryPfChargeDetailInfo.getInt("channel"));
        Assert.assertEquals("返回值不符合预期","56.00", queryPfChargeDetailInfo.getString("pay_fee"));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 612 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double cloth01_icard_fee = Double.parseDouble(String.format("%.2f", 12.00 / 61.00 * 5.00));
        Assert.assertEquals("返回值不符合预期", cloth01_icard_fee , queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double cloth01_third_fee = Double.parseDouble(String.format("%.2f", 12.00 - cloth01_icard_fee));
        Assert.assertEquals("返回值不符合预期", cloth01_third_fee , queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 611 + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("ecard_status"));
        double cloth02_icard_fee = Double.parseDouble(String.format("%.2f", 39.00 / 61.00 * 5.00));
        Assert.assertEquals("返回值不符合预期", cloth02_icard_fee , queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("icard_status"));
        double cloth02_third_fee = Double.parseDouble(String.format("%.2f", 39.00 - cloth02_icard_fee));
        Assert.assertEquals("返回值不符合预期", cloth02_third_fee , queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        //验证vouchers表中的Icard中合并订单日志记录正确
        String queryVouchersIcard = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id + "";
        ResultSet queryVouchersIcard01Info = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-2.00", queryVouchersIcard01Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-5.00", queryVouchersIcard01Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersIcard01Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersIcard01Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouchersIcard01Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouchersIcard01Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("pf_charge_id"));


        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + this.fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "wechat", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 56.0, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo.getString("operation"));


    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户仅仅使用余额支付
     *
     * 订单info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     *   $total_fee = 10.00;
     * 支付info:
     *   $card_coin = 5.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */

    public void testOldVersionPayOnlyByIcard() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 10.00;
        // 订单01的信息
        double order_fee = 51.00;
        double order_transfer_fee = 10.00;
        double order_cloth_01 = 39.00;
        double order_cloth_02 = 12.00;
        double coupon_fee_order01 = 0.00;
        double ecard_fee = 0.00;

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order_fee), "0", this.fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 61.00;//还有多少钱
        double card_money = 70.00;//花了多少假钱
        double card_zhenqian = 40.00;//花的钱里面有多少是真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, this.fan_id, card_zhenqian);

        this.queryParams.put("user_id", this.fan_id);
        this.clothWithPrice0001.put("id", 611);
        this.clothWithPrice0001.put("num", 1);
        this.clothWithPrice0001.put("price", order_cloth_01);
        this.clothWithPrice0001.put("clothes_id", 39);
        this.clothWithPrice0001.put("clothes_name", "羽绒服");
        this.clothWithPrice0002.put("id", 612);
        this.clothWithPrice0002.put("num", 1);
        this.clothWithPrice0002.put("price", order_cloth_02);
        this.clothWithPrice0002.put("clothes_id", 46);
        this.clothWithPrice0002.put("clothes_name", "短裤");
        this.clothWithPrice.add(0, clothWithPrice0001);
        this.clothWithPrice.add(1, clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn", CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id", 1);
        this.orderInfoParams.put("cloth_with_price", this.clothWithPrice);
        this.orderInfoParams.put("city_id", 1);
        this.orderInfoParams.put("price", order_fee);
        this.orderInfo.add(0, this.orderInfoParams);
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", order_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", total_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", "");
        this.payInfoParam.put("coupon_fee",0.00);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("icard_fee", 61.00);
        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_info", this.orderInfo);
        this.queryParams.put("pay_type", 1);//电子会员卡支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + this.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("type"));//当用户支付为0的时候，支付类型记为1
        Assert.assertEquals("返回值不符合预期", this.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,channel,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeDetailInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 61.00, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",1,queryPfChargeDetailInfo.getInt("channel"));
        Assert.assertEquals("返回值不符合预期","0.00", queryPfChargeDetailInfo.getString("pay_fee"));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 612 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 12.00 , queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_order_id = " + 611 + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 39.00 , queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("third_status"));

        //验证vouchers表中的Icard中合并订单日志记录正确
        String queryVouchersIcard = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id + "";
        ResultSet queryVouchersIcard01Info = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-40.00", queryVouchersIcard01Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-61.00", queryVouchersIcard01Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersIcard01Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersIcard01Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouchersIcard01Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouchersIcard01Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersIcard01Info.getInt("pf_charge_id"));


    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户仅仅使用余额支付
     *
     * 订单info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     *   $total_fee = 10.00;
     * 支付info:
     *   $card_coin = 5.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */

    public void testOldVersionPayOnlyByIcardButCallTwo() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 10.00;
        // 订单01的信息
        double order_fee = 51.00;
        double order_transfer_fee = 10.00;
        double order_cloth_01 = 39.00;
        double order_cloth_02 = 12.00;
        double coupon_fee_order01 = 0.00;
        double ecard_fee = 0.00;

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order_fee), "0", this.fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 140.00;//还有多少钱
        double card_money = 80.00;//花了多少假钱
        double card_zhenqian = 40.00;//花的钱里面有多少是真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, this.fan_id, card_zhenqian);

        this.queryParams.put("user_id", this.fan_id);
        this.clothWithPrice0001.put("id", 611);
        this.clothWithPrice0001.put("num", 1);
        this.clothWithPrice0001.put("price", order_cloth_01);
        this.clothWithPrice0001.put("clothes_id", 39);
        this.clothWithPrice0001.put("clothes_name", "羽绒服");
        this.clothWithPrice0002.put("id", 612);
        this.clothWithPrice0002.put("num", 1);
        this.clothWithPrice0002.put("price", order_cloth_02);
        this.clothWithPrice0002.put("clothes_id", 46);
        this.clothWithPrice0002.put("clothes_name", "短裤");
        this.clothWithPrice.add(0, clothWithPrice0001);
        this.clothWithPrice.add(1, clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn", CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id", 1);
        this.orderInfoParams.put("cloth_with_price", this.clothWithPrice);
        this.orderInfoParams.put("city_id", 1);
        this.orderInfoParams.put("price", order_fee);
        this.orderInfo.add(0, this.orderInfoParams);
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", order_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", 10.00);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", "");
        this.payInfoParam.put("coupon_fee",0.00);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("icard_fee",61.00);
        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_info", this.orderInfo);
        this.queryParams.put("pay_type", 1);//电子会员卡支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 7);
        this.queryParams.put("version",1);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        // 调用接口
        JSONObject result01 = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result01.toJSONString());
        Assert.assertTrue(result01.getString("httpStatus").equals("200"));
        JSONObject retBody01 = JSON.parseObject(result01.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody01.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "请勿重复支付", URLDecoder.decode(retBody01.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "0009", retBody01.getString("resp_code"));

    }



}
