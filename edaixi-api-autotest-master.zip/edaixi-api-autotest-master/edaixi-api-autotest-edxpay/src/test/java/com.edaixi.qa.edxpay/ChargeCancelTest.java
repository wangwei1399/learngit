package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.management.Descriptor;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 取消支付接口
 * Created by ningzhao on 16-5-17
 */
public class ChargeCancelTest {

    private static Logger logger = LoggerFactory
            .getLogger(ChargeCancelTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> PfChargeParams = null;
    private Map<String, Object> fanParams = null;
    private Map<String, Object> imsPaylog = null;
    private Map<String, Object> pfOrderDetail = null;
    private Map<String, Object> vouchersParams = null;
    public int fan_id = 0;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.PfChargeParams = new HashMap<String, Object>();
        this.fanParams = new HashMap<String, Object>();
        this.imsPaylog = new HashMap<String, Object>();
        this.pfOrderDetail = new HashMap<String, Object>();
        this.vouchersParams = new HashMap<String, Object>();
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        this.fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", this.fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    public void createPfChargeData(int pf_charge_id, int type, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int user_type,int paylog_id) {
        PfChargeParams.put("id", pf_charge_id);
        PfChargeParams.put("fan_id", this.fan_id);
        PfChargeParams.put("type", type);
        PfChargeParams.put("status", status);
        PfChargeParams.put("fee", fee);
        PfChargeParams.put("coupon_fee", coupon_fee);
        PfChargeParams.put("ecard_fee", ecard_fee);
        PfChargeParams.put("icard_fee", icard_fee);
        PfChargeParams.put("transfer_fee", transfer_fee);
        PfChargeParams.put("pay_fee", pay_fee);
        PfChargeParams.put("user_type", user_type);
        PfChargeParams.put("paylog_id",paylog_id);
        generalRongChain04Data.GeneralPfCharge(PfChargeParams);
    };

    public void createPfChargeDetailData(int pf_charge_detail_id, int business_order, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int charge_id) {
        PfChargeParams.put("id", pf_charge_detail_id);
        PfChargeParams.put("business_order", business_order);
        PfChargeParams.put("fan_id", this.fan_id);
        PfChargeParams.put("status", status);
        PfChargeParams.put("fee", fee);
        PfChargeParams.put("coupon_fee", coupon_fee);
        PfChargeParams.put("ecard_fee", ecard_fee);
        PfChargeParams.put("icard_fee", icard_fee);
        PfChargeParams.put("transfer_fee", transfer_fee);
        PfChargeParams.put("pay_fee", pay_fee);
        PfChargeParams.put("charge_id", charge_id);
        generalRongChain04Data.GeneralPfDetailCharge(PfChargeParams);
    };

    public void createImsPaylogData(int plid,String type,double fee,int status,int fan_id,int tid){
        imsPaylog.put("plid",plid);
        imsPaylog.put("type",type);
        imsPaylog.put("fee",fee);
        imsPaylog.put("status",status);
        imsPaylog.put("fan_id",fan_id);
        imsPaylog.put("tid",tid);
        generalRongChain04Data.GeneralImsPaylog(imsPaylog);
    }

    public void createPfOrderDetail(int id,int order_id,int cloth_id,int cloth_order_id,String cloth_name,double fee,double coupon_fee,double ecard_fee,double icard_fee,double third_fee){
        pfOrderDetail.put("id",id);
        pfOrderDetail.put("order_id",order_id);
        pfOrderDetail.put("cloth_id",cloth_id);
        pfOrderDetail.put("cloth_order_id",cloth_order_id);
        pfOrderDetail.put("cloth_name",cloth_name);
        pfOrderDetail.put("fee",fee);
        pfOrderDetail.put("coupon_fee",coupon_fee);
        pfOrderDetail.put("ecard_fee",ecard_fee);
        pfOrderDetail.put("icard_fee",icard_fee);
        pfOrderDetail.put("third_fee",third_fee);
        generalRongChain04Data.GeneralPfOrderDetail(pfOrderDetail);

    }

    public void createVouchers(int id,int direction,double zhenqian,double jiaqian,int voucherable_id,String voucherable_type,int card_id,String card_type,int combine_type,int combine_vouchers_id,int pf_charge_id){
        vouchersParams.put("id",id);
        vouchersParams.put("direction",direction);
        vouchersParams.put("zhenqian",zhenqian);
        vouchersParams.put("jiaqian",jiaqian);
        vouchersParams.put("voucherable_id",voucherable_id);
        vouchersParams.put("voucherable_type", voucherable_type);
        vouchersParams.put("card_id",card_id);
        vouchersParams.put("card_type",card_type);
        vouchersParams.put("combine_type",combine_type);
        vouchersParams.put("combine_vouchers_id",combine_vouchers_id);
        vouchersParams.put("pf_charge_id",pf_charge_id);
        generalRongChain04Data.GeneralVouchers(vouchersParams);
    }



    @Test

    public void testCancelPayByThird()throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        PlatformIndexTest platformIndexTest = new PlatformIndexTest();
        platformIndexTest.setUp();
        platformIndexTest.testPlatformIndex();

        String queryPfChargeDetail = "select business_order,fan_id,charge_id from pf_charge_detail where fan_id = " + platformIndexTest.fan_id + " order by business_order desc limit 1";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        int order01_id = queryPfChargeDetailInfo.getInt("business_order");
        int order02_id = queryPfChargeDetailInfo.getInt("business_order");

        int pf_charge_id = queryPfChargeDetailInfo.getInt("charge_id");

        this.queryParams.put("user_id", platformIndexTest.fan_id);
        this.queryParams.put("order_id",order01_id);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallChargeCancel(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        // 验证支付相关表中的订单状态变为4（取消订单）
        String queryPfchargeStatus = "select status from pf_charge where id = " + pf_charge_id + "";
        ResultSet pf_charge_status = mysqlQaDao.execQuerySql(queryPfchargeStatus);
        Assert.assertEquals("返回值不符合预期", 4 , pf_charge_status.getInt("status"));

        String queryPfchargeDetailOrder01Stauts = "select status from pf_charge_detail where business_order = " + order01_id + "";
        ResultSet order01_status = mysqlQaDao.execQuerySql(queryPfchargeDetailOrder01Stauts);
        Assert.assertEquals("返回值不符合预期",4 ,order01_status.getInt("status"));

        String queryPfchargeDetailOrder02Stauts = "select status from pf_charge_detail where business_order = " + order02_id + "";
        ResultSet order02_status = mysqlQaDao.execQuerySql(queryPfchargeDetailOrder02Stauts);
        Assert.assertEquals("返回值不符合预期",4 ,order02_status.getInt("status"));
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户支付时使用优惠券，满40减10，支付一个订单的金额
     *   when: 支付失败
     *   where: 老版本
     *   how: 优惠券解绑
     *   then: 解绑成功
     */
    public void testChargeCancelByCouponForOldVersion() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        // 模拟订单表的数据-订单金额540，运费为0
        String order_total_price_01 = "51.00";
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery,mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, order_total_price_01, "0", this.fan_id);

        // 模拟ims_paylog表支付中的数据
        String queryImsPaylog = "select plid from ims_paylog order by plid desc limit 1";
        int ims_paylog_id = mysqlQaDao.execQuerySql(queryImsPaylog).getInt("plid") + 1;
        String ims_paylog_type = "CASH";
        double ims_paylog_fee = 51.00;
        int ims_paylog_status = 1;
        int ims_paylog_tid = CommonTools.getRandomInt(9);
        this.createImsPaylogData(ims_paylog_id,ims_paylog_type,ims_paylog_fee,ims_paylog_status,this.fan_id,ims_paylog_tid);

        // 模拟pf_charge表支付中的数据
        String queryPfChargeId = "select id from pf_charge order by id desc limit 1";
        int pf_charge_id = CommonTools.getLastId(queryPfChargeId, this.mysqlQaDao) + 1;
        // type 是支持的支付方式，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int type = 2;
        double fee = 61.00;
        double coupon_fee = 10.00;
        double ecard_fee = 0.00;
        double icard_fee = 0.00;
        double transfer_fee = 10.00;
        double pay_fee = 51.00;
        int status = 1;
        int user_type = 3;
        this.createPfChargeData(pf_charge_id, type, fee, coupon_fee, ecard_fee, icard_fee, transfer_fee, pay_fee, status, user_type,ims_paylog_id);

        // 模拟pf_charge_detail中的第二条数据
        String queryPfDetailChargeId = "select id from pf_charge_detail order by id desc limit 1";
        int pf_charge_detail_id_02 = CommonTools.getLastId(queryPfDetailChargeId, this.mysqlQaDao) + 1;
        double charge_detail_fee_02 = 61.00;
        double charge_detail_coupon_fee_02 = 10.00;
        double charge_detail_ecard_fee_02 = 0.00;
        double charge_detail_icard_fee_02 = 0.00;
        double charge_detail_transfer_fee_02 = 0.00;
        double charge_detail_pay_fee_02 = 51.00;
        int charge_detail_status_02 = 1;
        this.createPfChargeDetailData(pf_charge_detail_id_02, order_id, charge_detail_fee_02, charge_detail_coupon_fee_02, charge_detail_ecard_fee_02, charge_detail_icard_fee_02, charge_detail_transfer_fee_02, charge_detail_pay_fee_02, charge_detail_status_02, pf_charge_id);

        // 模拟pf_order_detail中的数据
        String queryPfOrderDetailId = "select id from pf_order_detail order by id desc limit 1";
        int pf_order_detail_id_02 = CommonTools.getLastId(queryPfOrderDetailId, this.mysqlQaDao) + 1;
        int pf_order_cloth_order_id_01 = CommonTools.getRandomInt(3);
        double pf_order_detail_fee_02 = 12.00;
        double pf_order_detail_coupon_fee_02 = 2.35;
        double pf_order_detail_ecard_fee_02 = 0.00;
        double pf_order_detail_icard_fee_02 = 0.80;
        double pf_order_detail_third_fee_02 = 9.65;
        this.createPfOrderDetail(pf_order_detail_id_02,order_id,46,pf_order_cloth_order_id_01+1,"短裤",pf_order_detail_fee_02,pf_order_detail_coupon_fee_02,pf_order_detail_ecard_fee_02,pf_order_detail_icard_fee_02,pf_order_detail_third_fee_02);

        int pf_order_detail_id_03 = CommonTools.getLastId(queryPfOrderDetailId, this.mysqlQaDao) + 1;
        double pf_order_detail_fee_03 = 39.00;
        double pf_order_detail_coupon_fee_03 = 7.65;
        double pf_order_detail_ecard_fee_03 = 0.00;
        double pf_order_detail_icard_fee_03 = 2.59;
        double pf_order_detail_third_fee_03 = 31.35;
        this.createPfOrderDetail(pf_order_detail_id_03,order_id,39,pf_order_cloth_order_id_01+2,"羽绒服",pf_order_detail_fee_03,pf_order_detail_coupon_fee_03,pf_order_detail_ecard_fee_03,pf_order_detail_icard_fee_03,pf_order_detail_third_fee_03);

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int discount_type = 1;
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "10.00";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "NULL";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 40; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id,discount_type, coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        String queryCouponSncodeId = "select id from ims_icoupon_sncode order by id desc limit 1";
        int coupon_sncode_id = CommonTools.getLastId(queryCouponSncodeId, this.mysqlQaDao) + 1 ;
        int coupon_used =1;
        edxpayModuleService.createCouponSncdeData(coupon_sncode_id,icoupon_id,sncode,this.fan_id,coupon_used,pf_charge_id);

        this.queryParams.put("user_id", this.fan_id);
        this.queryParams.put("order_id",order_id);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallChargeCancel(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        String queryIcouponSncodeInfo = "select charge_id,used,usetime,order_sn,fan_id from ims_icoupon_sncode where id = " + coupon_sncode_id + "";
        ResultSet queryicouponSncodeRet = mysqlQaDao.execQuerySql(queryIcouponSncodeInfo);
        Assert.assertTrue("返回值不符合预期", queryicouponSncodeRet.getString("charge_id").isEmpty());
        Assert.assertEquals("返回值不符合预期",0,queryicouponSncodeRet.getInt("used"));
        Assert.assertEquals("返回值不符合预期",0,queryicouponSncodeRet.getInt("usetime"));
        Assert.assertEquals("返回值不符合预期",0,queryicouponSncodeRet.getInt("order_sn"));
        Assert.assertEquals("返回值不符合预期",this.fan_id,queryicouponSncodeRet.getInt("fan_id"));

        String queryPfChargeInfo = "select status from pf_charge where  id = " + pf_charge_id + "";
        ResultSet queryPfChargeRet = mysqlQaDao.execQuerySql(queryPfChargeInfo);
        Assert.assertEquals("返回值不符合预期",4,queryPfChargeRet.getInt("status"));// 4是取消支付

        String queryPfChargeDetailInfo = "select status from pf_charge_detail where  business_order = " + order_id + "";
        ResultSet queryPfChargeDetailRet = mysqlQaDao.execQuerySql(queryPfChargeDetailInfo);
        Assert.assertEquals("返回值不符合预期",4,queryPfChargeDetailRet.getInt("status"));

        String queryPfOrderDetailInfo = "select coupon_status,ecard_status,icard_status,third_status from pf_order_detail where  order_id = " + order_id + "";
        ResultSet queryPforderDetailRet = mysqlQaDao.execQuerySql(queryPfOrderDetailInfo);
        Assert.assertEquals("返回值不符合预期",4,queryPforderDetailRet.getInt("coupon_status"));
        Assert.assertEquals("返回值不符合预期",4,queryPforderDetailRet.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期",4,queryPforderDetailRet.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期",4,queryPforderDetailRet.getInt("third_status"));


    }

}