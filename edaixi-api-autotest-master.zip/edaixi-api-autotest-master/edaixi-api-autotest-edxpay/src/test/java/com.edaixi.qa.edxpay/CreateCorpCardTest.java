package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by ningzhao on 16/6/13.
 */
public class CreateCorpCardTest {
    private static Logger logger = LoggerFactory.getLogger(PlatformCallBackTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    private JSONObject rechargeParams = new JSONObject();
    private JSONObject rechargeSn01Params = new JSONObject();
    private JSONObject fanParams = new JSONObject();
    private JSONObject ecardLimitParams = new JSONObject();
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }

    @Test

    public void testCreateCorpCard() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id",recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info,mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id",fan_id);
        fanParams.put("mobile",mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        this.queryParams.put("user_id",fan_id);
        this.queryParams.put("corp_id",11);
        this.queryParams.put("welfare_id",CommonTools.getRandomInt(5));
        this.queryParams.put("rid",recharge_id);
        this.queryParams.put("jiaqian",80);
        this.queryParams.put("zhenqian",60);
        this.queryParams.put("use_begin_time",CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",-1));
        this.queryParams.put("use_end_time",CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss",10));

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallCreateCorpCard(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","0000",retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期","succ",retBody.getString("resp_msg"));

        String query_recharge_sncode_info = "select ";




    }
}
