package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 回调接口的测试
 * Created by ningzhao on 16-5-17
 */
public class PlatformContinuePayTest {

    private static Logger logger = LoggerFactory
            .getLogger(PlatformContinuePayTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");

    }


    @Test

    public void testContinuePay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        PlatformIndexTest platformIndexTest = new PlatformIndexTest();
        platformIndexTest.setUp();
        platformIndexTest.testPlatformIndex();
        String couponPrice = "12.00";//优惠券的金额
        Double charge_price = 12.00;

        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + platformIndexTest.fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");

        logger.info(platformIndexTest.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(platformIndexTest.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");


        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 44.00, retBody.getJSONObject("data").getDouble("total"));

        this.queryParams.put("plid",paylog_id);
        logger.info(this.queryParams.toString());
        String buildString01 = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result01 = this.edxpayModuleService.CallPlatformCallBack(buildString01, this.httpHead);
        logger.info(result01.toJSONString());
        Assert.assertTrue(result01.getString("httpStatus").equals("200"));
        JSONObject retBody01 = JSON.parseObject(result01.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody01.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","0000",retBody01.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期","succ",retBody01.getString("resp_msg"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + platformIndexTest.fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", platformIndexTest.fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", couponPrice, queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", charge_price, queryPfChargeInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "44.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where fan_id = " + platformIndexTest.fan_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySqlAllRet(queryPfChargeDetail);

    }


}