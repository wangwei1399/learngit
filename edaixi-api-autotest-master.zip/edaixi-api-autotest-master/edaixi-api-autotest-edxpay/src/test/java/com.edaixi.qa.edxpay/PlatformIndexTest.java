package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 第三方支付下单接口
 * Created by ningzhao on 16-4-18.
 */
public class PlatformIndexTest {

    public static Logger logger = LoggerFactory
            .getLogger(PlatformIndexTest.class);
    public EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    public GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();

    public Map<String, Object> orderClothesListsParams01 = null;
    public Map<String, Object> orderClothesListsParams02 = null;
    public Map<String, Object> orderClothesListsParams03 = null;

    public Map<String, Object> queryParams = null;
    public Map<String, Object> subFeeParam01 = null;
    public Map<String, Object> subFeeParam02 = null;
    public Map<String, Object> deliveryParam = null;
    public Map<String, Object> payInfoParam = null;
    public Map<String, Object> ecardLimitParams = null;
    public Map<String, Object> orderInfoParams = null;
    public Map<String, Object> orderInfoParams01 = null;
    public JSONObject OrderParams = new JSONObject();
    public JSONObject fanParams = new JSONObject();
    public JSONArray subFee = new JSONArray();
    public JSONArray ecard = new JSONArray();
    public JSONArray orderIds = new JSONArray();
    public Map<String, Object> httpHead = null;

    public int fan_id = 0;
    public int icoupon_id = 0;
    public int icoupon_sncode_id = 0;
    public int recharge_id = 0;
    public int recharge_sncode_id = 0;
    public int recharge_sncode_id_01 = 0;

    public int icard_card_id = 0;

    MysqlQaDao mysqlQaDao = new MysqlQaDao();


    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.orderClothesListsParams01 = new HashMap<String, Object>();
        this.orderClothesListsParams02 = new HashMap<String, Object>();
        this.orderClothesListsParams03 = new HashMap<String, Object>();

        this.subFeeParam01 = new HashMap<String, Object>();
        this.subFeeParam02 = new HashMap<String, Object>();
        this.deliveryParam = new HashMap<String, Object>();
        this.payInfoParam = new HashMap<String, Object>();
        this.ecardLimitParams = new HashMap<String, Object>();
        String fan_info = "select id from ims_fans order by id desc limit 1";
        fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);
    }

    // 模拟ims_fan表数据


    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");

    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用余额支付，满0减60的优惠券
     *
     * 订单01info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     * 订单02info:
     *   $order_fee = 22;订单金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     * 合单info:
     *   $total_fee = 73.00;
     *
     * 支付info:
     *   $card_coin = 73.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */
    public void testPayByIcardOnly() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 73.00;
        double total_transfer_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;

        double couponPrice = 0.00;

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 73.00;//还有多少钱
        double card_money = 80.00;//花了多少假钱
        double card_zhenqian = 60.00;//余额的钱里面有多少真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, fan_id, card_zhenqian);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额10，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);

        //接口调用参数
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_transfer_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 1);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 1);// 电子会员卡支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("type"));// 电子会员卡支付
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", total_fee, queryPfChargeInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", card_coin, queryPfChargeInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", total_transfer_fee, queryPfChargeInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("pay_fee"));

        queryPfChargeInfo.close();
        queryPfChargeInfo = null;

        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", order01_fee, queryPfChargeDetailInfo.getDouble("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", order01_fee / (order01_fee + order02_fee) * couponPrice));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", order02_fee/(order01_fee+order02_fee) * couponPrice));
        Double temp_total_fee = order01_fee - coupon_fee_order01 + order02_fee - coupon_fee_order02;
        Double temp_order01_fee = order01_fee - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * card_coin));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (order01_fee - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        queryPfChargeDetailInfo.close();
        queryPfChargeDetailInfo = null;

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * card_coin));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        queryPfChargeDetailInfo01.close();
        queryPfChargeDetailInfo01 = null;

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_02, queryPfOrderDetail02Info.getDouble("fee"));
        double  order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", order01_cloth_02/(order01_cloth_01 + order01_cloth_02) * coupon_fee_order01));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_02, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail02Info.getInt("third_status"));

        queryPfOrderDetail02Info.close();
        queryPfOrderDetail02Info = null;

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f",coupon_fee_order01 - order01_cloth02_coupon_fee));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01, queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail01Info.getInt("third_status"));

        queryPfOrderDetail01Info.close();
        queryPfOrderDetail01Info = null;

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order02_cloth_01, queryPfOrderDetail03Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail03Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", order02_cloth_01, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail03Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfOrderDetail03Info.getInt("third_status"));

        queryPfOrderDetail03Info.close();
        queryPfOrderDetail03Info = null;
    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario: 用户使用优惠券、余额、一张E卡、第三方支付支付订单；
     *   when:优惠券支持合并订单中的所有订单
     *   then:pf_charge,pf_charge_detail,vouchers,ims_icoupon_sncode,ims_recharge_sncode,ims_paylog,paylog_details,ims_icard_card
     */
    public void testPlatformIndex() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 73.00;
        double total_transfer_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "12.00";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "39,46";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 5; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, fan_id, 0, 0);

        // 模拟ims_recharge数据－用户支付的时候选择E卡
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        Double chargePrice = 12.00;
        String zhenqian = "10.00";
        int usednum = 0;
        int kind = 2;
        int validity_type = 0;
        int charge_validity_type = 0;
        edxpayModuleService.createChargeData(recharge_id, chargePrice, usednum, zhenqian, kind, validity_type, charge_validity_type);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        recharge_sncode_id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        int charge_user_type = 3;
        int charge_card_type = 1;
        Double charge_price = 12.00;
        int used = 0;
        edxpayModuleService.createChargeSncodeData(recharge_sncode_id, recharge_id, sncode, charge_user_type, charge_card_type, charge_price, zhenqian, used, fan_id);

        // 模拟ims_ecard_limit的数据
        int ecard_limit_category_id = 0;
        edxpayModuleService.createEcardLimitData(recharge_id, ecard_limit_category_id, fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 5.00;//还有多少钱
        double card_money = 10.00;//花了多少假钱
        double card_zhenqian = 3.00;//余额的钱里面有多少真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, fan_id, card_zhenqian);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额12，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);
        //接口调用参数
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_transfer_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("ecard_ids", this.ecard);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 2);// 微信支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 44, retBody.getJSONObject("data").getIntValue("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", couponPrice, queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", charge_price, queryPfChargeInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "44.00", queryPfChargeInfo.getString("pay_fee"));

        queryPfChargeInfo.close();
        queryPfChargeInfo = null;

        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "51.00", queryPfChargeDetailInfo.getString("fee"));
        logger.info(String.valueOf(51.00 * 12.00 / 63.00));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", 51.00 * 12.00 / 63.00)) + 0.01;
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", 12.00 * 12.00 / 63.00 - 0.01));
        Double temp_total_fee = 51.00 - coupon_fee_order01 + 12.00 - coupon_fee_order02 + 10.00;
        Double temp_order01_fee = 51.00 - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 12.00));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 5.00));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (51.00 - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        queryPfChargeDetailInfo.close();
        queryPfChargeDetailInfo = null;

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 12));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 5));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        queryPfChargeDetailInfo01.close();
        queryPfChargeDetailInfo01 = null;

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        queryCouponInfo.close();
        queryCouponInfo = null;

        //验证ecard表的记录被更新
        String queryEcard = "select rid,sncode,card_type,price,zhenqian,user_type from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryEcardInfo = mysqlQaDao.execQuerySql(queryEcard);
        Assert.assertEquals("返回值不符合预期", this.recharge_id, queryEcardInfo.getInt("rid"));
        Assert.assertEquals("返回值不符合预期", sncode, queryEcardInfo.getString("sncode"));
        Assert.assertEquals("返回值不符合预期", 1, queryEcardInfo.getInt("card_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo.getString("price"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo.getString("zhenqian"));

        queryEcardInfo.close();
        queryEcardInfo = null;

        // 验证ims_icard_card表中数据正确
        String queryIcardCard = "select id,cardno,coin,fan_id,zhenqian,rcard_sn from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryIcardCardInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("zhenqian"));

        //验证vouchers表中的Icard日志记录正确
        String queryVouchersIcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id + "";
        ResultSet queryVouthersIcardInfo = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期", 0, queryVouthersIcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -Double.parseDouble(String.format("%.2f", 3.00 / 5.00 * icard_fee)), queryVouthersIcardInfo.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -icard_fee, queryVouthersIcardInfo.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouthersIcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouthersIcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouthersIcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouthersIcardInfo.getString("card_type"));

        queryVouthersIcardInfo.close();
        queryVouthersIcardInfo = null;

        //验证vouchers表中的Icard日志记录正确
        String queryVouchersIcard01 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id_01 + "";
        ResultSet queryVouthersIcardInfo01 = mysqlQaDao.execQuerySql(queryVouchersIcard01);
        Assert.assertEquals("返回值不符合预期", 0, queryVouthersIcardInfo01.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -Double.parseDouble(String.format("%.2f",3.00/5.00*icard_fee_order02)), queryVouthersIcardInfo01.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -icard_fee_order02, queryVouthersIcardInfo01.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryVouthersIcardInfo01.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouthersIcardInfo01.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouthersIcardInfo01.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouthersIcardInfo01.getString("card_type"));

        queryVouthersIcardInfo01.close();
        queryVouthersIcardInfo01 = null;

        //验证vouchers表中的Ecard中合并订单日志记录正确
        String queryVouchersEcard01 = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + recharge_sncode_id + " and voucherable_id = " + pf_charge_id + "";
        ResultSet queryVouchersEcard01Info = mysqlQaDao.execQuerySql(queryVouchersEcard01);
        int combine_vouchers_id = queryVouchersEcard01Info.getInt("id");
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard01Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-10.00", queryVouchersEcard01Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-12.00", queryVouchersEcard01Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard01Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "CombineOrder", queryVouchersEcard01Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id, queryVouchersEcard01Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard01Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 2, queryVouchersEcard01Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersEcard01Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard01Info.getInt("pf_charge_id"));

        queryVouchersEcard01Info.close();
        queryVouchersEcard01Info = null;

        //验证vouchers表中的Ecard中订单1日志记录正确
        String queryVouchersEcard02 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where voucherable_id = " + order_id + " and card_type = 'Ecard'";
        ResultSet queryVouchersEcard02Info = mysqlQaDao.execQuerySql(queryVouchersEcard02);
        Double ecard_fee_order01_zhenqian = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 10));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard02Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -ecard_fee_order01_zhenqian, queryVouchersEcard02Info.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -ecard_fee, queryVouchersEcard02Info.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersEcard02Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersEcard02Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id, queryVouchersEcard02Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard02Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard02Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", combine_vouchers_id, queryVouchersEcard02Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard02Info.getInt("pf_charge_id"));

        queryVouchersEcard02Info.close();
        queryVouchersEcard02Info = null;

        //验证vouchers表中的Ecard相关日志记录正确
        String queryVouchersEcard03 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where voucherable_id = " + order_id_01 + " and card_type = 'Ecard'";
        ResultSet queryVouchersEcard03Info = mysqlQaDao.execQuerySql(queryVouchersEcard03);
        Double ecard_fee_order02_zhenqian = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 10));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard03Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -ecard_fee_order02_zhenqian, queryVouchersEcard03Info.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -ecard_fee_order02, queryVouchersEcard03Info.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryVouchersEcard03Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersEcard03Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id, queryVouchersEcard03Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard03Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard03Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", combine_vouchers_id, queryVouchersEcard03Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard03Info.getInt("pf_charge_id"));

        queryVouchersEcard03Info.close();
        queryVouchersEcard03Info = null;

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "wechat", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 44.00, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        queryImsPaylogInfo.close();
        queryImsPaylogInfo = null;

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        double order01_cloth01_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_ecard_fee, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth01_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_icard_fee, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth01_third_fee = Double.parseDouble(String.format("%.1f", (12.00 - order01_cloth01_coupon_fee - order01_cloth01_ecard_fee - order01_cloth01_icard_fee )));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_third_fee + 0.01, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));



        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 / 63.00 * 12.00));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_coupon_fee - queryPfOrderDetail01Info.getDouble("coupon_fee")) <= 0.01);
        double order01_cloth02_ecard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_ecard_fee, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth02_icard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_icard_fee - queryPfOrderDetail01Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth02_third_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee - order01_cloth02_ecard_fee - order01_cloth02_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_third_fee - 0.02, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        queryPfOrderDetail02Info.close();
        queryPfOrderDetail02Info = null;
        queryPfOrderDetail01Info.close();
        queryPfOrderDetail01Info = null;

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail03Info.getDouble("fee"));
        Double order02_cloth_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order02_cloth_coupon_fee, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        double order02_cloth_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * ecard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_ecard_fee, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("ecard_status"));
        double order02_cloth_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * icard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_icard_fee, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("icard_status"));
        double order02_cloth_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee - order02_cloth_ecard_fee - order02_cloth_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_third_fee, queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("third_status"));

        queryPfOrderDetail03Info.close();
        queryPfOrderDetail03Info = null;

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo.getString("operation"));

        queryPaylogDetailsInfo.close();
        queryPaylogDetailsInfo = null;

        String queryPaylogDetails01 = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id_01 + "";
        ResultSet queryPaylogDetailsInfo01 = mysqlQaDao.execQuerySql(queryPaylogDetails01);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo01.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPaylogDetailsInfo01.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo01.getString("operation"));

        queryPaylogDetailsInfo01.close();
        queryPaylogDetailsInfo01 = null;

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario: 用户使用优惠券、余额、两张E卡、第三方支付支付订单；
     *   when:优惠券支持合并订单中的所有订单
     *   then:pf_charge,pf_charge_detail,vouchers,ims_icoupon_sncode,ims_recharge_sncode,ims_paylog,paylog_details,ims_icard_card
     */
    public void testPlatformIndexByTwoEcard() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 73.00;
        double total_transfer_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;
        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "12.00";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "39,46";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 5; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, fan_id, 0, 0);

        // 模拟ims_recharge数据－用户支付的时候选择E卡
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        Double chargePrice = 12.00;
        String zhenqian = "10.00";
        int usednum = 0;
        int kind = 2;
        int validity_type = 0;
        int charge_validity_type = 0;
        edxpayModuleService.createChargeData(recharge_id, chargePrice, usednum, zhenqian, kind, validity_type, charge_validity_type);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        recharge_sncode_id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        int charge_user_type = 3;
        int charge_card_type = 1;
        Double charge_price = 12.00;
        int used = 0;
        edxpayModuleService.createChargeSncodeData(recharge_sncode_id, recharge_id, sncode, charge_user_type, charge_card_type, charge_price, zhenqian, used, fan_id);

        // 模拟第二条ims_recharge_sncode的数据
        recharge_sncode_id_01 = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        Double charge_price_01 = 15.00;
        edxpayModuleService.createChargeSncodeData(recharge_sncode_id_01, recharge_id, sncode +1, charge_user_type, charge_card_type, charge_price_01, zhenqian, used, fan_id);

        // 模拟ims_ecard_limit的数据
        int ecard_limit_category_id = 0;
        edxpayModuleService.createEcardLimitData(recharge_id, ecard_limit_category_id, fan_id);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 5.00;//还有多少钱
        double card_money = 10.00;//花了多少假钱
        double card_zhenqian = 3.00;//余额的钱里面有多少真钱
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, fan_id, card_zhenqian);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额12，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);

        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_transfer_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.ecard.add(1, recharge_sncode_id_01);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 1);
        this.payInfoParam.put("ecard_ids", this.ecard);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 2);// 微信支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 29, retBody.getJSONObject("data").getIntValue("total"));

        Double charge_price_total = Double.parseDouble(String.format("%.2f",charge_price + charge_price_01));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", couponPrice, queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", charge_price_total, queryPfChargeInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "29.00", queryPfChargeInfo.getString("pay_fee"));

        queryPfChargeInfo.close();
        queryPfChargeInfo = null;

        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "51.00", queryPfChargeDetailInfo.getString("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", 51.00 * 12.00 / 63.00 + 0.01));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", 12.00 * 12.00 / 63.00 - 0.01));
        Double temp_total_fee = 51.00 - coupon_fee_order01 + 12.00 - coupon_fee_order02 + 10.00;
        Double temp_order01_fee = 51.00 - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * charge_price_total));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 5));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (51.00 - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        queryPfChargeDetailInfo.close();
        queryPfChargeDetailInfo = null;

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * charge_price_total));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 5));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        queryPfChargeDetailInfo01.close();
        queryPfChargeDetailInfo01 = null;

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        queryCouponInfo.close();
        queryCouponInfo = null;

        //验证ecard表的记录被更新
        String queryEcard = "select rid,sncode,card_type,price,zhenqian,user_type from ims_recharge_sncode where id = " + recharge_sncode_id + "";
        ResultSet queryEcardInfo = mysqlQaDao.execQuerySql(queryEcard);
        Assert.assertEquals("返回值不符合预期", this.recharge_id, queryEcardInfo.getInt("rid"));
        Assert.assertEquals("返回值不符合预期", sncode, queryEcardInfo.getString("sncode"));
        Assert.assertEquals("返回值不符合预期", 1, queryEcardInfo.getInt("card_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo.getString("price"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo.getString("zhenqian"));

        queryEcardInfo.close();
        queryEcardInfo = null;

        String queryEcard01 = "select rid,sncode,card_type,price,zhenqian,user_type from ims_recharge_sncode where id = " + recharge_sncode_id_01 + "";
        ResultSet queryEcardInfo01 = mysqlQaDao.execQuerySql(queryEcard01);
        Assert.assertEquals("返回值不符合预期", this.recharge_id, queryEcardInfo01.getInt("rid"));
        Assert.assertEquals("返回值不符合预期", sncode + 1, queryEcardInfo01.getString("sncode"));
        Assert.assertEquals("返回值不符合预期", 1, queryEcardInfo01.getInt("card_type"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo01.getString("price"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryEcardInfo01.getString("zhenqian"));

        queryEcardInfo01.close();
        queryEcardInfo01 = null;

        // 验证ims_icard_card表中数据正确
        String queryIcardCard = "select id,cardno,coin,fan_id,zhenqian,rcard_sn from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryIcardCardInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("zhenqian"));

        queryIcardCardInfo.close();
        queryIcardCardInfo = null;

        //验证vouchers表中的Icard日志记录正确
        String queryVouchersIcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id + "";
        ResultSet queryVouthersIcardInfo = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期", 0, queryVouthersIcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -Double.parseDouble(String.format("%.2f", 3.00 / 5.00 * icard_fee)), queryVouthersIcardInfo.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -icard_fee, queryVouthersIcardInfo.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouthersIcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouthersIcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouthersIcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouthersIcardInfo.getString("card_type"));

        queryVouthersIcardInfo.close();
        queryVouthersIcardInfo = null;

        //验证vouchers表中的Icard日志记录正确
        String queryVouchersIcard01 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = " + icard_card_id + " and voucherable_id = " + order_id_01 + "";
        ResultSet queryVouthersIcardInfo01 = mysqlQaDao.execQuerySql(queryVouchersIcard01);
        Assert.assertEquals("返回值不符合预期", 0, queryVouthersIcardInfo01.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", -Double.parseDouble(String.format("%.2f",3.00/5.00*icard_fee_order02)), queryVouthersIcardInfo01.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", -icard_fee_order02, queryVouthersIcardInfo01.getDouble("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryVouthersIcardInfo01.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouthersIcardInfo01.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", icard_card_id, queryVouthersIcardInfo01.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Icard", queryVouthersIcardInfo01.getString("card_type"));

        queryVouthersIcardInfo01.close();
        queryVouthersIcardInfo01 = null;

        //验证vouchers表中的Ecard中合并订单日志记录正确
        String queryVouchersEcard01 = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + recharge_sncode_id + " and voucherable_id = " + order_id + " and combine_vouchers_id = 0";
        ResultSet queryVouchersEcard01Info = mysqlQaDao.execQuerySql(queryVouchersEcard01);
        int vouchers_ecard_id_01 = queryVouchersEcard01Info.getInt("id");
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard01Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-10.00", queryVouchersEcard01Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-12.00", queryVouchersEcard01Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersEcard01Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersEcard01Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id, queryVouchersEcard01Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard01Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard01Info.getInt("combine_type"));//0 单个订单,1 单个订单来自合单, 2 合并订单
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersEcard01Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard01Info.getInt("pf_charge_id"));

        queryVouchersEcard01Info.close();
        queryVouchersEcard01Info = null;

        String queryVouchersEcard0203 = "select id,direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where card_id = " + recharge_sncode_id_01 + " and voucherable_id = " + pf_charge_id + "";
        ResultSet queryVouchersEcard04Info = mysqlQaDao.execQuerySql(queryVouchersEcard0203);
        int combine_vouchers_id_0203 = queryVouchersEcard04Info.getInt("id");
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard04Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", "-10.00", queryVouchersEcard04Info.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期", "-15.00", queryVouchersEcard04Info.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard04Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "CombineOrder", queryVouchersEcard04Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id_01, queryVouchersEcard04Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard04Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 2, queryVouchersEcard04Info.getInt("combine_type"));//0 单个订单,1 单个订单来自合单, 2 合并订单
        Assert.assertEquals("返回值不符合预期", 0, queryVouchersEcard04Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard04Info.getInt("pf_charge_id"));

        queryVouchersEcard04Info.close();
        queryVouchersEcard04Info = null;

        //验证vouchers表中的Ecard中订单1日志记录正确
        String queryVouchersEcard02 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where voucherable_id = " + order_id + " and combine_vouchers_id = " + combine_vouchers_id_0203 + "";
        ResultSet queryVouchersEcard02Info = mysqlQaDao.execQuerySql(queryVouchersEcard02);
        Double ecard02_fee_order_jiaqian = Double.parseDouble(String.format("%.2f",-(ecard_fee-charge_price)));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard02Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", ecard02_fee_order_jiaqian, queryVouchersEcard02Info.getDouble("jiaqian"));
        Double ecard02_fee_order_zhenqian = Double.parseDouble(String.format("%.2f",ecard02_fee_order_jiaqian * 10.00/15.00));
        Assert.assertEquals("返回值不符合预期", ecard02_fee_order_zhenqian, queryVouchersEcard02Info.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", order_id, queryVouchersEcard02Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersEcard02Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id_01, queryVouchersEcard02Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard02Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard02Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", combine_vouchers_id_0203, queryVouchersEcard02Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard02Info.getInt("pf_charge_id"));

        queryVouchersEcard02Info.close();
        queryVouchersEcard02Info = null;

        //验证vouchers表中的Ecard相关日志记录正确
        String queryVouchersEcard03 = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type,combine_type,combine_vouchers_id,pf_charge_id from vouchers where voucherable_id = " + order_id_01 + " and combine_vouchers_id = " + combine_vouchers_id_0203 + "";
        ResultSet queryVouchersEcard03Info = mysqlQaDao.execQuerySql(queryVouchersEcard03);
        Double ecard02_fee_order01_jiaqian = Double.parseDouble(String.format("%.2f",-(ecard_fee_order02)));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard03Info.getInt("direction"));
        Assert.assertEquals("返回值不符合预期", ecard02_fee_order01_jiaqian, queryVouchersEcard03Info.getDouble("jiaqian"));
        Double ecard02_fee_order01_zhenqian = Double.parseDouble(String.format("%.2f",ecard02_fee_order01_jiaqian * 10.00/15.00));
        Assert.assertEquals("返回值不符合预期", ecard02_fee_order01_zhenqian, queryVouchersEcard03Info.getDouble("zhenqian"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryVouchersEcard03Info.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期", "Order", queryVouchersEcard03Info.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期", recharge_sncode_id_01, queryVouchersEcard03Info.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期", "Ecard", queryVouchersEcard03Info.getString("card_type"));
        Assert.assertEquals("返回值不符合预期", 1, queryVouchersEcard03Info.getInt("combine_type"));
        Assert.assertEquals("返回值不符合预期", combine_vouchers_id_0203, queryVouchersEcard03Info.getInt("combine_vouchers_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryVouchersEcard03Info.getInt("pf_charge_id"));

        queryVouchersEcard03Info.close();
        queryVouchersEcard03Info = null;

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "wechat", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 29.00, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));


        queryImsPaylogInfo.close();
        queryImsPaylogInfo = null;

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        double order01_cloth01_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_ecard_fee, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth01_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth01_icard_fee - queryPfOrderDetail02Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        Double order01_cloth01_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee - order01_cloth01_ecard_fee - order01_cloth01_icard_fee)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth01_third_fee-queryPfOrderDetail02Info.getDouble("third_fee"))<=0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));



        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 / 63.00 * 12.00));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_coupon_fee - queryPfOrderDetail01Info.getDouble("coupon_fee")) <= 0.01);
        double order01_cloth02_ecard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_ecard_fee, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth02_icard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_icard_fee - queryPfOrderDetail01Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth02_third_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee - order01_cloth02_ecard_fee - order01_cloth02_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_third_fee - 0.02, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        queryPfOrderDetail02Info.close();
        queryPfOrderDetail02Info = null;
        queryPfOrderDetail01Info.close();
        queryPfOrderDetail01Info = null;

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail03Info.getDouble("fee"));
        Double order02_cloth_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order02_cloth_coupon_fee, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        double order02_cloth_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * ecard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_ecard_fee, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("ecard_status"));
        double order02_cloth_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * icard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_icard_fee, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("icard_status"));
        double order02_cloth_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee - order02_cloth_ecard_fee - order02_cloth_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_third_fee, queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("third_status"));

        queryPfOrderDetail03Info.close();
        queryPfOrderDetail03Info = null;

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo.getString("operation"));

        queryPaylogDetailsInfo.close();
        queryPaylogDetailsInfo = null;

        String queryPaylogDetails01 = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id_01 + "";
        ResultSet queryPaylogDetailsInfo01 = mysqlQaDao.execQuerySql(queryPaylogDetails01);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo01.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPaylogDetailsInfo01.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo01.getString("operation"));

        queryPaylogDetailsInfo01.close();
        queryPaylogDetailsInfo01 = null;

    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:用户支付使用优惠券和余额和第三方支付
     *   when:优惠券支持合并订单中的所有订单
     *   where:
     *   how:
     *   then:
     */
    public void testpayByCouponIcardThird() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        String fan_info = "select id from ims_fans order by id desc limit 1";
        double total_fee = 73.00;
        double total_transfer_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;
        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "12.00";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "39,46";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 5; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, fan_id, 0, 0);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        icard_card_id = CommonTools.getLastId(icardCard, mysqlQaDao) + 1;
        double card_coin = 5.00;
        double card_money = 10.00;
        double card_zhenqian = 12.00;
        edxpayModuleService.createCardData(icard_card_id, sncode, card_coin, card_money, fan_id, card_zhenqian);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额12，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);


        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_transfer_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 1);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 2);// 微信支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 56, retBody.getJSONObject("data").getIntValue("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 2, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", couponPrice, queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "5.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "56.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "51.00", queryPfChargeDetailInfo.getString("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", 51.00 * 12.00 / 63.00 + 0.01));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", 12.00 * 12.00 / 63.00 - 0.01));
        Double temp_total_fee = 51.00 - coupon_fee_order01 + 12.00 - coupon_fee_order02 + 10.00;
        Double temp_order01_fee = 51.00 - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 5));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (51.00 - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 5));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        // 验证ims_icard_card表中数据正确
        String queryIcardCard = "select id,cardno,coin,fan_id,zhenqian,rcard_sn from ims_icard_card where id = " + icard_card_id + "";
        ResultSet queryIcardCardInfo = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryIcardCardInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryIcardCardInfo.getString("zhenqian"));

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "wechat", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 56.00, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        double order01_cloth01_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_ecard_fee, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth01_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth01_icard_fee - queryPfOrderDetail02Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth01_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee - order01_cloth01_ecard_fee - order01_cloth01_icard_fee)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth01_third_fee - queryPfOrderDetail02Info.getDouble("third_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 / 63.00 * 12.00));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_coupon_fee - queryPfOrderDetail01Info.getDouble("coupon_fee")) <= 0.01);
        double order01_cloth02_ecard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_ecard_fee, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth02_icard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_icard_fee - queryPfOrderDetail01Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth02_third_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee - order01_cloth02_ecard_fee - order01_cloth02_icard_fee)));
        Assert.assertTrue("返回值不符合预期", (queryPfOrderDetail01Info.getDouble("third_fee") - order01_cloth02_third_fee) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail03Info.getDouble("fee"));
        Double order02_cloth_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order02_cloth_coupon_fee, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        double order02_cloth_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * ecard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_ecard_fee, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("ecard_status"));
        double order02_cloth_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * icard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_icard_fee, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("icard_status"));
        double order02_cloth_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee - order02_cloth_ecard_fee - order02_cloth_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_third_fee, queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("third_status"));

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo.getString("operation"));

        String queryPaylogDetails01 = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id_01 + "";
        ResultSet queryPaylogDetailsInfo01 = mysqlQaDao.execQuerySql(queryPaylogDetails01);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo01.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPaylogDetailsInfo01.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "xiyi", queryPaylogDetailsInfo01.getString("operation"));

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:用户支付使用优惠券和现金
     *   when:优惠券支持合并订单中的所有订单
     *   where:
     *   how:
     *   then:pf_charge,pf_charge_detail,vouchers,ims_icoupon_sncode,ims_recharge_sncode,ims_paylog,paylog_details,ims_icard_card
     */
    public void testPayByCash() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 73.00;
        double total_transfer_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        String couponPrice = "12.00";//优惠券的金额
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "39,46";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 5; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, couponPrice, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, fan_id, 0, 0);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额12，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);

        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_transfer_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 0);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 3);// 现金支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 61, retBody.getJSONObject("data").getIntValue("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", couponPrice, queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("pay_fee"));
        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", "51.00", queryPfChargeDetailInfo.getString("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", 51.00 * 12.00 / 63.00 + 0.01));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", 12.00 * 12.00 / 63.00 - 0.01));
        Double temp_total_fee = 51.00 - coupon_fee_order01 + 12.00 - coupon_fee_order02 + 10.00;
        Double temp_order01_fee = 51.00 - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (51.00 - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "cash", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 61.00, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail02Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        double order01_cloth01_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_ecard_fee, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth01_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth01_icard_fee - queryPfOrderDetail02Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth01_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order01_cloth01_coupon_fee - order01_cloth01_ecard_fee - order01_cloth01_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_third_fee, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 39.00, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", 39.00 / 63.00 * 12.00));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_coupon_fee - queryPfOrderDetail01Info.getDouble("coupon_fee")) <= 0.01);
        double order01_cloth02_ecard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * ecard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_ecard_fee, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        double order01_cloth02_icard_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee) * icard_fee / (51.00 - coupon_fee_order01)));
        Assert.assertTrue("返回值不符合预期", (order01_cloth02_icard_fee - queryPfOrderDetail01Info.getDouble("icard_fee")) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth02_third_fee = Double.parseDouble(String.format("%.2f", (39.00 - order01_cloth02_coupon_fee - order01_cloth02_ecard_fee - order01_cloth02_icard_fee)));
        Assert.assertTrue("返回值不符合预期", (queryPfOrderDetail01Info.getDouble("third_fee") - order01_cloth02_third_fee) <= 0.01);
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", 12.00, queryPfOrderDetail03Info.getDouble("fee"));
        Double order02_cloth_coupon_fee = Double.parseDouble(String.format("%.2f", 12.00 / 63.00 * 12.00 - 0.01));
        Assert.assertEquals("返回值不符合预期", order02_cloth_coupon_fee, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        double order02_cloth_ecard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * ecard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_ecard_fee, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("ecard_status"));
        double order02_cloth_icard_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee) * icard_fee_order02 / (22.00 - coupon_fee_order02)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_icard_fee, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("icard_status"));
        double order02_cloth_third_fee = Double.parseDouble(String.format("%.2f", (12.00 - order02_cloth_coupon_fee - order02_cloth_ecard_fee - order02_cloth_icard_fee)));
        Assert.assertEquals("返回值不符合预期", order02_cloth_third_fee, queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("third_status"));

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo.getString("operation"));

        String queryPaylogDetails01 = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id_01 + "";
        ResultSet queryPaylogDetailsInfo01 = mysqlQaDao.execQuerySql(queryPaylogDetails01);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo01.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPaylogDetailsInfo01.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo01.getString("operation"));


    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用优惠券，优惠券是单品折扣券
     *
     * 订单01info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     * 订单02info:
     *   $order_fee = 12;订单金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     * 合单info:
     *   $total_fee = 10.00;
     *
     * 支付info:
     *   $couponPrice = 12.00;优惠券金额
     *   $card_coin = 5.00;余额金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */
    public void testPayByCouponButSupportOneCloth() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 10.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        // 订单02的信息
        double order02_fee = 22.00;
        double order02_transfer_fee = 10.00;
        double order02_cloth_01 = 12.00;

        // 模拟优惠券的模版
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        int discount_type = 2;
        double couponPrice = 12.00;//优惠券的金额
        int coupon_category_id = 1;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "39";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 50; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        int coupon_user_type = 3;//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, String.valueOf(couponPrice), coupon_category_id, coupon_clothes_id,discount_type, coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type);

        // 模拟优惠券的属性信息表
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        edxpayModuleService.createCouponSncdeData(icoupon_sncode_id, icoupon_id, sncode, fan_id, 0, 0);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);

        // 模拟订单表的数据-订单金额12，运费为10
        int order_id_01 = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        OrderParams.put("order_id", order_id_01);
        edxpayModuleService.createOrderData(order_id_01, String.valueOf(order02_fee), String.valueOf(order02_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query01 = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id_01 = CommonTools.getLastId(orderClothesList46Query01, mysqlQaDao) + 1;
        String orderSnQuery01 = "select ordersn from ims_washing_order where id = " + order_id_01 + "";
        String order_sn_01 = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        orderClothesListsParams03.put("id",order_clothes_list_46_id_01);
        orderClothesListsParams03.put("order_id",order_id_01);
        orderClothesListsParams03.put("order_sn",order_sn_01);
        orderClothesListsParams03.put("courier_id",courier_id);
        orderClothesListsParams03.put("clothes_id",clothes_id_46);
        orderClothesListsParams03.put("clothes_name",clothes_name_46);
        orderClothesListsParams03.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams03.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams03);

        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFeeParam02.put("order_id", order_id_01);
        this.subFeeParam02.put("fee", order02_transfer_fee);
        this.subFee.add(0, this.subFeeParam01);
        this.subFee.add(1, this.subFeeParam02);
        this.deliveryParam.put("total_fee", total_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 0);

        this.orderIds.add(0,order_id);
        this.orderIds.add(1,order_id_01);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 3);// 现金支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);

        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", 61, retBody.getJSONObject("data").getIntValue("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");

        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", "73.00", queryPfChargeInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", "12.00", queryPfChargeInfo.getString("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("icard_fee"));
        Assert.assertEquals("返回值不符合预期", "10.00", queryPfChargeInfo.getString("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPfChargeInfo.getString("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", "61.00", queryPfChargeInfo.getString("pay_fee"));

        queryPfChargeInfo.close();
        queryPfChargeInfo = null;

        // 验证pf_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", order01_fee, queryPfChargeDetailInfo.getDouble("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", order01_fee / (order01_fee) * couponPrice));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", 0.00/(order01_fee) * couponPrice));
        Double temp_total_fee = order01_fee - coupon_fee_order01 + order02_fee - coupon_fee_order02 + order02_transfer_fee;
        Double temp_order01_fee = order01_fee - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (order01_fee - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        queryPfChargeDetailInfo.close();
        queryPfChargeDetailInfo = null;

        // 验证pf_charge_detail表中订单2的数据正确
        String queryPfChargeDetail01 = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id_01 + "";
        ResultSet queryPfChargeDetailInfo01 = mysqlQaDao.execQuerySql(queryPfChargeDetail01);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo01.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 22.00, queryPfChargeDetailInfo01.getDouble("fee"));
        Double temp_order02_fee = 12.00 - coupon_fee_order02 + 10.00;
        Double ecard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Double icard_fee_order02 = Double.parseDouble(String.format("%.2f", temp_order02_fee / temp_total_fee * 0));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfChargeDetailInfo01.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee_order02, queryPfChargeDetailInfo01.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee_order02, queryPfChargeDetailInfo01.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 10.00, queryPfChargeDetailInfo01.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo01.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (12.00 - coupon_fee_order02 - ecard_fee_order02 - icard_fee_order02 + 10.00)), queryPfChargeDetailInfo01.getString("pay_fee"));

        queryPfChargeDetailInfo01.close();
        queryPfChargeDetailInfo01 = null;

        //验证优惠券记录被更新
        String queryCoupon = "select used,usetime,fan_id,charge_id from ims_icoupon_sncode where id = " + icoupon_sncode_id + "";
        ResultSet queryCouponInfo = mysqlQaDao.execQuerySql(queryCoupon);
        Assert.assertEquals("返回值不符合预期", 1, queryCouponInfo.getInt("used"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryCouponInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", pf_charge_id, queryCouponInfo.getInt("charge_id"));

        queryCouponInfo.close();
        queryCouponInfo = null;

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "cash", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 61.0, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        queryImsPaylogInfo.close();
        queryImsPaylogInfo = null;

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_02, queryPfOrderDetail02Info.getDouble("fee"));
        double  order01_cloth02_coupon_fee = 0.00 ;
        Assert.assertEquals("返回值不符合预期", order01_cloth02_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        double order01_cloth02_third_fee = Double.parseDouble(String.format("%.2f",order01_cloth_02 - order01_cloth02_coupon_fee));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_third_fee, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        queryPfOrderDetail02Info.close();
        queryPfOrderDetail02Info = null;

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = 12.00;
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01 - order01_cloth01_coupon_fee, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        queryPfOrderDetail01Info.close();
        queryPfOrderDetail01Info = null;

        String queryPfOrderDetail03 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id =" + order_id_01 + "";
        ResultSet queryPfOrderDetail03Info = mysqlQaDao.execQuerySql(queryPfOrderDetail03);
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPfOrderDetail03Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail03Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail03Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order02_cloth_01, queryPfOrderDetail03Info.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order02, queryPfOrderDetail03Info.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail03Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail03Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", Double.parseDouble(String.format("%.2f", order02_cloth_01 - coupon_fee_order02)), queryPfOrderDetail03Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail03Info.getInt("third_status"));

        queryPfOrderDetail03Info.close();
        queryPfOrderDetail03Info = null;

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo.getString("operation"));

        queryPaylogDetailsInfo.close();
        queryPaylogDetailsInfo = null;

        String queryPaylogDetails01 = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id_01 + "";
        ResultSet queryPaylogDetailsInfo01 = mysqlQaDao.execQuerySql(queryPaylogDetails01);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo01.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id_01, queryPaylogDetailsInfo01.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo01.getString("operation"));

        queryPaylogDetailsInfo01.close();
        queryPaylogDetailsInfo01 = null;
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-5-20
     * @Scenario: 用户使用E卡和第三方 订单个数为1
     *
     * 订单01info:
     *   $order_fee = 51;订单金额
     *   $order_cloth_01 = 39.00;羽绒服金额
     *   $order_cloth_02 ＝ 12.00;短裤金额
     *   $order_transfer_fee = 10;订单运费
     * 合单info:
     *   $total_fee = 0.00;
     *
     * 支付info:
     *   $couponPrice = 12.00;优惠券金额
     *   when: 无合并订单，只有一个订单
     *   where: 老版本
     *   how: 支付
     *   then: 返回数据正确
     */
    public void testPayByEcardButOneOrder() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String sncode = String.valueOf(CommonTools.getRandomInt(9));
        double total_fee = 0.00;
        // 订单01的信息
        double order01_fee = 51.00;
        double order01_transfer_fee = 0.00;
        double order01_cloth_01 = 39.00;
        double order01_cloth_02 = 12.00;
        double order02_fee = 0.00;
        double order02_transfer_fee = 0.00;

        double couponPrice = 0.00;

        // 模拟ims_recharge数据－用户支付的时候选择E卡
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        Double chargePrice = 12.00;
        String zhenqian = "10.00";
        int usednum = 0;
        int kind = 2;
        int validity_type = 0;
        int charge_validity_type = 0;
        edxpayModuleService.createChargeData(recharge_id, chargePrice, usednum, zhenqian, kind, validity_type, charge_validity_type);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        recharge_sncode_id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        int charge_user_type = 3;
        int charge_card_type = 1;
        Double charge_price = 12.00;
        int used = 0;
        edxpayModuleService.createChargeSncodeData(recharge_sncode_id, recharge_id, sncode, charge_user_type, charge_card_type, charge_price, zhenqian, used, fan_id);

        // 模拟ims_ecard_limit的数据
        int ecard_limit_category_id = 0;
        edxpayModuleService.createEcardLimitData(recharge_id, ecard_limit_category_id, fan_id);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery, mysqlQaDao) + 1;
        edxpayModuleService.createOrderData(order_id, String.valueOf(order01_fee), String.valueOf(order01_transfer_fee), fan_id);

        // 模拟订单衣物表的数据-羽绒服一件
        String orderClothesListQuery = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_id = CommonTools.getLastId(orderClothesListQuery, mysqlQaDao) + 1;
        String orderSnQuery = "select ordersn from ims_washing_order where id = " + order_id + "";
        String order_sn = mysqlQaDao.execQuerySql(orderSnQuery).getString("ordersn");
        int courier_id = 15;
        int clothes_id = 39;
        String clothes_name = "羽绒服";
        int courier_price_id = 260;
        String courier_price = "39.00";
        orderClothesListsParams01.put("id",order_clothes_list_id);
        orderClothesListsParams01.put("order_id",order_id);
        orderClothesListsParams01.put("order_sn",order_sn);
        orderClothesListsParams01.put("courier_id",courier_id);
        orderClothesListsParams01.put("clothes_id",clothes_id);
        orderClothesListsParams01.put("clothes_name",clothes_name);
        orderClothesListsParams01.put("courier_price_id",courier_price_id);
        orderClothesListsParams01.put("courier_price",courier_price);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams01);

        // 模拟订单衣物表的数据-短裤一件
        String orderClothesList46Query = "select id from order_clothes_lists order by id desc limit 1";
        int order_clothes_list_46_id = CommonTools.getLastId(orderClothesList46Query, mysqlQaDao) + 1;
        int clothes_id_46 = 46;
        String clothes_name_46 = "短裤";
        int courier_price_id_46 = 267;
        String courier_price_46 = "12.00";
        orderClothesListsParams02.put("id",order_clothes_list_46_id);
        orderClothesListsParams02.put("order_id",order_id);
        orderClothesListsParams02.put("order_sn",order_sn);
        orderClothesListsParams02.put("courier_id",courier_id);
        orderClothesListsParams02.put("clothes_id",clothes_id_46);
        orderClothesListsParams02.put("clothes_name",clothes_name_46);
        orderClothesListsParams02.put("courier_price_id",courier_price_id_46);
        orderClothesListsParams02.put("courier_price",courier_price_46);
        generalRongChain04Data.GeneralOrderClothesLists(orderClothesListsParams02);


        //接口调用参数
        this.subFeeParam01.put("order_id", order_id);
        this.subFeeParam01.put("fee", 0);
        this.subFee.add(0, this.subFeeParam01);
        this.deliveryParam.put("total_fee", total_fee);
        this.deliveryParam.put("sub_fee", this.subFee);
        this.ecard.add(0, recharge_sncode_id);
        this.payInfoParam.put("coupon_id", icoupon_sncode_id);
        this.payInfoParam.put("icard", 0);
        this.payInfoParam.put("ecard_ids", this.ecard);

        this.orderIds.add(0,order_id);

        this.queryParams.put("delivery", this.deliveryParam);
        this.queryParams.put("order_ids", this.orderIds);
        this.queryParams.put("pay_type", 3);// 微信支付
        this.queryParams.put("pay_info", this.payInfoParam);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("user_id",fan_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", order01_fee-chargePrice, retBody.getJSONObject("data").getDouble("total"));

        // 验证pf_charge表的数据正确
        String queryPfCharge = "select id,business_id,type,channel,fan_id,status,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,activity_fee,paylog_id,user_type from pf_charge where fan_id = " + fan_id + "";
        ResultSet queryPfChargeInfo = mysqlQaDao.execQuerySql(queryPfCharge);
        int pf_charge_id = queryPfChargeInfo.getInt("id");
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("type"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryPfChargeInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeInfo.getInt("status"));//0 未支付；1 正在支付；2 支付成功；3 退款 ； 4 取消订单；5 订单支付成功， 通知失败
        Assert.assertEquals("返回值不符合预期", order01_fee, queryPfChargeInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", chargePrice, queryPfChargeInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeInfo.getDouble("activity_fee"));
        Assert.assertEquals("返回值不符合预期", 3, queryPfChargeInfo.getInt("user_type"));
        Assert.assertEquals("返回值不符合预期", order01_fee - chargePrice, queryPfChargeInfo.getDouble("pay_fee"));

        queryPfChargeInfo.close();
        queryPfChargeInfo = null;

        // 验证ps_charge_detail表中订单1的数据正确
        String queryPfChargeDetail = "select business_id,business_order,fan_id,fee,coupon_fee,ecard_fee,icard_fee,transfer_fee,pay_fee,charge_id,status from pf_charge_detail where business_order = " + order_id + "";
        ResultSet queryPfChargeDetailInfo = mysqlQaDao.execQuerySql(queryPfChargeDetail);
        Assert.assertEquals("返回值不符合预期", 11, queryPfChargeDetailInfo.getInt("business_id"));
        Assert.assertEquals("返回值不符合预期", order01_fee, queryPfChargeDetailInfo.getDouble("fee"));
        Double coupon_fee_order01 = Double.parseDouble(String.format("%.2f", order01_fee / (order01_fee + order02_fee) * couponPrice));
        Double coupon_fee_order02 = Double.parseDouble(String.format("%.2f", order02_fee/(order01_fee+order02_fee) * couponPrice));
        Double temp_total_fee = order01_fee - coupon_fee_order01 + order02_fee - coupon_fee_order02 + order02_transfer_fee;
        Double temp_order01_fee = order01_fee - coupon_fee_order01;
        Double ecard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * chargePrice));
        Double icard_fee = Double.parseDouble(String.format("%.2f", temp_order01_fee / temp_total_fee * 0.00));
        Assert.assertEquals("返回值不符合预期", coupon_fee_order01, queryPfChargeDetailInfo.getDouble("coupon_fee"));
        Assert.assertEquals("返回值不符合预期", ecard_fee, queryPfChargeDetailInfo.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", icard_fee, queryPfChargeDetailInfo.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfChargeDetailInfo.getDouble("transfer_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfChargeDetailInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", String.format("%.2f", (order01_fee - coupon_fee_order01 - ecard_fee - icard_fee)), queryPfChargeDetailInfo.getString("pay_fee"));

        queryPfChargeDetailInfo.close();
        queryPfChargeDetailInfo = null;

        //验证paylog表的数据正确
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");
        Assert.assertEquals("返回值不符合预期", "cash", queryImsPaylogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期", retBody.getJSONObject("data").getString("trade_no"), queryImsPaylogInfo.getString("tid"));
        Assert.assertEquals("返回值不符合预期", 39.0, queryImsPaylogInfo.getDouble("fee"));
        Assert.assertEquals("返回值不符合预期", "washing", queryImsPaylogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期", fan_id, queryImsPaylogInfo.getInt("fan_id"));
        Assert.assertTrue("返回值不符合预期", queryImsPaylogInfo.getString("createtime").contains(CommonTools.getToday("yyyy-MM-dd")));

        queryImsPaylogInfo.close();
        queryImsPaylogInfo = null;

        // 验证pf_order_detail表中的数据正确
        String queryPfOrderDetail02 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id_46 + " and order_id = " + order_id + "";
        ResultSet queryPfOrderDetail02Info = mysqlQaDao.execQuerySql(queryPfOrderDetail02);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail02Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "短裤", queryPfOrderDetail02Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 46, queryPfOrderDetail02Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_02, queryPfOrderDetail02Info.getDouble("fee"));
        Double order01_cloth02_coupon_fee = Double.parseDouble(String.format("%.2f", order01_cloth_02/(order01_cloth_01 + order01_cloth_02) * coupon_fee_order01));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_coupon_fee, queryPfOrderDetail02Info.getDouble("coupon_fee"));
        Double order01_cloth02_ecard_fee = Double.parseDouble(String.format("%.2f", order01_cloth_02 / (order01_cloth_01 + order01_cloth_02) * ecard_fee));
        Assert.assertEquals("返回值不符合预期", order01_cloth02_ecard_fee, queryPfOrderDetail02Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail02Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_02 - order01_cloth02_ecard_fee - order01_cloth02_coupon_fee, queryPfOrderDetail02Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail02Info.getInt("third_status"));

        queryPfOrderDetail02Info.close();
        queryPfOrderDetail02Info = null;

        String queryPfOrderDetail01 = "select id,order_id,cloth_id,cloth_name,cloth_order_id,fee,coupon_fee,coupon_status,ecard_fee,ecard_status,icard_fee,icard_status,third_fee,third_status from pf_order_detail where cloth_id = " + clothes_id + " and order_id=" + order_id + "";
        ResultSet queryPfOrderDetail01Info = mysqlQaDao.execQuerySql(queryPfOrderDetail01);
        Assert.assertEquals("返回值不符合预期", order_id, queryPfOrderDetail01Info.getInt("order_id"));
        Assert.assertEquals("返回值不符合预期", "羽绒服", queryPfOrderDetail01Info.getString("cloth_name"));
        Assert.assertEquals("返回值不符合预期", 39, queryPfOrderDetail01Info.getInt("cloth_id"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01, queryPfOrderDetail01Info.getDouble("fee"));
        Double order01_cloth01_coupon_fee = Double.parseDouble(String.format("%.2f",coupon_fee_order01 - order01_cloth02_coupon_fee));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_coupon_fee, queryPfOrderDetail01Info.getDouble("coupon_fee"));
        Double order01_cloth01_ecard_fee = Double.parseDouble(String.format("%.2f", order01_cloth_01 / (order01_cloth_01 + order01_cloth_02) * ecard_fee));
        Assert.assertEquals("返回值不符合预期", order01_cloth01_ecard_fee, queryPfOrderDetail01Info.getDouble("ecard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("ecard_status"));
        Assert.assertEquals("返回值不符合预期", 0.00, queryPfOrderDetail01Info.getDouble("icard_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("icard_status"));
        Assert.assertEquals("返回值不符合预期", order01_cloth_01 - order01_cloth01_coupon_fee - order01_cloth01_ecard_fee, queryPfOrderDetail01Info.getDouble("third_fee"));
        Assert.assertEquals("返回值不符合预期", 1, queryPfOrderDetail01Info.getInt("third_status"));

        queryPfOrderDetail01Info.close();
        queryPfOrderDetail01Info = null;

        String queryPaylogDetails = "select id,content_type,content_id,operation,paylog_id from paylog_details where paylog_id = " + paylog_id + " and content_id = " + order_id + "";
        ResultSet queryPaylogDetailsInfo = mysqlQaDao.execQuerySql(queryPaylogDetails);
        Assert.assertEquals("返回值不符合预期", "order", queryPaylogDetailsInfo.getString("content_type"));
        Assert.assertEquals("返回值不符合预期", order_id, queryPaylogDetailsInfo.getInt("content_id"));
        Assert.assertEquals("返回值不符合预期", "daifu", queryPaylogDetailsInfo.getString("operation"));

        queryPaylogDetailsInfo.close();
        queryPaylogDetailsInfo = null;

    }

}
