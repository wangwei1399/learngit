package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16-4-18.
 */
public class GetOrderUsableCouponListTest {

    private static Logger logger = LoggerFactory
            .getLogger(GetOrderUsableCouponListTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> clothInfoParams = null;
    private JSONObject orderInfoParams01 = new JSONObject();
    private JSONObject orderInfoParams = new JSONObject();
    private JSONObject couponList = new JSONObject();
    private JSONObject couponSncodeParams = new JSONObject();
    private Map<String, Object> clothInfo = null;
    private Map<String, Object> clothInfo01 = null;

    private JSONArray clothes = new JSONArray();
    private JSONArray clothes01 = new JSONArray();
    private JSONArray orderInfo = new JSONArray();
    private JSONArray orderInfo01 = new JSONArray();

    private JSONObject fanParams = new JSONObject();


    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.clothInfo = new HashMap<String, Object>();
        this.clothInfoParams = new HashMap<String, Object>();
        this.clothInfo01 = new HashMap<String, Object>();

    }

    @After
    public void tearDown() {
        deleteCoupons(couponList);
        mysqlQaDao.close();

        logger.info("in teardown!");
    }

    private void deleteCoupons(JSONObject couponList){
        if (couponList.containsKey("id")){
            int id = couponList.getInteger("id");
            String sql = "delete from ims_icoupon_sncode WHERE cid ="+id;
            mysqlQaDao.execUpdateSql(sql);
            sql = "delete from ims_icoupon_list where id="+id;
            mysqlQaDao.execUpdateSql(sql);
        }

    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:测试优惠券的订单与订单的用户不匹配
     *   descriptions:
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *   when:测试优惠券的订单与订单的用户不匹配
     *   where:
     *   how:
     *   then:该优惠券不属于此用户
     */
    public void testWhenFanIdIsMisMatch() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);


        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);
        orderInfoParams.put("fan_id",fan_id+1);
        orderInfoParams.put("total_price",550);
        orderInfoParams.put("price",550);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);
        this.clothInfo.put("price",550);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);
        queryParams.put("order_info",this.orderInfo);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期",1,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",0 ,retBody.getJSONArray("data").getJSONObject(0).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期","金额未达到满减要求",retBody.getJSONArray("data").getJSONObject(0).getString("error"));


    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:测试优惠券还未到开始使用时间
     *   descriptions:
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *   when:测试优惠券的订单与订单的用户不匹配
     *   where:
     *   how:
     *   then:该优惠券不属于此用户
     */
    public void testWhenStarttimeIsFuture() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("starttime",CommonTools.getTimesnight()-1+24*60*60);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);


        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);
        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",550);
        orderInfoParams.put("price",550);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);
        this.clothInfo.put("price",550);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);
        queryParams.put("order_info",this.orderInfo);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期",1,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",0 ,retBody.getJSONArray("data").getJSONObject(0).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期","金额未达到满减要求",retBody.getJSONArray("data").getJSONObject(0).getString("error"));


    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:测试获取订单所需要的优惠券
     *   descriptions:
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是上海的用户
     *   when:有两张优惠券，但是有一张优惠券的使用城市是上海
     *   where:
     *   how:
     *   then:返回一张可用的优惠券，error:不能用于此城市
     */
    public void testWhenCouponCityIsShanghai() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","7,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);


        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据
        int icoupon_id_01 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_01);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","7,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",2);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);


        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_01 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_01);
        couponSncodeParams.put("cid", icoupon_id_01);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);
        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",550);
        orderInfoParams.put("price",550);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);

        this.clothInfo.put("id",CommonTools.getRandomInt(5));
        this.clothInfo.put("price",550);
        this.clothInfo.put("num",1);
        this.clothInfo.put("clothes_id",7);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothInfo.put("is_suit",0);
        this.clothInfo.put("is_bargain",0);

        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);
        queryParams.put("order_info",this.orderInfo);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期",2,retBody.getJSONArray("data").size());

        Assert.assertEquals("返回值不符合预期",1 ,retBody.getJSONArray("data").getJSONObject(0).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期",0 ,retBody.getJSONArray("data").getJSONObject(1).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期","不能用于此城市",retBody.getJSONArray("data").getJSONObject(1).getString("error"));


    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:测试获取订单所需要的优惠券
     *   descriptions:
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=2）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *   when:有两张优惠券，但是有一张优惠券的使用城市是上海
     *   where:
     *   how:
     *   then:返回一张可用的优惠券，error:品类不一致
     */
    public void testWhenCategoryIs2() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);
        // 模拟ims_icoupon_list数据
        int icoupon_id_01 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_01);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",2);
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);

        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_01 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_01);
        couponSncodeParams.put("cid", icoupon_id_01);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);
        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",550);
        orderInfoParams.put("price",550);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);

        this.clothInfo.put("id",CommonTools.getRandomInt(5));
        this.clothInfo.put("price",550);
        this.clothInfo.put("num",1);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothInfo.put("is_suit",0);
        this.clothInfo.put("is_bargain",0);

        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);
        queryParams.put("order_info",this.orderInfo);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(URLBuilder.httpBuildQuery(this.queryParams,"UTF_8"), this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期",2,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",1 ,retBody.getJSONArray("data").getJSONObject(0).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期",0 ,retBody.getJSONArray("data").getJSONObject(1).getIntValue("usable"));
        Assert.assertEquals("返回值不符合预期","不支持该品类",retBody.getJSONArray("data").getJSONObject(1).getString("error"));


    }



    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:测试获取合并支付的可用优惠券
     *   descriptions:
     *     优惠券的类型是满减，满500减120,使用品类是洗衣（category_id=1）,clothes_id是衬衫、马甲,限北京、微信内使用,满500可用、不支持余额支付,使用城市是北京的用户
     *   when:有两张优惠券，但是有一张优惠券的使用城市是上海
     *   where:
     *   how:
     *   then:返回一张可用的优惠券，error:品类不一致
     */
    public void testWhenMergePay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",1);
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","2,3,6,11");
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);


        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);

        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",550);
        orderInfoParams.put("price",550);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);

        orderInfoParams01.put("fan_id",fan_id);
        orderInfoParams01.put("total_price",550);
        orderInfoParams01.put("price",550);
        orderInfoParams01.put("user_type",1);
        orderInfoParams01.put("category_id",1);
        orderInfoParams01.put("city_id",1);

        this.clothInfo.put("id",CommonTools.getRandomInt(5));
        this.clothInfo.put("price",550);
        this.clothInfo.put("num",1);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothInfo.put("is_suit",0);
        this.clothInfo.put("is_bargain",0);

        this.clothInfo01.put("id",CommonTools.getRandomInt(5) + 1);
        this.clothInfo01.put("price",550);
        this.clothInfo01.put("num",1);
        this.clothInfo01.put("clothes_id",1);
        this.clothInfo01.put("clothes_name","测试衣服");
        this.clothInfo01.put("is_suit",0);
        this.clothInfo01.put("is_bargain",0);

        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);

        this.clothes01.add(0,this.clothInfo01);
        orderInfoParams01.put("clothes",this.clothes01);
        this.orderInfo.add(1, this.orderInfoParams01);
        queryParams.put("order_info",this.orderInfo);


        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期",1,retBody.getJSONArray("data").size());
        Assert.assertEquals("返回值不符合预期",1 ,retBody.getJSONArray("data").getJSONObject(0).getIntValue("usable"));


    }



    @Test

    public void testSortBySingle() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据-可用的满减券－满500减100 & 无品类限制 & 无支付方式限制 & 过期时间是明天
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",0);
        couponList.put("clothes_id","NULL");
        couponList.put("exclusive_channels",0);
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*1);// 明天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据－可用的打折券，折扣	洗衣、洗鞋 微信 明天 100
        int icoupon_id_01 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_01);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price",80);
        couponList.put("usednum", 0);
        couponList.put("least_price", 500);
        couponList.put("category_id","1,2");
        couponList.put("clothes_id","1");
        couponList.put("exclusive_channels","2");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_01 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_01);
        couponSncodeParams.put("cid", icoupon_id_01);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*1);// 明天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据－可用的打折券，折扣	洗衣	无	后天	100	8 3
        int icoupon_id_02 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_02);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price",80);
        couponList.put("usednum", 0);
        couponList.put("least_price", 500);
        couponList.put("category_id","1");
        couponList.put("clothes_id","1");
        couponList.put("exclusive_channels","2");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_02 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_02);
        couponSncodeParams.put("cid", icoupon_id_02);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据-可用的满减券－满减	洗衣	微信	明天	80	8	4
        int icoupon_id_03 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_03);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",0);
        couponList.put("clothes_id","NULL");
        couponList.put("exclusive_channels",2);
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_03 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_03);
        couponSncodeParams.put("cid", icoupon_id_03);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*1);// 明天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据-可用的满减券－满减	洗衣、洗鞋	无	后天	80	6	5
        int icoupon_id_04 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_04);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id","1,2");
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels",0);
        couponList.put("least_price",500);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_04 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_04);
        couponSncodeParams.put("cid", icoupon_id_04);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据－可用的打折券，折扣	洗衣	无	后天	100	8 3
        int icoupon_id_05 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_05);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price",80);
        couponList.put("usednum", 0);
        couponList.put("least_price", 500);
        couponList.put("category_id","0");
        couponList.put("exclusive_channels","2");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_05 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_05);
        couponSncodeParams.put("cid", icoupon_id_05);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);
        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",500);
        orderInfoParams.put("price",500);
        orderInfoParams.put("user_type", 1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);

        this.clothInfo.put("id",CommonTools.getRandomInt(5));
        this.clothInfo.put("price",500);
        this.clothInfo.put("num",1);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothInfo.put("is_suit",0);
        this.clothInfo.put("is_bargain", 0);

        this.clothes.add(0, this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);
        queryParams.put("order_info",this.orderInfo);
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id,retBody.getJSONArray("data").getJSONObject(0).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_01,retBody.getJSONArray("data").getJSONObject(1).getIntValue("id"));

        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_02,retBody.getJSONArray("data").getJSONObject(2).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_03,retBody.getJSONArray("data").getJSONObject(3).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_04,retBody.getJSONArray("data").getJSONObject(4).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_05,retBody.getJSONArray("data").getJSONObject(5).getIntValue("id"));


    }


    @Test

    public void testSort() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        Double price = 120.00;
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据-可用的满减券－满500减100 & 无品类限制 & 无支付方式限制 & 过期时间是明天
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",0);
        couponList.put("clothes_id","NULL");
        couponList.put("exclusive_channels",0);
        couponList.put("least_price",160);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id);
        couponSncodeParams.put("cid", icoupon_id);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*1);// 明天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据－~无	微信	~明天	~100	~小	满减	1	2
        int icoupon_id_01 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_01);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("least_price", 160);
        couponList.put("category_id","0");
        couponList.put("clothes_id","NULL");
        couponList.put("exclusive_channels","2");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_01 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_01);
        couponSncodeParams.put("cid", icoupon_id_01);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*1);// 明天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据，洗衣	无	后天	100	小	满减	11	3
        int icoupon_id_02 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_02);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("least_price", 160);
        couponList.put("category_id","1");
        couponList.put("clothes_id","1,2");
        couponList.put("exclusive_channels","0");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_02 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_02);
        couponSncodeParams.put("cid", icoupon_id_02);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据-洗鞋	微信	后天	100	大	折扣	8	4
        int icoupon_id_03 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_03);
        couponList.put("coupon_price", 100);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price","37.5");
        couponList.put("usednum", 0);
        couponList.put("category_id","2");
        couponList.put("clothes_id","18");
        couponList.put("exclusive_channels",2);
        couponList.put("least_price",160);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_03 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_03);
        couponSncodeParams.put("cid", icoupon_id_03);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_icoupon_list数据-洗鞋	微信	明天	80	小	满减	8	5
        int icoupon_id_04 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_04);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id","2");
        couponList.put("clothes_id","18");
        couponList.put("exclusive_channels","2");
        couponList.put("least_price",160);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_04 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_04);
        couponSncodeParams.put("cid", icoupon_id_04);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据-洗衣	微信	明天	80	大	满减	11	6
        int icoupon_id_05 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_05);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id","1");
        couponList.put("clothes_id","1");
        couponList.put("exclusive_channels","2");
        couponList.put("least_price",160);
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据－第一条数据
        int icoupon_sncode_id_05 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_05);
        couponSncodeParams.put("cid", icoupon_id_05);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据－~无	无	~后天	~80	~大	折扣	1	7
        int icoupon_id_06 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_06);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price",50);
        couponList.put("usednum", 0);
        couponList.put("least_price", 160);
        couponList.put("category_id","0");
        couponList.put("exclusive_channels","0");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_06 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_06);
        couponSncodeParams.put("cid", icoupon_id_06);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);


        // 模拟ims_icoupon_list数据－~无	无	~后天	~80	~大	折扣	1	7
        int icoupon_id_07 = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id_07);
        couponList.put("coupon_price", 80);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",2);
        couponList.put("discount_price",50);
        couponList.put("usednum", 0);
        couponList.put("least_price", 160);
        couponList.put("category_id","0");
        couponList.put("exclusive_channels","2");
        couponList.put("city_id",1);
        couponList.put("user_types",1);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        int icoupon_sncode_id_07 = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id", icoupon_sncode_id_07);
        couponSncodeParams.put("cid", icoupon_id_07);
        couponSncodeParams.put("sncode", CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id", fan_id);
        couponSncodeParams.put("used", 0);
        couponSncodeParams.put("endtime",CommonTools.getTimesnight()-1+24*60*60*2);// 后天过期
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        queryParams.put("fan_id", fan_id);
        queryParams.put("user_type",1);
        queryParams.put("get_all",1);

        orderInfoParams.put("fan_id",fan_id);
        orderInfoParams.put("total_price",500);
        orderInfoParams.put("price",500);
        orderInfoParams.put("user_type",1);
        orderInfoParams.put("category_id",1);
        orderInfoParams.put("city_id",1);

        orderInfoParams01.put("fan_id",fan_id);
        orderInfoParams01.put("total_price",160);
        orderInfoParams01.put("price",160);
        orderInfoParams01.put("user_type",1);
        orderInfoParams01.put("category_id",2);
        orderInfoParams01.put("city_id",1);

        this.clothInfo.put("id",CommonTools.getRandomInt(5));
        this.clothInfo.put("price",500);
        this.clothInfo.put("num",1);
        this.clothInfo.put("clothes_id",1);
        this.clothInfo.put("clothes_name","测试衣服");
        this.clothInfo.put("is_suit",0);
        this.clothInfo.put("is_bargain",0);

        this.clothInfo01.put("id",CommonTools.getRandomInt(5) + 1);
        this.clothInfo01.put("price",160);
        this.clothInfo01.put("num",1);
        this.clothInfo01.put("clothes_id",18);
        this.clothInfo01.put("clothes_name","测试鞋子");
        this.clothInfo01.put("is_suit",0);
        this.clothInfo01.put("is_bargain",0);

        this.clothes.add(0,this.clothInfo);
        orderInfoParams.put("clothes",this.clothes);
        this.orderInfo.add(0, this.orderInfoParams);

        this.clothes01.add(0,this.clothInfo01);
        orderInfoParams01.put("clothes",this.clothes01);
        this.orderInfo.add(1, this.orderInfoParams01);
        queryParams.put("order_info",this.orderInfo);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallGetUsableCouponList(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id,retBody.getJSONArray("data").getJSONObject(0).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_01,retBody.getJSONArray("data").getJSONObject(1).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_02,retBody.getJSONArray("data").getJSONObject(2).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_03,retBody.getJSONArray("data").getJSONObject(3).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_04,retBody.getJSONArray("data").getJSONObject(4).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_05,retBody.getJSONArray("data").getJSONObject(5).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_06,retBody.getJSONArray("data").getJSONObject(6).getIntValue("id"));
        Assert.assertEquals("返回值不符合预期", icoupon_sncode_id_07,retBody.getJSONArray("data").getJSONObject(7).getIntValue("id"));


    }

}