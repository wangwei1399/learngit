package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 回调接口的测试
 * Created by ningzhao on 16-5-17
 */
public class RefundDealTest {

    private static Logger logger = LoggerFactory
            .getLogger(RefundDealTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test

    /**
     * @User: zhaoning
     * @Date: 16/7/14
     * @Scenario: 用户使用优惠券、余额、一张E卡、第三方支付支付订单
     * when: 加工店还未分拣
     * where: 客服系统
     * how: 用户联系客服操作取消订单退款
     * then:
     */
    public void testRefundDeal() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        PlatformIndexTest platformIndexTest = new PlatformIndexTest();
        platformIndexTest.setUp();
        platformIndexTest.testPlatformIndex();

        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = " + platformIndexTest.fan_id + "";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        int paylog_id = queryImsPaylogInfo.getInt("plid");

        this.queryParams.put("plid", paylog_id);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformCallBack(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));


    }


}