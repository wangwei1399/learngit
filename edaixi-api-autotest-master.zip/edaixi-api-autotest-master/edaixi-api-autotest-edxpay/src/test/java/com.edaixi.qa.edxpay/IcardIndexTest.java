package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class IcardIndexTest {

    private static Logger logger = LoggerFactory
            .getLogger(IcardIndexTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private JSONObject queryParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-3-29
     * @Scenario:用户使用微信充值
     *   when:支付方式为微信
     *   where:可以充值的地方
     *   how:充值100元
     *   then: 充值成功，用户的余额等于充值后的金额，为100
     */
    public void testIcardRechage() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        int user_id = 623565;
        int pay_type = 2;//微信
        String trans_type = "recharge";
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);
        logger.info(result.toString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String retTid = loginBody.getJSONObject("data").getString("trade_no");
        String queryPayLog = "select type,weid,tid,openid,fee,status,module,fan_id,createtime,total_money from ims_paylog where tid = '" + retTid + "'";
        ResultSet queryPayLogInfo = mysqlQaDao.execQuerySql(queryPayLog);
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期","wechat",queryPayLogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期",0,queryPayLogInfo.getInt("weid"));
        Assert.assertEquals("返回值不符合预期", null,queryPayLogInfo.getString("openid"));
        Assert.assertEquals("返回值不符合预期", "100.00", queryPayLogInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0, queryPayLogInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", "icard", queryPayLogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期",623565,queryPayLogInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPayLogInfo.getString("total_money"));


    }

    @Test
    /**
     *
     * @author ningyao.zn
     * 测试支付宝充值
     *
     */
    public void testIcardRechageByAlipay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        int user_id = 623565;
        int pay_type = 6;//支付宝
        String trans_type = "recharge";
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String retTid = loginBody.getJSONObject("data").getString("trade_no");
        String queryPayLog = "select type,weid,tid,openid,fee,status,module,fan_id,createtime,total_money from ims_paylog where tid = '" + retTid + "'";
        ResultSet queryPayLogInfo = mysqlQaDao.execQuerySql(queryPayLog);
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期","alipay",queryPayLogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期",0,queryPayLogInfo.getInt("weid"));
        Assert.assertEquals("返回值不符合预期", null,queryPayLogInfo.getString("openid"));
        Assert.assertEquals("返回值不符合预期", "100.00", queryPayLogInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0, queryPayLogInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", "icard", queryPayLogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期",623565,queryPayLogInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPayLogInfo.getString("total_money"));

    }

    @Test
    /**
     *
     * @author ningyao.zn
     * 测试百度充值
     *
     */
    public void testIcardRechageByBaidu() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {

        int user_id = 623565;
        int pay_type = 11;//百度
        String trans_type = "recharge";
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String retTid = loginBody.getJSONObject("data").getString("trade_no");
        String queryPayLog = "select type,weid,tid,openid,fee,status,module,fan_id,createtime,total_money from ims_paylog where tid = '" + retTid + "'";
        ResultSet queryPayLogInfo = mysqlQaDao.execQuerySql(queryPayLog);
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期","baifubao",queryPayLogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期",0,queryPayLogInfo.getInt("weid"));
        Assert.assertEquals("返回值不符合预期", null,queryPayLogInfo.getString("openid"));
        Assert.assertEquals("返回值不符合预期", "100.00", queryPayLogInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0, queryPayLogInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", "icard", queryPayLogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期",623565,queryPayLogInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPayLogInfo.getString("total_money"));

    }


    @Test
    /**
     *
     * @author ningyao.zn
     * 测试付款
     *
     */
    public void testIcardPayment() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int order_id = (int)(currentTime % 10000000);
        String order_sn = String.valueOf(currentTime);
        int uid = 79;
        int old_category_id = 1;
        int status = 1;
        int status_delivery = 9;
        int pay_status = 0;
        int user_id = 623565;
        int pay_type = 2;//微信
        String trans_type = "payment";

        //造订单的数据
        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
                "VALUES\n" +
                "\t(" + order_id + ", NULL, 7, '" + order_sn + "', '', 1, 0.00, 0.00, '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, '接口测试', '2016-01-16', '18:00-20:00', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', "+ uid + ", 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";
        mysqlQaDao.execUpdateSql(orderInfo);

        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.queryParams.put("order_id",order_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);

        // 调用登录接口
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String retTid = loginBody.getJSONObject("data").getString("trade_no");
        String queryPayLog = "select type,weid,tid,openid,fee,status,module,fan_id,createtime,total_money from ims_paylog where tid = '" + retTid + "'";
        ResultSet queryPayLogInfo = mysqlQaDao.execQuerySql(queryPayLog);
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        Assert.assertEquals("返回值不符合预期","wechat",queryPayLogInfo.getString("type"));
        Assert.assertEquals("返回值不符合预期",0,queryPayLogInfo.getInt("weid"));
        Assert.assertEquals("返回值不符合预期", null,queryPayLogInfo.getString("openid"));
        Assert.assertEquals("返回值不符合预期", "100.00", queryPayLogInfo.getString("fee"));
        Assert.assertEquals("返回值不符合预期", 0, queryPayLogInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期", "washing", queryPayLogInfo.getString("module"));
        Assert.assertEquals("返回值不符合预期",623565,queryPayLogInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期", "0.00", queryPayLogInfo.getString("total_money"));
    }

    @Test
    /**
     *
     * @author ningyao.zn
     * 测试付款－订单已经付款后再调起付款
     *
     */
    public void testIcardPaymentByPayed() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int order_id = (int)(currentTime % 10000000);
        String order_sn = String.valueOf(currentTime);
        int uid = 79;
        int old_category_id = 1;
        int status = 1;
        int status_delivery = 1;
        int pay_status = 1;
        int user_id = 623565;
        int pay_type = 2;//微信
        String trans_type = "payment";

        //造订单的数据
        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
                "VALUES\n" +
                "\t(" + order_id + ", NULL, 7, '" + order_sn + "', '', 1, 0.00, 0.00, '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, '接口测试', '2016-01-16', '18:00-20:00', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', "+ uid + ", 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";
        mysqlQaDao.execUpdateSql(orderInfo);

        this.queryParams.put("user_id",user_id);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("trans_type",trans_type);
        this.queryParams.put("trans_amount",100);
        this.queryParams.put("order_id",order_id);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");

        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallIcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }


}
