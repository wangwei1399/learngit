package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 小e代付第三方支付接口
 * Created by ningzhao on 16-5-17
 */
public class PlatformEpayTest {

    private static Logger logger = LoggerFactory
            .getLogger(PlatformEpayTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private PlatformIndexTest platformIndexTest = new PlatformIndexTest();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> PfChargeParams = null;
    private Map<String, Object> fanParams = null;
    private Map<String, Object> imsPaylog = null;
    public int fan_id = 0;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.PfChargeParams = new HashMap<String, Object>();
        this.fanParams = new HashMap<String, Object>();
        this.imsPaylog = new HashMap<String, Object>();
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        this.fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", this.fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");

    }


    public void createPfChargeData(int pf_charge_id, int type, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int user_type,int paylog_id) {
        PfChargeParams.put("id", pf_charge_id);
        PfChargeParams.put("fan_id", this.fan_id);
        PfChargeParams.put("type", type);
        PfChargeParams.put("status", status);
        PfChargeParams.put("fee", fee);
        PfChargeParams.put("coupon_fee", coupon_fee);
        PfChargeParams.put("ecard_fee", ecard_fee);
        PfChargeParams.put("icard_fee", icard_fee);
        PfChargeParams.put("transfer_fee", transfer_fee);
        PfChargeParams.put("pay_fee", pay_fee);
        PfChargeParams.put("user_type", user_type);
        PfChargeParams.put("paylog_id",paylog_id);
        generalRongChain04Data.GeneralPfCharge(PfChargeParams);
    };

    public void createPfChargeDetailData(int pf_charge_detail_id, int business_order, double fee, double coupon_fee, double ecard_fee, double icard_fee, double transfer_fee, double pay_fee, int status, int charge_id) {
        PfChargeParams.put("id", pf_charge_detail_id);
        PfChargeParams.put("business_order", business_order);
        PfChargeParams.put("fan_id", this.fan_id);
        PfChargeParams.put("status", status);
        PfChargeParams.put("fee", fee);
        PfChargeParams.put("coupon_fee", coupon_fee);
        PfChargeParams.put("ecard_fee", ecard_fee);
        PfChargeParams.put("icard_fee", icard_fee);
        PfChargeParams.put("transfer_fee", transfer_fee);
        PfChargeParams.put("pay_fee", pay_fee);
        PfChargeParams.put("charge_id", charge_id);
        generalRongChain04Data.GeneralPfDetailCharge(PfChargeParams);
    };

    public void createImsPaylogData(int plid,String type,double fee,int status,int fan_id,int tid){
        imsPaylog.put("plid",plid);
        imsPaylog.put("type",type);
        imsPaylog.put("fee",fee);
        imsPaylog.put("status",status);
        imsPaylog.put("fan_id",fan_id);
        imsPaylog.put("tid",tid);
        generalRongChain04Data.GeneralImsPaylog(imsPaylog);
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:用户支付使用优惠券和E卡和余额和第三方支付
     *   when:优惠券支持合并订单中的所有订单
     *   where:
     *   how:
     *   then:
     */
    public void testChargeEpay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String queryImsPaylog = "select plid from ims_paylog order by plid desc limit 1";
        int ims_paylog_id = mysqlQaDao.execQuerySql(queryImsPaylog).getInt("plid") + 1;
        String ims_paylog_type = "CASH";
        double ims_paylog_fee = 61.00;
        int ims_paylog_status = 0;
        int ims_paylog_tid = CommonTools.getRandomInt(9);
        this.createImsPaylogData(ims_paylog_id,ims_paylog_type,ims_paylog_fee,ims_paylog_status,this.fan_id,ims_paylog_tid);


        String queryPfChargeId = "select id from pf_charge order by id desc limit 1";
        int pf_charge_id = CommonTools.getLastId(queryPfChargeId, this.mysqlQaDao) + 1;
        // type 是支持的支付方式，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int type = 2;
        double fee = 73.00;
        double coupon_fee = 12.00;
        double ecard_fee = 12.00;
        double icard_fee = 5.00;
        double transfer_fee = 10.00;
        double pay_fee = 44.00;
        int status = 1;
        int user_type = 3;
        this.createPfChargeData(pf_charge_id, type, fee, coupon_fee, ecard_fee, icard_fee, transfer_fee, pay_fee, status, user_type,ims_paylog_id);

        String queryPfDetailChargeId = "select id from pf_charge_detail order by id desc limit 1";
        int pf_charge_detail_id_01 = CommonTools.getLastId(queryPfDetailChargeId, this.mysqlQaDao) + 1;
        int business_order_01 = CommonTools.getRandomInt(8);
        double charge_detail_fee_01 = 22.00;
        double charge_detail_coupon_fee_01 = 2.29;
        double charge_detail_ecard_fee_01 = 3.88;
        double charge_detail_icard_fee_01 = 1.62;
        double charge_detail_transfer_fee_01 = 10.00;
        double charge_detail_pay_fee_01 = 14.21;
        int charge_detail_status_01 = 1;
        this.createPfChargeDetailData(pf_charge_detail_id_01, business_order_01, charge_detail_fee_01, charge_detail_coupon_fee_01, charge_detail_ecard_fee_01, charge_detail_icard_fee_01, charge_detail_transfer_fee_01, charge_detail_pay_fee_01, charge_detail_status_01, pf_charge_id);

        int pf_charge_detail_id_02 = CommonTools.getLastId(queryPfDetailChargeId, this.mysqlQaDao) + 1;
        int business_order_02 = CommonTools.getRandomInt(8);
        double charge_detail_fee_02 = 51.00;
        double charge_detail_coupon_fee_02 = 9.71;
        double charge_detail_ecard_fee_02 = 8.12;
        double charge_detail_icard_fee_02 = 3.38;
        double charge_detail_transfer_fee_02 = 0.00;
        double charge_detail_pay_fee_02 = 29.79;
        int charge_detail_status_02 = 1;
        this.createPfChargeDetailData(pf_charge_detail_id_02, business_order_02, charge_detail_fee_02, charge_detail_coupon_fee_02, charge_detail_ecard_fee_02, charge_detail_icard_fee_02, charge_detail_transfer_fee_02, charge_detail_pay_fee_02, charge_detail_status_02, pf_charge_id);


        this.queryParams.put("user_id", this.fan_id);
        this.queryParams.put("order_id",business_order_01);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        this.queryParams.put("pay_type",3);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallPlatformEpay(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", ims_paylog_tid,retBody.getJSONObject("data").getIntValue("trade_no") );
        Assert.assertEquals("返回值不符合预期",61.00,retBody.getJSONObject("data").getDouble("total"));

    }

}