package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ningzhao on 16-4-9.
 */
public class CorpEcardidsTest {
    private static Logger logger = LoggerFactory
            .getLogger(CorpEcardidsTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String,Object> queryParams = null;
    private JSONObject rechargeParams = new JSONObject();
    private JSONObject rechargeSn01Params = new JSONObject();
    private JSONObject fanParams = new JSONObject();
    private JSONObject ecardLimitParams = new JSONObject();
    private JSONObject ecardIdsObject = new JSONObject();
    private JSONArray ecardIds = new JSONArray();
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();

    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test

    public void testCorpEcardList() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();
        String price = "120.00";
        String zhenqian = "100.00";
        // 模拟ims_recharge数据
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id", recharge_id);
        rechargeParams.put("weid", 0);
        rechargeParams.put("price", price);
        rechargeParams.put("usednum", 0);
        rechargeParams.put("zhenqian", zhenqian);
        rechargeParams.put("kind", 2);
        rechargeParams.put("validity_type", 0);
        rechargeParams.put("charge_validity_type", 0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id", recharge_sncode_id);
        rechargeSn01Params.put("rid", recharge_id);
        rechargeSn01Params.put("sncode", String.valueOf(CommonTools.getRandomInt(9)));
        rechargeSn01Params.put("from_user", "NULL");
        rechargeSn01Params.put("user_type", 1);
        rechargeSn01Params.put("card_type", 1);
        rechargeSn01Params.put("price", price);
        rechargeSn01Params.put("zhenqian", zhenqian);
        rechargeSn01Params.put("used", 0);
        rechargeSn01Params.put("fan_id", fan_id);
        rechargeSn01Params.put("draw_time", current_time / 1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_ecard_limit的数据
        ecardLimitParams.put("id", recharge_id);
        generalRongChain04Data.GeneralEcardLimit(ecardLimitParams);

        this.ecardIds.add(recharge_sncode_id);
        this.ecardIdsObject.put("ecard_ids", this.ecardIds.toJSONString());
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.ecardIdsObject, "UTF_8");
        logger.info(building);

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallEcardids(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
    }




}
