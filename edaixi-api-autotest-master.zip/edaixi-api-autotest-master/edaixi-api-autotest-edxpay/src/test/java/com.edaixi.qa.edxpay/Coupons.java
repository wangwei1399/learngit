package com.edaixi.qa.edxpay;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by he_yi on 16/7/21.
 */
public class Coupons {
    private int id=0;
    private String couponSncode = "";
    private int money;//优惠券的金额
    private long beginTime;
    private long endTime;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private int fan_id = CommonTools.getFanId(mysqlQaDao);
    private int icoupon_id;

    public Coupons(int money, int fan_id){
        this(money);
        this.fan_id = fan_id;
    }

    public Coupons(int money){
        this.money = money;
        beginTime = strToUnix(CommonTools.getToday("yyyy-MM-dd HH:mm:ss"));
        endTime = strToUnix(CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 10));
    }

    public void create(){
        icoupon_id = CommonTools.getNewIdByTableName("ims_icoupon_list", mysqlQaDao);
        int coupon_category_id = 0;//优惠券支持的类目为0表示支持所有的类目
        String coupon_clothes_id = "";//优惠券支持的类目下面的衣物
        String coupon_exclusive_channels = "1,2,3,6,11";//优惠券支持的支付渠道，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int coupon_least_price = 5; //优惠券－满减的金额
        int coupon_city_id = 1;//优惠券支持的城市
        String coupon_user_type = "";//'1'=>'微信','2'=>'IOS','3'=>'安卓','6'=>'支付宝服务窗','7'=>'客服下单','8'=>'收衣店','9'=>'淘宝','10'=>'大众点评','11'=>'小米黄页','12'=>'360手机助手','13'=>'百度直达号','14'=>'糯米','15'=>'葡萄生活','16'=>'手机QQ','17'=>'绿地社区','18'=>'小E管家','19'=>'好搜','20'=>'浏览器','21'=>'搜狗生活','22'=>'hao到家';
        edxpayModuleService.createCouponData(icoupon_id, money, coupon_category_id, coupon_clothes_id, 1,coupon_exclusive_channels, coupon_least_price, coupon_city_id, coupon_user_type, beginTime, endTime);
        System.out.println();

        // 模拟优惠券的属性信息表
//        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        id = CommonTools.getNewIdByTableName("ims_icoupon_sncode", mysqlQaDao);
        couponSncode = String.valueOf(CommonTools.getRandomInt(9));
        edxpayModuleService.createCouponSncdeData(id, icoupon_id, couponSncode, fan_id, 0, 0);
    }

    public void delete(){
        String sql1 = "delete from ims_icoupon_list where id = "+icoupon_id;
        mysqlQaDao.execUpdateSql(sql1);
        String sql2 = "delete from ims_icoupon_sncode where id = "+id;
        mysqlQaDao.execUpdateSql(sql2);
    }

    private long strToUnix(String dateTime){
        Date date = null;
        try {
            date = dateFormat.parse(dateTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long time = date.getTime()/1000; //java时间是毫秒级别,时间戳是秒级别
        return time;
    }

    private String unixToStr(long unix){
        Date date = new Date(unix*1000);
        return dateFormat.format(date);
    }

    public int getId() {
        return id;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getBeginTime() {
        return unixToStr(beginTime);
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = strToUnix(beginTime);
    }

    public String getEndTime() {
        return unixToStr(endTime);
    }

    public void setEndTime(String endTime) {
        this.endTime = strToUnix(endTime);
    }

    public String getCouponSncode(){
        return couponSncode;
    }

    public long getBeginTimeUnix(){
        return beginTime*1000;
    }

    public long getEndTimeUnix(){
        return endTime*1000;
    }
}