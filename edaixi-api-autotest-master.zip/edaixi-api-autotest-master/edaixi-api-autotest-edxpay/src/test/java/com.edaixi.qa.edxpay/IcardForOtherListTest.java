package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.omg.CORBA.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.lang.Object;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class IcardForOtherListTest {

    private static Logger logger = LoggerFactory
            .getLogger(IcardForOtherListTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private JSONObject queryParams = new JSONObject();
    private Map<String, Object> queryMapParams = null;
    private Map<String, Object> vouchersParams = null;
    private Map<String, Object> payLogParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();

    // 操作充值的用户
    int fan_id = 0;

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryMapParams = new HashMap<String, Object>();
        this.vouchersParams = new HashMap<String, Object>();
        this.payLogParams = new HashMap<String, Object>();

        String fan_info = "select id from ims_fans order by id desc limit 1";
        fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }

    public void createVouchers(int id,int direction,double zhenqian,double jiaqian,int voucherable_id,String voucherable_type,int card_id,String card_type,int combine_type,int combine_vouchers_id,int pf_charge_id,int relation_id,int relation_status){
        vouchersParams.put("id",id);
        vouchersParams.put("direction",direction);
        vouchersParams.put("zhenqian",zhenqian);
        vouchersParams.put("jiaqian",jiaqian);
        vouchersParams.put("voucherable_id",voucherable_id);
        vouchersParams.put("voucherable_type", voucherable_type);
        vouchersParams.put("card_id",card_id);
        vouchersParams.put("card_type",card_type);
        vouchersParams.put("combine_type",combine_type);
        vouchersParams.put("combine_vouchers_id",combine_vouchers_id);
        vouchersParams.put("pf_charge_id",pf_charge_id);
        vouchersParams.put("relation_id",relation_id);
        vouchersParams.put("relation_status",relation_status);
        generalRongChain04Data.GeneralVouchers(vouchersParams);
    }

    @Test


    public void testIcardRechageForOthers() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String queryPaylog = "select plid from ims_paylog order by plid desc limit 1";
        ResultSet querypaylogInfo = mysqlQaDao.execQuerySql(queryPaylog);
        int paylog_id = querypaylogInfo.getInt("plid") + 1;
        String type = "wechat";
        double fee = 80.0;
        int status = 1;
        String module = "icard";
        int fan_id = 623565;
        int relation_fan_id = this.fan_id;
        this.payLogParams.put("id",paylog_id);
        this.payLogParams.put("type",type);
        this.payLogParams.put("fee",fee);
        this.payLogParams.put("status",status);
        this.payLogParams.put("module",module);
        this.payLogParams.put("fan_id",fan_id);
        this.payLogParams.put("relation_fan_id",relation_fan_id);
        generalRongChain04Data.GeneralPaylog(this.payLogParams);

        String queryVourchers = "select id from vouchers order by id  desc limit 1";
        ResultSet queryInfo = mysqlQaDao.execQuerySql(queryVourchers);
        int vouchers_id = queryInfo.getInt("id") + 1;
        int direction = 1;
        double zhenqian = 80.0;
        double jiaqian = 100.0;
        String voucherable_type = "Paylog";
        int card_id = 641350;
        String card_type = "Icard";
        int relation_status = 2;//1：客服操作成功状态；2：用户自己为他人充值操作成功状态位
        this.createVouchers(vouchers_id,direction,zhenqian,jiaqian,paylog_id,voucherable_type,card_id,card_type,0,0,0,this.fan_id,relation_status);


        this.queryMapParams.put("user_id",this.fan_id);

        JSONObject resultList = this.edxpayModuleService.CallIcardOtherList(this.queryMapParams, this.httpHead);
        logger.info(resultList.toString());
        Assert.assertTrue(resultList.getString("httpStatus").equals("200"));
        JSONObject BodyList = JSON.parseObject(resultList.getString("httpBody"));

        Assert.assertEquals("返回值不符合预期","18500133948",BodyList.getJSONArray("data").getJSONObject(0).getString("mobile"));
        Assert.assertEquals("返回值不符合预期",fee,BodyList.getJSONArray("data").getJSONObject(0).getDouble("trans_amount"));

    }



}
