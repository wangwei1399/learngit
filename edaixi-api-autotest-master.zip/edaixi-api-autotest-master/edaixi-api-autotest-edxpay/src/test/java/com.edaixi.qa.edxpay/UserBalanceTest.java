package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;

/**
 *
 * Created by he_yi on 16/3/2.
 */
public class UserBalanceTest {
    private static Logger logger = LoggerFactory.getLogger(UserBalanceTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    private final String sql_userTable_name = "ims_icard_card";
    private final String sql_userTable_field_balance ="coin";
    private final String sql_userTable_field_userid = "fan_id";

    private final String sql_voucharsTable_name ="vouchers";
    private final String sql_voucharsTable_filed_userid = "card_id";
    private final String sql_voucharsTable_file_moneyTrue = "zhenqian";
    private final String sql_voucharsTable_file_moneyFalse = "jiaqian";

    private final String sql_orderTable_name = "icard_malls";
    private final String sql_orderTable_filed_orderid = "mall_order_id";
    private final String sql_orderTable_filed_status = "status";//paid unpay refund
    private final String sql_orderTable_filed_money = "fee";

    DecimalFormat df = new DecimalFormat("#.00");

    private final String illegal_characters = "*;.!@~`*?/_-+=";
    private final String user_id = "1234567";

    public static int getRandomInt(int size){
        Random random = new Random();
        String mins ="1";
        String maxs = "9";

        for(int i=0;i<size-1;i++){
            mins+="1";
            maxs+="9";
        }

        int min = Integer.parseInt(mins);
        int max = Integer.parseInt(maxs);

        int s = random.nextInt(max) % (max - min +1)+min;
        return s;
    }

    private String getNotExistID(int id_size, String tableName, String filed_id_text){
        String id = String.valueOf(getRandomInt(id_size));
        String sql = "select * from "+tableName+" where "+filed_id_text+" = '"+id+"';";
        ResultSet result = mysqlQaDao.execQuerySql(sql);

        try {
            result.beforeFirst();//MysqlQaDao返回的结果集被last()了
            if(result.next()){
                logger.info("userID = "+result.getString(filed_id_text)+" already exits, create userID again");
                result.close();
                id = getNotExistID(id_size, tableName, filed_id_text);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    private String getNotExistUserId(int size){
        String user_id = getNotExistID(size, sql_userTable_name, sql_userTable_field_userid);
        return user_id;
    }

    private String getNotExistOrderId(int size){
        return getNotExistID(size, sql_orderTable_name, sql_orderTable_filed_orderid);
    }

    private String getUserId_ByBalance(String money){
        String uid = "";
        String sql = "select "+sql_userTable_field_userid
                +" from "+sql_userTable_name+" where "
                +sql_userTable_field_balance+"="+money+" limit 1;";
        ResultSet result = mysqlQaDao.execQuerySql(sql);

        try {
            result.beforeFirst();//MysqlQaDao返回的结果集被last()了
            if (result.next()){
                uid = result.getString(sql_userTable_field_userid);
            }else{
                uid = getNotExistUserId(5);
                String add_sql = "insert into "+sql_userTable_name+"(fan_id, coin) value("+uid+", "+money+");";
                logger.info("sql:"+sql);
                mysqlQaDao.execUpdateSql(add_sql);
                logger.info("insert user id is "+uid+" balance is 0");

                getUserId_ByBalance(money);
            }
            result.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return uid;
    }


    private String getUserBalance(String user_id){
        String balance = "";
        String sql = "select "+sql_userTable_field_balance+" from "+sql_userTable_name
                +" where "+sql_userTable_field_userid+" = '"+user_id+"';";

        ResultSet result = mysqlQaDao.execQuerySql(sql);
        try {
            result.beforeFirst();//MysqlQaDao返回的结果集被last()了
            while(result.next()){
                balance = result.getString(sql_userTable_field_balance);
            }
            result.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return balance;
    }

    /**
     * 修改账户余额
     * 因为新版本代码增加了发送短信功能,未绑定手机号码的user_id会报错
     * @param user_id
     * @param money
     * @return
     */
    private String setMoneyByUserId(String user_id, String money){
        String sql = "update "+sql_userTable_name+" set "+sql_userTable_field_balance+"="+money
                +" where "+sql_userTable_field_userid+" = "+user_id+";";

        if (mysqlQaDao.execUpdateSql(sql)){
            return money;
        }else{
            return "0.00";
        }
    }




    @After
    public void tearDown() {
        mysqlQaDao.close();


        logger.info("in teardown!");
    }


    @Test
    public void testBalanceQuery_illegalCharacters(){
        logger.info("test data: user_id is "+illegal_characters+"(illegal characters)");
        JSONObject result = edxpayModuleService.CallUserBalanceQuery(illegal_characters);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject j = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", "0.00",j.getString("coin"));
    }


    @Test
    public void testBalanceQuery_userIdNotExist(){
        String user_id = getNotExistUserId(5);
        logger.info("test data: user_id is "+user_id+"(not exist)");
        JSONObject result = edxpayModuleService.CallUserBalanceQuery(user_id);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject j = httpBody.getJSONObject("data");
        Assert.assertEquals("已与研发 何松涛 沟通,暂不处理", "0",j.getString("coin"));
    }

    @Test
    public void testBalanceQuery_userIdIsNull() throws UnsupportedEncodingException {
        logger.info("test data: not exits user_id is null");
        JSONObject result = edxpayModuleService.CallUserBalanceQuery("");
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0001",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "参数不能为空", URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));
    }

    @Test
    public void testBalanceQuery_userBalanceZero(){
        String uid = getUserId_ByBalance("0");
        logger.info("test data: user_id is "+uid+" balance is 0");
        JSONObject result = edxpayModuleService.CallUserBalanceQuery(uid);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject jarray = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", "0.00",jarray.getString("coin"));
    }

    @Test
    public void testBalanceQuery_userBalanceDecimals(){
        String balance = "3.54";
        String uid = getUserId_ByBalance(balance);
        logger.info("test data: user_id is "+uid+" balance is "+balance);
        JSONObject result = edxpayModuleService.CallUserBalanceQuery(uid);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject jarray = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", balance, jarray.getString("coin"));
    }

    @Test
    public void testBalanceQuery_userBalanceInteger(){
        String balance = "99999999.00";
        String uid = getUserId_ByBalance(balance);
        logger.info("test data: user_id is "+uid+" balance is "+balance);
        JSONObject result = edxpayModuleService.CallUserBalanceQuery(uid);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject jarray = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", String.valueOf(balance),jarray.getString("coin"));
    }




    /**
     * 扣除余额接口
     * 扣除全部余额,余额为两位小数
     * 参数 fee = 37.58
     * 用户账户余额为37.58
     */
    @Test
    public void testBalancePayment_spendAll(){
        String money = "37.58";
        String uid = this.user_id;
        setMoneyByUserId(uid, money); //add user by balance
        String order_id = getNotExistOrderId(5);
        logger.info("test data: user_id is "+uid+" mall_order id is "+order_id+" fee is "+money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, order_id, String.valueOf(money));
        logger.info("result json:"+result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject jarray = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", String.valueOf(money),jarray.getString("icard_paid"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("扣除余额失败", "0.00", lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 扣除比较大金额的情况
     * 参数 fee = 99999999.00
     */
    @Test
    public void testBalancePayment_spendBigMoney(){
        String money = "99999999.00";
        String uid = this.user_id;
        setMoneyByUserId(uid, money); //add user by balance
        String order_id = getNotExistOrderId(5);
        logger.info("test data: user_id is "+uid+" mall_order_id is "+order_id+" fee is "+money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, order_id, money);
        logger.info("result json:"+result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));
        JSONObject jarray = httpBody.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", money,jarray.getString("icard_paid"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("扣除余额失败", "0.00", lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 扣除金额大于账户余额
     */
    @Test
    public void testBalancePayment_spendMoneyOutNumberBalance() throws UnsupportedEncodingException {
        String balance_money= "85.00";
        String spend_money = "90.00";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance_money);   //add user by balance
        String order_id = getNotExistOrderId(5);
        logger.info("test data: user_id is "+uid+" mall_order_id is "+order_id+" fee is "+spend_money+" balance is "+balance_money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, order_id, spend_money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0110",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "余额不足",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("余额不应被扣除", balance_money, lastBalance);

    }

    /**
     * 扣除余额接口测试
     * 参数 mall_order_id 使用订单状态为已付状态的订单id
     */
    @Test
    public void testBalancePayment_orderPaid() throws SQLException, UnsupportedEncodingException {
        String order_id = getOrderIdByStatus(orderStatus.paid);
        String money = getOrderFee(order_id);
        String user_id = this.user_id;
        setMoneyByUserId(user_id, money);

        logger.info("test data: user_id is "+user_id+" mall_order_id is "+order_id+" fee is "+money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(user_id, order_id, money);
        logger.info("result json:"+result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","1020",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "此订单已经完成，不能再次支付",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(user_id);
        Assert.assertEquals("余额不应被扣除", money, lastBalance);

    }

    /**
     * 扣除余额接口测试
     * 参数 mall_order_id 使用订单状态为未付状态的订单id
     */
    @Test
    public void testBalancePayment_orderUnpay() throws UnsupportedEncodingException {
        String order_id = getOrderIdByStatus(orderStatus.unpay);
        String money = getOrderFee(order_id);
        String user_id = this.user_id;
        setMoneyByUserId(user_id, money);

        logger.info("test data: user_id is "+user_id+" mall_order_id is "+order_id+" fee is "+money);
        JSONObject result = edxpayModuleService.CallUserBalancePayment(user_id, order_id, money);
        logger.info("result json:"+result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(user_id);
        Assert.assertEquals("余额未扣除", "0.00", lastBalance);

    }

    /**
     * 扣除余额接口测试
     * 参数 mall_order_id 使用订单状态为已退款状态的订单id
     */
    @Test
    public void testBalancePayment_orderRefund() throws UnsupportedEncodingException {
        String order_id = getOrderIdByStatus(orderStatus.refund);
        String money = getOrderFee(order_id);
        String user_id = this.user_id;
        setMoneyByUserId(user_id, money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(user_id, order_id, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","1020",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "此订单已经完成，不能再次支付",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(user_id);
        Assert.assertEquals("余额不应被扣除", money, lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 参数 user_id 为特殊字符
     */
    @Test
    public void testBalancePayment_userIdIllegalCharacters(){
        String money = df.format(10);
        String uid = illegal_characters;
        String oid = getNotExistOrderId(5);

        logger.info("test data: user_id="+uid+" mall_order_id="+oid+"(not exist)"+" fee="+money);
        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, oid, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("已与研发 何松涛 沟通,暂不处理","0110",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "余额不足",java.net.URLDecoder.decode(httpBody.getString("resp_msg")));
    }

    /**
     * 扣除余额接口测试
     * 参数 mall_order_id 为特殊字符
     */
    @Test
    public void testBalancePayment_orderIdIllegalCharacters(){
        String balance = "60";
        String money = df.format(60.34);
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = illegal_characters;

        logger.info("test data: user_id="+uid+" mall_order_id="+oid+"(not exist)"+" fee="+money);
        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, oid, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("已与研发 何松涛 沟通,暂不处理","0110",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "余额不足",java.net.URLDecoder.decode(httpBody.getString("resp_msg")));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("余额扣除不正确", balance+".00", lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 参数 fee 为特殊字符
     */
    @Test
    public void testBalancePayment_moneyIllegalCharacters() throws UnsupportedEncodingException {
        String money = illegal_characters;
        String balance = "60";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getNotExistOrderId(5);

        logger.info("test data: user_id="+uid+" mall_order_id="+oid+"(not exist)"+" fee="+money);
        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, oid, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0010",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "金额不规范，需要非负浮点数",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("余额扣除不正确", df.format(Double.parseDouble(balance)), lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 参数 fee 为零
     */
    @Test
    public void testBalancePayment_moneyZero() throws UnsupportedEncodingException {
        String money = "0";
        String balance = df.format(60);
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getNotExistOrderId(8);

        logger.info("test data: user_id="+uid+" mall_order_id="+oid+"(not exist) fee="+money+" user balance is "+balance);
        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, oid, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0010",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "金额不规范，需要非负浮点数",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("余额扣除不正确", balance, lastBalance);
    }

    /**
     * 扣除余额接口测试
     * 扣除金额与订单金额不符
     * 参数 fee 与订单金额不一致
     */
    public void testBalancePayment_orderFeeNotMatch() throws UnsupportedEncodingException {
        String order_id = getOrderIdByStatus(orderStatus.paid);
        String money = getOrderFee(order_id);
        String order_fee = String.valueOf(Integer.parseInt(money)+1);
        String user_id = this.user_id;
        setMoneyByUserId(user_id, money);

        JSONObject result = edxpayModuleService.CallUserBalancePayment(user_id, order_id, order_fee);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","1019",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "订单金额与之不符",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(user_id);
        Assert.assertEquals("余额不应被扣除", money, lastBalance);
    }

    enum orderStatus{
        paid("paid"), unpay("unpay"), refund("refund");
        private String value = "";
        private orderStatus(String s){
            this.value = s;
        }

        public String getValue(){
            return value;
        }
    }
    private String getOrderIdByStatus(orderStatus status){
        String sql = "select "+sql_orderTable_filed_orderid+" from "+sql_orderTable_name
                +" where "+sql_orderTable_filed_status+"= '"+status+"' and  fee>0 order by id desc limit 1;";

        String oid = "";
        String money = String.valueOf(getRandomInt(2));
        ResultSet result = mysqlQaDao.execQuerySql(sql);
        try {
            result.beforeFirst();
            if (result.next()){
                oid = result.getString(sql_orderTable_filed_orderid);
                result.close();
            }else{
                oid = addOrderId(money, status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return oid;

    }
    private String addOrderId(String money, orderStatus status) {
        String oid = getNotExistOrderId(5);
        String tmpsql = "insert into icard_malls (fee, status, mall_order_id)value("+money+",'"+status.getValue()+"',"+oid+");";
        mysqlQaDao.execUpdateSql(tmpsql);

        String s2 = "select * from icard_malls where mall_order_id='"+oid+"';";
        ResultSet resultSet = mysqlQaDao.execQuerySql(s2);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                return oid;
            }else{
                logger.info("error!!!!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    private String getOrderFee(String order_id){
        String sql = "select fee from icard_malls where mall_order_id = '"+order_id+"' limit 1";
        logger.info("getOrderFee sql:"+sql);
        ResultSet result = mysqlQaDao.execQuerySql(sql);
        String fee = "";
        try {
            result.beforeFirst();
            while (result.next()){
                fee = result.getString(sql_orderTable_filed_money);
            }
        } catch (SQLException e) {

            e.printStackTrace();
        }

        return fee;
    }

    /**
     * 扣除余额接口
     * 参数 mall_order_id 为空
     * @throws UnsupportedEncodingException
     */
    @Test
    public void testBalancePayment_orderIdNull() throws UnsupportedEncodingException {
        String uid = this.user_id;
        setMoneyByUserId(uid, "10"); //add user
        String money = "5";
        logger.info("test data: user_id is "+uid+" mall_order_id is null"+"money is "+money);
        testBalancePayment_nullParam(uid, "", money);

    }

    /**
     * 扣除余额接口
     * 参数 fee 为空
     * @throws UnsupportedEncodingException
     */
    @Test
    public void testBalancePayment_moneyIsNull() throws UnsupportedEncodingException {
        String uid = this.user_id;
        setMoneyByUserId(uid, "90"); //add user
        String order_id = getNotExistOrderId(5);
        logger.info("test data: user_id is "+uid+" mall_order_id is "+order_id+" fee is null");
//        testBalancePayment_nullParam(uid, order_id, "");
        JSONObject result = edxpayModuleService.CallUserBalancePayment(uid, order_id, "");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0010",httpBody.getString("resp_code"));
    }


    /**
     * 扣除余额接口
     * 参数 user_id 为空
     * @throws UnsupportedEncodingException
     */
    @Test
    public void testBalancePayment_userIdIsNull() throws UnsupportedEncodingException {
        String money = "90";
        String order_id = getNotExistOrderId(5);
        logger.info("test data: user_id is null mall_order_id is "+order_id+" fee is "+money);
        testBalancePayment_nullParam("", order_id, money);
    }

    private void testBalancePayment_nullParam(String userId, String orderId, String money) throws UnsupportedEncodingException {
        JSONObject result = edxpayModuleService.CallUserBalancePayment(userId, orderId, money);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0001",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "参数不能为空",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));
    }




    /**
     * 退款接口测试
     * 参数 fee 为零
     * 参数 refund_type 为0
     */
    @Test
    public void testBalanceRefund_moneyZero0(){
        testBalanceRefund_moneyZero(0);
    }

    /**
     * 退款接口测试
     * 参数 fee 为零
     * 参数 refund_type 为1
     */
    @Test
    public void testBalanceRefund_moneyZero1(){
        testBalanceRefund_moneyZero(1);
    }
    private void testBalanceRefund_moneyZero(int refund_type){
        String balance = "10";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = addOrderId("0", orderStatus.paid);
        String refund_money = "0";

        logger.info("test data: user balance is "+balance+" user_id is "+uid+" mall_order_id is "+oid+" " +
                "fee is "+refund_money+"refund_type is "+refund_type+" order status is "+orderStatus.paid);

        JSONObject result = edxpayModuleService.CallUserBalanceRefund(uid, oid, refund_money, refund_type);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",httpBody.getString("resp_msg"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("退款金额不正确", df.format(Double.parseDouble(balance)),lastBalance);

        String r_type = getRefundType(oid);
        Assert.assertEquals("退款类型不正确", String.valueOf(refund_type),r_type);
    }



    /**
     * 退款接口测试
     *参数 refund_type 为0 取消订单退款
     */
    @Test
    public void testBalanceRefund_success0() throws UnsupportedEncodingException, SQLException {
        testBalanceRefund_success(0);
    }

    /**
     * 退款接口测试
     *参数 refund_type 为1 订单失败退款
     */
    @Test
    public void testBalanceRefund_success1() throws UnsupportedEncodingException, SQLException {
        testBalanceRefund_success(1);
    }

    private void testBalanceRefund_success(final int refund_type) throws UnsupportedEncodingException, SQLException {
        String balance = "10";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getOrderIdByStatus(orderStatus.paid);
        String refund_money = getOrderFee(oid);

        logger.info("test data: user balance is "+balance+" user_id is "+uid+" mall_order_id is "+oid+" " +
                "fee is "+refund_money+"refund_type is "+refund_type+" order status is "+orderStatus.paid);

        JSONObject result = edxpayModuleService.CallUserBalanceRefund(uid, oid, refund_money, refund_type);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","0000",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "succ",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        double m = Double.parseDouble(balance) + Double.parseDouble(refund_money);
        String expect_money = df.format(m);

        String actual_money = getUserBalance(uid);
        Assert.assertEquals("退款金额未退回账户余额中", expect_money, actual_money);


        Assert.assertEquals("退款类型不正确", String.valueOf(refund_type), getRefundType(oid));
    }

    private String getRefundType(String order_id){
        String re_type = "";
        String sql = "select refund_type from icard_malls where mall_order_id='"+order_id+"';";
        ResultSet r = mysqlQaDao.execQuerySql(sql);
        try {
            r.beforeFirst();
            while (r.next()){
                re_type = r.getString("refund_type");
            }
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return re_type;
    }

    /**
     * 退款接口测试
     * 订单已退,不能重复退款
     * @throws UnsupportedEncodingException
     */
    @Test
    public void testBalanceRefund_orderRefund() throws UnsupportedEncodingException {
        String balance = "10";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getOrderIdByStatus(orderStatus.refund);
        String refund_money = getOrderFee(oid);

        logger.info("test data: user balance is "+balance+" user_id is "+uid+" mall_order_id is "+oid+" " +
                "fee is "+refund_money+" order status is "+orderStatus.refund);

        JSONObject result = edxpayModuleService.CallUserBalanceRefund(uid, oid, refund_money, 0);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","1022",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "此订单已经退款，不能重复退款",java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));


        String lastBalance = getUserBalance(uid);
        String d_balance = df.format(Double.parseDouble(balance));
        Assert.assertEquals("退款金额不正确", d_balance,lastBalance);
    }

    /**
     * 退款接口测试
     * 退款订单不存在
     **/
    @Test
    public void testBalanceRefund_orderNotExist() throws UnsupportedEncodingException {
        String balance = "10";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getNotExistOrderId(9);
        String money = "9";

        logger.info("test data: user balance is "+balance+" user_id is "+uid+" mall_order_id is "+oid+"(not exist)" +
                "fee is "+money);

        JSONObject result = edxpayModuleService.CallUserBalanceRefund(uid, oid, money, 1);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","1023",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "此订单不存在", java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(uid);
        Assert.assertEquals("退款金额不正确", df.format(Double.parseDouble(balance)),lastBalance);

    }

    /**
     * 退单接口测试
     * 未完成支付订单,无法退款
     */
    @Test
    public void testBalanceRefund_orderUnpay() throws UnsupportedEncodingException {
        String balance = "10";
        String uid = this.user_id;
        setMoneyByUserId(uid, balance);
        String oid = getOrderIdByStatus(orderStatus.unpay);
        String money = getOrderFee(oid);

        logger.info("test data: user balance is "+balance+" user_id is "+uid+" mall_order_id is "+oid+ "fee is "+money+" order status"+orderStatus.unpay);

        JSONObject result = edxpayModuleService.CallUserBalanceRefund(uid, oid, money, 1);
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject httpBody = JSON.parseObject(result.getString("httpBody"));
        logger.info("result json:"+httpBody.toJSONString());
        Assert.assertEquals("返回值不符合预期","1021",httpBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", "此订单未支付，不能退款", java.net.URLDecoder.decode(httpBody.getString("resp_msg"), "utf-8"));

        String lastBalance = getUserBalance(uid);
        String b_balance = df.format(Double.parseDouble(balance));
        Assert.assertEquals("退款金额不正确", b_balance,lastBalance);
    }


}
