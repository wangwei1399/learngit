package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.omg.CORBA.NameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by ningzhao on 16-4-18.
 */
public class ChargeIndexTest {

    private static Logger logger = LoggerFactory
            .getLogger(ChargeIndexTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private JSONObject couponList = new JSONObject();
    private JSONObject couponSncodeParams = new JSONObject();
    private JSONObject orderInfoParams = new JSONObject();
    private JSONObject orderInfoParams01 = new JSONObject();
    private JSONObject OrderParams = new JSONObject();
    private JSONObject fanParams = new JSONObject();
    private JSONObject rechargeParams = new JSONObject();
    private JSONObject rechargeSn01Params = new JSONObject();
    private JSONObject icardCardParams = new JSONObject();
    private JSONObject clothWithPrice0001 = new JSONObject();
    private JSONObject clothWithPrice0002 = new JSONObject();
    private JSONObject clothWithPrice0101 = new JSONObject();
    private Map<String, Object> subFeeParam = null;
    private Map<String, Object> deliveryParam = null;

    private JSONArray orderInfo = new JSONArray();
    private JSONArray clothWithPrice = new JSONArray();
    private JSONArray delivery = new JSONArray();
    private JSONArray subFee = new JSONArray();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.deliveryParam = new HashMap<String, Object>();
        this.subFeeParam = new HashMap<String, Object>();

    }

    @After
    public void tearDown() {
        deleteCoupons(couponList);
        mysqlQaDao.close();

        logger.info("in teardown!");
    }

    private void deleteCoupons(JSONObject couponList){
        if (couponList.containsKey("id")){
            int id = couponList.getInteger("id");
            String sql = "delete from ims_icoupon_sncode WHERE cid ="+id;
            mysqlQaDao.execUpdateSql(sql);
            sql = "delete from ims_icoupon_list where id="+id;
            mysqlQaDao.execUpdateSql(sql);
        }

    }

    @Test
    public void testChargeIndex() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long current_time = System.currentTimeMillis();

        String sncode = String.valueOf(CommonTools.getRandomInt(9));

        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        fanParams.put("id", fan_id);
        fanParams.put("mobile", mobile);
        generalRongChain04Data.GeneralImsFans(fanParams);

        // 模拟ims_icoupon_list数据－用户此订单上使用的优惠券
        String price = "12.00";
        String icoupon_list_info = "select id from ims_icoupon_list order by id desc limit 1;";
        int icoupon_id = CommonTools.getLastId(icoupon_list_info, mysqlQaDao) + 1;
        couponList.put("id", icoupon_id);
        couponList.put("coupon_price", price);
        couponList.put("totalnum", 0);
        couponList.put("discount_type",1);
        couponList.put("usednum", 0);
        couponList.put("category_id",0);
        couponList.put("clothes_id","NULL");
        couponList.put("exclusive_channels","1,2,3,6,11");
        couponList.put("least_price",50);
        couponList.put("city_id",1);
        couponList.put("user_types",3);
        generalRongChain04Data.GeneralIcouponList(couponList);
        // 模拟ims_icoupon_sncode表的数据
        String icoupon_sncode_info = "select id from ims_icoupon_sncode order by id desc limit 1";
        int icoupon_sncode_id = CommonTools.getLastId(icoupon_sncode_info, mysqlQaDao) + 1;
        couponSncodeParams.put("id",icoupon_sncode_id);
        couponSncodeParams.put("cid",icoupon_id);
        couponSncodeParams.put("sncode",CommonTools.getRandomInt(9));
        couponSncodeParams.put("fan_id",fan_id);
        couponSncodeParams.put("used",0);
        generalRongChain04Data.GeneralIcouponSncode(couponSncodeParams);

        // 模拟ims_recharge数据－用户支付的时候选择E卡
        String zhenqian = "10.00";
        String recharge_info = "select id from ims_recharge order by id desc limit 1;";
        int recharge_id = CommonTools.getLastId(recharge_info, mysqlQaDao) + 1;
        rechargeParams.put("recharge_id",recharge_id);
        rechargeParams.put("weid",0);
        rechargeParams.put("price",price);
        rechargeParams.put("usednum",0);
        rechargeParams.put("zhenqian",zhenqian);
        rechargeParams.put("kind",2);
        rechargeParams.put("validity_type",0);
        rechargeParams.put("charge_validity_type",0);
        generalRongChain04Data.GeneralRecharge(rechargeParams);
        // 模拟第一条ims_recharge_sncode的数据
        String rechargeSncode = "select id from ims_recharge_sncode order by id desc limit 1";
        int recharge_sncode_id = CommonTools.getLastId(rechargeSncode, mysqlQaDao) + 1;
        rechargeSn01Params.put("recharge_sncode_id", recharge_sncode_id);
        rechargeSn01Params.put("rid", recharge_id);
        rechargeSn01Params.put("sncode", sncode);
        rechargeSn01Params.put("from_user", "NULL");
        rechargeSn01Params.put("user_type", 1);
        rechargeSn01Params.put("card_type", 1);
        rechargeSn01Params.put("price", price);
        rechargeSn01Params.put("zhenqian", zhenqian);
        rechargeSn01Params.put("used", 0);
        rechargeSn01Params.put("fan_id", fan_id);
        rechargeSn01Params.put("draw_time", current_time / 1000);
        generalRongChain04Data.GeneralRechargeSncode(rechargeSn01Params);

        // 模拟ims_icard_card的数据
        String icardCard = "select id from ims_icard_card order by id desc limit 1";
        int icard_card_id = CommonTools.getLastId(icardCard,mysqlQaDao) +1;
        icardCardParams.put("id",icard_card_id);
        icardCardParams.put("card_number",sncode);
        icardCardParams.put("coin",50.00);
        icardCardParams.put("money",100.00);
        icardCardParams.put("updatetime",current_time/1000);
        icardCardParams.put("dateline",current_time/1000);
        icardCardParams.put("fan_id",fan_id);
        icardCardParams.put("zhenqian",1200.00);
        generalRongChain04Data.GeneralEcardCard(icardCardParams);

        // 模拟订单表的数据-订单金额51，运费为0
        String orderIdQuery = "select id from ims_washing_order order by id desc limit 1";
        int order_id = CommonTools.getLastId(orderIdQuery,mysqlQaDao) + 1;
        OrderParams.put("order_id",order_id);
        OrderParams.put("order_sn",CommonTools.getOrdersn(order_id));
        OrderParams.put("status",1);
        OrderParams.put("status_delivery",1);
        OrderParams.put("pay_status",0);
        OrderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
        OrderParams.put("washing_time","14:00~16:00");
        OrderParams.put("old_category_id",1);
        OrderParams.put("totalprice","51");
        OrderParams.put("delivery_fee","0");
        OrderParams.put("fan_id",fan_id);
        generalRongChain04Data.GeneralOrder(OrderParams);

        this.queryParams.put("user_id",fan_id);
        this.clothWithPrice0001.put("id",611);
        this.clothWithPrice0001.put("num",1);
        this.clothWithPrice0001.put("price","39.0");
        this.clothWithPrice0001.put("clothes_id",39);
        this.clothWithPrice0001.put("clothes_name","羽绒服");
        this.clothWithPrice0002.put("id",612);
        this.clothWithPrice0002.put("num",1);
        this.clothWithPrice0002.put("price","12.0");
        this.clothWithPrice0002.put("clothes_id",46);
        this.clothWithPrice0002.put("clothes_name","短裤");
        this.clothWithPrice.add(0,clothWithPrice0001);
        this.clothWithPrice.add(1,clothWithPrice0002);
        this.orderInfoParams.put("id", order_id);
        this.orderInfoParams.put("ordersn",CommonTools.getOrdersn(order_id));
        this.orderInfoParams.put("category_id",1);
        this.orderInfoParams.put("cloth_with_price",this.clothWithPrice);
        this.orderInfoParams.put("city_id",1);
        this.orderInfoParams.put("price",51);
        this.orderInfo.add(0,this.orderInfoParams);
        this.subFeeParam.put("order_id",order_id);
        this.subFeeParam.put("fee",0);
        this.subFee.add(0,this.subFeeParam);
        this.deliveryParam.put("total_fee",0);
        this.deliveryParam.put("sub_fee",this.subFee);

        this.queryParams.put("delivery",this.deliveryParam);
        this.queryParams.put("order_info",this.orderInfo);
        this.queryParams.put("pay_type",2);//微信支付，系统会默认扣款顺序先从余额中扣除
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type",3);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        // 调用接口
        JSONObject result = this.edxpayModuleService.CallChargeIndex(buildString, this.httpHead);
        logger.info(result.toJSONString());

        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","succ",URLDecoder.decode(retBody.getString("resp_msg"),"UTF-8"));
        Assert.assertEquals("返回值不符合预期",fan_id,retBody.getJSONObject("data").getIntValue("user_id"));
        Assert.assertEquals("返回值不符合预期","51.00",retBody.getJSONObject("data").getString("order_amount"));
        Assert.assertEquals("返回值不符合预期","0.00",retBody.getJSONObject("data").getString("trans_amount"));
        Assert.assertEquals("返回值不符合预期","有1张优惠券可用",URLDecoder.decode(retBody.getJSONObject("data").getJSONObject("pay_text").getString("coupon_text"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","无可用e卡",URLDecoder.decode(retBody.getJSONObject("data").getJSONObject("pay_text").getString("ecard_text"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","余额50.00",URLDecoder.decode(retBody.getJSONObject("data").getJSONObject("pay_text").getString("icard_default_text"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","",URLDecoder.decode(retBody.getJSONObject("data").getJSONObject("pay_text").getString("icard_text"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期","0",retBody.getJSONObject("data").getString("icard_amount"));
        Assert.assertEquals("返回值不符合预期","50.00",retBody.getJSONObject("data").getString("icard_coin"));
        Assert.assertEquals("返回值不符合预期","51.00",retBody.getJSONObject("data").getString("third_amount"));
        Assert.assertEquals("返回值不符合预期","[6,2,11,3]",retBody.getJSONObject("data").getJSONObject("third").getString("all"));
        Assert.assertEquals("返回值不符合预期","[6,2,11,3]",retBody.getJSONObject("data").getJSONObject("third").getString("usable"));
        Assert.assertEquals("返回值不符合预期",1,retBody.getJSONObject("data").getIntValue("choose"));//是否可以切换E卡\优惠券等
        Assert.assertEquals("返回值不符合预期",0,retBody.getJSONObject("data").getIntValue("type"));//0是首次访问,1是非首次访问



    }

}
