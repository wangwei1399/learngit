package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class RcardIndexTest {

    private static Logger logger = LoggerFactory
            .getLogger(RcardIndexTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private JSONObject queryParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }


    @Test
    /**
     *
     * @author ningyao.zn
     * 实体卡充值
     * 场景：实体卡没有使用过、用户没有绑定过实体卡
     *
     */
    public void testRCardIndex() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int user_id = (int)(currentTime % 1000000);
        int rcard_id = (int)(currentTime % 10000000);
        int icard_id = (int)(currentTime % 1000000);
        String card_user = String.valueOf((currentTime % 10000000));
        String card_pwd = String.valueOf((currentTime % 1000000));
        int card_number = (int)(currentTime % 100000000);
        int icard_id_old = 0;

        String insertRcardMembers = "INSERT INTO `ims_rcard_members` (`id`, `rid`, `sn_password`, `money`, `icardid`, `xiaoshoujia`, `chongzhijine`, `zhenqian`, `sn_code`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t("+ rcard_id + ", 9, '" + card_pwd + "', 100.00, "+ icard_id_old + ", 0, 0, 120.00, "+ card_user + ", '2016-01-19 10:57:17', '2016-01-19 10:57:17');\n";
        String insertIcardCard = "INSERT INTO `ims_icard_card` (`id`, `cardpre`, `cardno`, `coin`, `money`, `updatetime`, `dateline`, `fan_id`, `zhenqian`, `rcard_sn`)\n" +
                "VALUES\n" +
                "\t("+ icard_id + ", '', " + card_number + ", 50.00, 100.00, 1450335200, 1404476292, "+ user_id + ", 1200.00, NULL);\n";
        mysqlQaDao.execUpdateSql(insertRcardMembers);
        mysqlQaDao.execUpdateSql(insertIcardCard);

        this.queryParams.put("user_id",user_id);
        this.queryParams.put("card_user",card_user);
        this.queryParams.put("card_pwd",card_pwd);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");
        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        // 验证ims_rcard_members表中数据正确
        String queryRcardMembers = "select sn_password,money,icardid,zhenqian,sn_code from ims_rcard_members where sn_code = " + card_user + "";
        ResultSet queryRcardMembersInfo = mysqlQaDao.execQuerySql(queryRcardMembers);
        Assert.assertEquals("返回值不符合预期","0.00",queryRcardMembersInfo.getString("money"));
        Assert.assertEquals("返回值不符合预期","0.00",queryRcardMembersInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期",icard_id,queryRcardMembersInfo.getInt("icardid"));

        // 验证vouchers表中数据正确
        String queryVouchersRcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ rcard_id + " and card_type = 'Rcard'";
        ResultSet queryVouthersRcardInfo = mysqlQaDao.execQuerySql(queryVouchersRcard);
        Assert.assertEquals("返回值不符合预期",2,queryVouthersRcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","-120.00",queryVouthersRcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","-100.00",queryVouthersRcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",icard_id,queryVouthersRcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersRcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",rcard_id,queryVouthersRcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Rcard",queryVouthersRcardInfo.getString("card_type"));

        // 验证ims_icard_card表中数据正确
        String queryIcardCard = "select id,cardno,coin,fan_id,zhenqian,rcard_sn from ims_icard_card where id = " + icard_id + "";
        ResultSet queryIcardCardInfo  = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期","150.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期",user_id,queryIcardCardInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期","1320.00",queryIcardCardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期",card_user,queryIcardCardInfo.getString("rcard_sn"));

        //验证vouchers表中的数据正确
        String queryVouchersIcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ icard_id + " and card_type = 'Icard'";
        ResultSet queryVouthersIcardInfo = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期",3,queryVouthersIcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","120.00",queryVouthersIcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","100.00",queryVouthersIcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",rcard_id,queryVouthersIcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","Rcard",queryVouthersIcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",icard_id,queryVouthersIcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersIcardInfo.getString("card_type"));

    }


    @Test
    /**
     *
     * @author ningyao.zn
     * 实体卡充值
     * 场景：实体卡使用过了
     *
     */
    public void testRCardIndexByUesed() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int user_id = (int)(currentTime % 1000000);
        int rcard_id = (int)(currentTime % 1000000);
        int icard_id = (int)(currentTime % 1000000);
        String card_user = String.valueOf((currentTime % 10000000));
        String card_pwd = String.valueOf((currentTime % 1000000));
        int card_number = (int)(currentTime);

        String insertRcardMembers = "INSERT INTO `ims_rcard_members` (`id`, `rid`, `sn_password`, `money`, `icardid`, `xiaoshoujia`, `chongzhijine`, `zhenqian`, `sn_code`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t("+ rcard_id + ", 9, '" + card_pwd + "', 0.00, "+ icard_id + ", 0, 0, 0.00, "+ card_user + ", '2016-01-19 10:57:17', '2016-01-19 10:57:17');\n";
        String insertIcardCard = "INSERT INTO `ims_icard_card` (`id`, `cardpre`, `cardno`, `coin`, `money`, `updatetime`, `dateline`, `fan_id`, `zhenqian`, `rcard_sn`)\n" +
                "VALUES\n" +
                "\t("+ icard_id + ", '', " + card_number + ", 50.00, 100.00, 1450335200, 1404476292, "+ user_id + ", 1200.00, NULL);\n";
        mysqlQaDao.execUpdateSql(insertRcardMembers);
        mysqlQaDao.execUpdateSql(insertIcardCard);
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("card_user",card_user);
        this.queryParams.put("card_pwd",card_pwd);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");
        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").contains("2001"));

    }

    @Test
    /**
     *
     * @author ningyao.zn
     * 实体卡充值
     * 场景：用户不存在
     *
     */
    public void testRCardIndexByInvalidUser() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int user_id = (int)(currentTime % 10000000);
        int rcard_id = (int)(currentTime % 1000000);
        String card_user = String.valueOf((currentTime % 10000000));
        String card_pwd = String.valueOf((currentTime % 1000000));
        int icard_id_old = 0;

        String insertRcardMembers = "INSERT INTO `ims_rcard_members` (`id`, `rid`, `sn_password`, `money`, `icardid`, `xiaoshoujia`, `chongzhijine`, `zhenqian`, `sn_code`, `created_at`, `updated_at`)\n" +
                "VALUES\n" +
                "\t("+ rcard_id + ", 9, '" + card_pwd + "', 100.00, "+ icard_id_old + ", 0, 0, 120.00, "+ card_user + ", '2016-01-19 10:57:17', '2016-01-19 10:57:17');\n";
        mysqlQaDao.execUpdateSql(insertRcardMembers);

        this.queryParams.put("user_id",user_id);
        this.queryParams.put("card_user",card_user);
        this.queryParams.put("card_pwd",card_pwd);
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
        String building = URLBuilder.httpBuildQuery(this.queryParams, "UTF_8");
        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CallRcardIndex(building, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_code").contains("0000"));
        Assert.assertTrue("返回值不符合预期",loginBody.getString("resp_msg").contains("succ"));
        // 验证ims_rcard_members表中数据正确
        String queryRcardMembers = "select sn_password,money,icardid,zhenqian,sn_code from ims_rcard_members where sn_code = " + card_user + "";
        ResultSet queryRcardMembersInfo = mysqlQaDao.execQuerySql(queryRcardMembers);
        Assert.assertEquals("返回值不符合预期","0.00",queryRcardMembersInfo.getString("money"));
        Assert.assertEquals("返回值不符合预期","0.00",queryRcardMembersInfo.getString("zhenqian"));
        String queryIcardInfo = "select id from ims_icard_card where fan_id = " + user_id + "";
        ResultSet queryIcardId = mysqlQaDao.execQuerySql(queryIcardInfo);
        Assert.assertEquals("返回值不符合预期",queryIcardId.getInt("id"),queryRcardMembersInfo.getInt("icardid"));

        // 验证vouchers表中数据正确
        String queryVouchersRcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ rcard_id + " and card_type = 'Rcard'";
        ResultSet queryVouthersRcardInfo = mysqlQaDao.execQuerySql(queryVouchersRcard);
        Assert.assertEquals("返回值不符合预期",2,queryVouthersRcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","-120.00",queryVouthersRcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","-100.00",queryVouthersRcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",queryIcardId.getInt("id"),queryVouthersRcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersRcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",rcard_id,queryVouthersRcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Rcard",queryVouthersRcardInfo.getString("card_type"));

        // 验证ims_icard_card表中数据正确
        String queryIcardCard = "select id,cardno,coin,fan_id,zhenqian,rcard_sn from ims_icard_card where id = " + queryIcardId.getInt("id") + "";
        ResultSet queryIcardCardInfo  = mysqlQaDao.execQuerySql(queryIcardCard);
        Assert.assertEquals("返回值不符合预期","100.00",queryIcardCardInfo.getString("coin"));
        Assert.assertEquals("返回值不符合预期",user_id,queryIcardCardInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期","120.00",queryIcardCardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期",card_user,queryIcardCardInfo.getString("rcard_sn"));

        //验证vouchers表中的数据正确
        String queryVouchersIcard = "select direction,zhenqian,jiaqian,voucherable_id,voucherable_type,card_id,card_type from vouchers where card_id = "+ queryIcardId.getInt("id") + " and card_type = 'Icard'";
        ResultSet queryVouthersIcardInfo = mysqlQaDao.execQuerySql(queryVouchersIcard);
        Assert.assertEquals("返回值不符合预期",3,queryVouthersIcardInfo.getInt("direction"));
        Assert.assertEquals("返回值不符合预期","120.00",queryVouthersIcardInfo.getString("zhenqian"));
        Assert.assertEquals("返回值不符合预期","100.00",queryVouthersIcardInfo.getString("jiaqian"));
        Assert.assertEquals("返回值不符合预期",rcard_id,queryVouthersIcardInfo.getInt("voucherable_id"));
        Assert.assertEquals("返回值不符合预期","Rcard",queryVouthersIcardInfo.getString("voucherable_type"));
        Assert.assertEquals("返回值不符合预期",queryIcardId.getInt("id"),queryVouthersIcardInfo.getInt("card_id"));
        Assert.assertEquals("返回值不符合预期","Icard",queryVouthersIcardInfo.getString("card_type"));
    }



}
