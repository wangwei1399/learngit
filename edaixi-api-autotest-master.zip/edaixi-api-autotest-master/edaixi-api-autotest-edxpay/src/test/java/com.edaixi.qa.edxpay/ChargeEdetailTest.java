package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * 小e代付订单明细
 * Created by ningzhao on 16-5-17
 */
public class ChargeEdetailTest {

    private static Logger logger = LoggerFactory
            .getLogger(ChargeEdetailTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> fanParams = null;
    long current_time = System.currentTimeMillis();
    public int fan_id = 0;

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.fanParams = new HashMap<String, Object>();
        // 模拟ims_fan表数据
        String fan_info = "select id from ims_fans order by id desc limit 1";
        this.fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String mobile = "100" + CommonTools.getRandomInt(8);
        this.fanParams.put("id", this.fan_id);
        this.fanParams.put("mobile", mobile);
        this.generalRongChain04Data.GeneralImsFans(this.fanParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();

        logger.info("in teardown!");
    }




    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-19
     * @Scenario:用户支付使用优惠券和E卡和余额和第三方支付
     *   when:优惠券支持合并订单中的所有订单
     *   where:
     *   how:
     *   then:
     */
    public void testChargeEdetail() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String queryPfChargeId = "select id from pf_charge order by id desc limit 1";
        int pf_charge_id = CommonTools.getLastId(queryPfChargeId, this.mysqlQaDao) + 1;
        // type 是支持的支付方式，1是余额，2是微信，3是现金，6是支付宝，11是百度钱包
        int type = 2;
        double fee = 73.00;
        double coupon_fee = 12.00;
        double ecard_fee = 12.00;
        double icard_fee = 5.00;
        double transfer_fee = 10.00;
        double pay_fee = 44.00;
        int status = 1;
        int user_type = 3;
        edxpayModuleService.createPfChargeData(pf_charge_id, this.fan_id,type, fee, coupon_fee, ecard_fee, icard_fee, transfer_fee, pay_fee, status, user_type);

        String queryPfDetailChargeId = "select id from pf_charge_detail order by id desc limit 1";
        int pf_charge_detail_id_01 = CommonTools.getLastId(queryPfDetailChargeId, this.mysqlQaDao) + 1;
        int business_order_01 = CommonTools.getRandomInt(8);
        double charge_detail_fee_01 = 22.00;
        double charge_detail_coupon_fee_01 = 2.29;
        double charge_detail_ecard_fee_01 = 3.88;
        double charge_detail_icard_fee_01 = 1.62;
        double charge_detail_transfer_fee_01 = 10.00;
        double charge_detail_pay_fee_01 = 14.21;
        int charge_detail_status_01 = 1;
        edxpayModuleService.createPfChargeDetailData(pf_charge_detail_id_01, this.fan_id,business_order_01, charge_detail_fee_01, charge_detail_coupon_fee_01, charge_detail_ecard_fee_01, charge_detail_icard_fee_01, charge_detail_transfer_fee_01, charge_detail_pay_fee_01, charge_detail_status_01, pf_charge_id);

        int pf_charge_detail_id_02 = CommonTools.getLastId(queryPfDetailChargeId, this.mysqlQaDao) + 1;
        int business_order_02 = CommonTools.getRandomInt(8);
        double charge_detail_fee_02 = 51.00;
        double charge_detail_coupon_fee_02 = 9.71;
        double charge_detail_ecard_fee_02 = 8.12;
        double charge_detail_icard_fee_02 = 3.38;
        double charge_detail_transfer_fee_02 = 0.00;
        double charge_detail_pay_fee_02 = 29.79;
        int charge_detail_status_02 = 1;
        edxpayModuleService.createPfChargeDetailData(pf_charge_detail_id_02, this.fan_id,business_order_02, charge_detail_fee_02, charge_detail_coupon_fee_02, charge_detail_ecard_fee_02, charge_detail_icard_fee_02, charge_detail_transfer_fee_02, charge_detail_pay_fee_02, charge_detail_status_02, pf_charge_id);

        this.queryParams.put("user_id", this.fan_id);
        this.queryParams.put("order_id", business_order_01);
        this.queryParams.put("business_id", 11);
        this.queryParams.put("user_type", 3);
        logger.info(this.queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        this.httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        JSONObject result = this.edxpayModuleService.CallChargeEdetail(buildString, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        logger.info(URLDecoder.decode(retBody.getString("resp_msg"), "UTF-8"));
        Assert.assertEquals("返回值不符合预期", "succ", retBody.getString("resp_msg"));
        Assert.assertEquals("返回值不符合预期", "0000", retBody.getString("resp_code"));
        Assert.assertEquals("返回值不符合预期", this.fan_id, retBody.getJSONObject("data").getIntValue("user_id"));
        Assert.assertEquals("返回值不符合预期",73.00, retBody.getJSONObject("data").getDouble("order_amount"));
        Assert.assertEquals("返回值不符合预期",10.00, retBody.getJSONObject("data").getDouble("trans_amount"));
        Assert.assertEquals("返回值不符合预期",12.00, retBody.getJSONObject("data").getDouble("coupon_amount"));
        Assert.assertEquals("返回值不符合预期",12.00, retBody.getJSONObject("data").getDouble("ecard_amount"));
        Assert.assertEquals("返回值不符合预期",5.00, retBody.getJSONObject("data").getDouble("icard_amount"));
        Assert.assertEquals("返回值不符合预期",44.00, retBody.getJSONObject("data").getDouble("third_amount"));
        Assert.assertEquals("返回值不符合预期","[6,2,11,3]", retBody.getJSONObject("data").getJSONObject("third").getString("all"));
        Assert.assertEquals("返回值不符合预期","[6,2,11,3]", retBody.getJSONObject("data").getJSONObject("third").getString("usable"));


    }

}