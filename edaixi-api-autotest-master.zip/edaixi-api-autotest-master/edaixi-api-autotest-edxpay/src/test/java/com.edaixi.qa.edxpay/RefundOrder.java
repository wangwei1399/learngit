package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.CreateOrderByStatus;
import com.edaixi.qa.common.URLBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by he_yi on 16/7/21.
 */
public class RefundOrder {
    public static Logger logger = LoggerFactory
            .getLogger(RefundOrder.class);
    private int orderId, courierId, fanId, cardId;
    private String orderSn;
    //    private double ecardMoney = 0.00; //e卡
    private double balanceMoney = 0.00;//余额
    private double cashMoney = 0.00; //现金
    private double thirdPartyMoney = 0.00; //第三方
    private double transferMoney = 0.00; //运费
    private double sumMoney = 0.00;
    private boolean couponIsUsed = false;

    public Coupons getCoupon() {
        return coupon;
    }

    public Ecard getEcard() {
        return ecard;
    }

    public int getCardId() {
        return cardId;
    }

    private Coupons coupon = null;
    private Ecard ecard = null;
    private Map<Integer, String> clothMap = new HashMap<Integer, String>();
    private Map<Integer, Double> pricesMap = new HashMap<Integer, Double>();
    private List<Integer> orderClotheIdList = new ArrayList<>();
    private List<Integer>[] orderClotheIdListArray;
    private List<Map<String, Object>> orderClotheMap = new ArrayList<>();
    private List<Map<String, Object>>[] orderClotheMapArray;
    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private orderStatus orderStatus;
    private boolean useFlag = true;

    private List<Map> orderList = new ArrayList<>();


    public enum orderStatus{
        pay;
//        jiagongdianQianShou;
    }

    public RefundOrder(orderStatus orderStatus){
        this.orderStatus = orderStatus;
        init();
    }

    public RefundOrder(){
        this.orderStatus = orderStatus.pay;
        init();
    }


    private void init(){
        courierId = CommonTools.get_courierId(mysqlQaDao);
        fanId = CommonTools.getFanId(mysqlQaDao);
        String sql_cardId = "select id from ims_icard_card where fan_id = "+fanId;
        cardId = CommonTools.getLastId(sql_cardId, mysqlQaDao);

    }

    private void createWaitPayOrder(){
        CreateOrderByStatus createOrder = new CreateOrderByStatus();
        CreateOrderByStatus.orderStatus createOrderStatus = null;
        switch (orderStatus){
            case pay:
                createOrderStatus = CreateOrderByStatus.orderStatus.qu_paidan;
                break;

//            case jiagongdianQianShou:
//                createOrderStatus = CreateOrderByStatus.orderStatus.jiagongdian_qianshou;
//                break;

        }
        createOrder.setCourierId(courierId);
        createOrder.setFanId(fanId);
        createOrder.getOrderByStatus(createOrderStatus);
        orderSn = createOrder.getOrderSn();
        orderId = createOrder.getOrderId();

        if (transferMoney != 0.00){
            useFlag = false;
        }

        if (coupon != null && !couponIsUsed){
            sumMoney+=coupon.getMoney();
            createClothPrices(coupon.getMoney());
        }
        if (ecard != null){
            sumMoney+=ecard.getMoney();
            double tmp = ecard.getMoney();
            if (!useFlag){
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);
        }
        if (balanceMoney != 0.00) {
            sumMoney+=balanceMoney;
            double tmp = balanceMoney;
            if (!useFlag){
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);
//            updateBalanceMoney();
        }
        if (cashMoney != 0.00){
            sumMoney+=cashMoney;
            double tmp = cashMoney;
            if (!useFlag){
                tmp -= transferMoney;
                useFlag = true;
            }
            createClothPrices(tmp);
        }else {
            if (thirdPartyMoney != 0.00){
                double tmp = thirdPartyMoney;
                if (!useFlag){
                    tmp -= transferMoney;
                    useFlag = true;
                }
                sumMoney+=thirdPartyMoney;
                createClothPrices(tmp);
            }
        }


        String sql = "update ims_washing_order set totalprice="+(sumMoney+transferMoney)+" , delivery_fee="+ transferMoney
                +"where id ="+orderId;
        mysqlQaDao.execUpdateSql(sql);

    }

    public void addOrder(){
        createWaitPayOrder();
        Map tmpOrderMap = new HashMap<>();
        tmpOrderMap.put("orderId", orderId);
        tmpOrderMap.put("orderSn", orderSn);
        tmpOrderMap.put("transferMoney", transferMoney);
        tmpOrderMap.put("sumMoney", sumMoney);
        tmpOrderMap.put("priceMap", pricesMap);
        tmpOrderMap.put("clothMap", clothMap);
        tmpOrderMap.put("ecard", ecard);
        tmpOrderMap.put("balance", balanceMoney);
        tmpOrderMap.put("cash", cashMoney);
        tmpOrderMap.put("third", thirdPartyMoney);
        orderList.add(tmpOrderMap);

        orderId = 0;
        orderSn = "";
        transferMoney = 0.00;
        sumMoney = 0.00;
        pricesMap = new HashMap<>();
        clothMap = new HashMap<>();
        ecard = null;
        balanceMoney = 0.00;
        cashMoney = 0.00;
        thirdPartyMoney = 0.00;
    }






    public JSONObject payOrder(){
        createWaitPayOrder();
        Map<String, Object>[] payClothMap = new Map[pricesMap.size()];
        Map<String, Object> subFeeParam01 = new HashMap<String, Object>();
        subFeeParam01.put("order_id", orderId);
        subFeeParam01.put("fee", transferMoney);
//        subFeeParam01.put("fee", 0);

        JSONArray subFee = new JSONArray();
        subFee.add(0,subFeeParam01);

        Map<String, Object> deliveryParam = new HashMap<String, Object>();
//        deliveryParam.put("total_fee", 0.00);//合单运费金额
        deliveryParam.put("total_fee", transferMoney);//合单运费金额
        deliveryParam.put("sub_fee", subFee);

        JSONArray clothWithPrice = new JSONArray();
        Object[] clothInfo = clothMap.entrySet().toArray();

        int i = 0;
        for(Map.Entry<Integer, Double> entry : pricesMap.entrySet()){
            payClothMap[i] = new HashMap<String, Object>();
            payClothMap[i].put("id",entry.getKey());
            payClothMap[i].put("num",1);
            payClothMap[i].put("price",entry.getValue());
            System.out.println("prices:"+entry.getValue());
//            payClothMap[i].put("price",10);


            int clothId = Integer.parseInt(clothInfo[i].toString().split("=")[0]);
            String clothNam = clothInfo[i].toString().split("=")[1];
            payClothMap[i].put("clothes_id",clothId);
            payClothMap[i].put("clothes_name",clothNam);

            clothWithPrice.add(i, payClothMap[i]);
            i++;
        }

        Map<String, Object> orderInfoParams = new HashMap<String, Object>();
        orderInfoParams.put("id", orderId);
        orderInfoParams.put("ordersn",orderSn);
        orderInfoParams.put("category_id", 1);
        orderInfoParams.put("cloth_with_price", clothWithPrice);
        orderInfoParams.put("city_id", 1);
        orderInfoParams.put("price", sumMoney-transferMoney);
//        orderInfoParams.put("price", 10);
        JSONArray orderInfo = new JSONArray();
        orderInfo.add(orderInfoParams);

        Map<String, Object> superMap = new HashMap<String, Object>();
        superMap.put("user_id", fanId);
        superMap.put("business_id", 11);
        superMap.put("user_type", 3);
        superMap.put("delivery", deliveryParam);
        superMap.put("order_info", orderInfo);
        Map<String, Object> payInfoParam = new HashMap<String, Object>();
        if (balanceMoney != 0.00){
            payInfoParam.put("icard", 1);
            superMap.put("pay_type", 1);// 电子会员卡支付
        }else{
            payInfoParam.put("icard", 0);
            superMap.put("pay_type", 2);// 微信支付
        }

        if (ecard != null){
            JSONArray ecardJson = new JSONArray();
            ecardJson.add(0, ecard.getId());
            payInfoParam.put("ecard_ids", ecardJson);
        }


        if (coupon != null){
            payInfoParam.put("coupon_id", coupon.getId());
        }

        superMap.put("pay_info", payInfoParam);

        logger.info(superMap.toString());
        String buildString = URLBuilder.httpBuildQuery(superMap, "");
        Map<String, Object> httpHead = new HashMap<String, Object>();
        httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
        JSONObject result = edxpayModuleService.CallPlatformIndex(buildString, httpHead);

        String sql_clothOrderId = "select cloth_order_id, fee from pf_order_detail where order_id="+orderId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql_clothOrderId);
        try {
            resultSet.beforeFirst();
            while(resultSet.next()){
                int id = resultSet.getInt("cloth_order_id");
                orderClotheIdList.add(id);

                String fee = resultSet.getString("fee");
                Map<String, Object> map = new HashMap<>();
                map.put("id", id);
                map.put("fee", fee);
                orderClotheMap.add(map);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (cashMoney != 0 || thirdPartyMoney !=0){
            JSONObject json = JSON.parseObject(result.getString("httpBody"));
            callBack(json.getString("trade_no"));
        }

        return result;

    }

    private void callBack(String trade_no){
        String queryImsPaylog = "select plid,type,tid,fee,module,fan_id,createtime from ims_paylog where fan_id = "+fanId+" and tid = '"+trade_no+"';";
        ResultSet queryImsPaylogInfo = mysqlQaDao.execQuerySql(queryImsPaylog);
        Map<String, Object> queryParams = new HashMap<>();
        int paylog_id = 0;
        try {
            paylog_id = queryImsPaylogInfo.getInt("plid");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        queryParams.put("plid",paylog_id);
        logger.info(queryParams.toString());
        String buildString = URLBuilder.httpBuildQuery(queryParams, "");
        Map<String, Object> httpHead = new HashMap<>();
        httpHead.put("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");

        // 调用接口
        EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
        JSONObject result = edxpayModuleService.CallPlatformCallBack(buildString, httpHead);
        logger.info("回调接口"+result.toJSONString());
    }

    public void deletePrices(){
        String sql = "delete from prices where id in (";
        Set set = pricesMap.keySet();
        for (Iterator iterator = set.iterator(); iterator.hasNext();){
            sql += iterator.next()+",";
        }
        sql = sql.substring(0, sql.length()-1);
        sql+=");";
        mysqlQaDao.execUpdateSql(sql);
    }


    private void updateBalanceMoney(){
        double money = balanceMoney;
        if (ecard == null && cashMoney == 0.00 && thirdPartyMoney == 0.00){
            money = balanceMoney + transferMoney;
        }
        String sql = "update ims_icard_card set coin ="+money+" where id = "+cardId;
        mysqlQaDao.execUpdateSql(sql);
    }

    private void createClothPrices(double money){
        int priceId = CommonTools.getNewIdByTableName("prices", mysqlQaDao);
        int clothId = getClothId();
        String sql = "insert into prices(id, clothes_id, city_id, price, jgd_price, smart_key, wash_deadline_dian, wash_deadline_chang, is_deleted, ori_id, is_suit, serial_index, sort_mark) " +
                "values("+priceId+", "+clothId+",1,"+money+",0.00, -1, 30, 30,0,12810,0,12810,12810);";
        mysqlQaDao.execUpdateSql(sql);
        pricesMap.put(priceId, money);


//        //创建小e和加工店分拣结果表,status 10:只小e分拣 20加工店分拣结果比小e多, 21加工店和小e分拣一致, 22加工店分拣比小e少
//        int orderClothId = CommonTools.getNewIdByTableName("order_clothes_lists", mysqlQaDao);
//        String clothName = clothMap.get(clothId);
//        sql = "insert into order_clothes_lists(id,order_id,order_sn,status,courier_id,clothes_id,clothes_name,courier_price_id,courier_price,outlet_price_id,outlet_price,can_rewash,can_wash,rewash,type)";
//        sql+="values("+orderClothId+","+orderId+",'"+orderSn+"',21,"+courierId+","+clothId+",'"+clothName+"',"+priceId+","+money+","+priceId+","+money+",1,1,0,'OrderClothesList');";
//        mysqlQaDao.execUpdateSql(sql);
//        orderClotheIdList.add(orderClothId);
    }


    private int getClothId(){
        String sql_cloth = "select id, name from clothes where is_deleted=0 order by rand() limit 1;";//order by rand()随机排序
        ResultSet result = mysqlQaDao.execQuerySql(sql_cloth);
        int id = 0;
        try {
            result.beforeFirst();
            while (result.next()){
                id = result.getInt("id");
                String name = result.getString("name");
                if (clothMap.containsKey(id)){
                    getClothId();
                }else{
                    clothMap.put(id, name);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    public void setFanId(int fanId){
        this.fanId = fanId;
        String sql_cardId = "select id from ims_icard_card where fan_id = "+fanId;
        cardId = CommonTools.getLastId(sql_cardId, mysqlQaDao);
    }

    public List<Integer> getOrderClotheIdList(){
        return orderClotheIdList;
    }


    public void setEcard(Ecard ecard) {
        this.ecard = ecard;
    }

    public void setBalanceMoney(double balanceMoney) {
        this.balanceMoney = balanceMoney;
    }

    public void setCashMoney(double cashMoney) {
        this.cashMoney = cashMoney;
    }

    public void setThirdPartyMoney(double thirdPartyMoney) {
        this.thirdPartyMoney = thirdPartyMoney;
    }

    public void setTransferMoney(double transferMoney) {
        this.transferMoney = transferMoney;
    }

    public void setCounpon(Coupons counpon) {
        if (this.coupon == null){
            this.coupon = counpon;
            couponIsUsed = true;
        }

    }

    public int getOrderId(){
        return orderId;
    }

    public String getOrderSn(){
        return orderSn;
    }

    public Map<Integer, String> getClothInfo(){
        return clothMap;
    }

    public Map<Integer, Double> getClothPriceInfo(){
        return pricesMap;
    }

    public double getBalanceMoney() {
        return balanceMoney;
    }

    public double getCashMoney() {
        return cashMoney;
    }

    public double getThirdPartyMoney() {
        return thirdPartyMoney;
    }

    public double getTransferMoney() {
        return transferMoney;
    }

    public double getSumMoney() {
        return sumMoney;
    }

    public List<Map<String, Object>> getOrderClotheMap(){
        return orderClotheMap;
    }

    public List<Map<String, Object>> getClothParameter(){
        List<Map<String, Object>> list = new ArrayList<>();
        List<Map<String, Object>> orderClothMap  = getOrderClotheMap();
        Map<Integer, String> clothInfo = getClothInfo();
        int i =0;
        for (Map.Entry<Integer, String> entry : clothInfo.entrySet()) {

            int id = entry.getKey();
            String name = entry.getValue();
            Map<String, Object> clothMap = orderClothMap.get(i);
            int orderClothId = (int) clothMap.get("id");
            String fee = String.valueOf(clothMap.get("fee"));

            Map<String, Object> map = new HashMap<>();
            map.put("cloth_id", id);
            map.put("name", name);
            map.put("cloth_order_id", orderClothId);
            map.put("fee", fee);
            list.add(map);
            i++;
        }

        return list;

    }

}
