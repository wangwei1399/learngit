package com.edaixi.qa.edxpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralCaiwuAdminData;
import com.edaixi.qa.common.URLBuilder;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class GetCompanyInfoTest {

    private static Logger logger = LoggerFactory
            .getLogger(GetCompanyInfoTest.class);
    private EdxpayModuleService edxpayModuleService = new EdxpayModuleService();
    private Map<String, Object> queryParams = null;
    private GeneralCaiwuAdminData generalCaiwuAdminData = new GeneralCaiwuAdminData();
    private Map<String, Object> httpHead = null;
    private Map<String, Object> companyParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc-caiwuadmin.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams  = new HashMap<String, Object>();
        this.companyParams = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();
        logger.info("in teardown!");
    }

    @Test

    public void testGetCompanyInfo() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String companyInfo = "select id from company order by id desc limit 1";
        ResultSet companyInfoRet = mysqlQaDao.execQuerySql(companyInfo);
        int id = companyInfoRet.getInt("id") + 1;

        String companyInfo2 = "select company_id from company order by company_id desc limit 1";
        ResultSet companyInfoRet2 = mysqlQaDao.execQuerySql(companyInfo2);
        int company_id = companyInfoRet2.getInt("company_id") + 1;

        int money = 1000;
        int realmoney = 900;
        int note = CommonTools.getRandomInt(4);
        this.companyParams.put("id",id);
        this.companyParams.put("company_id",company_id);
        generalCaiwuAdminData.GeneralCompany(this.companyParams);

        this.queryParams.put("company_id", company_id);

        String buildString = URLBuilder.httpBuildQuery(this.queryParams, "");
        logger.info(this.queryParams.toString());
        this.httpHead.put("Content-Type","application/x-www-form-urlencoded;charset=utf-8");

        // 调用绑定接口
        JSONObject result = this.edxpayModuleService.CallGetCompanyInfo(buildString,this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue("返回值不符合预期", result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期", "成功", URLDecoder.decode(loginBody.getString("resp_msg"),"UTF-8"));
        Assert.assertEquals("返回值不符合预期", 100,loginBody.getJSONObject("data").getIntValue("earnest"));
        Assert.assertEquals("返回值不符合预期", 100,loginBody.getJSONObject("data").getIntValue("advance"));
        Assert.assertEquals("返回值不符合预期", 0,loginBody.getJSONObject("data").getIntValue("wallet"));
        Assert.assertEquals("返回值不符合预期", 0,loginBody.getJSONObject("data").getIntValue("wallet_realmoney"));
        Assert.assertEquals("返回值不符合预期", "",loginBody.getJSONObject("data").getString("notice"));

    }


}
