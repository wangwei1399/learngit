package com.edaixi.qa.wuliuapp;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


/**
 * Created by guolaidong on 2016/1/15.
 */
public class PostXiaoeRefundInfoTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private  JSONObject couponParams = new JSONObject();

    private Map<String,Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp(){ this.httpHead = new HashMap<String, Object>(); }

    @After
    public void tearDown(){ logger.info("in teardown!"); }

    @Test
    /**
     * guolaidong
     */

    public void testPostXiaoeFefundInfo() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //获取user_token
        String uid = "157";
        String usertokenstr = "select user_token from courier_profiles where courier_id = "+ uid +"";
        ResultSet resultSet = mysqlQaDaoWuliu.execQuerySql(usertokenstr);
        String user_token = resultSet.getString("user_token");

        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key",ConfigData.app_key);
        this.queryParams.put("client_name",ConfigData.client_name_android);
        this.queryParams.put("uid",uid);
        this.queryParams.put("name","北京");
        this.queryParams.put("idcard_number","210213199312071265");
        this.queryParams.put("bankcard_number","123456789124356");
        this.queryParams.put("bank_name","甘肃银行");
        this.queryParams.put("quit_reason","身体原因");


        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()){
            key = it.next();
            value = treemap.get(key);
            strkeyvalue =strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);
        logger.info("strqueryParams:" + strqueryParams);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + user_token);


        logger.info("sign:" + sign);
        logger.info("user_token:" + user_token);

        this.queryParams.put("sign", sign);
        logger.info("this.queryParams：" + this.queryParams);

        JSONObject result = this.wuliuappModuleService.CallPostXiaoeRefundInfo("",this.queryParams);
        logger.info(result.toJSONString());
        String resultstr =  "select pay_deposit_state from ims_washing_courier where id = " + uid + "";
        ResultSet respaystate = mysqlQaDao.execQuerySql(resultstr);
        Assert.assertEquals("返回值不符合预期","-1",respaystate.getString("pay_deposit_state"));

        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

        String updateCourier = "update ims_washing_courier set pay_deposit_state = '1' where id = " + uid + "";
        String updatebackdeposits = "update back_deposits set state = '2' where courier_id = " + uid + "";

        mysqlQaDao.execUpdateSql(updateCourier);
        mysqlQaDaozhongbao.execUpdateSql(updatebackdeposits);

    }








}
