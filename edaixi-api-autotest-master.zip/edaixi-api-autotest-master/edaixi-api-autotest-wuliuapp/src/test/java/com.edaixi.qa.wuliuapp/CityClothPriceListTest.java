package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class CityClothPriceListTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();
    private Map<String, Object> httpHead = null;

    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    //城市衣物价格接口
    //case1：
    public void testCityClothPriceList1() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        long unixTimestamp = currentTime / 1000;
        //电话
        String tel = (Long.toString(currentTime)).substring(2, 13);
        //32位随机数
        String randomPushToken = String.valueOf(UUID.randomUUID());
        //今天
        String todayTime = (new SimpleDateFormat("yyyy-MM-dd")).format(new Date());
        String dateTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

//        String strCourierId = "select max(id) from ims_washing_courier;";
//        ResultSet resCourierId = mysqlQaDao.execQuerySql(strCourierId);
//        int courierId = resCourierId.getInt(1) + 1;

        //插入小e
//        String strCourier1 = "insert into ims_washing_courier (realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,start_time,end_time,edaixi_nr,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,jiebo,deposit,pay_deposit_state,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel,song_angway,channel_type) " +
//                "values('测试','000000','" + tel + "',NULL,'1','" + randomPushToken + "','" + dateTime + "','" + dateTime + "','北京','1','5','1','1111111111111111','222222222222222222','招商银行','1','1','1','2015-11-01',NULL,'EZB-0010-0000" + courierId + "','com." + courierId + ".zhongbao','1','1','0','android_client','0','0',NULL,'0',NULL,NULL,NULL,NULL,'0','0',NULL,'0','0','" + unixTimestamp + "','" + unixTimestamp + "',NULL,'0',NULL,'0','1','0.00','1','测试','0',NULL,NULL,NULL,'1',NULL);\n";
//        mysqlQaDao.execUpdateSql(strCourier1);


//        String strUid = "select id from ims_washing_courier where tel = '" + tel + "'";
//        ResultSet resUid = mysqlQaDao.execQuerySql(strUid);
//
//        //获取user_token
//        String uid = resUid.getString(1);
//        String strCourierProfiles = "insert into courier_profiles (courier_id,user_token) values('" + uid + "','" + randomPushToken + "');";
//        mysqlQaDaoWuliu.execUpdateSql(strCourierProfiles);

        int courierId = CommonTools.get_courierId(mysqlQaDao);
        logger.info("courierid: " + courierId);

        //订单号
        String a = "4";
        long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
        String lastSixordersn = (Long.toString(ordersn)).substring(8, 14);

        //插入调度派单后的订单数据
        String strOrder = "insert into ims_washing_order (from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid,status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time,createtime,qujian_paidan_time,qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time,jiagongdian_qianshou_time,jiagongdian_id,wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time,wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time,jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status,diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi,yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id,address_song_id,auto_dispatched_qu_at,auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count,washing_duration,model_version) " +
                "values(NULL,'3','" + ordersn + "','','1','0.00','0.00','','0.00','0.00','0.00','1','9','',NULL,'0','3','','" + todayTime + "','11:00-12:00','','','测试员','13681057539','北京','东城区','马杓胡同甲27号','北京','东城区','马杓胡同甲27号','3425','0','0',NULL,'0',NULL,'0',NULL,'" + unixTimestamp + "','" + unixTimestamp + "','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" + dateTime + "','" + dateTime + "','0','" + unixTimestamp + "','0','0',NULL,'0','0','0','623419',NULL,'18','2414','35','36',NULL,NULL,NULL,'0','595735','595735',NULL,NULL,'" + lastSixordersn + "','1','0',NULL,'1339874','0.00',NULL,NULL,NULL,'0');\n";
        mysqlQaDao.execUpdateSql(strOrder);

        String strOrderId = "select id from ims_washing_order where ordersn = '" + ordersn + "'";
        ResultSet resOrderid = mysqlQaDao.execQuerySql(strOrderId);
        String order_id = resOrderid.getString(1);

        //接口传的参数，用来计算sign值
        //wuliuapp必传3通用参数
        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");
        //接口单独要求的参数
        //category_id：1洗衣2洗鞋3窗帘4高端服饰5奢侈品皮具13酒店快洗
        this.queryParams.put("uid", courierId);
        this.queryParams.put("checksum", "");

        //生成sign
        //map里排序
//        TreeMap treemap = new TreeMap(this.queryParams);
//
//        //遍历treemap，用&链接
//        Object key = null;
//        Object value = null;
//        String strkeyvalue = "";
//
//        Iterator it = treemap.keySet().iterator();
//        while (it.hasNext()) {
//            key = it.next();
//            value = treemap.get(key);
//            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
//        }
//        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);
//
//        //计算sign
//        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + randomPushToken);
        String sign = wuliuappModuleService.getSign(courierId, this.queryParams);
        this.queryParams.put("sign", sign);

        /* 调用被测接口 */
        JSONObject result = this.wuliuappModuleService.CallCityClothPriceList("", this.queryParams);

        logger.info(result.toJSONString());

        //验证返回结果
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        //返回数据格式
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("price"));
        Assert.assertEquals(true, result.getString("httpBody").contains("category_id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tags"));

        //清除测试数据
        String strDelCourier = "delete from ims_washing_courier where tel = '" + tel + "'";
        mysqlQaDao.execUpdateSql(strDelCourier);
        String strDelCourierRecruits = "delete from courier_recruits  where tel = '" + tel + "'";
        mysqlQaDaozhongbao.execUpdateSql(strDelCourierRecruits);
    }
    }
