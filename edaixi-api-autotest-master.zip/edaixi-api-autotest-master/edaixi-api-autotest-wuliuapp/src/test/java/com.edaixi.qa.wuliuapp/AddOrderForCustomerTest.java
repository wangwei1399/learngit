package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddOrderForCustomerTest {

	private static Logger logger = LoggerFactory
			.getLogger(AddOrderForCustomerTest.class);
	private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();

    private Map<String, Object> httpHead = null;
	private static MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();

    Date dt = new Date();
    long time = dt.getTime();
    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");


    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
	}

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


    @AfterClass
    public static void recovery(){
    }


	@Test
	/**
	 *
	 * @author ningyao.zn
     *
     *
     *
	 */
    public void testAddOrderForCustomer() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {
        long currentTime = System.currentTimeMillis();
//        int order_id = (int)(currentTime % 10000000);
        int order_id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1;
//        int trans_task_id = (int)(currentTime % 100000);
        int trans_task_id = CommonTools.getLastId("select id from trans_tasks order by id desc limit 1;", mysqlQaDao)+1;
        String order_sn = String.valueOf(currentTime);
        int uid = 79;
        int old_category_id = 1;
        int new_category_id = 3;
        int status = 1;
        int status_delivery = 1;
        int pay_status = 1;
        //获取到用户的token
        String tokenInfo = "select user_token from courier_profiles where courier_id = " + uid + "";
        ResultSet retTokenInfo = mysqlQaDaoWuliu.execQuerySql(tokenInfo);
        String userTokenInfo = retTokenInfo.getString("user_token");
        //造订单的数据
        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
                "VALUES\n" +
                "\t(" + order_id + ", NULL, 7, '" + order_sn + "', '', 1, 0.00, 0.00, '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, '接口测试', '2016-01-16', '18:00-20:00', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', "+ uid + ", 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";

        //造交接单的数据
        String transOrderInfo = "INSERT INTO `trans_tasks` (`id`, `bagsn`, `from_id`, `from_type`, `from_address_id`, `to_id`, `to_type`, `to_address_id`, `next_task_id`, `transfer_task_id`, `transferred_by`, `dead_line`, `prority`, `status`, `direction`, `finished_at`, `created_at`, `updated_at`, `category_id`, `ordersn`, `washing_status`, `order_id`, `trans_group_id`, `trans_ttl`, `trans_type`)\n" +
                "VALUES\n" +
                "\t("+ trans_task_id + ", NULL, "+ uid + ", 'zhongbao', NULL, NULL, 'customer', 595975, NULL, NULL, NULL, '2016-01-16 20:00:00', NULL, 'started', 'get', NULL, '2016-01-08 10:17:12', '2016-01-08 10:17:12', " + old_category_id + ", '" + order_sn + "', 'unwashed', '" + order_id + "', 267, 0, 0);\n";
        mysqlQaDao.execUpdateSql(orderInfo);
        mysqlQaDao.execUpdateSql(transOrderInfo);

        this.queryParams.put("order_id",order_id);
        this.queryParams.put("trans_task_id",trans_task_id);
        this.queryParams.put("uid",uid);
        this.queryParams.put("category_id",new_category_id);
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key","wuliu_app");
        this.queryParams.put("client_name","ios_client");
        List<String> queryParamslist = new ArrayList<String>();
        for (String key : queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign=this.wuliuappModuleService.string2MD5(addString + "J3n4dMTSPQ" + userTokenInfo);
        this.queryParams.put("sign",sign);

        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallAddOrderForCustomer("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        int new_order_id = loginBody.getJSONObject("data").getInteger("order_id");
        // 验证生成的订单数据是否正确
        String queryNewOrder = "select id,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,status,status_delivery,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song," +
                "address_song,courier_qu,courier_song,createtime,qujian_paidan_time,created_at,updated_at,diaodu_queren_time,fan_id,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,address_qu_id,address_song_id,last_six_ordersn,category_id from ims_washing_order where id = "+ new_order_id + ";";

        ResultSet newOrderInfo = mysqlQaDao.execQuerySql(queryNewOrder);
        Assert.assertEquals("返回值不符合预期",7,newOrderInfo.getInt("user_type"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("ordersn").length() > 0);
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("bagsn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("totalprice"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("delivery_fee"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("coupon_sn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("coupon_paid"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("money_paid"));
        Assert.assertEquals("返回值不符合预期",1,newOrderInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",9,newOrderInfo.getInt("status_delivery"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("pay_status"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("paytype"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("remark").contains("小e代下单"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("washing_date").contains(String.valueOf(formatDate.format(dt))));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_date").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_time").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("username").contains("杨"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("tel").contains("12345678906"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city").contains("北京"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area").contains("朝阳区"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address").contains("清华东路"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city_song").contains("北京"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area_song").contains("朝阳区"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address_song").contains("清华东路"));
        Assert.assertEquals("返回值不符合预期",uid,newOrderInfo.getInt("courier_qu"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("courier_song"));
        Assert.assertEquals("返回值不符合预期",30, newOrderInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期",18, newOrderInfo.getInt("good_id"));
        Assert.assertEquals("返回值不符合预期",595975, newOrderInfo.getInt("address_qu_id"));
        Assert.assertEquals("返回值不符合预期",595975, newOrderInfo.getInt("address_song_id"));
        Assert.assertEquals("返回值不符合预期",new_category_id, newOrderInfo.getInt("category_id"));
        Assert.assertEquals("返回值不符合预期",newOrderInfo.getString("ordersn").substring(newOrderInfo.getString("ordersn").length()-6,newOrderInfo.getString("ordersn").length()), newOrderInfo.getString("last_six_ordersn"));
        // 验证生成的交接单的数据是否正确
        String queryTransOrder = "select id,from_id,from_type,to_type,to_address_id,dead_line,status,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type from " +
                "trans_tasks where order_id = " + new_order_id + "";
        ResultSet queryTranInfo = mysqlQaDao.execQuerySql(queryTransOrder);
        Assert.assertEquals("返回值不符合预期",uid,queryTranInfo.getInt("from_id"));
        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("from_type").contains("zhongbao"));
        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("to_type").contains("customer"));
        Assert.assertEquals("返回值不符合预期", 595975,queryTranInfo.getInt("to_address_id"));
        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("status").contains("started"));
        Assert.assertEquals("返回值不符合预期", new_category_id,queryTranInfo.getInt("category_id"));
        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("washing_status").contains("unwashed"));
        Assert.assertEquals("返回值不符合预期", 0,queryTranInfo.getInt("trans_ttl"));
        Assert.assertEquals("返回值不符合预期", 0,queryTranInfo.getInt("trans_type"));


    }




}
