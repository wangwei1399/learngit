package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.experimental.theories.DataPoint;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
@RunWith(Theories.class)
public class WuliuSongTuihuiTest {
    private static Logger logger = LoggerFactory.getLogger(WuliuSongTuihuiTest.class);
    private static WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private static GeneralRongChain04Data rongchang04 = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();

    //初始化请勿修改!!!
    private  final String order_id = String.valueOf(CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1); ;
    private  final String order_sn=CommonTools.getOrdersn(order_id);
    private  final int courier_id=CommonTools.get_courierId(mysqlQaDao);
    private  final String group_id=String.valueOf(CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao)+1);;
    private  final int trans_task_id=CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao)+6;
    private static final String app_key = ConfigData.app_key;

    //初始化可以赋值
    private static String bagsn = "00034477489";
    private String app_version=ConfigData.app_version;
    private String client_name = ConfigData.client_name_android;
    private int category_id = 1;


    private void createOrder(){
//        int id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao);
//        order_id = String.valueOf(id+1);
//        order_sn = CommonTools.getOrdersn(order_id);
//        courier_id=CommonTools.get_courierId(mysqlQaDao);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("order_id", order_id);
        tmp.put("order_sn", order_sn);
        tmp.put("status", 1);
        tmp.put("status_delivery", 15);
        tmp.put("pay_status", 1);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        tmp.put("washing_time", "22:00-24:00");
        tmp.put("uid", courier_id);
        tmp.put("old_category_id", category_id);
        tmp.put("uid_song", courier_id);
        tmp.put("bagsn", bagsn);
        rongchang04.GeneralOrder(tmp);
    }

    private void createTrans(){
        int tmp_dispatch_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao);
        String dispatch_id = String.valueOf(tmp_dispatch_id+1);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("id", dispatch_id);
        tmp.put("order_id", order_id);
        tmp.put("status", "finished");
        tmp.put("courier_id", courier_id);
        tmp.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd 00:00:00", 1));
        tmp.put("category_id", category_id);
        rongchang04.GeneralDispatchTask(tmp);

//        int tmp_group_id = CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao);
//        group_id = String.valueOf(tmp_group_id+1);
        tmp.clear();
        tmp.put("id", group_id);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("current_task_id", 0);
        tmp.put("last_task_id", 0);
        tmp.put("dispatch_task_id", dispatch_id);
        tmp.put("order_id", order_id);
        rongchang04.GeneralTransGroups(tmp);


        int tmp_trans_tasks_id = CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao);
//        trans_task_id = (++tmp_trans_tasks_id);

        tmp.clear();
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("ordersn", order_sn);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "finished");
        tmp.put("direction", "get");
        tmp.put("category_id", category_id);
        tmp.put("trans_group_id", group_id);
        tmp.put("washing_status", "unwashed");
        tmp.put("finished_at", CommonTools.getToday("yyyy-MM-dd hh:mm:ss"));
        rongchang04.GeneralTransTasks(tmp);

//        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "send");
        rongchang04.GeneralTransTasks(tmp);

//        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("from_id", 67);
        tmp.put("from_type", "jiagongdian");
        tmp.put("to_id", courier_id);
        tmp.put("to_type", "zhongbao");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

//        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "started");
        tmp.put("direction", "send");
        tmp.remove("finished_at");
        tmp.put("washing_status", "washed");
        rongchang04.GeneralTransTasks(tmp);

//        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);


//        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("to_id", "NULL");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", "NULL");
        tmp.put("direction", "send");
        tmp.put("status", "init");
        rongchang04.GeneralTransTasks(tmp);


        String sql = "update trans_groups set current_task_id="+(tmp_trans_tasks_id-1)+", last_task_id="+trans_task_id+
                " where id ="+group_id;
        mysqlQaDao.execUpdateSql(sql);
    }

    @DataPoint
    public static String back_reason = "联系不上客户";


    @Theory
    public void testWuliuSongTuihui(String reason){
        createOrder();
        createTrans();
        Map<String, Object> queryParams = new HashMap<String, Object>();
        queryParams.put("app_version", app_version);
        queryParams.put("uid", courier_id);
        queryParams.put("back_reason", reason);
        queryParams.put("app_key", app_key);
        queryParams.put("trans_task_id", trans_task_id);
        queryParams.put("order_id", order_id);
        queryParams.put("client_name", client_name);
        String sign = wuliuappModuleService.getSign(courier_id, queryParams);
        queryParams.put("sign", sign);
        JSONObject resultJson = wuliuappModuleService.CallWuliuSongTuihuiTest(queryParams);
        logger.info("result json:"+resultJson.toJSONString());
        Assert.assertEquals("返回值不符合预期","200",resultJson.getString("httpStatus"));

        String sql = "select back_reason_song from ims_washing_order where id="+order_id;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        String true_back_reason = "";
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                true_back_reason = resultSet.getString("back_reason_song");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        logger.info("expected:"+reason+" actual:"+true_back_reason);
        Assert.assertEquals("返回值不符合预期",reason,true_back_reason);

    }

}