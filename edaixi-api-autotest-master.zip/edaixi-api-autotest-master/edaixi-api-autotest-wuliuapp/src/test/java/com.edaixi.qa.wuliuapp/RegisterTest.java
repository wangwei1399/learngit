package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.*;

public class RegisterTest {
    private static Logger logger = LoggerFactory
        .getLogger(RegisterTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test

    public void testRegisterTest() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        String deletetel="delete from ims_washing_courier where tel=12345678367";
        mysqlQaDao.execUpdateSql(deletetel);
        long currentTime = System.currentTimeMillis();
        String pushToken = (int)(currentTime % 1000000) + "OrtUe51BjU";
        this.queryParams.put("tel","12345678367");
        this.queryParams.put("id_number","012345678965487");
        this.queryParams.put("realname","大闸蟹");
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key",ConfigData.app_key);
        this.queryParams.put("city_id","1");
        this.queryParams.put("password","123456");
        this.queryParams.put("bank_name","长安银行");
        this.queryParams.put("sex","女");
        this.queryParams.put("bank_card","1345678945123654");
        this.queryParams.put("client_name",ConfigData.client_name_android);
        this.queryParams.put("uid","");
        List<String> queryParamslist = new ArrayList<String>();
        for (String key : queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign=this.wuliuappModuleService.string2MD5UTF8(addString + "J3n4dMTSPQ");
        this.queryParams.put("sign",sign);

        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallRegister("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }

}
