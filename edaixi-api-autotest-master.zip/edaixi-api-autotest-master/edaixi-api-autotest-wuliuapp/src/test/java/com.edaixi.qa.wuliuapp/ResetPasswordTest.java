package com.edaixi.qa.wuliuapp;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.*;


/**
 * Created by yjc-edaixi on 2016/1/18.
 */
public class ResetPasswordTest {
    private static Logger logger = LoggerFactory
            .getLogger(ResetPasswordTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test
    /**
     *
     * @author ningyao.zn
     *
     *
     *
     */
    public void testResetPassword() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        String updatetime = String.valueOf(currentTime).substring(0,10);
        int id = CommonTools.getLastId("select id from ims_washing_mobile order by id desc limit 1;", mysqlQaDao)+1;
        String deletecode="delete from ims_washing_mobile where mobile='12345678944'";
        mysqlQaDao.execUpdateSql(deletecode);
        String codeinfo="INSERT INTO `ims_washing_mobile` (`id`, `mobile`, `code`, `updatetime`, `fan_id`, `pattern`)\n"+
                "VALUES\n" +
                "\t(" + id + ", 12345678944, 1234, " + updatetime + ", 0, 'courier_reset')";
        mysqlQaDao.execUpdateSql(codeinfo);
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("code","1234");
        this.queryParams.put("password","123456");
        this.queryParams.put("app_key",ConfigData.app_key);
        this.queryParams.put("phone","12345678944");
        this.queryParams.put("client_name",ConfigData.client_name_android);
        List<String> queryParamslist = new ArrayList<String>();
        for (String key : queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign=this.wuliuappModuleService.string2MD5(addString + "J3n4dMTSPQ");
        this.queryParams.put("sign",sign);

        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallResetPassword("", this.queryParams);
        logger.info(result.toJSONString());
        //Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }

}
