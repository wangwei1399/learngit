package com.edaixi.qa.wuliuapp;

/**
 * Created by he_yi on 16/4/12.
 */
public class ConfigData {
    public final static int pay_type = 6;
    public final static String app_version = "4.1.5.0";
    public final static String app_key = "wuliu_app";
    public final static String client_name_android = "android_client";
    public final static String client_name_ios = "ios_client";
}
