package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.*;

public class ExtracCashApplyTest {


    private static Logger logger = LoggerFactory
            .getLogger(ExtracCashApplyTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test

    public void testExtracCashApplyTest() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        String pushToken = (int)(currentTime % 1000000) + "OrtUe51BjU";
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key","wuliu_app");
        this.queryParams.put("client_name","android_client");
        this.queryParams.put("apply_amount","1");
        this.queryParams.put("bankcard","123456879123456778");
        this.queryParams.put("apply_idcard","123456789012345677");
        this.queryParams.put("uid","79");
        this.queryParams.put("isconfirm","0");
        this.queryParams.put("user_type","2");
        this.queryParams.put("ts",currentTime);
        this.queryParams.put("market","AppStore");
        this.queryParams.put("bankname","甘肃银行");
        this.queryParams.put("apply_name","李尧");
        String sign = wuliuappModuleService.getSign("79", queryParams);
        this.queryParams.put("sign",sign);
        // 调用登录接口

        JSONObject result = this.wuliuappModuleService.CallExtracCashApply("", this.queryParams);
        logger.info(result.toJSONString());
        //Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }

}