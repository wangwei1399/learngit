package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by guolaidong on 2016/2/1.
 */
public class ExtracCashRecordTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    /**
     * guolaidong
     */

    public void testExtracCashRecord() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //获取user_token
        String uid = "78";
        String usertokenstr = "select user_token from courier_profiles where courier_id = " + uid + "";
        ResultSet resultSet = mysqlQaDaoWuliu.execQuerySql(usertokenstr);
        String user_token = resultSet.getString("user_token");

        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");
        this.queryParams.put("uid", uid);
        this.queryParams.put("per_page", "20");
        this.queryParams.put("page", "1");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);
        logger.info("strqueryParams:" + strqueryParams);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + user_token);

        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallExtracCashRecord("", this.queryParams);
        logger.info(result.toJSONString());
        JSONObject retBody = JSON.parseObject(result.getString("httpBody"));
        JSONObject retData = JSON.parseObject(result.getString("data"));

        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        Assert.assertEquals("返回结果不符合预期", "true", retBody.getString("ret"));
       // Assert.assertEquals("返回结果不符合预期","3",retData.getString("state"));
       // Assert.assertEquals("返回结果不符合预期","229.89",result.getString("amount"));
       // Assert.assertEquals("返回结果不符合预期","null",result.getString("reasult_reason"));
       // Assert.assertEquals("返回结果不符合预期","东亚银行",result.getString("bank_name"));
       // Assert.assertEquals("返回结果不符合预期","6217000010051545987",result.getString("bank_card"));
       // Assert.assertEquals("返回结果不符合预期","2016-01-05 18:42:50",result.getString("date"));

        Assert.assertEquals(true,result.getString("httpBody").contains("\"id\":10"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"state\":3"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"amount\":229.89"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"reasult_reason\":null"));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"bank_name\":\"东亚银行\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"bank_card\":\"6217000010051545987\""));
        Assert.assertEquals(true,result.getString("httpBody").contains("\"date\":\"2016-01-05 18:42:50\""));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        String courierwithdraw = "select * from courier_withdraw_logs where courier_id = " + uid + " order by month desc";
        ResultSet resCourier = mysqlQaDao.execQuerySql(courierwithdraw);
        resCourier.first();
////        Assert.assertEquals("返回结果不符合预期","229.89",resCourier.getString("money"));
//        Assert.assertEquals("返回结果不符合预期","2016-01-05 18:42:50.0",resCourier.getString("created_at"));
//        Assert.assertEquals("返回结果不符合预期","东亚银行",resCourier.getString("bank_name"));
//        Assert.assertEquals("返回结果不符合预期","6217000010051545987",resCourier.getString("bank_card"));
//        Assert.assertEquals("返回结果不符合预期","opening",resCourier.getString("status"));
//        resCourier.last();
//        Assert.assertEquals("返回结果不符合预期",10,resCourier.getRow());
    }
}
