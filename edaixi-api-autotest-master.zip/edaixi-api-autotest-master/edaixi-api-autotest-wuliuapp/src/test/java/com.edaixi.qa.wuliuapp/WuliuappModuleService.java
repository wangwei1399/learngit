package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class WuliuappModuleService {
	private static Logger logger = LoggerFactory.getLogger(WuliuappModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;

	public WuliuappModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.globalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.globalConf.getProperty("wuliuapp.addr"));
	}

	public String string2MD5(String inStr) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		md.update(inStr.getBytes());
		byte[] bs = md.digest();
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < bs.length; i++) {
            stringBuffer.append(String.format("%02x", bs[i] & 0xff));
		}
		return  stringBuffer.toString();
	}

    public String string2MD5UTF8(String str) throws NoSuchAlgorithmException,UnsupportedEncodingException {
        MessageDigest messageDigest = null;
        messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.reset();
        messageDigest.update(str.getBytes("UTF-8"));
        byte[] byteArray = messageDigest.digest();
        StringBuffer md5StrBuff = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)
                md5StrBuff.append("0").append(
                        Integer.toHexString(0xFF & byteArray[i]));
            else
                md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
        }
        return md5StrBuff.toString();
    }

    public String getUserToken(String courier_id){
        String token = "";
        boolean noToke = true;

        String sql = "select user_token from courier_profiles where courier_id="+courier_id+";";
        MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc.wuliu.properties");
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            resultSet.beforeFirst();
            if (resultSet.next()){
                resultSet.last();
                token = resultSet.getString("user_token");

                if (!token.equals("") || token != null){
                    noToke = false;
                }
            }

            if (noToke){
                String insertSQL = "insert into courier_profiles(courier_id, user_token) values("+courier_id+", 'a33a9d42e2ffbcb3d216eda42f03bbb7');";
                mysqlQaDao.execUpdateSql(insertSQL);
                return getUserToken(courier_id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return token;
    }


    public String getSign(String courierId, Map<String, Object> queryParams){
        List<String> queryParamslist = new ArrayList<String>();
        for (String key : queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        String userToke = this.getUserToken(courierId);
        return this.getSign(userToke, queryParamslist);
    }

    public String getSign(int courierId, Map<String, Object> queryParams){
        return getSign(String.valueOf(courierId), queryParams);
    }

    public String getSign(String userToken, List<String> queryParamslist){
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign= null;
        try {
            sign = this.string2MD5UTF8(addString + "J3n4dMTSPQ" + userToken);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return sign;
    }

    public static String getBagsn(){
        File file = new File("src/test/resources/bagsn.txt");
        System.out.println(file.getAbsolutePath());
        String s = "";
        FileReader fileReader;
        try {
            fileReader = new FileReader(file);
            BufferedReader bf = new BufferedReader(fileReader);
            String tmp = "";
            while ((tmp = bf.readLine()) != null){
                s = tmp;
                if (s.charAt(s.length()-1) != 'N'){
                    break;
                }
            }
            bf.close();
            fileReader.close();
            replaceText(file, s, s+" N");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return s;
    }


    public static void replaceText(File file, String oldStr,String replaceStr) {
        String temp = "";
        try {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuffer buf = new StringBuffer();

            // 保存该行前面的内容
            for (int j = 1; (temp = br.readLine()) != null
                    && !temp.equals(oldStr); j++) {
                buf = buf.append(temp);
                buf = buf.append(System.getProperty("line.separator"));
            }

            // 将内容插入
            buf = buf.append(replaceStr);

            // 保存该行后面的内容
            while ((temp = br.readLine()) != null) {
                buf = buf.append(System.getProperty("line.separator"));
                buf = buf.append(temp);
            }

            br.close();
            FileOutputStream fos = new FileOutputStream(file);
            PrintWriter pw = new PrintWriter(fos);
            pw.write(buf.toString().toCharArray());
            pw.flush();
            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }




	public JSONObject CallIncomeDetails(String authorization,Map<String, Object> queryParam){
		String method = "get";
		return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.income.details"), method, authorization, queryParam);
	}
    public JSONObject CallLogin(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.login"), method, authorization, queryParam);
    }
    public JSONObject CallChangeOrderCategory(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.change.order.category"), method, authorization,queryParam);
    }
    public JSONObject CallAddOrderForCustomer(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.add.order.for.customer"), method, authorization,queryParam);
    }
    public JSONObject CallSendSms(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.sendsms"), method, authorization,queryParam);
    }
    public JSONObject CallResetPassword(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.reset.password"), method, authorization,queryParam);
    }
    public JSONObject CallVerifyCode(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.verify.code"), method, authorization,queryParam);
    }
    public JSONObject CallCities(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.cities"), method, authorization,queryParam);
    }
    public JSONObject CallSupportRefundBank(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.support.refund.bank"), method, authorization,queryParam);
    }
    public JSONObject CallRegister(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.register"), method, authorization,queryParam);
    }
    public JSONObject CallTotalMessage(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.total.message"), method, authorization,queryParam);
    }
    public JSONObject CallHomeMessage(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.home.message"), method, authorization,queryParam);
    }
    public JSONObject CallSettingsPanel(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.settings.panel"), method, authorization,queryParam);
    }
    public JSONObject CallGetQuOrderList(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.qu.order.list"), method, authorization,queryParam);
    }
    public JSONObject CallGetSongOrderList(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.song.order.list"), method, authorization,queryParam);
    }
    public JSONObject CallExtracCashInfo(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.extrac.cash.info"), method, authorization,queryParam);
    }
    public JSONObject CallExtracCashRecord(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.extrac.cash.record"), method, authorization,queryParam);
    }
    public JSONObject CallXiaoeRefundInfo(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.xiaoe.refund.info"), method, authorization,queryParam);
    }
    public JSONObject CallXiaoeStatusInfo(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.xiaoe.status.info"), method, authorization,queryParam);
    }
    public JSONObject CallExtracCashApply(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.extrac.cash.apply"), method, authorization,queryParam);
    }
    public JSONObject CallGetSchedule(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.schedule"), method, authorization,queryParam);
    }
    public JSONObject CallUseAutoSchedule(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.use.auto.schedule"), method, authorization,queryParam);
    }
    public JSONObject CallUseAutoScheduleReverse(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.use.auto.schedule_reverse"), method, authorization,queryParam);
    }
    public JSONObject CallSetSchedule(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.set.schedule"), method, authorization,queryParam);
    }
    public JSONObject CallMassSetSchedule(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.mass.set.schedule"), method, authorization,queryParam);
    }
    public JSONObject CallChangePassword(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.change.password"), method, authorization,queryParam);
    }
    public JSONObject CallGetNotifications(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.notifications"), method, authorization,queryParam);
    }
    public JSONObject CallGetCouriersMessages(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.couriers.message"), method, authorization,queryParam);
    }
    public JSONObject CallClearMessages(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.clear.messages"), method, authorization,queryParam);
    }
    public JSONObject CallCreatePersonInformation(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.create.person.information"), method, authorization,queryParam);
    }
    public JSONObject CallDetail(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.detail"), method, authorization,queryParam);
    }
    public JSONObject CallQrcode(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.qrcode"), method, authorization,queryParam);
    }
    public JSONObject CallQrcodeList(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.qrcode_list"), method, authorization,queryParam);
    }
    public JSONObject CallQrcodePoster(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.qrcode_poster"), method, authorization,queryParam);
    }
    public JSONObject CallQrcodeShare(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.qrcode_share"), method, authorization,queryParam);
    }
    public JSONObject CallRechargeLists(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.recharge.lists"), method, authorization,queryParam);
    }
    public JSONObject CallYigouka(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.yigouka"), method, authorization,queryParam);
    }
    public JSONObject CallGouka(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.gouka"), method, authorization,queryParam);
    }
    public JSONObject CallPostXiaoeRefundInfo(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.post.xiaoe.refund.info"), method, authorization,queryParam);
    }

    public JSONObject CallGetOrderByOrderSn(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.order.by.order_sn"), method, authorization,queryParam);
    }

    public JSONObject CallBackReasonList(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.reason.list"), method, authorization,queryParam);
    }

    public JSONObject CallWuliuSongQianshou(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu_song_qianshou"), method, authorization, queryParam);
    }

    public JSONObject CallKehuQianshou(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.kehu_qianshou"), method, authorization, queryParam);
    }

    public JSONObject CallWuliuQuTuihuiTest(Map<String, Object> queryParams){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.qu.tuihui"), method, "", queryParams);
    }

    public JSONObject CallWuliuSongTuihuiTest(Map<String, Object> queryParams){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.song.tuihui"), method, "", queryParams);
    }

    public JSONObject CallGetQuTuihuiResasonList(Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.get.reason.list"), method, "",queryParam);
    }

    public JSONObject CallWuliuQuYiqu(Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.qu.yiqu"), method, "",queryParam);
    }

    public JSONObject CallAllJobsTodoList(String s, JSONObject queryParams){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.qu.all_jobs_todo_list"), method, "",queryParams);
    }

    public JSONObject CallApplyResult(String s, JSONObject queryParams){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.qu.apply_result"), method, "",queryParams);
    }

    public JSONObject CallApply(String s, Map<String, Object> queryParams){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.wuliu.qu.apply"), method, "",queryParams);
    }

    public JSONObject CallAppVersion(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.appversin"), method, authorization, queryParam);
    }

    public JSONObject CallCityClothPriceList(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.city_cloth_price_list"), method, authorization, queryParam);
    }
    public JSONObject CallSignContract(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.sign_contract"), method, authorization, queryParam);
    }

    public JSONObject CallChangSongDeliveryTime(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.chang_song_delivery_time"), method, authorization, queryParam);
    }
    public JSONObject CallUploadAvatar(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.upload.avatar"), method, authorization, queryParam);
    }
    public JSONObject CallPayDeposit(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.pay.deposit"), method, authorization, queryParam);
    }

    public JSONObject CallWuliuDaifu(Map<String ,Object> queryParams){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.daifu"), method, "", queryParams);
    }

    public JSONObject CallWuliuFenjian(Map<String ,Object> queryParams){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.fenjian"), method, "", queryParams);
    }

    public JSONObject CallRewashVerify(String s, JSONObject queryParams) {
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.callRewashVerify"),  method, s, queryParams);
    }

    public JSONObject CallPageContentCondition(String authorization,Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.callpage_content_condition"), method, authorization, queryParam);
    }

    public JSONObject CallQrcodeOrder(String authorization,Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.globalConf.getProperty("api.wuliuapp.callqrcodeorder"), method, authorization, queryParam);
    }
}
