package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class MassSetScheduleTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testMassSetSchedule() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {
        int uid = 78;
        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", ConfigData.app_key);
        this.queryParams.put("client_name", ConfigData.client_name_android);
        this.queryParams.put("schedules", "{\"2420\":[],\"2418\":[],\"2417\":[56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71],\"2419\":[]}");
        this.queryParams.put("uid", uid);
        String sign = wuliuappModuleService.getSign(uid, queryParams);
        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallMassSetSchedule("", this.queryParams);
        logger.info(result.toJSONString());


        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));


    }
}
