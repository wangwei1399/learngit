package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by guolaidong on 2016/2/5.
 */
public class GetCourierMessagesTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    /**
     * guolaidong
     */

    public void testXiaoeRefundInfoTest() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //获取user_token
        String uid = "78";
        String usertokenstr = "select user_token from courier_profiles where courier_id = " + uid + "";
        ResultSet resultSet = mysqlQaDaoWuliu.execQuerySql(usertokenstr);
        String user_token = resultSet.getString("user_token");

        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");
        this.queryParams.put("uid", uid);
        this.queryParams.put("per_page","20");
        this.queryParams.put("page","1");

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + user_token);

        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallGetCouriersMessages("", this.queryParams);
        logger.info(result.toJSONString());

        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));



    }

}
