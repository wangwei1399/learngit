package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApplyResultTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();
    private Map<String, Object> httpHead = null;

    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    //申请小e状态
    //case1：申请提交后的状态：还未通过
    public void testApplyResult1() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        //电话
        String tel = (Long.toString(currentTime)).substring(2, 13);
        //32位随机数
        String  randomPushToken = String.valueOf(UUID.randomUUID());
        //今天
        String dateTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

        String strCourierId = "select max(id) from ims_washing_courier;";
        ResultSet resCourierId =  mysqlQaDao.execQuerySql(strCourierId);
        int courierId = resCourierId.getInt(1) + 1;
        logger.info("courierid: " + courierId);

        //插入申请的小e
        String strCourier = "insert into ims_washing_courier (realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,edaixi_nr,start_time,end_time,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,deposit,pay_deposit_state,jiebo,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel,song_angway,channel_type) \n" +
                "values('测试','000000','" + tel + "','284','1','" + randomPushToken + "','" + dateTime + "','" + dateTime + "','北京','1',NULL,'1','6226660202847238','110226198212294213','东亚银行','1','1','0','EZB-0010-00000" + courierId + "',NULL,NULL,'com." + courierId + ".zhongbao','0','1','0','android_client','1','0',NULL,'0',NULL,'男',NULL,NULL,'0','0',NULL,NULL,'0','1','0',NULL,'0',NULL,'0','0.00','0','0','测试','0','284',NULL,NULL,'1',NULL);";
        mysqlQaDao.execUpdateSql(strCourier);

         String strCourierRecruits = "insert into courier_recruits (courier_id,state,kind,name,tel,age,gender,city_id,area,street_name,service_time_type,catch_reasons,created_at,updated_at,id_photo_front,id_photo_back,ready_authority,avatar,kaitong,inviter_tel,pass_time) " +
                "values('" + courierId + "','0','1','测试','" + tel + "',NULL,'男','1',NULL,'3路;13路;42路;60路;118路;612路;701路;夜21路;夜3路,地安门东','全天','时间自由','" + dateTime + "','" + dateTime + "',NULL,NULL,NULL,'197','0','',NULL);\n";
        mysqlQaDaozhongbao.execUpdateSql(strCourierRecruits);

        String strUid = "select id from ims_washing_courier where tel = '"+tel+"'";
        ResultSet resUid =  mysqlQaDao.execQuerySql(strUid);

        //获取user_token
        String uid = resUid.getString(1);
        String strCourierProfiles = "insert into courier_profiles (courier_id,user_token) values('"+uid+"','"+randomPushToken+"');";
        mysqlQaDaoWuliu.execUpdateSql(strCourierProfiles);

        //接口传的参数，用来计算sign值
        //wuliuapp必传3通用参数
        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");
        //接口单独要求的参数
        this.queryParams.put("uid", uid);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + randomPushToken);

        this.queryParams.put("sign", sign);

        /* 调用被测接口 */
        JSONObject result = this.wuliuappModuleService.CallApplyResult("", this.queryParams);


        logger.info(result.toJSONString());

        //验证返回结果
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        //小e状态，正在申请的小e
     //   Assert.assertEquals(true, result.getString("httpBody").contains("您的申请资料已提交，请耐心等待通知"));
     //   Assert.assertEquals(true, result.getString("httpBody").contains("\"enable\":false"));

        //清除测试数据
        String strDelCourier = "delete from ims_washing_courier where tel = '" + tel + "'";
        mysqlQaDao.execUpdateSql(strDelCourier);
        String strDelCourierRecruits = "delete from courier_recruits  where tel = '" + tel + "'";
        mysqlQaDaozhongbao.execUpdateSql(strDelCourierRecruits);

    }

    @Test
    //申请小e状态
    //case2：正式小e
    public void testApplyResult2() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        //准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        long unixTimestamp =currentTime/1000;
        //电话
        String tel = (Long.toString(currentTime)).substring(2, 13);
        //32位随机数
        String  randomPushToken = String.valueOf(UUID.randomUUID());
        //今天
        String dateTime = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());

        String strCourierId = "select max(id) from ims_washing_courier;";
        ResultSet resCourierId =  mysqlQaDao.execQuerySql(strCourierId);
        int courierId = resCourierId.getInt(1) + 1;
        logger.info("courierid: " + courierId);

        //插入申请的小e
        String strCourier = "insert into ims_washing_courier (realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,start_time,end_time,edaixi_nr,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,jiebo,deposit,pay_deposit_state,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel,song_angway,channel_type) " +
                "values('测试','000000','" + tel + "',NULL,'1',NULL,'" + dateTime + "','" + dateTime + "','北京','1','5','1','1111111111111111','222222222222222222','招商银行','1','1','1','2015-11-01',NULL,'EZB-0010-0000" + courierId + "','com." + courierId + ".zhongbao','1','1','0','android_client','0','0',NULL,'0',NULL,NULL,NULL,NULL,'0','0',NULL,'0','0','" + unixTimestamp + "','" + unixTimestamp + "',NULL,'0',NULL,'0','1','0.00','1','测试','0',NULL,NULL,NULL,'1',NULL);\n";
        mysqlQaDao.execUpdateSql(strCourier);

        String strUid = "select id from ims_washing_courier where tel = '"+tel+"'";
        ResultSet resUid =  mysqlQaDao.execQuerySql(strUid);

        //获取user_token
        String uid = resUid.getString(1);
        String strCourierProfiles = "insert into courier_profiles (courier_id,user_token) values('"+uid+"','"+randomPushToken+"');";
        mysqlQaDaoWuliu.execUpdateSql(strCourierProfiles);

        //接口传的参数，用来计算sign值
        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");

        this.queryParams.put("uid", uid);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + randomPushToken);
        this.queryParams.put("sign", sign);

        //调用被测接口
        JSONObject result = this.wuliuappModuleService.CallApplyResult("", this.queryParams);
        logger.info(result.toJSONString());

        //验证
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        //小e状态正常小e
        Assert.assertEquals(true, result.getString("httpBody").contains("\"enable\":true"));

        //清除测试数据
        String strDelCourier = "delete from ims_washing_courier where tel = '" + tel + "'";
        mysqlQaDao.execUpdateSql(strDelCourier);
        String strDelCourierRecruits = "delete from courier_recruits  where tel = '" + tel + "'";
        mysqlQaDaozhongbao.execUpdateSql(strDelCourierRecruits);

    }

}