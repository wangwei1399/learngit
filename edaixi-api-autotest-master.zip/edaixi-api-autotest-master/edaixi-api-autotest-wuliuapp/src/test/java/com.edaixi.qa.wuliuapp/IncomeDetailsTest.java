package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class IncomeDetailsTest {

	private static Logger logger = LoggerFactory
			.getLogger(IncomeDetailsTest.class);
	private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
	}

	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * @author ningyao.zn
     *
     *
     *
	 */
    public void testIncomeDetails_date(){
        String date = CommonTools.getToday("yyyy-MM-dd");
        this.queryParams.put("date",date);
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("uid",79);
        this.queryParams.put("app_key",ConfigData.app_key);
        this.queryParams.put("client_name",ConfigData.client_name_android);

        String sign =  wuliuappModuleService.getSign(79, this.queryParams);
        this.queryParams.put("sign",sign);

        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallIncomeDetails("",this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }


    @Test
    public void testIncomeDetails_month(){
        String month = CommonTools.getToday("yyyy-MM");
        this.queryParams.clear();
        this.queryParams.put("date",month);
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("uid",79);
        this.queryParams.put("app_key","wuliu_app");
        this.queryParams.put("client_name","android_client");

        String sign =  wuliuappModuleService.getSign(79, this.queryParams);
        this.queryParams.put("sign",sign);

        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallIncomeDetails("",this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
    }


}
