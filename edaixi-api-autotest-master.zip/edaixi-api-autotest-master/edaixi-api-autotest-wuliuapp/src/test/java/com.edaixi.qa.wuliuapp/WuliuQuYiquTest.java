package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.CreateOrderByStatus;
import junit.framework.Assert;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class WuliuQuYiquTest {
    private static Logger logger = LoggerFactory
            .getLogger(WuliuQuYiquTest.class);
    private static WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private static CreateOrderByStatus createOrder = new CreateOrderByStatus();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();

    private static int orderId;
    private static int transTasksId;
    private static String bagsn = "00097563853";
    private static int courierId = CommonTools.get_courierId(mysqlQaDao);
    private static String remark = "";
    private static String app_version = ConfigData.app_version;
    private static String app_key = ConfigData.app_key;
    private static String client_name = ConfigData.client_name_android;
    private static String courier_lng = "116.416357";
    private static String courier_lat = "39.897651";
    private static JSONObject resultJson;

    private static Map<String, String> mapWashingOrder;

    private static void init(){
        createOrder.setCourierId(courierId);
        createOrder.getOrderByStatus(CreateOrderByStatus.orderStatus.qu_paidan);
        orderId = createOrder.getOrderId();
        transTasksId = CommonTools.getLastId("select id from trans_tasks where order_id="+orderId+" limit 1", mysqlQaDao);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("app_version", app_version);
        map.put("uid", courierId);
        map.put("app_key", app_key);
        map.put("order_id", orderId);
        map.put("remark", remark);
        map.put("client_name", client_name);
        map.put("bagsn", bagsn);
        map.put("trans_task_id", transTasksId);
        map.put("courier_lng", courier_lng);
        map.put("courier_lat", courier_lat);
        String sign = wuliuappModuleService.getSign(courierId, map);
        map.put("sign", sign);
        JSONObject result = wuliuappModuleService.CallWuliuQuYiqu(map);
        logger.info("result json:"+result.toJSONString());
        resultJson = result;

        mapWashingOrder = get_ims_washing_order_tableInfo();
    }

    private static Map<String, String> get_ims_washing_order_tableInfo(){
        Map<String, String> result = new HashMap<String, String>();

        String sql = "select bagsn, logistics_remark, qujian_time, wuliu_qu_yiqu_time, status_delivery, updated_at"
                +" from ims_washing_order where id = "+orderId+" limit 1;";

        ResultSet r = mysqlQaDao.execQuerySql(sql);

        try {
            r.beforeFirst();
            if (r.next()){
                result.put("bagsn", r.getString("bagsn"));
                result.put("logistics_remark", r.getString("logistics_remark"));
                result.put("qujian_time", r.getString("qujian_time"));
                result.put("wuliu_qu_yiqu_time", r.getString("wuliu_qu_yiqu_time"));
                result.put("status_delivery", r.getString("status_delivery"));
                result.put("updated_at", r.getString("updated_at"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    @BeforeClass
    public static void beforeClass(){
        init();
    }

    @AfterClass
    public static void afterClass(){
        String deleteSql = "delete from ims_washing_order where bagsn='"+bagsn+"';";
        mysqlQaDao.execUpdateSql(deleteSql);
        deleteSql = "delete from trans_groups where bagsn='"+bagsn+"';";
        mysqlQaDao.execUpdateSql(deleteSql);
        deleteSql = "delete from trans_tasks where bagsn='"+bagsn+"';";
        mysqlQaDao.execUpdateSql(deleteSql);
        deleteSql = "delete from working_tasks where order_id="+orderId;
        mysqlQaDao.execUpdateSql(deleteSql);
    }

    @Test
    public void testQuYiqu(){
        Assert.assertEquals("返回值不符合预期","200",resultJson.getString("httpStatus"));
    }

    @Test
    public void ims_washing_order_bagsn(){//_ims_washing_order_bagsn
        mapWashingOrder = get_ims_washing_order_tableInfo();
        String errorText = "ims_washing_order表的bagsn字段值不正确!";
        String mapText = mapWashingOrder.get("bagsn");
        logger.info("ims_washing_order表的bagsn字段的值为"+mapText);
        Assert.assertEquals(errorText, bagsn, mapText);
    }

    @Test
    public void ims_washing_order_logistics_remark(){
        String errorText = "ims_washing_order表的logistics_remark字段值不正确!";
        String mapText = mapWashingOrder.get("logistics_remark" );
        logger.info("ims_washing_order表的logistics_remark"+mapText);
        Assert.assertEquals(errorText, remark, mapText);
    }

}