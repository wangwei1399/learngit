package com.edaixi.qa.wuliuapp;

import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

/**
 * Created by guolaidong on 2016/6/13.
 */
public class GetSign {

    public static String getSign(Map<String, Object> queryParams) throws UnsupportedEncodingException {
        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        ParseMD5 parseMD5 = new ParseMD5();
        //String sign = parseMD5.parseStrToMd5L32(strqueryParams + "J3n4dMTSPQ" + user_token);
        return "";

    }
}
