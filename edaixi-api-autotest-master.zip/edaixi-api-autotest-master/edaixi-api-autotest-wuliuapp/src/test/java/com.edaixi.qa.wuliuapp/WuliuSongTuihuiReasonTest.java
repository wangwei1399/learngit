package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class WuliuSongTuihuiReasonTest {

    @Test
    public void testReason1(){
        new WuliuSongTuihuiTest().testWuliuSongTuihui("联系不上客户");
    }

    @Test
    public void testReason2(){
        new WuliuSongTuihuiTest().testWuliuSongTuihui("客户不家无法送件");
    }

    @Test
    public void testReason3(){
        new WuliuSongTuihuiTest().testWuliuSongTuihui("其他:测试原因");
    }


}