package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.CreateOrderByStatus;
import junit.framework.Assert;
import org.junit.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class WuliuFenjianTest {
    private static WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static Logger logger = LoggerFactory
            .getLogger(WuliuFenjianTest.class);

    private static String app_version = ConfigData.app_version;
    private static int courierId = CommonTools.get_courierId(mysqlQaDao);
    private static String app_key = ConfigData.app_key;
    private static String client_name = ConfigData.client_name_android;
    private static String courier_lng = "116.416357";
    private static String courier_lat = "39.897651";
    private static int transTaskId;
    private static int orderId;
    private static JSONObject resultJson;

    /**
     * 创建初始化数据方法
     */
    private static void init(){
        CreateOrderByStatus createOrder = new CreateOrderByStatus();
        createOrder.setCourierId(courierId);    //设置创建订单分配的小e
        createOrder.getOrderByStatus(CreateOrderByStatus.orderStatus.qu_paidan); //创建调度取派单状态的订单

        orderId = createOrder.getOrderId();
        transTaskId = CommonTools.getLastId("select id from trans_tasks where order_id="+orderId+" limit 1;", mysqlQaDao);
        logger.info("create orderId:"+orderId);

        //商品计价列表
        String amount_list = "{\"4525\":0,\"3995\":0,\"2413\":0,\"239\":1,\"2885\":0,\"4143\":0,\"4144\":0,\"104\":0,\"242\":0,\"103\":0,\"236\":0,\"237\":1}";

        Map<String ,Object> map = new HashMap<String, Object>();
        map.put("app_version", app_version);
        map.put("app_key", app_key);
        map.put("client_name", client_name);
        map.put("order_id", orderId);
        map.put("uid", courierId);
        map.put("trans_task_id", transTaskId);
        map.put("security_check", "false");
        map.put("courier_lng", courier_lng);
        map.put("courier_lat", courier_lat);
        map.put("amount_list", amount_list);
        String sign = wuliuappModuleService.getSign(courierId, map);
        map.put("sign", sign);

        resultJson = wuliuappModuleService.CallWuliuFenjian(map);
        logger.info("result json:"+resultJson.toJSONString());
    }

    public int getOrderId(){
        logger.info("get orderId:"+orderId);
        return orderId;
    }

    @BeforeClass
    public static void before(){
        init();
    }

    @Test
    public void testRequest(){
        Assert.assertEquals("返回值不符合预期","200",resultJson.getString("httpStatus"));
        JSONObject body = JSON.parseObject(resultJson.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","true",body.getString("ret"));
    }






}