package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class RewashVerifyTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testRewashVerify() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {
        //获取user_token
        String uid = "143";
        String usertokenstr = "select user_token from courier_profiles where courier_id = " + uid + "";
        ResultSet resultSet = mysqlQaDaoWuliu.execQuerySql(usertokenstr);
        String user_token = resultSet.getString("user_token");

        /**
         * 做订单数据
         */
        long currentTime = System.currentTimeMillis();
        long unixTimestamp =currentTime/1000;
        String a = "4";
        //订单号
        long ordersn = Long.parseLong(a.concat(Long.toString(currentTime)));
        //封签号
        String bagsn = (Long.toString(currentTime)).substring(2, 13);
        //今天
        String dateTime = (new SimpleDateFormat("yyyy-MM-dd")).format(new Date());
        String dateTimeHHmmss = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
        //明天
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE,+1);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String tomorrowTime = sdf.format(calendar.getTime());
        //订单后六位
        String lastSixordersn = (Long.toString(ordersn)).substring(8, 14);
        //衣物条码号
        String washingBarcode = (Long.toString(currentTime)).substring(5, 13);

        /**
         * 插入数据库新订单数据
         * (1)ims_washing_order
         * (3)trans_tasks
         * (5)trans_groups
         * (6)working_tasks
         */

        //订单表ims_washing_order插入数据
        String strOrder = "insert into ims_washing_order (from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid,status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time,createtime,qujian_paidan_time,qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time,jiagongdian_qianshou_time,jiagongdian_id,wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time,wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time,jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status,diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi,yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id,address_song_id,auto_dispatched_qu_at,auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count,washing_duration,model_version) " +
                "values" +
                "(NULL,'3','" + ordersn + "','','1','0.00','0.00','','0.00','0.00','0.00','1','9','',NULL,'0','1',' [ 背心 深蓝灰]','" + dateTime + "','18:00-19:00','','','测试员','13681057539','北京','东城区','马杓胡同甲27号','北京','东城区','马杓胡同甲27号','" + uid + "','0','0',NULL,'0',NULL,'0',NULL,'" + unixTimestamp + "','" + unixTimestamp + "','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'" + dateTimeHHmmss + "','" + dateTimeHHmmss + "','0','" + unixTimestamp + "','0','0',NULL,'1','247834068','0','623419',NULL,'18','2417','42','43',NULL,NULL,NULL,'0','595735','595735',NULL,NULL,'" + lastSixordersn + "','1','0',NULL,NULL,'0.00','247834068','1',NULL,'11');";
        mysqlQaDao.execUpdateSql(strOrder);
        //找到orderid
        String strOrderId = "select id from ims_washing_order where ordersn = '" + ordersn + "'";
        ResultSet rsOrderId =  mysqlQaDao.execQuerySql(strOrderId);
        String orderId = rsOrderId.getString(1);

        //新衣物表order_clothes_lists插入数据
        String strOrdClothList = "insert into order_clothes_lists (order_id,order_sn,bag_sn,status,courier_id,outlet_id,clothes_id,clothes_name,courier_price_id,outlet_price_id,courier_price,outlet_price,flaw,color,grid,brand,wash_result,can_rewash,can_wash,cannot_wash_reason,rewash_reason,primary_rewash_flaw,primary_rewash_operation,secondary_rewash_flaw,secondary_rewash_operation,washing_barcode,original_barcode,outlet_sort_time,outlet_report_time,ori_id,is_deleted,created_at,updated_at,rewash,type,courier_sort_time,verify_code,undeal_flaw,rewash_operation_id,is_bargain,suit_id) " +
                "values" +
                "('" + orderId + "','" + ordersn + "',NULL,'92',NULL,'458','8','背心',NULL,NULL,'-12.00','-9.00','','深蓝灰',NULL,'',NULL,'1','1',NULL,'没洗干净 11',NULL,NULL,NULL,NULL,'" + washingBarcode + "',NULL,NULL,NULL,NULL,NULL,'" + dateTimeHHmmss + "','" + dateTimeHHmmss + "','0','OrderClothesList',NULL,NULL,NULL,NULL,'0','0');";
        mysqlQaDao.execUpdateSql(strOrdClothList);

        /**
         *做交接单数据
         */
        //数据准备，交接单id
        String strTrans = "select max(id),max(trans_group_id) from trans_tasks";
        ResultSet resMaxid =  mysqlQaDao.execQuerySql(strTrans);
        int max_id = Integer.parseInt(resMaxid.getString(1));
        int max_id1 = max_id + 1;
        int max_id2 = max_id + 2;
        int max_id3 = max_id + 3;
        int max_group_id = Integer.parseInt(resMaxid.getString(2)) + 1;

        //(3)trans_tasks表里插入数据
        String strTransTask = "insert into trans_tasks (bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type,city_id) values(NULL,'" + uid + "','zhongbao',NULL,NULL,'customer','595735',NULL,NULL,NULL,'" + dateTimeHHmmss + "',NULL,'started','get',NULL,'" + dateTimeHHmmss + "','" + dateTimeHHmmss + "','1','" + ordersn + "','unwashed','" + orderId + "','" + max_group_id + "','0','0','1');";
        mysqlQaDao.execUpdateSql(strTransTask);

        //dispatch_task表里插入数据
        String strDispatch = "insert into dispatch_tasks (order_id,status,from_type,from_id,to_type,to_id,dispatch_type,courier_id,hope_time,finished_at,category_id,created_at,updated_at,type,ordersn,city_id,extra_type) values('" + orderId + "','dispatched','jiagongdian',NULL,'Address','595735','0','" + uid + "','" + dateTimeHHmmss + "',NULL,'1','" + dateTimeHHmmss + "','" + dateTimeHHmmss + "','DispatchTask',NULL,'1','0');";
        mysqlQaDao.execUpdateSql(strDispatch);

        //trans_group表里插入数据,找出dispatch_task_id
        String strDispatchid = "SELECT id FROM dispatch_tasks WHERE order_id = '" + orderId + "'";
        ResultSet resDispatchid = mysqlQaDao.execQuerySql(strDispatchid);
        String dispatch_task_id = resDispatchid.getString(1);
        //(4)trans_groups表里插入数据
        String strTransGroup = "insert into trans_groups (order_id,ordersn,bagsn,current_task_id,last_task_id,order_type,order_status,status_delivery,type,created_at,updated_at,propose_outlet_id,dispatch_task_id,full_process_deadline,last_process_deadline) " +
                "values" +
                "('" + orderId + "','" + ordersn + "',NULL,'" + max_id1 + "','" + max_id1 + "',NULL,'1',NULL,'TransGroup','" + dateTimeHHmmss + "','" + dateTimeHHmmss + "',NULL,'" + dispatch_task_id + "',NULL,NULL);";
        mysqlQaDao.execUpdateSql(strTransGroup);

        //找出order_clothes_lists表里的id
        String strClothListId = "SELECT id FROM order_clothes_lists WHERE order_id = '" + orderId + "'";
        ResultSet rsClothListId = mysqlQaDao.execQuerySql(strClothListId);
        String clothListId = rsClothListId.getString(1);

        String goodsItems = "[{\"goods_id\":\"" + clothListId + "\",\"wash_code_type\":0,\"input_wash_code\":\"" + washingBarcode + "\"}]";

        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", ConfigData.app_key);
        this.queryParams.put("client_name", ConfigData.client_name_android);
        this.queryParams.put("goods_items", goodsItems);
        this.queryParams.put("order_id", orderId);
        this.queryParams.put("uid", uid);

        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + user_token);

        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallRewashVerify("", this.queryParams);
        logger.info(result.toJSONString());

        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }


}