package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.*;

public class CreatePersonInformationTest {
    private static Logger logger = LoggerFactory
            .getLogger(CreatePersonInformationTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test

    public void testCreatePersonInformationTest() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        String pushToken = (int)(currentTime % 1000000) + "OrtUe51BjU";
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key","wuliu_app");
        this.queryParams.put("client_name","android_client");
        this.queryParams.put("address","北京酒仙桥大山子");
        this.queryParams.put("tel","12345678944");
        this.queryParams.put("tags","11");
        this.queryParams.put("uid","78");
//        List<String> queryParamslist = new ArrayList<String>();
//        for (String key : queryParams.keySet()) {
//            queryParamslist.add(key + "=" + queryParams.get(key));
//        }
//        Collections.sort(queryParamslist);
//        StringBuilder sbBuilder = new StringBuilder();
//        for (String paramsListItem : queryParamslist) {
//            sbBuilder.append(paramsListItem);
//            sbBuilder.append("&");
//        }
//        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
//        String sign=this.wuliuappModuleService.string2MD5UTF8(addString + "J3n4dMTSPQ");
        String sign = wuliuappModuleService.getSign("78",queryParams);
        this.queryParams.put("sign",sign);
        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallCreatePersonInformation("", this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

    }

}