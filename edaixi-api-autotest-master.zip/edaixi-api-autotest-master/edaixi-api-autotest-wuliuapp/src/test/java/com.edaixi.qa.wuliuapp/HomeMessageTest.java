package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

/**
 * Created by guolaidong on 2016/2/1.
 */
public class HomeMessageTest {

    private static Logger logger = LoggerFactory
            .getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private JSONObject queryParams = new JSONObject();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }

    @Test
    public void testHomeMessage() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int uid = 78;
        //获取到用户的token
        String queryTokenInfo = "select user_token from courier_profiles where courier_id = " + uid + "";
        ResultSet queryTokenInfoRet = mysqlQaDaoWuliu.execQuerySql(queryTokenInfo);
        String user_token = queryTokenInfoRet.getString("user_token");

        this.queryParams.put("uid","78");
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key",ConfigData.app_key);
        this.queryParams.put("client_name",ConfigData.client_name_android);
        List<String> queryParamslist = new ArrayList<String>();
        for (String key :queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem :queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign=this.wuliuappModuleService.string2MD5UTF8(addString + "J3n4dMTSPQ" + user_token);
        this.queryParams.put("sign",sign);


        // 调用登录接口
        JSONObject result = this.wuliuappModuleService.CallHomeMessage("",this.queryParams);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"ret\":true"));
        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals(true, result.getString("httpBody").contains("home_info"));
        Assert.assertEquals(true, result.getString("httpBody").contains("today_income"));
        Assert.assertEquals(true, result.getString("httpBody").contains("extrac_cash"));
        Assert.assertEquals(true, result.getString("httpBody").contains("current_month_income"));
        Assert.assertEquals(true, result.getString("httpBody").contains("star_rating"));
        Assert.assertEquals(true, result.getString("httpBody").contains("date"));
        Assert.assertEquals(true, result.getString("httpBody").contains("shitika_number"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_van"));
        Assert.assertEquals(true, result.getString("httpBody").contains("update"));
        Assert.assertEquals(true, result.getString("httpBody").contains("message"));
        Assert.assertEquals(true, result.getString("httpBody").contains("forced"));
        Assert.assertEquals(true, result.getString("httpBody").contains("uri"));
        Assert.assertEquals(true, result.getString("httpBody").contains("is_updated"));
        Assert.assertEquals(true, result.getString("httpBody").contains("func_list"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":1"));
        //Assert.assertEquals(true,result.getString("httpBody").contains("\"id\":12463"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"qujian\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("url"));
        Assert.assertEquals(true, result.getString("httpBody").contains("klass"));
        Assert.assertEquals(true, result.getString("httpBody").contains("type"));
        Assert.assertEquals(true, result.getString("httpBody").contains("id"));
        Assert.assertEquals(true, result.getString("httpBody").contains("url_type"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"取件\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("image_url"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":0"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"enable\":true"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":2"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"songjian\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"送件\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":1"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":3"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"zhuanyundan\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"转运单\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":2"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":4"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"zhuanyun\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"转运\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":3"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":5"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"chongzhi\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"售卡\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":4"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":6"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"tuiguang\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"推广\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":5"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":11"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"lanshou\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"揽收\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":6"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":7"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"xiaoxi\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"消息\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":7"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":8"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"xiaoe\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"小e申请\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":8"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":9"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"zancun\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"暂存\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":9"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"id\":10"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"name\":\"zancundan\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"暂存单\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"position\":10"));
        Assert.assertEquals(true, result.getString("httpBody").contains("tip_message"));
        Assert.assertEquals(true, result.getString("httpBody").contains("banner"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"banner管理\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("description"));
        Assert.assertEquals(true, result.getString("httpBody").contains("\"title\":\"奢侈品\""));
        Assert.assertEquals(true, result.getString("httpBody").contains("popups"));
        Assert.assertEquals(true, result.getString("httpBody").contains("avatar"));
        Assert.assertEquals(true, result.getString("httpBody").contains("small_avatar_url"));
        Assert.assertEquals(true, result.getString("httpBody").contains("normal_avatar_url"));



    }
}
