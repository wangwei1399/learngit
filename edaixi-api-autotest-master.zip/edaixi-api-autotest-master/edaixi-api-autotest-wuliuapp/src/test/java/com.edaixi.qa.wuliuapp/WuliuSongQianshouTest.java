package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class WuliuSongQianshouTest {
    private static Logger logger = LoggerFactory.getLogger(WuliuSongQianshouTest.class);
    private static WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private static GeneralRongChain04Data rongchang04 = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();

    private static String order_id;
    private static int courier_id;
    private static String order_sn;
    private static String bagsn = "00038769511";
    private int trans_task_id;


    private final String app_version = ConfigData.app_version;
    private final String client_name_android = ConfigData.client_name_android;
    private final String app_key = ConfigData.app_key;



    private void createOrder(){
        int id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao);
        order_id = String.valueOf(id+1);
        order_sn = CommonTools.getOrdersn(order_id);
        courier_id = CommonTools.get_courierId(mysqlQaDao);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("order_id", order_id);
        tmp.put("order_sn", order_sn);
        tmp.put("status", 1);
        tmp.put("status_delivery", 15);
        tmp.put("pay_status", 1);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        tmp.put("washing_time", "22:00-24:00");
        tmp.put("uid", courier_id);
        tmp.put("old_category_id", 2);
        tmp.put("uid_song", courier_id);
        tmp.put("bagsn", bagsn);
        rongchang04.GeneralOrder(tmp);
    }

    private void createTrans(){
        int tmp_dispatch_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao);
        String dispatch_id = String.valueOf(tmp_dispatch_id+1);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("id", dispatch_id);
        tmp.put("order_id", order_id);
        tmp.put("status", "finished");
        tmp.put("courier_id", courier_id);
        tmp.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd 00:00:00", 1));
        tmp.put("category_id", 2);
        rongchang04.GeneralDispatchTask(tmp);

        int tmp_group_id = CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao);
        String group_id = String.valueOf(tmp_group_id+1);
        tmp.clear();
        tmp.put("id", group_id);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("current_task_id", 0);
        tmp.put("last_task_id", 0);
        tmp.put("dispatch_task_id", dispatch_id);
        tmp.put("order_id", order_id);
        rongchang04.GeneralTransGroups(tmp);


        int tmp_trans_tasks_id = CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao);
        trans_task_id = (++tmp_trans_tasks_id);
        tmp.clear();
        tmp.put("id", trans_task_id);
        tmp.put("ordersn", order_sn);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "finished");
        tmp.put("direction", "get");
        tmp.put("category_id", 2);
        tmp.put("trans_group_id", group_id);
        tmp.put("washing_status", "unwashed");
        tmp.put("finished_at", CommonTools.getToday("yyyy-MM-dd hh:mm:ss"));
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "send");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("from_id", 67);
        tmp.put("from_type", "jiagongdian");
        tmp.put("to_id", courier_id);
        tmp.put("to_type", "zhongbao");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "started");
        tmp.put("direction", "send");
        tmp.remove("finished_at");
        tmp.put("washing_status", "washed");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("to_id", "NULL");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", "NULL");
        tmp.put("direction", "send");
        tmp.put("status", "init");
        rongchang04.GeneralTransTasks(tmp);


        String sql = "update trans_groups set current_task_id="+(tmp_trans_tasks_id-1)+", last_task_id="+trans_task_id+
                " where id ="+group_id;
        mysqlQaDao.execUpdateSql(sql);
    }


    @Test
    public void testWuliuSongQianshouTest(){
        createOrder();
        createTrans();

        String nowUnix = String.valueOf(System.currentTimeMillis()).substring(0, 10);
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("courier_lng", nowUnix);
        param.put("app_version" , app_version);
        param.put("uid" , courier_id);
        param.put("app_key" , app_key);
        param.put("courier_lat" , nowUnix);
        param.put( "trans_task_id" , trans_task_id);
        param.put( "order_id" , order_id);
        param.put( "client_name" , client_name_android);
        param.put("verify_code", order_sn);
        String sing = wuliuappModuleService.getSign(courier_id , param);
        param.put("sign" , sing);

        JSONObject resultJson = wuliuappModuleService.CallWuliuSongQianshou("", param);
        logger.info("result json:"+resultJson.toJSONString());
        Assert.assertEquals("返回值不符合预期","200",resultJson.getString("httpStatus"));
    }

}