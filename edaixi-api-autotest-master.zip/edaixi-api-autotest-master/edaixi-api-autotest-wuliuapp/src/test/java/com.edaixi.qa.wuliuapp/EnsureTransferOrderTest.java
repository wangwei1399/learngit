package com.edaixi.qa.wuliuapp;

import junit.framework.Assert;
import org.junit.Test;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.ParseException;
//药直达确认机制
public class EnsureTransferOrderTest {


@Test


public void testAddOrderForCustomer() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {Assert.assertEquals("返回值不符合预期",1,0);}

}