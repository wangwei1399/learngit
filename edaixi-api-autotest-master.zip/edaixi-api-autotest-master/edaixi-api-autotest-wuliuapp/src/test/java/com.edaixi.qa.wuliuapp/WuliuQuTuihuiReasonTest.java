package com.edaixi.qa.wuliuapp;


import org.junit.Test;

public class WuliuQuTuihuiReasonTest {

    @Test
    public void testReason1(){
        new WuliuQuTuihuiTest().testWuliuQuTuihui("订单时段不能服务");
    }

    @Test
    public void testReason2(){
        new WuliuQuTuihuiTest().testWuliuQuTuihui("地址不在本人服务区");
    }

    @Test
    public void testReason3(){
        new WuliuQuTuihuiTest().testWuliuQuTuihui("联系不上客户");
    }

    @Test
    public void testReason4(){
        new WuliuQuTuihuiTest().testWuliuQuTuihui("客户要求取消订单");
    }

    @Test
    public void testReason5(){
        new WuliuQuTuihuiTest().testWuliuQuTuihui("其他:测试其他");
    }

}