package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class ApplyTest {

    private static Logger logger = LoggerFactory.getLogger(LoginTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private Map<String, Object> queryParams = new HashMap<String, Object>();
    private JSONObject couponParams = new JSONObject();

    private Map<String, Object> httpHead1 = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlQaDaoWuliu = new MysqlQaDao("jdbc.wuliu.properties");
    MysqlQaDao mysqlQaDaozhongbao = new MysqlQaDao("jdbc.zhongbao.properties");

    @Before
    public void setUp() {
        this.httpHead1 = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test
    //提交小e申请资料
    //case1：正常的申请
    public void testApply1() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        String tel = (Long.toString(currentTime)).substring(2, 13);
        String  randomPushToken = String.valueOf(UUID.randomUUID());

//        String strCourierId = "select max(id) from ims_washing_courier;";
//        ResultSet resCourierId =  mysqlQaDao.execQuerySql(strCourierId);
//        int courierId = resCourierId.getInt(1) + 1;
//        resCourierId.close();
//        resCourierId = null;
        int courierId = CommonTools.getLastId("select id from ims_washing_courier order by id desc limit 1;", mysqlQaDao)+1;


        String strCourier = "insert into ims_washing_courier (id,realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,start_time,end_time,edaixi_nr,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,jiebo,deposit,pay_deposit_state,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel,song_angway,channel_type) " +
                "values("+courierId+",'测试','000000','"+tel+"','0','1','"+randomPushToken+"','2016-03-31 11:43:26','2016-03-31 11:43:30','北京','1',NULL,'1','6226660212847238','110126198212294212','东亚银行','1','1','0',NULL,NULL,'EZB-0010-000"+courierId+"','com."+courierId+".zhongbao','0','1','0','android_client','1','0',NULL,'0',NULL,'男',NULL,NULL,'0','0',NULL,'0','0','1','0',NULL,'0',NULL,'0','0','0.00','0','测试','0',NULL,NULL,NULL,'1',NULL);\n";
        mysqlQaDao.execUpdateSql(strCourier);


        logger.info("courierid: " + courierId);
        int courier_recruitsId = CommonTools.getLastId("select id from courier_recruits order by id desc limit 1;", mysqlQaDaozhongbao)+1;
        String strCourierRecruits = "insert into courier_recruits (id,courier_id,state,kind,name,tel,age,gender,city_id,area,street_name,service_time_type,catch_reasons,created_at,updated_at,id_photo_front,id_photo_back,kaitong,avatar,ready_authority,inviter_tel,pass_time) " +
                "values("+courier_recruitsId+","+courierId+",'0','1','测试','"+tel+"',NULL,'男','1',NULL,'测试地址','全天','时间自由','2016-03-31 11:13:22','2016-03-31 11:13:22',NULL,NULL,'0','43',NULL,'',NULL);\n";
        mysqlQaDaozhongbao.execUpdateSql(strCourierRecruits);

//        String strUid = "select id from ims_washing_courier where tel = '"+tel+"'";
//        ResultSet resUid =  mysqlQaDao.execQuerySql(strUid);

        //获取user_token
        String uid = String.valueOf(courierId);//resUid.getString(1);
//        resUid.close();
//        resUid = null;

//        String strCourierProfiles = "insert into courier_profiles (courier_id,user_token) values('"+uid+"','"+randomPushToken+"');";
//        mysqlQaDaoWuliu.execUpdateSql(strCourierProfiles);
//        logger.info("sing:", randomPushToken);
        this.queryParams.put("app_version",ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");
        this.queryParams.put("apply_name", "test");
        this.queryParams.put("catch_reasons", "a");
        this.queryParams.put("idcard_number", "110226198212294212");
        this.queryParams.put("inviter_tel", "");
        this.queryParams.put("isconfirm", "0");
        this.queryParams.put("service_time_type", "3");
        this.queryParams.put("street_name", "3;13;42;60;118;612;701;21;3");
        this.queryParams.put("uid", uid);
        this.queryParams.put("avatar", "http://avatar-10000135.image.myqcloud.com/de6bf194-ac09-44ac-b6d6-6ad66ca8e600");

        String sign = wuliuappModuleService.getSign(uid,this.queryParams);
        //生成sign
        //map里排序
//        TreeMap treemap = new TreeMap(this.queryParams);
//
//        //遍历treemap，用&链接
//        Object key = null;
//        Object value = null;
//        String strkeyvalue = "";
//
//        Iterator it = treemap.keySet().iterator();
//        while (it.hasNext()) {
//            key = it.next();
//            value = treemap.get(key);
//            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
//        }
//        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
//        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + randomPushToken);

        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallApply("", this.queryParams);
        logger.info(result.toJSONString());

        Assert.assertTrue(result.getString("httpStatus").equals("201"));
        Assert.assertEquals(true, result.getString("httpBody").contains("您的资料正在审核中，请耐心等待通知"));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

        //清除测试数据
//        String strDelCourier = "delete from ims_washing_courier where tel = '" + tel + "'";
        String strDelCourier = "delete from ims_washing_courier where id="+courierId;
        mysqlQaDao.execUpdateSql(strDelCourier);
//        String strDelCourierRecruits = "delete from courier_recruits  where tel = '" + tel + "'";
        String strDelCourierRecruits = "delete from courier_recruits  id="+courier_recruitsId;
        mysqlQaDaozhongbao.execUpdateSql(strDelCourierRecruits);

    }


    @Test
    //小e申请资料
    //case2:非正常的申请，身份证号不正确
    public void testApply2() throws SQLException, UnsupportedEncodingException, NoSuchAlgorithmException {

        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
        String tel = (Long.toString(currentTime)).substring(2, 13);
        String  randomPushToken = String.valueOf(UUID.randomUUID());

        String strCourierId = "select max(id) from ims_washing_courier;";
        ResultSet resCourierId =  mysqlQaDao.execQuerySql(strCourierId);
        int courierId = resCourierId.getInt(1) + 1;
        logger.info("courierid: " + courierId);

        String strCourier = "insert into ims_washing_courier (realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,start_time,end_time,edaixi_nr,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,jiebo,deposit,pay_deposit_state,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel,song_angway,channel_type) " +
                "values('测试','000000','"+tel+"','0','1','"+randomPushToken+"','2016-03-31 11:43:26','2016-03-31 11:43:30','北京','1',NULL,'1','6226660202847238','110226198212294212','东亚银行','1','1','0',NULL,NULL,'EZB-0010-000"+courierId+"','com."+courierId+".zhongbao','0','1','0','android_client','1','0',NULL,'0',NULL,'男',NULL,NULL,'0','0',NULL,'0','0','1','0',NULL,'0',NULL,'0','0','0.00','0','测试','0',NULL,NULL,NULL,'1',NULL);\n";
        mysqlQaDao.execUpdateSql(strCourier);

        String strCourierRecruits = "insert into courier_recruits (courier_id,state,kind,name,tel,age,gender,city_id,area,street_name,service_time_type,catch_reasons,created_at,updated_at,id_photo_front,id_photo_back,kaitong,avatar,ready_authority,inviter_tel,pass_time) " +
                "values('"+courierId+"','0','1','测试','"+tel+"',NULL,'男','1',NULL,'测试地址','全天','时间自由','2016-03-31 11:13:22','2016-03-31 11:13:22',NULL,NULL,'0','43',NULL,'',NULL);\n";
        mysqlQaDaozhongbao.execUpdateSql(strCourierRecruits);

        String strUid = "select id from ims_washing_courier where tel = '"+tel+"'";
        ResultSet resUid =  mysqlQaDao.execQuerySql(strUid);

        //获取user_token
        String uid = resUid.getString(1);

        String strCourierProfiles = "insert into courier_profiles (courier_id,user_token) values('"+uid+"','"+randomPushToken+"');";
        mysqlQaDaoWuliu.execUpdateSql(strCourierProfiles);

        this.queryParams.put("app_version", ConfigData.app_version);
        this.queryParams.put("app_key", "wuliu_app");
        this.queryParams.put("client_name", "android_client");

        this.queryParams.put("apply_name", "测试");
        this.queryParams.put("catch_reasons", "a");
        //身份证号不对
        this.queryParams.put("idcard_number", "110226198212294213");
        this.queryParams.put("inviter_tel", "");
        this.queryParams.put("isconfirm", "0");
        this.queryParams.put("service_time_type", "3");
        this.queryParams.put("street_name", "3路;13路;42路;60路;118路;612路;701路;夜21路;夜3路,地安门东");
        this.queryParams.put("uid", uid);
        this.queryParams.put("avatar", "http://avatar-10000135.image.myqcloud.com/de6bf194-ac09-44ac-b6d6-6ad66ca8e600");


        //生成sign
        //map里排序
        TreeMap treemap = new TreeMap(this.queryParams);

        //遍历treemap，用&链接
        Object key = null;
        Object value = null;
        String strkeyvalue = "";

        Iterator it = treemap.keySet().iterator();
        while (it.hasNext()) {
            key = it.next();
            value = treemap.get(key);
            strkeyvalue = strkeyvalue + key.toString() + "=" + value.toString() + "&";
        }
        String strqueryParams = strkeyvalue.substring(0, strkeyvalue.length() - 1);

        //计算sign
        String sign = this.wuliuappModuleService.string2MD5UTF8(strqueryParams + "J3n4dMTSPQ" + randomPushToken);

        this.queryParams.put("sign", sign);

        JSONObject result = this.wuliuappModuleService.CallApply("", this.queryParams);
        logger.info(result.toJSONString());

        Assert.assertEquals(true, result.getString("httpBody").contains("\"commit_status\":false"));

        JSONObject loginBody = JSON.parseObject(result.getString("httpBody"));

        //清除测试数据
//        String strDelCourier = "delete from ims_washing_courier where tel = '" + tel + "'";
        String strDelCourier = "delete from ims_washing_courier where id="+courierId;
        mysqlQaDao.execUpdateSql(strDelCourier);
//        String strDelCourierRecruits = "delete from courier_recruits  where tel = '" + tel + "'";
        String strDelCourierRecruits = "delete from courier_recruits  where courier_id="+courierId;
        mysqlQaDaozhongbao.execUpdateSql(strDelCourierRecruits);


    }




}