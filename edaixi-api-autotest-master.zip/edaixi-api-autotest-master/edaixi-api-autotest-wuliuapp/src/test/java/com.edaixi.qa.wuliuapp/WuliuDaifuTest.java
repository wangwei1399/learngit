package com.edaixi.qa.wuliuapp;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.CreateOrderByStatus;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Timestamp;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class WuliuDaifuTest {
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static WuliuappModuleService moduleService = new WuliuappModuleService();
    private static Logger logger = LoggerFactory
            .getLogger(WuliuDaifuTest.class);

    private static int pay_type = 6;
    private static String app_version = ConfigData.app_version;
    private static int courierId = CommonTools.get_courierId(mysqlQaDao);
    private static String app_key = ConfigData.app_key;
    private static String client_name = ConfigData.client_name_android;
    private static int transTaskId;
    private static int orderId;
    private static JSONObject resultJson;

    private static void init(){
//        CreateOrderByStatus createOrder = new CreateOrderByStatus();
//        createOrder.setCourierId(courierId);
//        createOrder.getOrderByStatus(CreateOrderByStatus.orderStatus.qu_paidan);
//
//        orderId = createOrder.getOrderId();

        //运行分拣接口测试,用于创建相关数据,并且获得id
        WuliuFenjianTest fenjianTest = new WuliuFenjianTest();
        fenjianTest.before();
        orderId = fenjianTest.getOrderId();
        transTaskId = CommonTools.getLastId("select id from trans_tasks where order_id="+orderId+" limit 1;", mysqlQaDao);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pay_type", pay_type);
        map.put("app_version", app_version);
        map.put("uid", courierId);
        map.put("app_key", app_key);
        map.put("trans_task_id", transTaskId);
        map.put("order_id", orderId);
        map.put("client_name", client_name);
        String sign = moduleService.getSign(courierId, map);
        map.put("sign", sign);

        resultJson = moduleService.CallWuliuDaifu(map);
        logger.info("result json:"+resultJson.toJSONString());
    }

    @BeforeClass
    public static void beforeClass(){
        init();
    }

    @Test
    public void testDaifu(){
        Assert.assertEquals("返回值不符合预期","200",resultJson.getString("httpStatus"));
        JSONObject body = JSON.parseObject(resultJson.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期","true",body.getString("ret"));
    }
}