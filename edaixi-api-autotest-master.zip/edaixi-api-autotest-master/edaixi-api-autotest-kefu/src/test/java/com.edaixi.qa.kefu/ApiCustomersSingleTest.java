package com.edaixi.qa.kefu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ApiCustomersSingleTest {

	private static Logger logger = LoggerFactory
			.getLogger(ApiCustomersSingleTest.class);
	private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao1 = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
	}


	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * http://api09.edaixi.cn:3329/api/v1/customers/single?mobile=15313019855
	 *
	 * @author ningyao.zn
	 */
	public void testApiCustomersSingle() throws SQLException{
		}
}
