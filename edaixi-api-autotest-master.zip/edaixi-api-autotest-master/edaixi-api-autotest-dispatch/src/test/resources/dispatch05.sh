ssh test05 "kill -9 \$(ps -ef|grep sidekiq |awk '{print \$2}')"
ssh test05 "bash -l -c 'cd /data/www/app/wuliu/current;nohup bundle exec sidekiq -e production >/dev/null 2>&1 &'"
ssh test05 "bash -l -c 'cd /data/www/app/api_server/current;nohup bundle exec sidekiq -e production >/dev/null 2>&1 &'"
