package com.edaixi.qa.dispatch;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * Created by he_yi on 16/10/31.
 */
public class SSH {
    private static Logger logger = LoggerFactory.getLogger(SSH.class);
    private static File keyFile = new File("src/test/resources/TnWqFPNVUkkeQNzUNb.pem");

    private SSH(){

    }



    public static void runShellFile(String filePatch){
        String hostName = "54.223.154.75";
        int port = 22;
        String loginName = "ubuntu";

        Connection conn = new Connection(hostName, port);
        Session ssh = null;
        try {
            conn.connect();

            boolean isConn = conn.authenticateWithPublicKey(loginName, keyFile, "");
            if (!isConn){
//                System.out.println("链接失败：用户名或密码错误");
                logger.info("ssh链接失败");
            }else{
//                System.out.println("链接成功");
                logger.info("ssh连接成功");
                //拷贝本地文件到服务器
                SCPClient clt = conn.createSCPClient();
                clt.put(filePatch, "/tmp");
                String fileName = filePatch.substring(filePatch.lastIndexOf("/")+1, filePatch.length());
                logger.info("拷贝"+fileName+"到跳板机/tmp目录下");
                //运行服务器命令
                ssh = conn.openSession();
                ssh.execCommand("cd /tmp; sh "+fileName);
                logger.info("ssh command"+"cd /tmp;sh "+fileName);
                InputStream is = new StreamGobbler(ssh.getStdout());
                BufferedReader brs = new BufferedReader(new InputStreamReader(is));
//                while (true)
//                {
//                    String line = brs.readLine();
//                    if (line == null)
//                    {
//                        break;
//                    }
//                    System.out.println(line);
//                }
            }
        } catch (IOException e) {
//            System.out.println(e.getMessage());
            e.printStackTrace();
        } finally {
            //连接的Session和Connection对象都需要关闭
            if(ssh!=null) {
                ssh.close();
            }
            if(conn!=null) {
                conn.close();
            }

            logger.info("关闭ssh连接");
        }
    }


    public static void runCommand(String command){
        String hostName = "54.223.154.75";
        int port = 22;
        String loginName = "ubuntu";

        Connection conn = new Connection(hostName, port);
        Session ssh = null;
        try {
            conn.connect();

            boolean isConn = conn.authenticateWithPublicKey(loginName, keyFile, "");
            if (!isConn){
//                System.out.println("链接失败：用户名或密码错误");
                logger.info("ssh链接失败");
            }else{
//                System.out.println("链接成功");
                logger.info("ssh连接成功");

                //运行服务器命令
                ssh = conn.openSession();
                ssh.execCommand(command);
                InputStream is = new StreamGobbler(ssh.getStdout());
                BufferedReader brs = new BufferedReader(new InputStreamReader(is));
                logger.info("ssh command:"+command);
//                while (true)
//                {
//                    String line = brs.readLine();
//                    if (line == null)
//                    {
//                        break;
//                    }
//                    System.out.println(line);
//                }
            }
        } catch (IOException e) {
//            System.out.println(e.getMessage());
            e.printStackTrace();
        } finally {
            //连接的Session和Connection对象都需要关闭
            if(ssh!=null) {
                ssh.close();
            }
            if(conn!=null) {
                conn.close();
            }

            logger.info("关闭ssh连接");
        }
    }
}
