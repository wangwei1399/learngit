package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by he_yi on 16/11/7.
 */
public class Redis {
    private static String tuiguangKey = "";

    public static void setTuiGuang(int cityId, int courierId, int fanId, int second){

        String s = "ssh test05 \"source ~/.profile; cd /data/www/app/api_server/current && bundle exec rails runner -e production \\\"Rails.cache.write(" +
                "'city_id_"+cityId+"_customer_"+fanId+"', "+courierId+", expires_in: "+second+".seconds)\\\"\"";
        tuiguangKey = "city_id_"+cityId+"_customer_"+fanId;
        SSH.runCommand(s);
        try {
            //延迟保障脚本运行完毕
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void deleteTuiguang(){
        if (!tuiguangKey.equals("")){
            String s = "redis-cli -h test05 -p 6379 del "+tuiguangKey;
            SSH.runCommand(s);
            tuiguangKey = "";
        }

    }

    public static void flushAll(){
        SSH.runCommand("redis-cli -h test05 -p 6379 FLUSHALL");
    }

    public static void deleteStatistics(){
        SSH.runCommand("redis-cli -h test05 -p 6379 keys \"frequent_courier_of_customer_*\" | xargs -i redis-cli del");
        SSH.runCommand("redis-cli -h test05 -p 6379 del \"city_北京_general_courier_ids\"");
        SSH.runCommand("redis-cli -h test05 -p 6379 del \"city_北京_city_excellent_courier_ids\"");
        SSH.runCommand("redis-cli -h test05 -p 6379 del \"city_北京_general_courier\"");
        SSH.runCommand("redis-cli -h test05 -p 6379 del \"city_北京_excellent_courier\"");
        SSH.runCommand("redis-cli -h test05 -p 6379 del courier_negative_feedback_cache_all");
    }

    public static void setPaidanPunish(){
        SSH.runCommand("redis-cli -h test05 -p 6379 keys \"auto_dispach_city_id_*_punish_list_*\" | xargs -i redis-cli del");
    }
}
