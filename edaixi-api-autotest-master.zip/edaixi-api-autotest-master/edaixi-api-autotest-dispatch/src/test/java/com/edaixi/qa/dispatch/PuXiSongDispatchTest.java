package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.*;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by he_yi on 16/11/10.
 */
public class PuXiSongDispatchTest {
    private static Logger logger = LoggerFactory.getLogger(PuXiSongDispatchTest.class);
    private MysqlQaDao mysqlQaDao = null;
    private List<Integer> courierIdList = null;
    private int orderId = 0;
    private ApiModuleService apiModuleService = new ApiModuleService();
    @BeforeClass
    public static void beforeClass(){
//        DispatchService.start();    //启动自动派单服务
    }


    @Before
    public void before(){
        courierIdList = new ArrayList<>();
//        mysqlQaDao = new MysqlQaDao();
//        DispatchTestHelper.setCourierZone().deleteTestPolygonGroupAllCourier(); //删除测试区域下所有小e的绑定关系
//        Redis.deleteStatistics();   //删除统计相关缓存
    }

    @After
    public void after(){
//        DispatchTestHelper.createCourier().deleteCourier(courierIdList);
//        logger.info("清空小e及相关数据");
//        DispatchTestHelper.deleteOrder(orderId);
//        logger.info("清空订单相关数据,防止自动派单失败时订单未被删除");
//        courierIdList.clear();
//        courierIdList = null;
//        logger.info("清空courierIdList");
//        mysqlQaDao.close();
//        mysqlQaDao = null;
    }

    @Test
    public void song(){

        int courierId = DispatchTestHelper.createCourier().createBasicCourier();
        courierIdList.add(courierId);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(courierId);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(courierId);

        CreateOrderByStatus createOrderByStatus = new CreateOrderByStatus();
        createOrderByStatus.setCourierId(courierId);
        createOrderByStatus.setAddress_song_id(EnumPolygonGroup.zhongbaoPolyonGroup.getId());
        orderId = createOrderByStatus.getOrderByStatus(CreateOrderByStatus.orderStatus.jiagongdian_fenjian);

        String time = String.valueOf(System.currentTimeMillis()).substring(0, 10);
        apiModuleService.CallJiagongdianDaobao(orderId, Long.valueOf(time));
        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierId, quCourierId);


    }

    @Test
    public void ff(){
        CreateOrderByStatus createOrderByStatus = new CreateOrderByStatus();
        createOrderByStatus.setCourierId(2);
        createOrderByStatus.setAddress_song_id(EnumPolygonGroup.zhongbaoPolyonGroup.getId());
        orderId = createOrderByStatus.getOrderByStatus(CreateOrderByStatus.orderStatus.jiagongdian_fenjian);
    }
}
