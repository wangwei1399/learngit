package com.edaixi.qa.dispatch;

/**
 * Created by he_yi on 16/11/10.
 */
public enum EnumPolygonGroup {
    ziyingPolyonGroup("大山子-自营", 142),
    zhongbaoPolyonGroup("大山子", 358);

    private int index = 0;
    private String title = "";
    private EnumPolygonGroup(String s, int i){
        index = i;
        title = s;
    }

    public String getTitle(){
        return title;
    }

    public int getId(){
        return index;
    }

    @Override
    public String toString(){
        return title+","+index;
    }


}
