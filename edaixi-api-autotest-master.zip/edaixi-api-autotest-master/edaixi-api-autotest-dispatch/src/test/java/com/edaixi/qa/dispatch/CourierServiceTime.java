package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

/**
 * Created by he_yi on 16/11/1.
 */
public class CourierServiceTime {
    private static CourierServiceTime serviceTime = null;
    private MysqlQaDao mysqlQaDao = null;

    private CourierServiceTime(){

    }

    public static CourierServiceTime getCourierServiceTime(){
        if (serviceTime == null){
            serviceTime = new CourierServiceTime();
        }

        return serviceTime;
    }

    public void fullServiceTime(int courierId){
        deleteAllServiceTime(courierId);

        String sql = "";
        String dateTime = getNowTime();
        int courier_type = 1;

        ResultSet r = getMysqlQaDao().execQuerySql("select kind from ims_washing_courier where id="+courierId);
        try {
            courier_type = r.getInt("kind");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (int i=0;i<7*24;i=i+24){
            for (int j=8;j<24;j++){
                int time = i+j;
                sql = "insert into courier_schedules(time_modular, map_polygon_group_id, courier_id, is_available, week_nr,city_id, courier_type, created_at, updated_at) " +
                        "values("+time+", 0, "+courierId+",1, -1, 1, "+courier_type+", '"+dateTime+"', '"+dateTime+"');";
                System.out.println(sql);
                getMysqlQaDao().execUpdateSql(sql);
            }

        }

        mysqlClose();
    }




    public void deleteAllServiceTime(int courierId) {
        String sql = "delete from courier_schedules where courier_id=" + courierId;
        getMysqlQaDao().execUpdateSql(sql);
        mysqlClose();
    }


    private void mysqlClose(){
        mysqlQaDao.close();
        mysqlQaDao = null;
    }


    private MysqlQaDao getMysqlQaDao(){
        if (mysqlQaDao == null) {
            mysqlQaDao = new MysqlQaDao();
        }
        return mysqlQaDao;
    }

    private String getNowTime(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = dateFormat.format(System.currentTimeMillis());
        return date;
    }
}
