package com.edaixi.qa.dispatch;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.SCPClient;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;

/**
 * Created by he_yi on 16/10/31.
 */
public class DispatchService {
    private static Logger logger = LoggerFactory.getLogger(DispatchService.class);


    private DispatchService(){

    }


    public static void start(){
//        SSH.runShellFile("src/test/resources/dispatch05.sh");
        Redis.flushAll();
        SSH.runCommand("ssh test05 \"kill -9 \\$(ps -ef|grep sidekiq |awk '{print \\$2}')\"");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        SSH.runCommand("ssh test05 \"bash -l -c 'cd /data/www/app/wuliu/current;nohup bundle exec sidekiq -e production >/dev/null 2>&1 &'\"");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        SSH.runCommand("ssh test05 \"bash -l -c 'cd /data/www/app/api_server/current;nohup bundle exec sidekiq -e production >/dev/null 2>&1 &'\"");
        try {
            Thread.sleep(15000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
