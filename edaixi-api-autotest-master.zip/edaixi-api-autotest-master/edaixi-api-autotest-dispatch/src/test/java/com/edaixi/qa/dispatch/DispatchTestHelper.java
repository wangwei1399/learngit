package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

/**
 * Created by he_yi on 16/11/1.
 */
public class DispatchTestHelper {

    public static CourierServiceTime setCourierServiceTime(){
        return CourierServiceTime.getCourierServiceTime();
    }

    public static CreateCourier createCourier(){
        return CreateCourier.getCreateCourier();
    }

    public static CourierZone setCourierZone(){
        return CourierZone.getCourierZone();
    }

    public static CourierScore setCourierScore(){
        return CourierScore.getCourierScore();
    }

    public static String getNowTime(String format){
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        String date = dateFormat.format(System.currentTimeMillis());
        return date;
    }

    public static CourierSet setCourierOthers(){
        return CourierSet.getCourierSet();
    }


    public static void deleteOrder(int orderId){
        MysqlQaDao mysqlQaDao = getRongChainMysql();
        String sql = "delete from ims_washing_order where id = "+orderId;
        mysqlQaDao.execUpdateSql(sql);

        sql = "delete from vouchers where voucherable_type='Order' and voucherable_id in("+orderId+");";
        mysqlQaDao.execUpdateSql(sql);

        sql = "delete from trans_tasks where order_id in("+orderId+");";
        mysqlQaDao.execUpdateSql(sql);

        sql = "delete from trans_groups where order_id in("+orderId+");";
        mysqlQaDao.execUpdateSql(sql);


        mysqlQaDao.close();
        mysqlQaDao = null;
    }

    public static int getOrderQuCourierId(int orderId){
        try {
            //增加3秒延迟,解决派单服务操作时间
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        MysqlQaDao mysqlQaDao = getRongChainMysql();
        String sql = "select courier_qu from ims_washing_order where id = "+orderId;
        ResultSet r = mysqlQaDao.execQuerySql(sql);
        int courierId = 0;
        try {
            courierId = r.getInt("courier_qu");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        mysqlQaDao.close();
        mysqlQaDao = null;

        return courierId;
    }

    public static int getOrderSongCourierId(int orderId){
        MysqlQaDao mysqlQaDao = getRongChainMysql();
        String sql = "select courier_song from ims_washing_order where orderId = "+orderId;
        ResultSet r = mysqlQaDao.execQuerySql(sql);
        int courierId = 0;
        try {
            courierId = r.getInt("courier_song");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        mysqlQaDao.close();
        mysqlQaDao = null;

        return courierId;
    }

    private static MysqlQaDao getRongChainMysql(){
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        return mysqlQaDao;
    }
}
