package com.edaixi.qa.dispatch;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by he_yi on 16/11/3.
 */
public class CourierSet {
    private static CourierSet courierSet = null;
    private static Logger logger = LoggerFactory.getLogger(CourierSet.class);

    private CourierSet(){

    }

    public static CourierSet getCourierSet(){
        if (courierSet== null){
            courierSet = new CourierSet();
        }

        return courierSet;
    }


    public JSONObject refuseOrder(int orderId, String backReason){
        ApiModuleService apiModuleService = new ApiModuleService();
        JSONObject  jsonObject = apiModuleService.CallWuliuQuTuihui(orderId, backReason);
        logger.info("小e拒绝订单:"+jsonObject.toJSONString());
        return jsonObject;
    }

    public JSONObject refuseOrderNoServiceTime(int orderId){
        return refuseOrder(orderId, "订单时段不能服务");
    }

    public void paidanInterface(int orderId, int courierId){
        ApiModuleService apiModuleService = new ApiModuleService();
        JSONObject jsonObject =apiModuleService.CallDiaoDuPaiDan(orderId, courierId);
        JSONObject json = JSON.parseObject(jsonObject.getString("httpBody"));
        logger.info("小e"+courierId+"订单派单:"+jsonObject.toJSONString());
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        if (!json.getBooleanValue("data")){
            if (json.getString("error_msg").contains("调度已派单")){
                ResultSet resultSet = mysqlQaDao.execQuerySql("select courier_qu from ims_washing_order where id="+orderId);
                try {
                    int tmp = resultSet.getInt("courier_qu");
                    if (courierId != tmp ){
                        JSONObject jsonObject1 = apiModuleService.CallDiaoDuGaiPai(orderId, courierId);
                        logger.info("小e"+tmp+"订单改派:"+jsonObject1.toJSONString());
                    }{
                        logger.info("小e"+courierId+"订单改派:已经派单给"+tmp+"无需改派");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void serviceFanTimes(int courierId, int fanId, int times){
        int cityId = 0;
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        String sql = "select city_id from ims_washing_courier where id = "+courierId;
        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
        try {
            cityId = resultSet.getInt("city_id");
            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        mysqlQaDao.close();
        mysqlQaDao = null;

        MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
        String sql2 = "insert into stats_courier_fan_amount_all(courier_id, fan_id, city_id, service_proportion) values("+courierId+", "+fanId+","+cityId+", "+times+");";
        mysqlStats.execUpdateSql(sql2);
        mysqlStats.close();
        mysqlStats = null;
    }

    public void tuiGuang(int cityId, int courierId, int fanId){
        Redis.setTuiGuang(cityId, courierId, fanId, 14400);
    }

    public void tuiGuang(int cityId, int courierId, int fanId, int second){
        Redis.setTuiGuang(cityId, courierId, fanId, second);
    }

    public void deleteTuiguang(){
        Redis.deleteTuiguang();
    }

    public void punish(int courierId, String type){
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        int cityId = CommonTools.getCourierCityId(courierId, mysqlQaDao);
        String now = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        long start = CommonTools.timeStrToUnix("yyyy-MM-dd 00:00:00", CommonTools.getToday("yyyy-MM-dd 00:00:00"));
        long end = CommonTools.timeStrToUnix("yyyy-MM-dd 00:00:00", CommonTools.getAfterDate("yyyy-MM-dd 00:00:00", 10));
        String sql = "insert into courier_punishes(courier_id, city_id, kind, reason, start_time, end_time, created_at, updated_at)"
                +"values("+courierId+","+cityId+", '"+type+"', '自动测试', "+start+", "+end+", '"+now+"', '"+now+"' )";
        MysqlQaDao mysqlZhongbao = new MysqlQaDao("jdbc.zhongbao.properties");
        mysqlZhongbao.execUpdateSql(sql);

        mysqlQaDao.close();
        mysqlQaDao = null;

        mysqlZhongbao.close();
        mysqlZhongbao = null;
    }

    public void paidanPunish(int courierId){
        punish(courierId, "paidan");
        Redis.setPaidanPunish();
    }


}
