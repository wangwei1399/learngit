package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by he_yi on 16/11/1.
 */
public class CourierScore {
//    private MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
//    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static CourierScore courierScore = null;

    private CourierScore(){

    }

    public static CourierScore getCourierScore(){
        if (courierScore == null){
            courierScore = new CourierScore();
        }

        return courierScore;
    }

    /**设置小e评分
     * @param courierId 小eID
     * @param level 等级:0不及格,1及格,2优秀
     * @param rank  同等级下优先级,按照1'2'3排序
     */
    public void byLevel(int courierId, int level, int rank){
        String sql = "";
        int kind = 1;
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        ResultSet r = mysqlQaDao.execQuerySql("select kind from ims_washing_courier where id="+courierId);
        try {
            kind = r.getInt("kind");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            mysqlQaDao.close();
            mysqlQaDao = null;
        }

        switch (level){
            case 0:
                //不及格
                deleteScore(courierId);
                break;

            case 1:
                //及格
                sql = "insert into stats_auto_distribute(courier_id, kind, city, order_score, paidan_score, rank)"
                        +"values("+courierId+","+kind+",'北京', -30, 0,"+rank+");";
                break;

            case 2:
                //优秀
                sql = "insert into stats_auto_distribute(courier_id, kind, city, order_score, paidan_score, rank, total_service_time)"
                        +"values("+courierId+","+kind+",'北京', -5, 0.8,"+rank+", 50);";
                break;
        }

        if (!sql.equals("")){
            MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
            mysqlStats.execUpdateSql(sql);
            mysqlStats.close();
        }

    }


    /**设置小e评分
     * @param courierId 小eID
     * @param level 等级:0不及格,1及格,2优秀
     */
    public void byLevel(int courierId, int level){
        byLevel(courierId, level, 1);
    }


    /**
     * @param courierId
     * @param order_score
     * @param paidan_score
     * @param total_service_time
     * @param rank
     */
    public void byScore(int courierId, int order_score, double paidan_score, int total_service_time, int rank){
        int kind = 1;
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        ResultSet r = mysqlQaDao.execQuerySql("select kind from ims_washing_courier where id="+courierId);
        try {
            kind = r.getInt("kind");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            mysqlQaDao.close();
        }

        deleteScore(courierId);

        String sql = "insert into stats_auto_distribute(courier_id, kind, city, order_score, paidan_score, rank, total_service_time)"
                +"values("+courierId+","+kind+",'北京',"+order_score+", "+paidan_score+","+rank+", "+total_service_time+");";

        MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
        mysqlStats.execUpdateSql(sql);
        mysqlStats.close();
    }


    /**根据分数设置小e评分
     * @param courierId 小eID
     * @param order_score  订单评分
     * @param paidan_score 派单评分
     * @param total_service_time 总服务时间
     */
    public void byScore(int courierId, int order_score, double paidan_score, int total_service_time){
        byScore(courierId, order_score, paidan_score, total_service_time,1);
    }


    /**
     * 删除小e评级
     * @param courierId
     */
    public void deleteScore(int courierId){
        String sql = "delete from stats_auto_distribute where courier_id="+courierId;
        MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
        mysqlStats.execUpdateSql(sql);
        mysqlStats.close();
    }


    /**删除小e差评
     * @param courierId
     */
    public void deleteBadScore(int courierId){
        String sql = "delete from stats_auto_distribute_bad_score where courier_id = "+courierId;
        MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
        mysqlStats.execUpdateSql(sql);
        mysqlStats.close();

    }


    /**给小e增加差评
     * @param courierID
     */
    public void setBadScore(int courierID, int fanId){
        String sql = "insert into stats_auto_distribute_bad_score(courier_id, fan_id)" +
                "values("+courierID+", "+fanId+");";
        MysqlQaDao mysqlStats = new MysqlQaDao("jdbc.stats.properties");
        mysqlStats.execUpdateSql(sql);
        mysqlStats.close();
    }

}
