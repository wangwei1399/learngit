package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by he_yi on 16/11/1.
 */
public class PuXiQuDispatchTest {
    private static Logger logger = LoggerFactory.getLogger(PuXiQuDispatchTest.class);
    private MysqlQaDao mysqlQaDao = null;
    private List<Integer> courierIdList = null;
    private int orderId = 0;

    @BeforeClass
    public static void beforeClass(){
//        DispatchService.start();    //启动自动派单服务
    }


    @Before
    public void before(){
        courierIdList = new ArrayList<>();
        mysqlQaDao = new MysqlQaDao();
        DispatchTestHelper.setCourierZone().deleteTestPolygonGroupAllCourier(); //删除测试区域下所有小e的绑定关系
        Redis.deleteStatistics();   //删除统计相关缓存
    }

    @After
    public void after(){
        DispatchTestHelper.createCourier().deleteCourier(courierIdList);
        logger.info("清空小e及相关数据");
        DispatchTestHelper.deleteOrder(orderId);
        logger.info("清空订单相关数据,防止自动派单失败时订单未被删除");
        courierIdList.clear();
        courierIdList = null;
        logger.info("清空courierIdList");
        mysqlQaDao.close();
        mysqlQaDao = null;
    }

    @Test
    public void onlyOneCourier(){
        //只有1个小e情况
        int courierId = DispatchTestHelper.createCourier().createBasicCourier("11110982234");  //根据电话号码创建小e
        courierIdList.add(courierId);   //小eID加入list用于执行完成之后清除
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(courierId); //设置新建的小e绑定到测试区域
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(courierId); //设置新生成的小e服务时间

        CreateOrder createOrder = new CreateOrder();
        createOrder.setValue(CreateOrder.EnumOrder.address, "大山子 798");
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierId, quCourierId);
    }

    @Test
    public void courierPuxiPower(){
        //2个小e,一个奢侈品一个普洗
        int luxuryCourierId = DispatchTestHelper.createCourier().createLuxuryCourier("1110"+CommonTools.getRandomNumberToString(6));
        courierIdList.add(luxuryCourierId);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(luxuryCourierId);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(luxuryCourierId);

        int puXicourierId =  DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(puXicourierId);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(puXicourierId);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(puXicourierId);

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", puXicourierId, quCourierId);
    }

    @Test
    public void courierZone(){
        //2个小普洗小e,只有一个绑定了订单的区域
        int courierId1 = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(courierId1);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(courierId1);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(courierId1);

        int courierId2 = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(courierId2);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(courierId2);

        CreateOrder createOrder = new CreateOrder();
        int orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierId1, quCourierId);
    }

    @Test
    public void courierServiceTime(){
        //2个普洗小e,绑定相同区域,只有一个有服务时间
        int courierId1 = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(courierId1);
        DispatchTestHelper.setCourierServiceTime().fullServiceTime(courierId1);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(courierId1);

        int courierId2 = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(courierId2);
        DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(courierId2);

        CreateOrder createOrder = new CreateOrder();
        int orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierId1, quCourierId);
    }

    @Test
    public void courierTuiGuang(){
        //3个小e,其中一个是4小时内推广的
        for (int i=0;i<3;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);
        }

        int fanId = CommonTools.getFanId(mysqlQaDao);
        //设置4小时内推广小e
        DispatchTestHelper.setCourierOthers().tuiGuang(1, courierIdList.get(0), fanId);

        CreateOrder createOrder = new CreateOrder();
        createOrder.setValue(CreateOrder.EnumOrder.user_id, fanId);
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(0).intValue(), quCourierId);
        DispatchTestHelper.setCourierOthers().deleteTuiguang();

    }

    @Test
    public void courierPunish(){
        //3个小e,其中2个收到派单惩罚
        for (int i=0;i<3;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            if (i!=0){
                //设置小e取件派单惩罚
                DispatchTestHelper.setCourierOthers().paidanPunish(id);
            }
        }

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(0).intValue(), quCourierId);
    }


    @Test
    public void courierNoServiceTimeRefunse(){
        //3个普洗小e,2个以订单时段不能服务为原因拒绝过订单
        for (int i=0;i<3;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            if (i!=2){
                //设置小e取件派单惩罚
                CreateOrder order = new CreateOrder();
                int oid = order.getOrderId();
                DispatchTestHelper.setCourierOthers().paidanInterface(oid, id);
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                DispatchTestHelper.setCourierOthers().refuseOrderNoServiceTime(oid);
            }
        }

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(2).intValue(), quCourierId);
    }

    @Test
    public void courierServiceTimesFull(){
        //3个小e,服务用户次数分别为1,2,3

        int courierSum = 3;
        int fanId = CommonTools.getFanId(mysqlQaDao);
        for (int i=0;i<courierSum;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            DispatchTestHelper.setCourierOthers().serviceFanTimes(id, fanId, i+1);
        }

        CreateOrder createOrder = new CreateOrder();
        createOrder.setValue(CreateOrder.EnumOrder.user_id, fanId);
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(courierSum-1).intValue(), quCourierId);
    }

    @Test
    public void courierBadScore(){
        //3个小e,2个有订单用户的差评

        int fanId = CommonTools.getFanId(mysqlQaDao);
        int courierSum = 3;
        for (int i=0;i<courierSum;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            //设置小e评分为及格
            DispatchTestHelper.setCourierScore().byLevel(id, 1);
            if (i != courierSum-1){
                //设置小e有差评
                DispatchTestHelper.setCourierScore().setBadScore(id, fanId);
            }
        }

        CreateOrder createOrder = new CreateOrder();
        createOrder.setValue(CreateOrder.EnumOrder.user_id, fanId);
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(courierSum-1).intValue(), quCourierId);
    }


    @Test
    public void courierLevelScore(){
        //3个小e,评分分别为不及格,及格和优秀
        for (int i=0;i<3;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            DispatchTestHelper.setCourierScore().byLevel(id, i);
        }

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(2).intValue(), quCourierId);
    }


    @Test
    public void courierLevelScorePriority(){
        //3个小e,评分都是优秀,优先级分别为3,2,1
        for (int i=0;i<3;i++){
            int id = DispatchTestHelper.createCourier().createBasicCourier("11110"+ CommonTools.getRandomNumberToString(6));
            DispatchTestHelper.setCourierServiceTime().fullServiceTime(id);
            DispatchTestHelper.setCourierZone().bindingTestPolygonGroup(id);
            courierIdList.add(id);

            DispatchTestHelper.setCourierScore().byLevel(id, 2, 3-i);
        }

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", courierIdList.get(2).intValue(), quCourierId);
    }

    @Test
    public void ziyingZone(){
        //自营物流测试
        int ziyingId = DispatchTestHelper.createCourier().createZiYingCourier("11110"+ CommonTools.getRandomNumberToString(6));
        courierIdList.add(ziyingId);
        DispatchTestHelper.setCourierZone().bindingPolygonGroup(ziyingId, EnumPolygonGroup.ziyingPolyonGroup.getId(), true);

        CreateOrder createOrder = new CreateOrder();
        orderId = createOrder.getOrderId();

        int quCourierId = DispatchTestHelper.getOrderQuCourierId(orderId);
        org.junit.Assert.assertEquals("取件小e预期结果不正确", ziyingId, quCourierId);

    }





    @Test
    public void clear(){
//        DispatchTestHelper.createCourier().deleteCourier(111);
        List<Integer> list = new ArrayList<>();
        list.add(255);
//        list.add(242);
//        list.add(243);
        DispatchTestHelper.createCourier().deleteCourier(list);
        DispatchTestHelper.deleteOrder(993804452);
//        DispatchTestHelper.deleteOrder(993804422);
//        DispatchTestHelper.deleteOrder(993804423);
//        DispatchService.start();
//        SSH.runCommand("ssh test05 \"kill -9 \\$(ps -ef|grep sidekiq |awk '{print \\$2}')\"");
//        System.out.println(DispatchTestHelper.setCourierOthers().refuseOrderNoServiceTime(993804401).toJSONString());
    }


}
