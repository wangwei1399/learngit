package com.edaixi.qa.dispatch;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class ApiModuleService {
	private static Logger logger = LoggerFactory.getLogger(ApiModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;
	private Properties openGlobalConf = null;

	public ApiModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.openGlobalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.openGlobalConf.getProperty("api.server"));
	}


    public JSONObject CallApiCustomersSingle(String access_token,String authorization, Map<String, Object> queryParam){
        String method = "get";
        return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.v1.customers.single"), method, authorization, queryParam);
    }
	public JSONObject CallDiaoDuSongPaiDan(String access_token,String authorization,int order_id, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.diaodu_song_paidan"), String.valueOf(order_id)), method, authorization, queryParam);
	}
	public JSONObject CallDiaoDuPaiDan(int order_id, int courierId){
		String method = "post";
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("courier_id", courierId);
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.diaodu_paidan"),String.valueOf(order_id)), method, "", param);
	}

	public JSONObject CallDiaoDuGaiPai(int orderId, int courierId){
		String method = "post";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("courier_qu", courierId);
		Map<String, Object> param = new HashMap<>();
		map.put("order_params",map);
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.gai_pai"), String.valueOf(orderId)), method, "", param);
	}


	public JSONObject CallApiOrders(String access_token,String authorization, Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.v1.orders"), method, authorization, queryParam);
	}

	public JSONObject CallWuliuQuTuihui(int orderId, String backReason){
		String method = "post";
		Map<String, Object> queryParam = new HashMap<>();
		queryParam.put("back_reason", backReason);
		queryParam.put("id",  orderId);
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.wuliu_qu_tuihui"), String.valueOf(orderId)), method, "", queryParam);
	}

	/**小e助手 已取接口
	 * 使用小e助手app,完成计价,支付,输入封签号后,会调用此接口
	 * @param order_id ims_washing_order表的ID
	 * @param bagsn    封签号
	 * @param uid      小eID
	 * @param remark   订单备注
	 * @return	JSON
	 */
	public JSONObject CallApiWuliuYiQu(String order_id, String bagsn, String uid, String remark){
		String url = MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.wuliu_yiqu"),order_id)+"bagsn="+bagsn+"&remark="+remark+"&uid="+uid;
		String method = "post";

		Map<String, Object> param = new HashMap<String, Object>();
		param.put("bagsn", bagsn);
		param.put("uid", uid);
		param.put("remark", remark);

		return this.dmService.callApi2Json(url, method, "",param);
	}

	/**物流送签收接口,小e接受送件单时触发
	 * @param orderId
	 * @param courierId
	 * @return
	 */
	public JSONObject CallApiWuliuSongQianShou(String orderId, String courierId){
		String url = MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.wuliu_song_qianshou"), orderId, courierId);
		String method = "post";
		return this.dmService.callApi2Json(url,method, "", null);
	}

	/**物流送退回接口,小e拒绝送件单时触发
	 * @param orderId
	 * @return
	 */
	public JSONObject CallApiWuliuSongTuiHuiTest(String orderId, String back_reason, String trans_tasks_id){
		String url = MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.wuliu_song_tuihui"), orderId);
		String method = "post";
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("back_reason", back_reason);
		param.put("trans_tasks_id", trans_tasks_id);
		return this.dmService.callApi2Json(url,method, "", param);
	}

	public JSONObject CallApiKeHuQianShouTest(String orderId){
		String url = MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.kehu_qianshou"), orderId);
		String method = "post";
		return this.dmService.callApi2Json(url,method, "", null);
	}

	public JSONObject CallApiDiaoduQuXiaoTest(String orderId, String back_reason){
		String url = MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.dingdan_quxiao"), orderId);
		String method = "post";
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("back_reason", back_reason);
		return this.dmService.callApi2Json(url,method, "", param);
	}

//	public JSONObject CallApiWuliuQuYiTest(String access_token,String authorization, Map<String, Object> queryParam){
//		String method = "post";
//		return this.dmService.callApi2Json(this.openGlobalConf.getProperty("api.v1.orders"), method, authorization, queryParam);
//	}

	public JSONObject CallJiagongdianQianshouTest(String access_token,String authorization, String order_id,Map<String, Object> queryParam){
		String method = "post";
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.jiagongdian_qianshou"), order_id), method, authorization, queryParam);
	}

	public JSONObject CallJiagongdianDaobao(int order_id,long timeStamp){
		String method = "post";
		Map<String, Object> map = new HashMap<>();
		map.put("id", order_id);
		map.put("timestamp", timeStamp);
		return this.dmService.callApi2Json(MessageFormat.format(this.openGlobalConf.getProperty("api.v1.logisticss.id.jiagongdian_yidabao"), String.valueOf(order_id)), method, "", map);
	}

}
