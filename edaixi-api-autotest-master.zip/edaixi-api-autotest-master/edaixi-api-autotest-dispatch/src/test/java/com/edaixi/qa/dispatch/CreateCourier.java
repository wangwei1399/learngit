package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by he_yi on 16/11/1.
 */
public class CreateCourier {
    private static CreateCourier createCourier = null;
    private MysqlQaDao mysqlQaDao = null;

    private CreateCourier(){

    }

    public static CreateCourier getCreateCourier(){
        if (createCourier == null){
            createCourier = new CreateCourier();
        }
        return createCourier;
    }

    private String getCreateSql(Map<String, String> fieldMap){
        String sql1 = "insert into ims_washing_courier(";
        String sql2 = "values(";

        for (Map.Entry<String, String> e : fieldMap.entrySet()){
            String key = e.getKey();
            String value = e.getValue();

            sql1+=key+",";
            sql2+=value+",";
        }

        sql1 = sql1.substring(0, sql1.length()-1);
        sql2 = sql2.substring(0, sql2.length()-1);

        sql1+=")";
        sql2+=");";
        return sql1+sql2;
    }

    private Map<String, String> getBasicFieldMap(){
        Map<String, String> map = new HashMap<>();
        String dateTime = getNowTime();
        map.put("realname", "'自动派单测试用户'");
        map.put("password", "'000000'");
        map.put("outlet_id", "0");
        map.put("status", "1");
        map.put("created_at", "'"+dateTime+"'");
        map.put("updated_at", "'"+dateTime+"'");
        map.put("city", "'北京'");
        map.put("kind", "1");//0自营物流,1普洗小e,3奢侈品
        map.put("use_auto_schedule", "1");
        map.put("bank_card", "'62258810454536652'");
        map.put("id_number", "'110105199885523652'");
        map.put("bank_name", "'工商银行'");
        map.put("bank_user_name", "'自动派单'");
        map.put("jiedan", "1");//普洗权限
        map.put("edaixi_nr", "'EZY-0010-00000003'");
        map.put("channel", "'com.1.zhongbao'");
        map.put("city_id", "1");
        map.put("saofen", "1");
        map.put("shouka", "1");
        map.put("song_angway", "1");
        map.put("contract_version", "1");
        map.put("client_name", "'android_client'");
        String s = CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 10);
        long contract_version_end_time = CommonTools.timeStrToUnix("yyyy-MM-dd HH:mm:ss", s);
        map.put("contract_version_end_time", String.valueOf(contract_version_end_time));

        return map;
    }

    public int createBasicCourier(){
        return createBasicCourier("1110"+CommonTools.getRandomNumberToString(6));
    }

    public int createBasicCourier(String tel){
        return createBasicCourier(tel, "自动派单测试普洗");
    }

    public int createBasicCourier(String tel, String name){
        return createBasicCourier(tel, name, "000000");
    }

    public int createBasicCourier(String tel, String name, String pw){
        Map<String, String> map = getBasicFieldMap();
        map.put("tel", "'"+tel+"'");
        map.put("realname", "'"+name+"'");
        map.put("password", "'"+pw+"'");
        String sql = getCreateSql(map);
        return create(sql);
    }

    public int createLuxuryCourier(String tel){
        return createLuxuryCourier(tel, "自动派单奢侈品");
    }

    public int createLuxuryCourier(String tel, String name){
       return createLuxuryCourier(tel, name, "000000");
    }

    public int createLuxuryCourier(String tel, String name, String pw){
        Map<String, String> map = getBasicFieldMap();
        map.put("tel", "'"+tel+"'");
        map.put("realname", "'"+name+"'");
        map.put("password", "'"+pw+"'");
        map.put("luxury_logistic", "1");
        map.put("jiedan", "1");
        map.put("kind", "3");
        String sql = getCreateSql(map);
        return create(sql);
    }

    public int createZiYingCourier(String tel){
        return createZiYingCourier(tel, "自动派单自营物流", "000000");
    }

    public int createZiYingCourier(String tel, String name, String pw){
        Map<String, String> map = getBasicFieldMap();
        map.put("tel","'"+tel+"'");
        map.put("realname", "'"+name+"'");
        map.put("password", "'"+pw+"'");
        map.put("kind", "0");
        String sql = getCreateSql(map);
        return create(sql);
    }


    public void deleteCourier(int courierId){
        List<Integer> list = new ArrayList<>();
        list.add(courierId);
        deleteCourier(list);

    }

    public void deleteCourier(List<Integer> courierIdList){
        if (!courierIdList.isEmpty()){
            String courierIds = "";
            for (int id: courierIdList){
                System.out.println("e ID"+id);
                courierIds += id +",";
            }
            courierIds = courierIds.substring(0, courierIds.length()-1);

            mysqlQaDao = new MysqlQaDao();
            String sql = "delete from ims_washing_courier where id in("+courierIds+");";
            mysqlQaDao.execUpdateSql(sql);

            sql = "delete from courier_schedules where courier_id in("+courierIds+");";
            mysqlQaDao.execUpdateSql(sql);

            sql = "delete from courier_polygons where courier_id in("+courierIds+");";
            mysqlQaDao.execUpdateSql(sql);

            sql = "select id from ims_washing_order where courier_qu in("+courierIds+") or courier_song in("+courierIds+");";
            ResultSet resultSet = mysqlQaDao.execQuerySqlAllRet(sql);
            String orderIDs = "";
            ArrayList<Integer> tmpList = new ArrayList<>();
            try {
                while (resultSet.next()){
                    int id = resultSet.getInt("id");
                    tmpList.add(id);
                }
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            if (!tmpList.isEmpty()){
                for (int i: tmpList){
                    orderIDs += i+ ",";
                }

                orderIDs = orderIDs.substring(0, orderIDs.length()-1);

                sql = "delete from vouchers where voucherable_type='Order' and voucherable_id in("+orderIDs+");";
                mysqlQaDao.execUpdateSql(sql);

                sql = "delete from trans_tasks where order_id in("+orderIDs+");";
                mysqlQaDao.execUpdateSql(sql);

                sql = "delete from trans_groups where order_id in("+orderIDs+");";
                mysqlQaDao.execUpdateSql(sql);

                sql = "delete from ims_washing_order where id in("+orderIDs+");";
                mysqlQaDao.execUpdateSql(sql);
            }





            MysqlQaDao mysqlStats04 = new MysqlQaDao("jdbc.stats.properties");
            sql = "delete from stats_auto_distribute_bad_score where courier_id in("+courierIds+");";
            mysqlStats04.execUpdateSql(sql);

            sql = "delete from stats_auto_distribute where courier_id in("+courierIds+");";
            mysqlStats04.execUpdateSql(sql);


            MysqlQaDao mysqlZhongbao = new MysqlQaDao("jdbc.zhongbao.properties");
            sql = "delete from courier_punishes where courier_id in("+courierIds+");";
            mysqlZhongbao.execUpdateSql(sql);

            mysqlZhongbao.close();
            mysqlZhongbao = null;

            mysqlStats04.close();
            mysqlStats04 = null;

            mysqlQaDao.close();
            mysqlQaDao = null;
        }


    }


    private int create(String sql){
        mysqlQaDao = new MysqlQaDao();
        mysqlQaDao.execUpdateSql(sql);
        int id = 0;
        ResultSet r = mysqlQaDao.execQuerySql("select id from ims_washing_courier order by id desc limit 1;");
        try {
            id = r.getInt("id");
            r.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        mysqlQaDao.close();
        mysqlQaDao = null;

        return id;
    }



    private String getNowTime(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = dateFormat.format(System.currentTimeMillis());
        return date;
    }
}
