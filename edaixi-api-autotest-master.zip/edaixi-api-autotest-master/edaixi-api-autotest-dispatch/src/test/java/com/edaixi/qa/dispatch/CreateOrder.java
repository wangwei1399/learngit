package com.edaixi.qa.dispatch;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


/**
 * Created by he_yi on 16/11/2.
 */
public class CreateOrder {
    private static Logger logger = LoggerFactory.getLogger(CreateOrder.class);

    private static String city="北京";
    private static String area="朝阳区";
    private static String address="大山子 798";
    private static String tel="18611369742";
    private static String customer_lng="11";
    private static String customer_lat="12";
    private static String user_type="7";//1微信2IOS3安卓4会员卡5实体会员卡6支付宝服务窗7客服8收衣店9淘宝
    private static int user_id= CommonTools.getFanId(new MysqlQaDao());
    private static int totalnum= 1;
    private static int good=3;
    private static String washing_date= CommonTools.getToday("yyyy-MM-dd");
    private static String washing_time="20:00-22:00";
    private static String pay_type="3";
    private static String remark="自动下单备注";
    private static int category_id = 1;

    private JSONObject json=null;
    private String orderId;
    private String statusCode;
    private String ordersn;

    public enum EnumOrder{
        city("city"),
        area("area"),
        address("address"),
        tel("tel"),
        user_id("user_id"),
        totalnum("totalnum"),
        good("good"),
        washing_date("washing_date"),
        washing_time("washing_time"),
        remark("remark"),
        category("category_id");

        private String value="";
        private EnumOrder(String value){
            this.value = value;
        }

        @Override
        public String toString(){
            return value;
        }
    }

//    public String getWashing_time(int time){
//        if (time<8 || time>24){
//            return "8:00-10:00";
//        }else{
//
//        }
//    }

    public void setValue(EnumOrder key, Object value2){
        String value = String.valueOf(value2);
        switch (key){
            case city:
                this.city = value;
                break;
            case area:
                this.area = value;
                break;
            case address:
                this.address = value;
                break;
            case user_id:
                this.user_id = Integer.parseInt(value);
                break;
            case totalnum:
                this.totalnum = Integer.parseInt(value);
                break;
            case good:
                this.good = Integer.parseInt(value);
                break;
            case washing_date:
                this.washing_date = value;
                break;
            case washing_time:
                this.washing_time = value;
                break;
            case remark:
                this.remark = value;
                break;
            case tel:
                this.tel = value;
                break;
            case category:
                this.category_id = Integer.parseInt(value);
                break;

        }
    }

    public String getWashing_date(){
        return washing_date;
    }

    public String getWashing_time(){
        return washing_time;
    }


    public JSONObject getJSONObject(){
        JSONObject tmp = request();
//        if (tmp.getString("httpStatus").equals())
        return tmp;
    }

    public int getOrderId(){
        JSONObject tmpJson = getJSONObject();
        JSONObject body = JSON.parseObject(tmpJson.getString("httpBody"));

        int id = body.getInteger("data");
        return id;
    }

    public int getStatusCode(){
        return getJSONObject().getInteger("httpStatus");
    }

    public String getOrdersn(){
        String sn = "";
        String sql = "select ordersn from ims_washing_order where id="+getOrderId();
        MysqlQaDao mysqlQaDao = new MysqlQaDao();
        ResultSet r = mysqlQaDao.execQuerySql(sql);
        try {
            r.beforeFirst();
            if (r.next()){
                sn = r.getString("ordersn");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sn;
    }


    private JSONObject request(){
        if (this.json == null){
            Map<String, Object> queryParams = new HashMap<String, Object>();
            queryParams.put("city",city);
            queryParams.put("area",area);
            queryParams.put("address",address);
            queryParams.put("tel",tel);
            queryParams.put("customer_lng",customer_lng);
            queryParams.put("customer_lat",customer_lat);
            queryParams.put("user_type",user_type);
            queryParams.put("user_id",user_id);
            queryParams.put("totalnum",totalnum);
            queryParams.put("good",good);
            queryParams.put("washing_date",washing_date);
            queryParams.put("washing_time",washing_time);
            queryParams.put("pay_type",pay_type);
            queryParams.put("remark",remark);
            queryParams.put("category_id", category_id);

            ApiModuleService apiModuleService = new ApiModuleService();
            this.json = apiModuleService.CallApiOrders("",  "", queryParams);
        }

        return this.json;
    }
}
