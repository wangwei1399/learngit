package com.edaixi.qa.dispatch;

import com.edaixi.base.qa.common.dao.MysqlQaDao;

import java.text.SimpleDateFormat;

/**
 * Created by he_yi on 16/11/1.
 */
public class CourierZone {
    private static CourierZone courierZone = null;
    private MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private int testZoneId = 358;
    private CourierZone(){

    }

    public static CourierZone getCourierZone(){
        if (courierZone == null){
            courierZone = new CourierZone();
        }
        return courierZone;
    }


    /**设置小e绑定区域
     * @param polygonGroupId 区域组ID,15环境358是大山子
     * @param isPrimary
     * @return
     */
    public void bindingPolygonGroup(int courierId, int polygonGroupId, boolean isPrimary){
        if (polygonGroupId == 0){
            polygonGroupId = testZoneId; //15环境的大山子区为测试区
        }

        int primary = 0;
        if (isPrimary){
            primary = 1;
        }
        String dateTime = getNowTime("yyyy-MM-dd HH:mm:ss");
        String sql = "insert into courier_polygons(courier_id, polygon_group_id, is_primary, created_at, updated_at)" +
                "values("+courierId+", "+polygonGroupId+", "+primary+", '"+dateTime+"', '"+dateTime+"');";
        mysqlQaDao.execUpdateSql(sql);
    }

    public void bindingTestPolygonGroup(int courierId){
        bindingPolygonGroup(courierId, testZoneId, true);
    }

    public int getTestZoneId(){
        return testZoneId;
    }


    public void deleteTestPolygonGroupAllCourier(){
        deletePolygonGroupAllCourier(testZoneId);
    }


    /**删除小e的绑定区域
     * @param courierId 小eID
     * @param polygonGroupId 区域ID,如果为0则清空全部
     */
    public void deleteBindingPolygonGroup(int courierId, int polygonGroupId){
        String whereSql = "";
        if (polygonGroupId != 0){
            whereSql = " and polygon_group_id="+polygonGroupId;
        }

        String sql = "delete from courier_polygons where courier_id="+courierId+whereSql;
        mysqlQaDao.execUpdateSql(sql);
    }

    /**删除区域下的所有小e绑定关系
     * @param polygonGroupId
     */
    public void deletePolygonGroupAllCourier(int polygonGroupId){
        String sql = "delete from courier_polygons where polygon_group_id="+polygonGroupId;
        mysqlQaDao.execUpdateSql(sql);
    }



    private String getNowTime(String format){
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        String date = dateFormat.format(System.currentTimeMillis());
        return date;
    }
}
