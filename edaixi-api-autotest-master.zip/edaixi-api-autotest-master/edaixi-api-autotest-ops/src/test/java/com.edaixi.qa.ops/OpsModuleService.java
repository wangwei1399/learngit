package com.edaixi.qa.ops;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class OpsModuleService {
	private static Logger logger = LoggerFactory.getLogger(OpsModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService dmService = null;
	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;
	private Map<String, Object> headParams = null;

	private Properties openGlobalConf = null;

	public OpsModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.headParams = new HashMap<String, Object>();
		this.openGlobalConf = GlobalConfig.getProperties();
		dmService = (RestService) this.baseServiceFactory.getService();
		dmService.init(this.openGlobalConf.getProperty("ops.server"));
	}


    public JSONObject CallGenericClothes(Map<String, Object> queryParam){
        String method = "post";
        return this.dmService.callApi2Json(this.openGlobalConf.getProperty("generic.clothes"), method, queryParam,headParams);
    }


}
