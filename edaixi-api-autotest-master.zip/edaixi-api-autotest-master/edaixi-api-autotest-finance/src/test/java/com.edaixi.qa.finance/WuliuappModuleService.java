package com.edaixi.qa.finance;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/**
 * Created by ningzhao on 16/6/28.
 */
public class WuliuappModuleService {
    private static Logger logger = LoggerFactory.getLogger(WuliuappModuleService.class);
    private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
    private GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    private RestService service = null;

    protected Properties globalConf = null;
    private Map<String, Object> queryParams = null;
    private Map<String, Object> orderParams = null;

    public WuliuappModuleService(){
        this.init();
    }
    public final void init(){
        this.queryParams = new HashMap<String, Object>();
        this.orderParams = new HashMap<String, Object>();
        this.globalConf = GlobalConfig.getProperties();

        service = (RestService) this.baseServiceFactory.getService();
        service.init(this.globalConf.getProperty("wuliuapp.addr"));
    }

    public String string2MD5UTF8(String str) throws NoSuchAlgorithmException,UnsupportedEncodingException {
        MessageDigest messageDigest = null;
        messageDigest = MessageDigest.getInstance("MD5");
        messageDigest.reset();
        messageDigest.update(str.getBytes("UTF-8"));
        byte[] byteArray = messageDigest.digest();
        StringBuffer md5StrBuff = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            if (Integer.toHexString(0xFF & byteArray[i]).length() == 1)
                md5StrBuff.append("0").append(
                        Integer.toHexString(0xFF & byteArray[i]));
            else
                md5StrBuff.append(Integer.toHexString(0xFF & byteArray[i]));
        }
        return md5StrBuff.toString();
    }

    public String getSign(String userToken,Map<String, Object> queryParams){
        List<String> queryParamslist = new ArrayList<String>();
        for (String key : queryParams.keySet()) {
            queryParamslist.add(key + "=" + queryParams.get(key));
        }
        Collections.sort(queryParamslist);
        return this.getSign(userToken, queryParamslist);
    }

    public String getSign(String userToken, List<String> queryParamslist){
        StringBuilder sbBuilder = new StringBuilder();
        for (String paramsListItem : queryParamslist) {
            sbBuilder.append(paramsListItem);
            sbBuilder.append("&");
        }
        String addString = sbBuilder.substring(0, sbBuilder.length() - 1);
        String sign= null;
        try {
            sign = this.string2MD5UTF8(addString + "Uth6Fgo70P" + userToken);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return sign;
    }

    public void createOrderData(int order_id,String order_total_price,String order_delivery_fee,int fan_id){
        orderParams.put("order_id",order_id);
        orderParams.put("order_sn", CommonTools.getOrdersn(order_id));
        orderParams.put("status",1);
        orderParams.put("status_delivery",1);
        orderParams.put("pay_status",0);
        orderParams.put("nextDate",CommonTools.getAfterDate("yyyy-MM-dd", 1));
        orderParams.put("washing_time","14:00~16:00");
        orderParams.put("old_category_id",1);
        orderParams.put("totalprice",order_total_price);
        orderParams.put("delivery_fee",order_delivery_fee);
        orderParams.put("fan_id",fan_id);
        generalRongChain04Data.GeneralOrder(orderParams);
    }


    public JSONObject CallGetIncomeDetails(Map<String, Object> queryParam,Map<String, Object> httpHead){
        String method = "get";
        return this.service.callApi2Json(this.globalConf.getProperty("income.details"), method, queryParam, httpHead);
    }


}
