package com.edaixi.qa.finance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import junit.framework.Assert;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class GetBonusRuleTest {

    private static Logger logger = LoggerFactory
            .getLogger(GetBonusRuleTest.class);
    private FinanceModuleService financeModuleService = new FinanceModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    private Map<String, Object> generalCouriersParams = null;
    private Map<String, Object> generalBonusGroupsParams = null;
    private Map<String, Object> generalCardBonusParams = null;
    private Map<String, Object> generalTransferBonusParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlZhongBao = new MysqlQaDao("jdbc-zhongbao.properties");
    GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    GeneralZhongBaoData generalZhongBaoData = new GeneralZhongBaoData();

    int courier_id = 0;
    int bonus_groups_id = 0;

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
        this.generalCouriersParams = new HashMap<String, Object>();
        this.generalBonusGroupsParams = new HashMap<String, Object>();
        this.generalCardBonusParams = new HashMap<String, Object>();
        this.generalTransferBonusParams = new HashMap<String, Object>();

        // kind == 1 && is_zhongtui==0 && kuaixi == 0 this courier is xiaoe
        String courier_info = "select id from ims_washing_courier order by id desc limit 1";
        this.courier_id = CommonTools.getLastId(courier_info, this.mysqlQaDao) + 1;
        String tel = "100" + CommonTools.getRandomInt(8);
        String push_token = "6314" + CommonTools.getRandomInt(8);
        String is_zhongtui = "0";
        String kuaixi = "0";
        String city_id = "2";// shanghai
        String city = "上海";
        this.generalCouriersParams.put("courier_id",this.courier_id);
        this.generalCouriersParams.put("tel",tel);
        this.generalCouriersParams.put("push_token",push_token);
        this.generalCouriersParams.put("is_zhongtui",is_zhongtui);
        this.generalCouriersParams.put("kuaixi",kuaixi);
        this.generalCouriersParams.put("city_id",city_id);
        this.generalCouriersParams.put("city",city);
        generalRongChain04Data.GeneralCouriers(this.generalCouriersParams);

        String bonus_group_info = "select id from bonus_groups order by id desc limit 1";
        this.bonus_groups_id = CommonTools.getLastId(bonus_group_info, this.mysqlZhongBao) + 1;
        String role = "xiaoe";
        int status = 1;
        this.generalBonusGroupsParams.put("id",bonus_groups_id);
        this.generalBonusGroupsParams.put("role",role);
        this.generalBonusGroupsParams.put("city_id",city_id);
        this.generalBonusGroupsParams.put("status",status);
        generalZhongBaoData.GeneralBonusGroups(mysqlZhongBao,this.generalBonusGroupsParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();
        logger.info("in teardown!");
    }


    @Test

    public void testGetSellCardBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException, ParseException {
        String card_bonus_info  = "select id from card_bonus order by id desc limit 1";
        int card_bonus_id = CommonTools.getLastId(card_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 3.0;
        String pay_base = "真钱";
        this.generalCardBonusParams.put("id",card_bonus_id);
        this.generalCardBonusParams.put("amount",amount);
        this.generalCardBonusParams.put("pay_base",pay_base);
        this.generalCardBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralCardBonus(mysqlZhongBao,this.generalCardBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",3);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        String retBody = result.getString("httpBody");
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期","%",retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期",pay_base,retBodyJson.get("pay_base").getAsString());
        Assert.assertEquals("返回值不符合预期",bonus_groups_id,retBodyJson.get("bonus_group_id").getAsInt());

    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: normal-order-qu-service-fee
     *   when: category_id = 1 && operation_type = "取件"
     *   where: amount = 4.0
     *   how: event_type = 4
     *   then: amount = 4.0
     */
    public void testGetNormalOrderQuServiceFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 4.0;
        String operation_type = "取件";
        int category_id = 1;
        int status = 1;
        String pay_type = "元";
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",4);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期",bonus_groups_id,retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: normal-order-qu-delivery-fee
     *   when: category_id = 1 && operation_type = "取件运费"
     *   where: amount = 5.0
     *   how: event_type = 5
     *   then: amount = 5.0
     */
    public void testGetNormalOrderQuDeliveryFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 5.0;
        String pay_type = "%";
        String operation_type = "取件运费";
        int category_id = 1;
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",5);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期",bonus_groups_id,retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: fanxi-normal-order-qu-fee
     *   when: category_id = 1 && operation_type = "返洗取件"
     *   where: amount = 6.0
     *   how: event_type = 6;
     *   then: amount = 6.0;
     */
    public void testGetFanxiNormalOrderQuFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 6.0;
        String pay_type = "%";
        String operation_type = "返洗取件";
        int category_id = 1;
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",6);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }
    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: luxury-order-qu-service-fee
     *   when: category_id = 5 && operation_type = "取件"
     *   where: amount = 7.0
     *   how: event_type = 7
     *   then: amount = 7.0
     */
    public void testGetLuxuryOrderQuServiceFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 7.0;
        String pay_type = "%";
        String operation_type = "取件";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",7);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }
    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: luxury-order-qu-delivery-fee
     *   when: category_id = 5 && operation_type = "取件运费"
     *   where: amount = 8.0
     *   how: event_type = 8;
     *   then: amount = 8.0;
     */
    public void testGetLuxuryOrderQuDeliveryFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 8.0;
        String pay_type = "%";
        String operation_type = "取件运费";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",8);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: fanxi-luxury-order-qu-fee
     *   when: category_id = 5 && operation_type = "返洗取件"
     *   where: amount = 9.0
     *   how: event_type = 9;
     *   then: amount = 9.0;
     */
    public void testGetFanxiLuxuryOrderQuFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 9.0;
        String pay_type = "%";
        String operation_type = "返洗取件";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",9);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: zhuanyun-qu-fee
     *   when: category_id = 1 && operation_type = "转运"
     *   where: amount = 11.0
     *   how: event_type = 11;
     *   then: amount = 11.0;
     */
    public void testGetZhuanyunQuFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 11.0;
        String pay_type = "元";
        String operation_type = "转运";
        int category_id = 1;// 洗衣
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",11);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: zhuanyun-song-fee
     *   when: category_id = 1 && operation_type = "被转运"
     *   where: amount = 12.0
     *   how: event_type = 12;
     *   then: amount = 12.0;
     */
    public void testGetZhuanyunSongFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 12.0;
        String pay_type = "元";
        String operation_type = "转运";
        int category_id = 1;// 洗衣
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",12);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: normal-order-song-service-fee
     *   when: category_id = 1 && operation_type = "送件"
     *   where: amount = 13.0
     *   how: event_type = 13
     *   then: amount = 13.0
     */
    public void testGetNormalOrderSongServiceFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 15.0;
        String operation_type = "送件";
        int category_id = 1;
        int status = 1;
        String pay_type = "元";
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",13);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期",bonus_groups_id,retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: normal-order-song-delivery-fee
     *   when: category_id = 1 && operation_type = "送件运费"
     *   where: amount = 14.0
     *   how: event_type = 14
     *   then: amount = 14.0
     */
    public void testGetNormalOrderSongDeliveryFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 16.0;
        String pay_type = "%";
        String operation_type = "送件运费";
        int category_id = 1;
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",14);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期",bonus_groups_id,retBodyJson.get("bonus_group_id").getAsInt());
    }
    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: fanxi-normal-order-song-fee
     *   when: category_id =  && operation_type = "返洗送件"
     *   where: amount = 15.0
     *   how: event_type = 15;
     *   then: amount = 15.0;
     */
    public void testGetFanxiNormalOrderSongFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 15.0;
        String pay_type = "%";
        String operation_type = "返洗送件";
        int category_id = 1;
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",15);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: luxury-order-song-service-fee
     *   when: category_id = 5 && operation_type = "送件"
     *   where: amount = 16.0
     *   how: event_type = 16;
     *   then: amount = 16.0;
     */
    public void testGetLuxuryOrderSongServiceFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 16.0;
        String pay_type = "%";
        String operation_type = "送件";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",16);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User: zhaoning
     * @Date: 16/7/19
     * @Scenario: luxury-order-song-delivery-fee
     *   when: category_id = 5 && operation_type = "送件运费"
     *   where: amount = 17.0
     *   how: event_type = 17;
     *   then: amount = 17.0;
     */
    public void testGetLuxuryOrderSongDeliveryFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 17.0;
        String pay_type = "%";
        String operation_type = "送件运费";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",17);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: fanxi-luxury-order-song-fee
     *   when: category_id = 5 && operation_type = "返洗送件"
     *   where: amount = 18.0
     *   how: event_type = 18;
     *   then: amount = 18.0;
     */
    public void testGetFanxiLuxuryOrderSongFeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from transfer_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 18.0;
        String pay_type = "%";
        String operation_type = "返洗送件";
        int category_id = 5;// 奢侈品皮具
        int status = 1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralTransferBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",18);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: qu-reward-fee
     *   when: category_id = 1 && operation_type = "取件" && rate = 5
     *   where: amount = 19.0
     *   how: event_type = 19;
     *   then: amount = 19.0;
     */
    public void testGetQuReward5FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 19.0;
        String pay_type = "%";
        String operation_type = "取件";
        int category_id = 1;
        int status = 1;
        int rating = 5;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",19);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: qu-reward-fee-5
     *   when: category_id = 1 && operation_type = "取件" && rate = 4
     *   where: amount = 19.0
     *   how: event_type = 19;
     *   then: amount = 19.0;
     */
    public void testGetQuReward4FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 19.0;
        String pay_type = "%";
        String operation_type = "取件";
        int category_id = 1;
        int status = 1;
        int rating = 4;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",19);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: qu-reward-fee-(-1)
     *   when: category_id = 1 && operation_type = "取件" && rate = 4
     *   where: amount = 19.0
     *   how: event_type = 19;
     *   then: amount = 19.0;
     */
    public void testGetQuReward1FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 19.0;
        String pay_type = "%";
        String operation_type = "取件";
        int category_id = 1;
        int status = 1;
        int rating = -1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",19);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }


    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: song-reward-fee-(-1)
     *   when: category_id = 1 && operation_type = "送件" && rate = -1
     *   where: amount = 20.0
     *   how: event_type = 20;
     *   then: amount = 20.0;
     */
    public void testGetSongReward1FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 20.0;
        String pay_type = "%";
        String operation_type = "送件";
        int category_id = 1;
        int status = 1;
        int rating = -1;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",20);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }

    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: song-reward-fee
     *   when: category_id = 1 && operation_type = "送件" && rate = 4
     *   where: amount = 20.0
     *   how: event_type = 20;
     *   then: amount = 20.0;
     */
    public void testGetSongReward4FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 20.0;
        String pay_type = "%";
        String operation_type = "送件";
        int category_id = 1;
        int status = 1;
        int rating = 4;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",20);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }


    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: song-reward-fee-(5)
     *   when: category_id = 1 && operation_type = "送件" && rate = 5
     *   where: amount = 20.0
     *   how: event_type = 20;
     *   then: amount = 20.0;
     */
    public void testGetSongReward5FeeBonusRule() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from reward_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 20.0;
        String pay_type = "%";
        String operation_type = "送件";
        int category_id = 1;
        int status = 1;
        int rating = 5;
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("operation_type",operation_type);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("status",status);
        this.generalTransferBonusParams.put("pay_type",pay_type);
        this.generalTransferBonusParams.put("rating",rating);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralRewardBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",20);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);
        queryParams.put("rate",rating);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0);
        Assert.assertEquals("返回值不符合预期",amount,retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期",pay_type,retBodyJson.get("pay_type").getAsString());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
    }


    @Test
    /**
     * @User:  zhaoning
     * @Date: 16/7/19
     * @Scenario: promotion_order_fee
     *   when: category_id = 5 && pay_limit = first_order && pay_base = "真钱"
     *   where: amount = 2.0
     *   how: event_type = 2;
     *   then: amount = 2.0;
     */
    public void testGetPromotionorderFeeBonus() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException{
        String transfer_bonus_info = "select id from promotion_bonus order by id desc limit 1";
        int transfer_bonus_id = CommonTools.getLastId(transfer_bonus_info,this.mysqlZhongBao) + 1;
        double amount = 10.0;
        int category_id = 5;
        String pay_limit = "first_order";
        String pay_base = "真钱";
        this.generalTransferBonusParams.put("id",transfer_bonus_id);
        this.generalTransferBonusParams.put("amount",amount);
        this.generalTransferBonusParams.put("category_id",category_id);
        this.generalTransferBonusParams.put("pay_base",pay_base);
        this.generalTransferBonusParams.put("pay_limit",pay_limit);
        this.generalTransferBonusParams.put("bonus_group_id",this.bonus_groups_id);
        generalZhongBaoData.GeneralPromotionBonus(mysqlZhongBao,this.generalTransferBonusParams);

        queryParams.put("courier_id",this.courier_id);
        queryParams.put("event_type",2);
        queryParams.put("finished_at", CommonTools.getToday("yy-MM-dd HH:mm:ss"));
        queryParams.put("category_id",category_id);

        JSONObject result = financeModuleService.CallGetBonusRule(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        String retBody = result.getString("httpBody");
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JsonParser parser = new JsonParser();
        JsonArray retBodyArray = (JsonArray) parser.parse(retBody);
        JsonObject retBodyJson = (JsonObject) retBodyArray.get(0).getAsJsonArray().get(0);
        Assert.assertEquals("返回值不符合预期", amount, retBodyJson.get("amount").getAsDouble());
        Assert.assertEquals("返回值不符合预期", bonus_groups_id, retBodyJson.get("bonus_group_id").getAsInt());
        Assert.assertEquals("返回值不符合预期",pay_limit,retBodyJson.get("pay_limit").getAsString());
        Assert.assertEquals("返回值不符合预期",pay_base,retBodyJson.get("pay_base").getAsString());

    }

}
