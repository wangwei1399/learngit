package com.edaixi.qa.finance;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.*;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class IncomeDetailsTest {

    private static Logger logger = LoggerFactory
            .getLogger(IncomeDetailsTest.class);
    private WuliuappModuleService wuliuappModuleService = new WuliuappModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> usualSalaryParams = null;
    private Map<String, Object> generalBonusGroupsParams = null;
    private GeneralCaiwu04Data generalCaiwu04Data = new GeneralCaiwu04Data();
    private Map<String, Object> httpHead = null;
    private Map<String, Object> fanParams = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    MysqlQaDao mysqlCaiwu04Dao = new MysqlQaDao("jdbc-caiwu04.properties");
    MysqlQaDao mysqlZhongBao = new MysqlQaDao("jdbc-zhongbao.properties");

    int courier_id = 0;
    int bonus_groups_id = 0;
    int city_id = 31;

    private Map<String, Object> generalCouriersParams = null;
    GeneralRongChain04Data generalRongChain04Data = new GeneralRongChain04Data();
    GeneralZhongBaoData generalZhongBaoData = new GeneralZhongBaoData();

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams  = new HashMap<String, Object>();
        this.usualSalaryParams = new HashMap<String, Object>();
        this.fanParams = new HashMap<String, Object>();
        this.generalCouriersParams = new HashMap<String, Object>();
        this.generalBonusGroupsParams = new HashMap<String, Object>();
        // kind == 1 && is_zhongtui==0 && kuaixi == 0 this courier is xiaoe
        String courier_info = "select id from ims_washing_courier order by id desc limit 1";
        this.courier_id = CommonTools.getLastId(courier_info, this.mysqlQaDao) + 1;
        String tel = "100" + CommonTools.getRandomInt(8);
        String push_token = "6314" + CommonTools.getRandomInt(8);
        String is_zhongtui = "0";
        String kuaixi = "0";
        String city = "保定";
        this.generalCouriersParams.put("courier_id",this.courier_id);
        this.generalCouriersParams.put("tel",tel);
        this.generalCouriersParams.put("push_token",push_token);
        this.generalCouriersParams.put("is_zhongtui",is_zhongtui);
        this.generalCouriersParams.put("kuaixi",kuaixi);
        this.generalCouriersParams.put("city_id",this.city_id);
        this.generalCouriersParams.put("city",city);
        generalRongChain04Data.GeneralCouriers(this.generalCouriersParams);

        String bonus_group_info = "select id from bonus_groups order by id desc limit 1";
        this.bonus_groups_id = CommonTools.getLastId(bonus_group_info, this.mysqlZhongBao) + 1;
        String role = "xiaoe";
        int status = 1;
        this.generalBonusGroupsParams.put("id",bonus_groups_id);
        this.generalBonusGroupsParams.put("role",role);
        this.generalBonusGroupsParams.put("city_id",this.city_id);
        this.generalBonusGroupsParams.put("status",status);
        generalZhongBaoData.GeneralBonusGroups(mysqlZhongBao,this.generalBonusGroupsParams);
    }

    private void generalUsualSalaryParams(int event_type, double money){
        String fan_info = "select id from ims_fans order by id desc limit 1";
        int fan_id = CommonTools.getLastId(fan_info, this.mysqlQaDao) + 1;
        String usual_salary_records_info = "select id from wuliu_usual_salary_records order by id desc limit 1";
        int id = CommonTools.getLastId(usual_salary_records_info,this.mysqlCaiwu04Dao) +1;
        int bonus_rule_id = 3;
        int is_calculated = 0;
        usualSalaryParams.put("id",id);
        usualSalaryParams.put("courier_id",courier_id);
        usualSalaryParams.put("event_type",event_type);
        usualSalaryParams.put("money",money);
        usualSalaryParams.put("user_id",fan_id);
        usualSalaryParams.put("bonus_rule_id",bonus_rule_id);
        usualSalaryParams.put("is_calculated",is_calculated);
        usualSalaryParams.put("city_id",this.city_id);
        generalCaiwu04Data.GeneralUsualSalaryRecords(this.mysqlCaiwu04Dao,usualSalaryParams);
    }

    @After
    public void tearDown() {
        mysqlQaDao.close();
        logger.info("in teardown!");
    }

    @Test

    public void testIncomeDetails() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        //计算推广成单的费用（2）
        int event_type_2 = 2;
        double money_2 = 2;
        generalUsualSalaryParams(event_type_2,money_2);
        //计算售卡的费用（3）
        int event_type_3 = 3;
        double money_3 = 3;
        generalUsualSalaryParams(event_type_3,money_3);
        //计算普通订单的取件服务费（4）
        int event_type_4 = 4;
        double money_4 = 4;
        generalUsualSalaryParams(event_type_4,money_4);
        //计算普通订单的取件运费（5）
        int event_type_5 = 5;
        double money_5 = 5;
        generalUsualSalaryParams(event_type_5,money_5);
        //计算返洗的普通订单取件费（6）
        int event_type_6 = 6;
        double money_6 = 6;
        generalUsualSalaryParams(event_type_6,money_6);
        //计算奢侈品订单取件服务费（7）
        int event_type_7 = 7;
        double money_7 = 7;
        generalUsualSalaryParams(event_type_7,money_7);
        //计算奢侈品订单取件运费（8）
        int event_type_8 = 8;
        double money_8 = 8;
        generalUsualSalaryParams(event_type_8,money_8);
        //计算返洗的奢侈品订单取件费（9）
        int event_type_9 = 9;
        double money_9 = 9;
        generalUsualSalaryParams(event_type_9,money_9);
        //计算特殊时段取件提成（10）
        int event_type_10 = 10;
        double money_10 = 10;
        generalUsualSalaryParams(event_type_10,money_10);
        //计算转运取件的费用（11）
        int event_type_11 = 11;
        double money_11 = 11;
        generalUsualSalaryParams(event_type_11,money_11);
        //计算转运送件的费用（12）
        int event_type_12 = 12;
        double money_12 = 12;
        generalUsualSalaryParams(event_type_12,money_12);
        //计算普通订单的送件服务费（13）
        int event_type_13 = 13;
        double money_13 = 13;
        generalUsualSalaryParams(event_type_13,money_13);
        //计算普通订单的送件运费（14）
        int event_type_14 = 14;
        double money_14 = 14;
        generalUsualSalaryParams(event_type_14,money_14);
        //计算返洗的普通订单送件费（15）
        int event_type_15 = 15;
        double money_15 = 15;
        generalUsualSalaryParams(event_type_15,money_15);
        //计算奢侈品订单送件服务费（16）
        int event_type_16 = 16;
        double money_16 = 16;
        generalUsualSalaryParams(event_type_16,money_16);
        //计算奢侈品订单送件运费（17）
        int event_type_17 = 17;
        double money_17 = 17;
        generalUsualSalaryParams(event_type_17,money_17);
        //计算返洗的奢侈品订单送件费（18）
        int event_type_18 = 18;
        double money_18 = 18;
        generalUsualSalaryParams(event_type_18,money_18);
        //计算取件评价提成（19）
        int event_type_19 = 19;
        double money_19 = 19;
        generalUsualSalaryParams(event_type_19,money_19);
        //计算送件评价提成（20）
        int event_type_20 = 20;
        double money_20 = 20;
        generalUsualSalaryParams(event_type_20,money_20);

        String today = CommonTools.getToday("yyyy-MM");
        queryParams.put("uid",courier_id);
        queryParams.put("date",today);

        JSONObject result = wuliuappModuleService.CallGetIncomeDetails(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期",true,body.getBooleanValue("ret"));
        JSONObject data_body = body.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", 209.0, data_body.getDoubleValue("general_income"));
        double qujian_income = money_4 + money_5 + money_7 + money_8;
        double songjian_income = money_13 + money_14 + money_17 + money_16;
        Assert.assertEquals("返回值不符合预期", "营业额提成", data_body.getJSONArray("general_content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", qujian_income + songjian_income, data_body.getJSONArray("general_content").getJSONObject(0).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 0, data_body.getJSONArray("general_content").getJSONObject(0).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(0).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "取件提成", data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", qujian_income, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "送件提成", data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", songjian_income, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "推广", data_body.getJSONArray("general_content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_2 + money_3, data_body.getJSONArray("general_content").getJSONObject(1).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 1, data_body.getJSONArray("general_content").getJSONObject(1).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(1).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "成单提成", data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_2, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "售卡提成", data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_3, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "奖励", data_body.getJSONArray("general_content").getJSONObject(2).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_19 + money_20, data_body.getJSONArray("general_content").getJSONObject(2).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 2, data_body.getJSONArray("general_content").getJSONObject(2).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(2).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "好评激励", data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_19 + money_20, data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        double zhuanyun_income = money_11 + money_12;
        double fanxi_income = money_6 + money_9 + money_15 + money_18;

        Assert.assertEquals("返回值不符合预期", "其他", data_body.getJSONArray("general_content").getJSONObject(3).getString("title"));
        Assert.assertEquals("返回值不符合预期", zhuanyun_income + fanxi_income + money_10, data_body.getJSONArray("general_content").getJSONObject(3).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 3, data_body.getJSONArray("general_content").getJSONObject(3).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(3).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "付转运费", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", 0.0, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "收转运费", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", zhuanyun_income, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "返洗收入", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getString("title"));
        Assert.assertEquals("返回值不符合预期",  fanxi_income, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "特殊时段取件收入", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getString("title"));
        Assert.assertEquals("返回值不符合预期",  money_10, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getBooleanValue("click"));

    }

    @Test

    public void testIncomeDetailsByDay() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        //计算推广成单的费用（2）
        int event_type_2 = 2;
        double money_2 = 2;
        generalUsualSalaryParams(event_type_2,money_2);
        //计算售卡的费用（3）
        int event_type_3 = 3;
        double money_3 = 3;
        generalUsualSalaryParams(event_type_3,money_3);
        //计算普通订单的取件服务费（4）
        int event_type_4 = 4;
        double money_4 = 4;
        generalUsualSalaryParams(event_type_4,money_4);
        //计算普通订单的取件运费（5）
        int event_type_5 = 5;
        double money_5 = 5;
        generalUsualSalaryParams(event_type_5,money_5);
        //计算返洗的普通订单取件费（6）
        int event_type_6 = 6;
        double money_6 = 6;
        generalUsualSalaryParams(event_type_6,money_6);
        //计算奢侈品订单取件服务费（7）
        int event_type_7 = 7;
        double money_7 = 7;
        generalUsualSalaryParams(event_type_7,money_7);
        //计算奢侈品订单取件运费（8）
        int event_type_8 = 8;
        double money_8 = 8;
        generalUsualSalaryParams(event_type_8,money_8);
        //计算返洗的奢侈品订单取件费（9）
        int event_type_9 = 9;
        double money_9 = 9;
        generalUsualSalaryParams(event_type_9,money_9);
        //计算特殊时段取件提成（10）
        int event_type_10 = 10;
        double money_10 = 10;
        generalUsualSalaryParams(event_type_10,money_10);
        //计算转运取件的费用（11）
        int event_type_11 = 11;
        double money_11 = 11;
        generalUsualSalaryParams(event_type_11,money_11);
        //计算转运送件的费用（12）
        int event_type_12 = 12;
        double money_12 = 12;
        generalUsualSalaryParams(event_type_12,money_12);
        //计算普通订单的送件服务费（13）
        int event_type_13 = 13;
        double money_13 = 13;
        generalUsualSalaryParams(event_type_13,money_13);
        //计算普通订单的送件运费（14）
        int event_type_14 = 14;
        double money_14 = 14;
        generalUsualSalaryParams(event_type_14,money_14);
        //计算返洗的普通订单送件费（15）
        int event_type_15 = 15;
        double money_15 = 15;
        generalUsualSalaryParams(event_type_15,money_15);
        //计算奢侈品订单送件服务费（16）
        int event_type_16 = 16;
        double money_16 = 16;
        generalUsualSalaryParams(event_type_16,money_16);
        //计算奢侈品订单送件运费（17）
        int event_type_17 = 17;
        double money_17 = 17;
        generalUsualSalaryParams(event_type_17,money_17);
        //计算返洗的奢侈品订单送件费（18）
        int event_type_18 = 18;
        double money_18 = 18;
        generalUsualSalaryParams(event_type_18,money_18);
        //计算取件评价提成（19）
        int event_type_19 = 19;
        double money_19 = 19;
        generalUsualSalaryParams(event_type_19,money_19);
        //计算送件评价提成（20）
        int event_type_20 = 20;
        double money_20 = 20;
        generalUsualSalaryParams(event_type_20,money_20);

        String date = CommonTools.getAfterDate("yyyy-MM-dd", -1);
        queryParams.put("uid",courier_id);
        queryParams.put("date",date);

        JSONObject result = wuliuappModuleService.CallGetIncomeDetails(queryParams, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));
        Assert.assertEquals("返回值不符合预期",true,body.getBooleanValue("ret"));
        JSONObject data_body = body.getJSONObject("data");
        Assert.assertEquals("返回值不符合预期", 209.0, data_body.getDoubleValue("general_income"));
        double qujian_income = money_4 + money_5 + money_7 + money_8;
        double songjian_income = money_13 + money_14 + money_17 + money_16;
        Assert.assertEquals("返回值不符合预期", "营业额提成", data_body.getJSONArray("general_content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", qujian_income + songjian_income, data_body.getJSONArray("general_content").getJSONObject(0).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 0, data_body.getJSONArray("general_content").getJSONObject(0).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(0).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "取件提成", data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", qujian_income, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));
        Assert.assertEquals("返回值不符合预期", 0, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(0).getIntValue("id"));

        Assert.assertEquals("返回值不符合预期", "送件提成", data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", songjian_income, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));
        Assert.assertEquals("返回值不符合预期", 1, data_body.getJSONArray("general_content").getJSONObject(0).getJSONArray("content").getJSONObject(1).getIntValue("id"));

        Assert.assertEquals("返回值不符合预期", "推广", data_body.getJSONArray("general_content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_2 + money_3, data_body.getJSONArray("general_content").getJSONObject(1).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 1, data_body.getJSONArray("general_content").getJSONObject(1).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(1).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "成单提成", data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_2, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "售卡提成", data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_3, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(1).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "奖励", data_body.getJSONArray("general_content").getJSONObject(2).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_19 + money_20, data_body.getJSONArray("general_content").getJSONObject(2).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 2, data_body.getJSONArray("general_content").getJSONObject(2).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(2).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "好评激励", data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", money_19 + money_20, data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(2).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));

        double zhuanyun_income = money_11 + money_12;
        double fanxi_income = money_6 + money_9 + money_15 + money_18;

        Assert.assertEquals("返回值不符合预期", "其他", data_body.getJSONArray("general_content").getJSONObject(3).getString("title"));
        Assert.assertEquals("返回值不符合预期", zhuanyun_income + fanxi_income + money_10, data_body.getJSONArray("general_content").getJSONObject(3).getDoubleValue("general_income"));
        Assert.assertEquals("返回值不符合预期", 3, data_body.getJSONArray("general_content").getJSONObject(3).getIntValue("position"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(3).getBooleanValue("enable"));

        Assert.assertEquals("返回值不符合预期", "付转运费", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getString("title"));
        Assert.assertEquals("返回值不符合预期", 0.0, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", true, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getBooleanValue("click"));
        Assert.assertEquals("返回值不符合预期", 2, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(0).getIntValue("id"));

        Assert.assertEquals("返回值不符合预期", "收转运费", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getString("title"));
        Assert.assertEquals("返回值不符合预期", zhuanyun_income, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(1).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "返洗收入", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getString("title"));
        Assert.assertEquals("返回值不符合预期",  fanxi_income, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(2).getBooleanValue("click"));

        Assert.assertEquals("返回值不符合预期", "特殊时段取件收入", data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getString("title"));
        Assert.assertEquals("返回值不符合预期",  money_10, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getDoubleValue("amount"));
        Assert.assertEquals("返回值不符合预期", false, data_body.getJSONArray("general_content").getJSONObject(3).getJSONArray("content").getJSONObject(3).getBooleanValue("click"));

    }

}
