package com.edaixi.qa.caiwuadmin;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.caiwuadmin.CaiwuadminModuleService;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class CreateRechargeTest {

    private static Logger logger = LoggerFactory
            .getLogger(CreateRechargeTest.class);
    private CaiwuadminModuleService edxpayModuleService = new CaiwuadminModuleService();
    private JSONObject queryParams = new JSONObject();

    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao("jdbc05.properties");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
    }

    @After
    public void tearDown() {
        logger.info("in teardown!");
    }


    @Test
    /**
     * @User: zhaoning
     * @Date: 16-4-07
     * @Scenario:创建E卡
     *   when:需要创建E卡
     *   where:财务后台的E卡管理
     *   then:正常创建一张E卡
     */
    public void testCreateRechage() throws SQLException, NoSuchAlgorithmException, UnsupportedEncodingException {
        long currentTime = System.currentTimeMillis();
        int sncode_id = (int)(currentTime % 10000000);
        int kind = 2;
        int pay_type = 2;//微信
        String trans_type = "recharge";
        this.queryParams.put("kind",kind);
        this.queryParams.put("title",currentTime);
        this.queryParams.put("zhenqian",100);
        this.queryParams.put("stock_id",1);
        this.queryParams.put("price",120);
        this.queryParams.put("usednum",0);
        this.queryParams.put("validity_type",0);
        this.queryParams.put("starttime", CommonTools.getToday("yyyy-MM-dd"));
        this.queryParams.put("endtime",CommonTools.getAfterDate("yyyy-MM-dd",20));
        this.queryParams.put("charge_validity_type",0);
        this.queryParams.put("charge_starttime",CommonTools.getToday("yyyy-MM-dd"));
        this.queryParams.put("charge_endtime",CommonTools.getAfterDate("yyyy-MM-dd",20));
        this.queryParams.put("apply_department","api_auto_test");
        this.queryParams.put("applicant","api_auto_test");
        this.queryParams.put("city","beijing");
        this.httpHead.put("Cookie","ci_session=737925d742b650b54c2af475c13b5a6911024e2d");
        // 调用登录接口
        JSONObject result = this.edxpayModuleService.CreateRecharge(this.queryParams, this.httpHead);
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("200"));

        String queryRecharge = "select `id`, `weid`, `title`, `price`, `usednum`, FROM_UNIXTIME(`starttime`) as starttime, FROM_UNIXTIME(`endtime`) as endtime, FROM_UNIXTIME(`create_time`) as create_time, `use_limit`, `zhenqian`, `apply_department`, `applicant`, `city`, `product_good_id`, `created_at`, `updated_at`, `kind`, `stock_id`, `recharge_group_id`, `is_hidden`, `is_actived`, `validity_type`, `fixed_term`, `fixed_begin_term`, `charge_validity_type`, `charge_fixed_term`, `charge_fixed_begin_term`,FROM_UNIXTIME(`charge_starttime`) as charge_starttime, FROM_UNIXTIME(`charge_endtime`) as charge_endtime, `minimum_stock_amount`, `restock_amount` from " +
                "ims_recharge where title like '" + currentTime + "'";
        ResultSet rechargeInfo = mysqlQaDao.execQuerySql(queryRecharge);

        Assert.assertEquals("返回值不符合预期",120,rechargeInfo.getInt("price"));
        Assert.assertEquals("返回值不符合预期",0,rechargeInfo.getInt("usednum"));
        Assert.assertTrue("返回值不符合预期",rechargeInfo.getString("starttime").contains(CommonTools.getToday("yyyy-MM-dd")));

    }


}
