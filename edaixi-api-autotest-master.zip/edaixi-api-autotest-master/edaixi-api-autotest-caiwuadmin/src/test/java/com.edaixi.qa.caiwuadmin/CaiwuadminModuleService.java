package com.edaixi.qa.caiwuadmin;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.service.BaseServiceFactory;
import com.edaixi.base.qa.common.service.RestService;
import com.edaixi.base.qa.common.utils.GlobalConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Encoder;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class CaiwuadminModuleService {
	private static Logger logger = LoggerFactory.getLogger(CaiwuadminModuleService.class);
	private BaseServiceFactory baseServiceFactory = new BaseServiceFactory();
	private RestService caiwuadmin = null;

	protected Properties globalConf = null;
	private Map<String, Object> queryParams = null;

	public CaiwuadminModuleService(){
		this.init();
	}
	public final void init(){
		this.queryParams = new HashMap<String, Object>();
		this.globalConf = GlobalConfig.getProperties();
		caiwuadmin = (RestService) this.baseServiceFactory.getService();
		caiwuadmin.init(this.globalConf.getProperty("caiwuadmin.addr"));

	}


	public static String base64Encode(byte[] bytes){
		return new BASE64Encoder().encode(bytes);
	}


	public JSONObject CreateRecharge(Map<String, Object> queryParam,Map<String, Object> httpHead){
		String method = "post";
		return this.caiwuadmin.callApi2Json(this.globalConf.getProperty("rechargeCard.createRecharge"), method,queryParam,httpHead);
	}



}
