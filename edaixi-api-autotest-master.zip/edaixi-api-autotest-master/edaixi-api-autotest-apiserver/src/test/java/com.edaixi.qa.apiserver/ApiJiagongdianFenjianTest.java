package com.edaixi.qa.apiserver;

/**
 * ApiJiagongdianFenjianTest
 *
 * @author wangting
 * @date 2016/2/15
 */
public class ApiJiagongdianFenjianTest {
}
