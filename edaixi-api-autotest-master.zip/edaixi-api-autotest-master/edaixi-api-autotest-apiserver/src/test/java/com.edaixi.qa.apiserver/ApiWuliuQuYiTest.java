//package com.edaixi.qa.apiserver;
//
//import com.alibaba.fastjson.JSON;
//import com.alibaba.fastjson.JSONObject;
//import com.edaixi.base.qa.common.dao.MysqlQaDao;
//import com.edaixi.qa.common.CommonTools;
//import com.edaixi.qa.common.CreateOrderByStatus;
//import junit.framework.Assert;
//import org.junit.After;
//import org.junit.Before;
//import org.junit.BeforeClass;
//import org.junit.Test;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.text.SimpleDateFormat;
//import java.util.*;
//
///**
// * ApiWuliuQuYiTest
// *
// * @author wangting
// * @date 2016/2/4
// */
//public class ApiWuliuQuYiTest {
//
//
//    private static Logger logger = LoggerFactory
//            .getLogger(ApiWuliuQuYiTest.class);
//    private static ApiModuleService shareAPIModuleService = new ApiModuleService();
//    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
//    private static CreateOrderByStatus createOrderByStatus = new CreateOrderByStatus();
//
//    private final static int courier_id = CommonTools.get_courierId(mysqlQaDao);
//    private static int orderId ;
//    private static String ordersn = "";
//
//    private Map<String, Object> queryParams = null;
//    private Map<String, List> mapOrder_clothe_list;
//
//    private List<Integer> beforeOrder_clothes_listsId;
//
//
//    @BeforeClass
//    public void setUp() {
//        createOrderByStatus.setCourierId(courier_id);
//        createOrderByStatus.getOrderByStatus(CreateOrderByStatus.orderStatus.qu_paidan);
//        orderId = createOrderByStatus.getOrderId();
//        ordersn = createOrderByStatus.getOrderSn();
//
//        this.queryParams = new HashMap<String, Object>();
//        beforeOrder_clothes_listsId = getBeforeOrder_clothes_listsId();
//    }
//
//
//    @After
//    public void tearDown() {
//        logger.info("in teardown!");
//    }
//
//
//    @Test
//    /**
//     *
//     * http://localhost:3006/api/v1/orders
//     *
//     * @author ningyao.zn
//     */
//    public void testApiDiaoduPaidan() throws SQLException {
//        // 准备好接口需要的参数
//        long currentTime = System.currentTimeMillis();
//        int order_id = CommonTools.getLastId("select * from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1;
//        String tel = "1500000" + String.valueOf(currentTime % 10000);
//        String push_token = String.valueOf(currentTime % 10000) + "be1-b250-40a9-99a1-eeb2896041c4";
//        String order_sn = CommonTools.getOrdersn(order_id);
//
//        Calendar calendar = new GregorianCalendar();
////        calendar.setTime(dt);
//        calendar.add(calendar.DATE,1);
//        Date nextDate = calendar.getTime();
//
//        int uid = 0;
//        int old_category_id = 1;
//        int status = -1;
//        int status_delivery = 11;
//        int pay_status = 0;
////        String courier_id = String.valueOf(currentTime % 10000);
//        int courier_id = CommonTools.get_courierId(mysqlQaDao);
//        String washing_time = "10:00-12:00";
//
//        //造订单的数据
//        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
//                "VALUES\n" +
//                "\t(" + order_id + ", NULL, 7, '" + order_sn + "', '', 1, 0.00, 0.00, '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, '接口测试', '" + formatDate.format(nextDate) + "', '" + washing_time + "', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', "+ uid + ", 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";
//
////        String courierInfo = "INSERT INTO `ims_washing_courier` (`id`, `realname`, `password`, `tel`, `outlet_id`, `status`, `push_token`, `created_at`, `updated_at`, `city`, `kind`, `polygon_group_id`, `use_auto_schedule`, `bank_card`, `id_number`, `bank_name`, `saofen`, `shouka`, `jiedan`, `edaixi_nr`, `start_time`, `end_time`, `channel`, `luxury_logistic`, `city_id`, `zhuanyun`, `client_name`, `is_zhongtui`, `is_employee`, `close_time`, `kuaixi`, `street_name`, `gender`, `service_time_type`, `catch_reasons`, `is_zancun`, `is_owner`, `yizhan_id`, `is_van`, `songyao`, `contract_version`, `contract_version_end_time`, `hotel_id`, `is_part_time`, `is_lanshou`, `songfan`, `deposit`, `pay_deposit_state`, `jiebo`, `bank_user_name`, `tailor`, `tailor_outlet_id`, `detailed_address`, `emergency_tel`)\n" +
////                "VALUES\n" +
////                "\t(" + courier_id + ", '接口测试', '1234566', " + tel + ", 3, 1, '" + push_token + "', '2015-09-10 02:33:58', '2016-02-02 16:03:42', '北京', 1, 476, 1, '6778550144961236', '429008198709081111', '招行', 1, 1, 1, '001001000015', '2015-09-01', '2017-03-31', 'com.15.zhongbao', 1, 1, 1, 'android_client', 0, 0, NULL, 1, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, 1, 0, NULL, 0, NULL, 0, 0.00, 0, 0, NULL, 0, NULL, NULL, NULL);\n";
//
//        mysqlQaDao.execUpdateSql(orderInfo);
////        mysqlQaDao.execUpdateSql(courierInfo);
//
//        this.queryParams.put("courier_id",courier_id);
//
//        JSONObject result = this.shareAPIModuleService.CallDiaoDuPaiDan("", "", String.valueOf(order_id),this.queryParams);
//        // 验证接口返回的数据
//        logger.info(result.toJSONString());
//        Assert.assertTrue(result.getString("httpStatus").equals("201"));
//        JSONObject body = JSON.parseObject(result.getString("httpBody"));
//
//        //验证ims_washing_order 表中订单的状态和物流人员更新成功
//
//        String queryOrderInfo = "select courier_qu,status,pay_status,qujian_paidan_time,status_delivery,updated_at from ims_washing_order where id = " + order_id + "";
//        ResultSet retOrderInfo = mysqlQaDao.execQuerySql(queryOrderInfo);
//        Assert.assertEquals("返回值不符合预期",1,retOrderInfo.getInt("status"));
//        Assert.assertEquals("返回值不符合预期",9,retOrderInfo.getInt("status_delivery"));
//        Assert.assertEquals("返回值不符合预期",0,retOrderInfo.getInt("pay_status"));
//        Assert.assertEquals("返回值不符合预期",courier_id,retOrderInfo.getInt("courier_qu"));
//        Assert.assertTrue("返回值不符合预期", CommonTools.judgeTimeDifference(retOrderInfo.getString("updated_at"), CommonTools.getToday("yyyy-MM-dd HH:mm:ss"), 3));
//
//        // 验证生成的交接单的数据是否正确
//        String queryTransOrder = "select id,from_id,from_type,to_type,to_address_id,dead_line,status,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type from " +
//                "trans_tasks where order_id = " + order_id + "";
//        ResultSet queryTranInfo = mysqlQaDao.execQuerySql(queryTransOrder);
//        Assert.assertEquals("返回值不符合预期",uid,queryTranInfo.getInt("from_id"));
//        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("from_type").contains("zhongbao"));
//        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("to_type").contains("customer"));
//        Assert.assertEquals("返回值不符合预期", 595975,queryTranInfo.getInt("to_address_id"));
//        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("status").contains("started"));
//        Assert.assertEquals("返回值不符合预期", 1,queryTranInfo.getInt("category_id"));
//        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("washing_status").contains("unwashed"));
//        Assert.assertEquals("返回值不符合预期", 0,queryTranInfo.getInt("trans_ttl"));
//        Assert.assertEquals("返回值不符合预期", 0,queryTranInfo.getInt("trans_type"));
//        // 验证生成的group数据是否正确
//        String queryGroup = "select id,order_id,ordersn,current_task_id,last_task_id,order_type,order_status,status_delivery,type from trans_groups where order_id = " + order_id + "";
//        ResultSet queryGroupInfo = mysqlQaDao.execQuerySql(queryGroup);
//        Assert.assertEquals("返回值不符合预期",queryTranInfo.getString("id"),queryGroupInfo.getString("current_task_id"));
//        Assert.assertEquals("返回值不符合预期",queryTranInfo.getString("id"),queryGroupInfo.getString("last_task_id"));
//        Assert.assertEquals("返回值不符合预期",status,queryGroupInfo.getInt("order_status"));
//        Assert.assertTrue("返回值不符合预期",queryGroupInfo.getString("type").contains("TransGroup"));
//        Assert.assertEquals("返回值不符合预期",queryGroupInfo.getString("id"),queryTranInfo.getString("trans_group_id"));
//    }
//
//
//    public List<Integer> getBeforeOrder_clothes_listsId(){
//        String sql = "SELECT `order_clothes_lists`.id FROM `order_clothes_lists` WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`order_id` = "+orderId+" AND `order_clothes_lists`.`status` = 10";
//        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
//        List<Integer> list = new ArrayList<Integer>();
//        try {
//            resultSet.beforeFirst();
//            if (resultSet.next()){
//                list.add(resultSet.getInt("id"));
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        return list;
//
//    }
//
//    public double getOrderMoney(){
//        String sqlOrderMoney = "SELECT SUM(`order_clothes_lists`.`courier_price`) AS sum_id FROM `order_clothes_lists` WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`order_id` = "+orderId+" AND `order_clothes_lists`.`status` IN (10, 21, 22) AND (`order_clothes_lists`.`suit_id` != -1)";
//        double orderMoney = 0.00;
//        ResultSet resultSetOrderMoney = mysqlQaDao.execQuerySql(sqlOrderMoney);
//        try {
//            resultSetOrderMoney.beforeFirst();
//            while (resultSetOrderMoney.next()){
//                orderMoney = resultSetOrderMoney.getDouble("sum_id");
//            }
//            resultSetOrderMoney.close();
//
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        resultSetOrderMoney = null;
//
//        return orderMoney;
//    }
//
//
//
//    public double getDeliveryMoney(double orderMoney){
//        String sqls = "select city, category_id from ims_washing_order where id="+orderId;
//        String city = "";
//        String category_id = "";
//        ResultSet resultSet = mysqlQaDao.execQuerySql(sqls);
//        try {
//            resultSet.beforeFirst();
//            while (resultSet.next()){
//                city = resultSet.getString(city);
//                category_id = resultSet.getString(category_id);
//            }
//            resultSet.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        resultSet = null;
//
//        int city_id = 1;
//        ResultSet resultSetCityId = mysqlQaDao.execQuerySql("select id from cities WHERE `cities`.`name` = '"+city+"' LIMIT 1;");
//        try {
//            resultSetCityId.beforeFirst();
//            while (resultSetCityId.next()){
//                city_id = resultSetCityId.getInt("id");
//            }
//            resultSetCityId.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        resultSetCityId = null;
//
//        double deliveryMoney = 0.00;
//        String sqlDeliveryMoney = "SELECT `delivery_fee_settings`.* FROM `delivery_fee_settings` WHERE `delivery_fee_settings`.`is_deleted` = 0 AND (city_id = "+city_id+" and category_id = "+category_id+" and sentinel_min <= "+orderMoney+" and status = 'online') ORDER BY `delivery_fee_settings`.`sentinel_min` DESC LIMIT 1;";
//        ResultSet resultSetDeliveryMoney = mysqlQaDao.execQuerySql(sqlDeliveryMoney);
//        try {
//            resultSetDeliveryMoney.beforeFirst();
//            while(resultSetDeliveryMoney.next()){
//                deliveryMoney = resultSetDeliveryMoney.getDouble("delivery_fee");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        return deliveryMoney;
//    }
//
//    public void getOrder_clothes_listsResult(){
//        mapOrder_clothe_list = new HashMap<String, List>();
//        List<Integer> listCourier_id = new ArrayList<Integer>();
//        List<Integer> listClothes_id = new ArrayList<Integer>();
//        List<String> listClothes_name = new ArrayList<String>();
//
//        String sql = "SELECT `order_clothes_lists`.* FROM `order_clothes_lists` WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`order_id` = "+orderId+" AND `order_clothes_lists`.`status` = 10";
//        ResultSet resultSetOrderClothe = mysqlQaDao.execQuerySql(sql);
//        try {
//            resultSetOrderClothe.beforeFirst();
//            while (resultSetOrderClothe.next()){
//                listClothes_id.add(resultSetOrderClothe.getInt("courier_id"));
//                listClothes_id.add(resultSetOrderClothe.getInt("clothes_id"));
//                listClothes_name.add(resultSetOrderClothe.getString("clothes_name"));
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        mapOrder_clothe_list.put("courier_id", listCourier_id);
//        mapOrder_clothe_list.put("clothes_id", listClothes_id);
//        mapOrder_clothe_list.put("clothes_name", listClothes_name);
//    }
//
//
//    @Test
//    public void ims_washing_order_totalprice(){
//        String sql = "select totalprice from ims_washing_order where id="+orderId;
//        String totalprice = "";
//        ResultSet resultSet = mysqlQaDao.execQuerySql(sql);
//        try {
//            while (resultSet.next()){
//                totalprice = resultSet.getString("totalprice");
//            }
//            resultSet.close();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//
//        double orderMoney = getOrderMoney();
//        String truetotalprice = String.format("%.2f", (orderMoney + getDeliveryMoney(orderMoney)) );
//        org.junit.Assert.assertEquals("totalprice字段不正确", truetotalprice, totalprice);
//    }
//
//    @Test
//    public void order_clothes_listsBefore(){
//        boolean flag = false;
//        if (beforeOrder_clothes_listsId.isEmpty()){
//            flag = true;
//        }{
//            List<Integer> list = new ArrayList<Integer>();
//
//            for (int i=0;i<beforeOrder_clothes_listsId.size();i++){
//                ResultSet resultSet = mysqlQaDao.execQuerySql("select status from order_clothes_lists where id="+beforeOrder_clothes_listsId.get(i));
//                int status = 10;
//                try {
//                    status = resultSet.getInt("status");
//                } catch (SQLException e) {
//                    e.printStackTrace();
//                }
//                list.add(status);
//            }
//
//            if (!list.contains(10)){
//                flag = true;
//            }
//        }
//
//        org.junit.Assert.assertTrue("order_clothes_lists之前的数据的status不正确", flag);
//    }
//
//    public void test(){
//        String getJijiaId = "SELECT `order_clothes_lists`.`id`, `order_clothes_lists`.* FROM `order_clothes_lists` WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`order_id` = "+orderId+" AND `order_clothes_lists`.`status` = 10";
////        UPDATE `order_clothes_lists` SET `order_clothes_lists`.`status` = 11, `order_clothes_lists`.`updated_at` = '2016-05-16 14:35:53' WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`id` IN (14942, 14943)
////        INSERT INTO `order_clothes_lists` (`bag_sn`, `clothes_id`, `clothes_name`, `courier_id`, `courier_price`, `courier_price_id`, `courier_sort_time`, `created_at`, `is_bargain`, `order_id`, `order_sn`, `status`, `type`, `updated_at`) VALUES ('', 7, '衬衫', 168, 9.0, 7, '2016-05-16 14:35:53', '2016-05-16 14:35:53', 1, 9974458, '16051199744582', 10, 'OrderClothesList', '2016-05-16 14:35:53')
////        SELECT SUM(`order_clothes_lists`.`courier_price`) AS sum_id FROM `order_clothes_lists` WHERE `order_clothes_lists`.`type` IN ('OrderClothesList') AND `order_clothes_lists`.`order_id` = 9974458 AND `order_clothes_lists`.`status` IN (10, 21, 22) AND (`order_clothes_lists`.`suit_id` != -1)
////        UPDATE `ims_washing_order` SET `totalprice` = 19.0, `updated_at` = '2016-05-16 14:35:53' WHERE `ims_washing_order`.`id` = 9974458
//
//
//    }
//}
//
