package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.*;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 *
 * Created by he_yi on 16/3/9.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)   //设置按照测试方法名称顺序执行
public class ApiWuliuYiQuTest {
    private static Logger logger = LoggerFactory
            .getLogger(ApiWuliuYiQuTest.class);
    private static ApiModuleService shareAPIModuleService = new ApiModuleService();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static GeneralRongChain04Data rongChang04Data = new GeneralRongChain04Data();

    private static Map<String, String> mapWashingOrder;
    private static Map<Object, String> mapTransGroups;
    private static Map<Object, String> mapDispatchTasks;
    private static Map<Object, String> mapTransTasks;
    private static Map<Object, String> mapTransTasks_new1;
    private static Map<Object, String> mapTransTasks_new2;

    /*
     *变量值请勿修改!!!!!!!!!
     */

    private static String dispath_id;
    private static String task_id;
    private static String group_id;
    private static String order_id;
    private static String order_sn;
    private static String courie_id = String.valueOf(CommonTools.get_courierId(mysqlQaDao));


    public ApiWuliuYiQuTest(){

    }


    /*
     *变量值可以修改
     */
    private static String remark = "测试备注"; //备注
    private static String bagsn = "00043911769";   //封签号

    enum ims_washing_order_field {
        bagsn("bagsn"),
        logistics_remark("logistics_remark"),
        qujian_time("qujian_time"),
        wuliu_qu_yiqu_time("wuliu_qu_yiqu_time"),
        status_delivery("status_delivery"),
        updated_at("updated_at");


        private String value = "";

        private ims_washing_order_field(String v) {
            this.value = v;
        }

        @Override
        public String toString() {
            return this.value;
        }
    }

    enum trans_groups_field{
        bagsn("bagsn"),
        updated_at("updated_at"),
        current_task_id("current_task_id"),
        last_task_id("last_task_id");

        private String value = "";
        private trans_groups_field(String v){
            value = v;
        }

        @Override
        public String toString(){
            return value;
        }
    }

    enum trans_tasks_field{
        bagsn("bagsn"),
        status("status"),
        updated_at("updated_at"),
        finished_at("finished_at"),
        next_task_id("next_task_id");

        private String value = "";
        private trans_tasks_field(String v){
            value = v;
        }

        @Override
        public String toString(){
            return value;
        }
    }

    enum dispatch_tasks_field {
        status("status"),
        finished_at("finished_at"),
        updated_at("updated_at");

        private String value = "";

        private dispatch_tasks_field(String v) {
            this.value = v;
        }

        @Override
        public String toString() {
            return this.value;
        }
    }

    enum trans_tasks_new1_field{
        bagsn("bagsn"),
        category_id("category_id"),
        created_at("created_at"),
        direction("direction"),
        from_id("from_id"),
        from_type("from_type"),
        order_id("order_id"),
        ordersn("ordersn"),
        status("status"),
        to_type("to_type"),
        trans_group_id("trans_group_id"),
        trans_ttl("trans_ttl"),
        updated_at("updated_at"),
        washing_status("washing_status");

        private String value = "";
        private trans_tasks_new1_field(String v){
            value = v;
        }

        @Override
        public String toString(){
            return value;
        }
    }

    enum trans_tasks_new2_field{
        bagsn("bagsn"),
        category_id("category_id"),
        created_at("created_at"),
        direction("direction"),
        from_type("from_type"),
        order_id("order_id"),
        ordersn("ordersn"),
        status("status"),
        to_id("to_id"),
        to_type("to_type"),
        trans_group_id("trans_group_id"),
        trans_ttl("trans_ttl"),
        updated_at("updated_at"),
        washing_status("washing_status");

        private String value = "";
        private trans_tasks_new2_field(String v){
            value = v;
        }

        @Override
        public String toString(){
            return value;
        }
    }



    public static int getRandomInt(int size){
        Random random = new Random();
        String mins ="1";
        String maxs = "9";

        for(int i=0;i<size-1;i++){
            mins+="1";
            maxs+="9";
        }

        int min = Integer.parseInt(mins);
        int max = Integer.parseInt(maxs);

        int s = random.nextInt(max) % (max - min +1)+min;
        return s;
    }


    private static String get_courierId(){
        String sql_get_lastId = "select id from ims_washing_courier where tel=18881112222 order by id DESC limit 1;";

//        ResultSet result_last_id = mysqlQaDao.execQuerySql(sql_get_lastId);
        int id = getLastId(sql_get_lastId);
        if (id >0 ){
            return String.valueOf(id);
        }else{
            String now_id = String.valueOf(getLastId("select id from ims_washing_courier order by id desc limit 1;")+1);
//            String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
//            String sql =
//                    "insert into ims_washing_courier(id,realname,password,tel,outlet_id,status,push_token,created_at,updated_at,city,kind,polygon_group_id,use_auto_schedule,bank_card,id_number,bank_name,saofen,shouka,jiedan,edaixi_nr,start_time,end_time,channel,luxury_logistic,city_id,zhuanyun,client_name,is_zhongtui,is_employee,close_time,kuaixi,street_name,gender,service_time_type,catch_reasons,is_zancun,is_owner,yizhan_id,is_van,songyao,contract_version,contract_version_end_time,hotel_id,is_part_time,is_lanshou,songfan,deposit,pay_deposit_state,jiebo,bank_user_name,tailor,tailor_outlet_id,detailed_address,emergency_tel) " +
//                    "values("+ now_id+",'接口自动化测试','jiekouceshi1234',18881112222,0,1,'332a4cb08505866c8a85c37dff128a28','"+time+"','"+time+"','北京',1,NULL,1,62258810454536652,110105199885523652,'工商银行',1,1,1,'EZB-0010-000"+now_id+"',NULL,NULL,'com."+now_id+".zhongbao',0,1,0,'android_client',0,0,NULL,0,NULL,'男',NULL,NULL,0,0,NULL,NULL,0,1457432520,1489043736,NULL,0,NULL,0,0,1,0,'接口自动化测试',0,NULL,'个把',12566365425);";
//            logger.info("sql:"+sql);
//            mysqlQaDao.execUpdateSql(sql);

            Map<String, Object> tmp = new HashMap<String, Object>();
            tmp.put("courier_id", now_id);
            tmp.put("tel", "18881112222");
            tmp.put("push_token", "332a4cb08505866c8a85c37dff128a28");
            rongChang04Data.GeneralCouriers(tmp);

            return get_courierId();
        }
    }

    private static void create_order(){
        int last_id = getLastId("select id from ims_washing_order order by id desc limit 1;");

        order_id = String.valueOf(last_id+1);
        order_sn = new SimpleDateFormat("yyMMdd").format(System.currentTimeMillis())+order_id+getRandomInt(1);
        String time_now_yMd = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
        String time_now_unix = String.valueOf(System.currentTimeMillis()).substring(0,10);


//        String sql = "insert into ims_washing_order(id,from_user,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,receivables_paid,status,status_delivery,back_reason,logistics_remark,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song,address_song,courier_qu,courier_song,shoukuan_kuaidi,shoukuan_kuaidi_time,shoukuan_store,shoukuan_store_time,shoukuan_caiwu,shoukuan_caiwu_time,createtime,qujian_paidan_time,qujian_time,songhui_paidan_time,songhui_time,is_xianxia,kehu_song_shouyidian_time,shouyidian_qu_id,dingdan_quxiao_time,jiagongdian_qianshou_time,jiagongdian_id,wuliu_song_qianshou_time,shouyidian_song_qianshou_time,shouyidian_song_id,kehu_qianshou_time,wuliu_qu_tuihui_time,wuliu_song_tuihui_time,wuliu_qu_yiqu_time,jiagongdian_fenjian_time,jiagongdian_shangjia_time,back_reason_qu,back_reason_song,created_at,updated_at,caiwu_status,diaodu_queren_time,actual_price,xianjin_shoukuan,diaodu_song_paidan_time,is_fanxi,yuandingdan_id,fanxidan_id,fan_id,order_commented_at,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,song_week_nr,song_from_time_mod,song_to_time_mod,qianshoudian_id,address_qu_id,address_song_id,auto_dispatched_qu_at,auto_dispatched_song_at,last_six_ordersn,category_id,cannot_wash,cannot_wash_reason,client_id,discount,original_order_id,fanxi_count,washing_duration)" +
//                "values("+order_id+",NULL,7,"+order_sn+",'',1,74.00,10.00,'',0.00,0.00,0.00,1,9,'',NULL,1,3,'"+remark+"'," +
//                "'"+new SimpleDateFormat("yyyy-MM-dd").format(System.currentTimeMillis())+"','22:00-24:00','','','接口测试用户',18611369742,'北京','朝阳区','大山子 798','北京'," +
//                "'朝阳区','大山子 798',"+get_courierId()+",0,0,NULL,0,NULL,0,NULL,"+String.valueOf(System.currentTimeMillis()).substring(0,10)+","+
//                time_now_unix+",0,0,0,0,NULL,NULL," +
//                "NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL," +
//                "'"+time_now_yMd+"','"+time_now_yMd+"',0,"+time_now_unix+",0,0,NULL,0,0,0,623745,NULL,18,2410,118,119," +
//                "NULL,NULL,NULL,0,595983,595983,NULL,NULL,"+order_sn.substring(order_sn.length()-6, order_sn.length())+",1,0,NULL,NULL,0.00,NULL,NULL,NULL)";
//        mysqlQaDao.execUpdateSql(sql);


        Map<String, Object> map = new HashMap<String, Object>();
        map.put("order_id", order_id);
        map.put("order_sn", order_sn);
        map.put("status", 1);
        map.put("status_delivery", 9);
        map.put("pay_status", 1);
        map.put("nextDate", System.currentTimeMillis());
        map.put("washing_time", "22:00-24:00");
        map.put("uid", get_courierId());
        map.put("old_category_id", 1);
        map.put("totalprice","74.00");
        map.put("delivery_fee","10.00");
        rongChang04Data.GeneralOrder(map);

    }

    private static void create_transInfo(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd ");
        String time_dead_line = sdf.format(new Date(System.currentTimeMillis()).getTime() + 1 * 24 * 60 * 60 * 1000)+" 00:00:00";
        String time_now_full = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
//
        dispath_id = String.valueOf((getLastId("select id from dispatch_tasks order by id desc limit 1;")+1));
//        String sql_dispath ="insert into dispatch_tasks (id,order_id,status,from_type,from_id,to_type,to_id,dispatch_type,courier_id,hope_time,finished_at,category_id,created_at,updated_at,type,ordersn,city_id)" +
//                "values(" +
//                dispath_id+
//                ","+order_id+",'dispatched','jiagongdian',NULL,'Address',595983,0,"+get_courierId()+",'"+
//                time_dead_line+"',NULL,1," +
//                "'"+time_now_full+"','"+time_now_full+"','DispatchTask',NULL,1);";
//        mysqlQaDao.execUpdateSql(sql_dispath);

        Map<String, Object> tmp1 = new HashMap<String, Object>();
        tmp1.put("id",dispath_id);
        tmp1.put("order_id",order_id);
//        tmp1.put("nextDate",(new Date(System.currentTimeMillis()).getTime() + 1 * 24 * 60 * 60 * 1000));
        tmp1.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd", 1)+" 00:00:00");
        rongChang04Data.GeneralDispatchTask(tmp1);


        task_id = String.valueOf(getLastId("select id from trans_tasks order by id desc limit 1;")+1);
//        String sql_task = "insert into trans_tasks (id,bagsn,from_id,from_type,from_address_id,to_id,to_type,to_address_id,next_task_id,transfer_task_id,transferred_by,dead_line,prority,status,direction,finished_at,created_at,updated_at,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type)" +
//                "values("+
//                task_id+",NULL,"+courie_id+",'zhongbao',NULL,NULL,'customer',595983,NULL,NULL,NULL,'"+
//                time_dead_line+"',NULL,'started','get',NULL,'"+time_now_full+"','"+time_now_full+"',1,"+order_sn+",'unwashed',"+order_id+",97382,0,0);";
//        mysqlQaDao.execUpdateSql(sql_task);
        tmp1.clear();
        tmp1.put("id", task_id);
        tmp1.put("ordersn", order_sn);
        tmp1.put("order_id", order_id);
        tmp1.put("from_id", courie_id);
        tmp1.put("from_type", "zhongbao");
        rongChang04Data.GeneralTransTasks(tmp1);


        group_id = String.valueOf(getLastId("select id from trans_groups order by id desc limit 1;")+1);
//        String sql_groups = "insert into trans_groups (id,order_id,ordersn,bagsn,current_task_id,last_task_id,order_type,order_status,status_delivery,type,created_at,updated_at,propose_outlet_id,dispatch_task_id)" +
//                "values("+
//                group_id+","+order_id+",NULL,NULL,"+task_id+","+task_id+",NULL,1,NULL,'TransGroup','"+time_now_full+"','"+time_now_full+"',NULL,"+dispath_id+");";
//        mysqlQaDao.execUpdateSql(sql_groups);
        tmp1.clear();
        tmp1.put("id", group_id);
        tmp1.put("order_id", order_id);
        tmp1.put("current_task_id", task_id);
        tmp1.put("last_task_id", task_id);
        tmp1.put("dispatch_task_id", dispath_id);
        rongChang04Data.GeneralTransGroups(tmp1);



        String sql_upate_task_groupId = "update trans_tasks set trans_group_id ="+group_id+" where id="+task_id+";";
        mysqlQaDao.execUpdateSql(sql_upate_task_groupId);
    }

    private static Map<String, String> get_ims_washing_order_tableInfo(){
        Map<String, String> result = new HashMap<String, String>();

        String sql = "select bagsn, logistics_remark, qujian_time, wuliu_qu_yiqu_time, status_delivery, updated_at"
                +" from ims_washing_order where id = "+order_id+" limit 1;";

        ResultSet r = mysqlQaDao.execQuerySql(sql);

        try {
            r.beforeFirst();
            if (r.next()){
                result.put("bagsn", r.getString("bagsn"));
                result.put("logistics_remark", r.getString("logistics_remark"));
                result.put("qujian_time", r.getString("qujian_time"));
                result.put("wuliu_qu_yiqu_time", r.getString("wuliu_qu_yiqu_time"));
                result.put("status_delivery", r.getString("status_delivery"));
                result.put("updated_at", r.getString("updated_at"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

    private static Map<Object, String> getMapTransGroups(){
        String sql = "select bagsn, last_task_id, updated_at, current_task_id from trans_groups WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` ="+group_id+";";
        return getResultMap(trans_groups_field.class, sql);
    }


    private static Map<Object, String> getMapDispatchTasks(){
        String sql = "select status, finished_at, updated_at from dispatch_tasks WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` ="+dispath_id+";";
        return getResultMap(dispatch_tasks_field.class, sql);
    }

    private static Map<Object, String> getMapTransTasks(){
        String sql = "select bagsn, status, finished_at, updated_at,next_task_id from trans_tasks where id = "+task_id+";";
        return getResultMap(trans_tasks_field.class, sql);
    }

    private static Map<Object, String> getMapTransTasks_new1(){
        String sql = "select `bagsn`, `category_id`, `created_at`, `dead_line`, `direction`, `from_id`, `from_type`, `order_id`, `ordersn`, `status`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status` from trans_tasks where bagsn="+bagsn+" and direction='send' order by id desc limit 1;";
        return getResultMap(trans_tasks_new1_field.class, sql);
    }

    private static Map<Object, String> getMapTransTasks_new2(){
        String sql = "select `bagsn`, `category_id`, `created_at`, `dead_line`, `direction`, `from_type`, `order_id`, `ordersn`, `status`, `to_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status` from trans_tasks where bagsn="+bagsn+" order by id desc limit 1;";
        return getResultMap(trans_tasks_new2_field.class, sql);
    }

    private static Map<Object, String> getResultMap(Class enum_class, String sql){
        ResultSet r = mysqlQaDao.execQuerySql(sql);
        Map<Object, String> map = new HashMap<Object, String>();
        try {
            r.beforeFirst();
            if (r.next()){

                //枚举反射,遍历枚举
                for (Object o : enum_class.getEnumConstants()){
                    map.put(o, r.getString(o.toString()));
                }
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }

        return map;
    }

    public static double getTimeDifference(String dateBefore, String dateAfter){
        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        double d1;
        double d2;
        double c = 0.00;
        try {
            d1 = sd.parse(dateBefore).getTime();
            d2 = sd.parse(dateAfter).getTime();
            System.out.println(d2-d1);

            c = (d2-d1) /10000 / 6;

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return c;

    }



    private static int getLastId(String sql){
        int lastId =0;
        ResultSet r1 = mysqlQaDao.execQuerySql(sql);
        try {
            r1.beforeFirst();
            if (r1.next()){
                lastId = r1.getInt("id");
            }
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lastId;
    }



    @Before
    public void setUp() {
        logger.info("begin!");
    }


    @After
    public void tearDown() {
        logger.info("in teardown!");
    }



    @BeforeClass
    public static void init(){
        logger.info("before Class");
        courie_id = get_courierId();    //小eID,没有则创建

        create_order(); //创建订单
        create_transInfo(); //创建交接单


        logger.info("parameter: order_number="+order_sn+" uid="+courie_id+" order_id="+order_id+" bagsn="+bagsn+" remark="+remark);
        JSONObject resultJson = shareAPIModuleService.CallApiWuliuYiQu(order_id, bagsn, courie_id, remark);
        logger.info("result json:"+resultJson.toJSONString());
        if (!resultJson.getString("httpStatus").equals("201")){
            logger.info("链接异常,程序退出");
            System.exit(0);
        }
//        Assert.assertEquals("http链接异常", "201", resultJson.getString("httpStatus"));
        mapWashingOrder = get_ims_washing_order_tableInfo();
        mapDispatchTasks = getMapDispatchTasks();
        mapTransGroups = getMapTransGroups();
        mapTransTasks = getMapTransTasks();
        mapTransTasks_new1 = getMapTransTasks_new1();
        mapTransTasks_new2 = getMapTransTasks_new2();
    }



    @Test
    public void ims_washing_order_bagsn(){//_ims_washing_order_bagsn
        mapWashingOrder = get_ims_washing_order_tableInfo();
        String errorText = "ims_washing_order表的"+ims_washing_order_field.bagsn+"字段值不正确!";
        String mapText = mapWashingOrder.get(ims_washing_order_field.bagsn.toString());
        logger.info("ims_washing_order表的"+ims_washing_order_field.bagsn+"字段的值为"+mapText);
        Assert.assertEquals(errorText, bagsn, mapText);
    }

    @Test
    public void ims_washing_order_logistics_remark(){
        String errorText = "ims_washing_order表的"+ims_washing_order_field.logistics_remark+"字段值不正确!";
        String mapText = mapWashingOrder.get(ims_washing_order_field.logistics_remark.toString());
        logger.info("ims_washing_order表的"+ims_washing_order_field.logistics_remark+"字段的值为"+mapText);
        Assert.assertEquals(errorText, remark, mapText);
    }

    @Test
    public void ims_washing_order_qujian_time(){
        String errorText = "ims_washing_order表的"+ims_washing_order_field.qujian_time+"字段值不正确!";
//        double e = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double a = Double.valueOf(mapWashingOrder.get(ims_washing_order_field.qujian_time.toString()));
//        logger.info("ims_washing_order表的"+ims_washing_order_field.qujian_time+"字段的值为"+a+
//                " 当前系统时间为:"+e);
//        Assert.assertEquals(errorText, e, a, 60*3);   //判断数据库中的时间与当前系统时间差 不超过1分钟

        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        logger.info(mapWashingOrder.get(ims_washing_order_field.qujian_time));
        String a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.parseLong(mapWashingOrder.get(ims_washing_order_field.qujian_time.toString())) * 1000);
        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void ims_washing_order_wuliu_qu_yiqu_time(){
        String errorText = "ims_washing_order表的"+ims_washing_order_field.wuliu_qu_yiqu_time+"字段值不正确!";
        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.parseLong(mapWashingOrder.get(ims_washing_order_field.wuliu_qu_yiqu_time.toString())) * 1000);
        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void ims_washing_order_update_at(){
        String errorText = "ims_washing_order表的"+ims_washing_order_field.updated_at+"字段值不正确";
//        double e = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double a = 0;
//        try {
//            a = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapWashingOrder.get(ims_washing_order_field.updated_at.toString())).getTime()).substring(0,10));
//        } catch (ParseException e1) {
//            e1.printStackTrace();
//        }
//        logger.info("ims_washing_order表的"+ims_washing_order_field.updated_at+"字段的值为"+a+" 当前系统时间为:"+e);
//        Assert.assertEquals(errorText, e, a, 60*3);   //判断数据库中的时间与当前系统时间差 不超过3分钟
        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapWashingOrder.get(ims_washing_order_field.updated_at.toString()).replace(".0","");
logger.info(e);
        logger.info(a);

        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void ims_washing_order_status_deliver(){
        String errorText = "ims_washing_order表的"+ims_washing_order_field.status_delivery+"字段值不正确!";
        String mapText = mapWashingOrder.get(ims_washing_order_field.status_delivery.toString());
        logger.info("ims_washing_order表的"+ims_washing_order_field.status_delivery+"字段的值为"+mapText);
        Assert.assertEquals(errorText, "1", mapText);
    }







    @Test
    public void dispath_tasks_status(){
        String errorText = "dispath_tasks表的"+dispatch_tasks_field.status+"字段值不正确!";
        String mapText = mapDispatchTasks.get(dispatch_tasks_field.status);
        logger.info("dispath_tasks表的"+dispatch_tasks_field.status+"字段的值为"+mapText);
        Assert.assertEquals(errorText, "finished", mapText);
    }

    @Test
    public void dispath_tasks_finished_at(){
        String errorText = "dispath_tasks表的"+dispatch_tasks_field.finished_at+"字段值不正确!";
//        double e = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double a = 0;
//        try {
//            a = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapDispatchTasks.get(dispatch_tasks_field.finished_at)).getTime()).substring(0,10));
//        } catch (ParseException e1) {
//            e1.printStackTrace();
//        }
//        Assert.assertEquals(errorText, e, a, 60*3);
        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapDispatchTasks.get(dispatch_tasks_field.finished_at).replace(".0","");
        logger.info("e:"+e+" a:"+mapDispatchTasks.get(dispatch_tasks_field.finished_at));
        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void dispath_task_updated_at(){
        String errorText = "dispath_tasks表的"+dispatch_tasks_field.updated_at+"字段值不正确!";
//        double e = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double a = 0;
//        try {
//            a = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapDispatchTasks.get(dispatch_tasks_field.updated_at)).getTime()).substring(0,10));
//        } catch (ParseException e1) {
//            e1.printStackTrace();
//        }
//
//        logger.info("dispath_tasks表的"+dispatch_tasks_field.updated_at+"字段的值为"+a);
//        Assert.assertEquals(errorText, e, a, 60*3);
        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapDispatchTasks.get(dispatch_tasks_field.updated_at).replace(".0","");
        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void trans_groups_bagsn(){
        String errorText = "trans_groups表的"+trans_groups_field.bagsn+"字段值不正确!";
        String mapText = mapTransGroups.get(trans_groups_field.bagsn);
        logger.info("trans_groups表的"+trans_groups_field.bagsn+"字段的值为"+mapText);
        Assert.assertEquals(errorText, bagsn, mapText);
    }

    @Test
    public void trans_groups_updated_at(){
        String errorText = "trans_groups表的"+trans_groups_field.updated_at+"字段值不正确!";
//        double e = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double a = 0;
//        try {
//            a = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapTransGroups.get(trans_groups_field.updated_at)).getTime()).substring(0,10));
//        } catch (ParseException e1) {
//            e1.printStackTrace();
//        }
//        logger.info("trans_groups表的"+trans_groups_field.updated_at+"字段的值为"+a);
//        Assert.assertEquals(errorText, e, a, 60*3);

        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapTransGroups.get(trans_groups_field.updated_at).replace(".0","");

        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void trans_groups_last_task_id(){
        String lastId = String.valueOf(getLastId("select id from trans_tasks where bagsn="+bagsn+" order by id desc limit 1;"));
        String mapText = mapTransGroups.get(trans_groups_field.last_task_id);
        Assert.assertEquals("last_task_id字段异常", lastId, mapText);
    }

    @Test
    public void trans_groups_current_task_id(){
        String lastId = String.valueOf(getLastId("select id from trans_tasks where bagsn="+bagsn+" order by id desc limit 1;"));
        String mapText = mapTransGroups.get(trans_groups_field.current_task_id);
        Assert.assertEquals("current_task_id字段异常", lastId, mapText);
    }



    @Test
    public void trans_tasks_bagsn(){
        String errorText = "trans_tasks表的"+trans_tasks_field.bagsn+"字段值不正确!";
        String mapText = mapTransTasks.get(trans_tasks_field.bagsn);
        Assert.assertEquals(errorText, bagsn, mapText);
    }

    @Test
    public void trans_tasks_status(){
        String errorText = "trans_tasks表的"+trans_tasks_field.status+"字段值不正确!";
        String mapText = mapTransTasks.get(trans_tasks_field.status);
        Assert.assertEquals(errorText, "finished", mapText);
    }

    @Test
    public void trans_tasks_next_task_id(){
        String nextId = String.valueOf(getLastId("select id from trans_tasks where bagsn="+bagsn+" and direction='send' order by id desc limit 1;"));
        String errorText = "trans_tasks表的"+trans_tasks_field.next_task_id+"字段值不正确!";
        String mapText = mapTransTasks.get(trans_tasks_field.next_task_id);
        Assert.assertEquals(errorText, nextId, mapText);
    }

    @Test
    public void trans_tasks_finished_at(){
        String errorText = "trans_tasks表的"+trans_tasks_field.finished_at+"字段值不正确!";
//        double now = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0, 10));
//        double finished_at = 0;
//        try {
//            finished_at = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapTransTasks.get(trans_tasks_field.finished_at)).getTime()).substring(0,10));
//        } catch (ParseException e1) {
//            e1.printStackTrace();
//        }
//        Assert.assertEquals(errorText, now, finished_at, 60000*3);

        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapTransTasks.get(trans_tasks_field.finished_at).replace(".0","");
        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }

    @Test
    public void trans_tasks_updated_at(){
        String errorText = "trans_tasks表的"+trans_tasks_field.updated_at+"字段值不正确!";
        String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
        String a = mapTransTasks.get(trans_tasks_field.updated_at).replace(".0","");

        Assert.assertTrue(errorText, CommonTools.judgeTimeDifference(e, a, 60 * 3));
    }





    private String getNew1_ReallyResult(Object e){
        trans_tasks_new1_field t = (trans_tasks_new1_field)e;
        String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
        switch (t){
            case bagsn:
                return this.bagsn;
            case category_id:
                return "1";
            case created_at:
                return time;
            case direction:
                return "send";
            case from_id:
                return this.courie_id;
            case from_type:
                return "zhongbao";
            case order_id:
                return this.order_id;
            case ordersn:
                return this.order_sn;
            case status:
                return "started";
            case to_type:
                return "outlet";
            case trans_group_id:
                return this.group_id;
            case trans_ttl:
                return "1";
            case updated_at:
                return time;
            case washing_status:
                return "unwashed";
            default:
                return "";
        }
    }


    private String getNew2_ReallyResult(Object e){
        trans_tasks_new2_field t = (trans_tasks_new2_field)e;
        String time = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(System.currentTimeMillis());
        switch (t){
            case bagsn:
                return this.bagsn;
            case category_id:
                return "1";
            case created_at:
                return time;
            case direction:
                return "get";
            case to_id:
                return this.courie_id;
            case from_type:
                return "outlet";
            case order_id:
                return this.order_id;
            case ordersn:
                return this.order_sn;
            case status:
                return "started";
            case to_type:
                return "zhongbao";
            case trans_group_id:
                return this.group_id;
            case trans_ttl:
                return "1";
            case updated_at:
                return time;
            case washing_status:
                return "unwashed";
            default:
                return "";
        }
    }


    @Test
    public void trans_tasks_new1(){
        for (Object o : trans_tasks_new1_field.class.getEnumConstants()){
            String mapText = mapTransTasks_new1.get(o);
            String reallyText = getNew1_ReallyResult(o);

            if (o == trans_tasks_new1_field.created_at || o == trans_tasks_new1_field.updated_at){
//                double d1 = 0.0;
//                double d2 = 0.0;
//
//                try {
//                    d1 = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapText).getTime()).substring(0,10));
//                    d2 = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0,10));
//                } catch (ParseException e1) {
//                    e1.printStackTrace();
//                }
//                Assert.assertEquals(o+"返回结果异常", d2, d1, 60*3);
                String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
                String a = mapText.replace(".0","");

                Assert.assertTrue(o + "返回结果异常", CommonTools.judgeTimeDifference(e, a, 60 * 3));

            }else {
                Assert.assertEquals(o+"返回结果异常", reallyText, mapText);
            }

        }
    }

    @Test
    public void trans_tasks_new2(){
        for (Object o : trans_tasks_new2_field.class.getEnumConstants()){
            String mapText = mapTransTasks_new2.get(o);
            String reallyText = getNew2_ReallyResult(o);

            if (o == trans_tasks_new2_field.created_at || o == trans_tasks_new2_field.updated_at){
//                double d1 = 0.0;
//                double d2 = 0.0;
//                try {
//                    d1 = Double.parseDouble(String.valueOf(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(mapText).getTime()).substring(0,10));
//                    d2 = Double.parseDouble(String.valueOf(System.currentTimeMillis()).substring(0,10));
//                } catch (ParseException e1) {
//                    e1.printStackTrace();
//                }
//                Assert.assertEquals(o+"返回结果异常", d2, d1, 60*3);
                String e = CommonTools.getToday("yyyy-MM-dd HH:mm:ss");
                String a =mapText.replace(".0","");

                Assert.assertTrue(o + "返回结果异常", CommonTools.judgeTimeDifference(e, a, 60 * 3));
            }else{
                Assert.assertEquals(o+"返回结果异常", reallyText, mapText);
            }

        }
    }














//    UPDATE `ims_washing_order` SET `bagsn` = '00034649107', `logistics_remark` = '', `qujian_time` = 1457511219, `wuliu_qu_yiqu_time` = 1457511219, `status_delivery` = 1, `updated_at` = '2016-03-09 16:13:39' WHERE `ims_washing_order`.`id` = 984882359

//    UPDATE `trans_groups` SET `bagsn` = '00034649107', `updated_at` = '2016-03-09 16:13:39' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` = 97363

//    UPDATE `trans_tasks` SET `bagsn` = '00034649107', `status` = 'finished', `finished_at` = '2016-03-09 16:13:39', `updated_at` = '2016-03-09 16:13:39' WHERE `trans_tasks`.`id` = 977648

//    UPDATE `dispatch_tasks` SET `status` = 'finished', `finished_at` = '2016-03-09 16:13:39', `updated_at` = '2016-03-09 16:13:39' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` = 99211

//    INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `created_at`, `dead_line`, `direction`, `from_id`, `from_type`, `order_id`, `ordersn`, `status`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) VALUES ('00034649107', 1, '2016-03-09 16:13:39', '2016-03-10 10:00:00', 'send', 10003, 'zhongbao', 984882359, '16030948823598', 'started', 'outlet', 97363, 1, '2016-03-09 16:13:39', 'unwashed')

//    INSERT INTO `trans_tasks` (`bagsn`, `category_id`, `created_at`, `dead_line`, `direction`, `from_type`, `order_id`, `ordersn`, `status`, `to_id`, `to_type`, `trans_group_id`, `trans_ttl`, `updated_at`, `washing_status`) VALUES ('00034649107', 1, '2016-03-09 16:13:39', '2016-03-10 10:00:00', 'get', 'outlet', 984882359, '16030948823598', 'started', 10003, 'zhongbao', 97363, 1, '2016-03-09 16:13:39', 'unwashed')

//    UPDATE `trans_tasks` SET `next_task_id` = 977650, `updated_at` = '2016-03-09 16:13:39' WHERE `trans_tasks`.`id` = 977649

//    UPDATE `trans_groups` SET `current_task_id` = 977650, `last_task_id` = 977650, `updated_at` = '2016-03-09 16:13:39' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` = 97363

//    UPDATE `dispatch_tasks` SET `status` = 'finished', `finished_at` = '2016-03-09 16:13:39', `updated_at` = '2016-03-09 16:13:39' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` = 99211
}
