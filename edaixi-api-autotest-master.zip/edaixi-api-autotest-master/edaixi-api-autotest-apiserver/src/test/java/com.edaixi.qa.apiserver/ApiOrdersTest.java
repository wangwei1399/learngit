package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiOrdersTest {

	private static Logger logger = LoggerFactory
			.getLogger(ApiOrdersTest.class);
	private ApiModuleService shareAPIModuleService = new ApiModuleService();
	private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();
	Date dt = new Date();
	SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
	}


	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *第三方订单接口
	 * http://localhost:3006/api/v1/orders
	 *
	 * @author ningyao.zn
	 */
	public void testApiOrders() throws SQLException, ParseException {
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
		String city = "北京";
		String area = "海淀";
		String address = "测试地址";
		String tel = "18500133948";
		String customer_lng = "11";
		String customer_lat = "22";
		String user_type = "1";//1微信2IOS3安卓4会员卡5实体会员卡6支付宝服务窗7客服8收衣店9淘宝
		int user_id = 623565;
		int totalnum = 1;
		int good = 2560;
        Calendar calendar = new GregorianCalendar();
        logger.info(String.valueOf(dt));
        calendar.setTime(dt);
        calendar.add(calendar.DATE,1);
        Date nextDate = calendar.getTime();

		String washing_date = formatDate.format(nextDate);
        String washing_time = "20:00-22:00";
        int pay_type = 0;
		String remark = "api auto test";

		this.queryParams.put("city",city);
		this.queryParams.put("area",area);
		this.queryParams.put("address",address);
		this.queryParams.put("tel",tel);
		this.queryParams.put("customer_lng",customer_lng);
		this.queryParams.put("customer_lat",customer_lat);
		this.queryParams.put("user_type",user_type);
		this.queryParams.put("user_id",user_id);
		this.queryParams.put("totalnum",totalnum);
		this.queryParams.put("good",good);
		this.queryParams.put("washing_date",washing_date);
		this.queryParams.put("washing_time",washing_time);
		this.queryParams.put("pay_type",pay_type);
		this.queryParams.put("remark",remark);

		JSONObject result = this.shareAPIModuleService.CallApiOrders("", "", this.queryParams);
		// 验证接口返回的数据
		logger.info(result.toJSONString());
		Assert.assertTrue(result.getString("httpStatus").equals("201"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String queryNewOrder = "select id,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,status,status_delivery,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song," +
                "address_song,courier_qu,courier_song,createtime,qujian_paidan_time,created_at,updated_at,diaodu_queren_time,fan_id,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,address_qu_id,address_song_id,last_six_ordersn,category_id from ims_washing_order where id = "+ body.getString("data") + ";";

        ResultSet newOrderInfo = mysqlQaDao.execQuerySql(queryNewOrder);
        Assert.assertEquals("返回值不符合预期",user_type,newOrderInfo.getString("user_type"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("ordersn").length() > 0);
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("bagsn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("totalprice"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("delivery_fee"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("coupon_sn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("coupon_paid"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("money_paid"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",11,newOrderInfo.getInt("status_delivery"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("pay_status"));
        Assert.assertEquals("返回值不符合预期",pay_type,newOrderInfo.getInt("paytype"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("remark").contains(remark));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("washing_date").contains(String.valueOf(formatDate.format(nextDate))));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_date").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_time").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("tel").contains(tel));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city").contains(city));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area").contains(area));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address").contains(address));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city_song").contains(city));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area_song").contains(area));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address_song").contains(address));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("courier_qu"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("courier_song"));
        Assert.assertEquals("返回值不符合预期",623565, newOrderInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期",18, newOrderInfo.getInt("good_id"));
        String addressQuery = "SELECT id FROM `ims_washing_address` WHERE `ims_washing_address`.`type` IN ('Address') AND `ims_washing_address`.`fan_id` = 623565 AND `ims_washing_address`.`address` = '" + address + "' AND `ims_washing_address`.`city` = '北京' ORDER BY `ims_washing_address`.`id` ASC LIMIT 1";
        ResultSet addressInfo = mysqlQaDao.execQuerySql(addressQuery);
        Assert.assertEquals("返回值不符合预期",addressInfo.getInt("id"), newOrderInfo.getInt("address_qu_id"));
        Assert.assertEquals("返回值不符合预期",addressInfo.getInt("id"), newOrderInfo.getInt("address_song_id"));
		String queryCategoryId = "select service_category_id from service_goods where id = "+ good + "";
		ResultSet categoryInfo = mysqlQaDao.execQuerySql(queryCategoryId);
        Assert.assertEquals("返回值不符合预期",categoryInfo.getInt("service_category_id"), newOrderInfo.getInt("category_id"));
        Assert.assertEquals("返回值不符合预期",newOrderInfo.getString("ordersn").substring(newOrderInfo.getString("ordersn").length()-6,newOrderInfo.getString("ordersn").length()), newOrderInfo.getString("last_six_ordersn"));

        String queryDispatch = "select category_id,created_at,dispatch_type,order_id,type,from_type,to_type,city_id,updated_at,status,hope_time from dispatch_tasks where order_id = " + body.getString("data") + "";
        ResultSet retDispatchInfo = mysqlQaDao.execQuerySql(queryDispatch);
        Assert.assertEquals("返回值不符合预期",categoryInfo.getInt("service_category_id"), retDispatchInfo.getInt("category_id"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("created_at").contains(formatDate.format(dt)));
        Assert.assertEquals("返回值不符合预期",0, retDispatchInfo.getInt("dispatch_type"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("type").contains("DispatchTask"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("from_type").contains("jiagongdian"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("to_type").contains("Address"));
        Assert.assertEquals("返回值不符合预期",1, retDispatchInfo.getInt("city_id"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("hope_time").contains(formatDate.format(nextDate)));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("status").contains("started"));

        String queryFans = "select last_order_time,updated_at from ims_fans where id = '623565'";
        ResultSet retFansInfo = mysqlQaDao.execQuerySql(queryFans);
        Assert.assertEquals("返回值不符合预期", String.valueOf(formatTime.parse(newOrderInfo.getString("created_at")).getTime()/1000), retFansInfo.getString("last_order_time"));
        Assert.assertEquals("返回值不符合预期", newOrderInfo.getString("created_at"), retFansInfo.getString("updated_at"));

    }

    @Test
    /**非第三方订单接口
     * 与第三方接口区别在于"order_place"
     * @throws SQLException
     * @throws ParseException
     */
    public void testAPIOrder2() throws SQLException, ParseException {

        long currentTime = System.currentTimeMillis();
        String city = "北京";
        String area = "海淀";
        String address = "测试地址";
        String tel = "18500133948";
        String customer_lng = "11";
        String customer_lat = "22";
        String user_type = "1";//1微信2IOS3安卓4会员卡5实体会员卡6支付宝服务窗7客服8收衣店9淘宝
        int user_id = 623565;
        int totalnum = 1;
        int good = 2560;
        int order_place = 934;
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(dt);
        calendar.add(calendar.DATE,1);
        Date nextDate = calendar.getTime();

        String washing_date = formatDate.format(nextDate);
        String washing_time = "20:00-22:00";
        int pay_type = 0;
        String remark = "api auto test";

//        this.queryParams.put("city",city);
//        this.queryParams.put("area",area);
//        this.queryParams.put("address",address);
//        this.queryParams.put("tel",tel);
//        this.queryParams.put("customer_lng",customer_lng);
//        this.queryParams.put("customer_lat",customer_lat);

        this.queryParams.put("user_type",user_type);
        this.queryParams.put("user_id",user_id);
        this.queryParams.put("totalnum",totalnum);
        this.queryParams.put("good",good);
        this.queryParams.put("washing_date",washing_date);
        this.queryParams.put("washing_time",washing_time);
        this.queryParams.put("pay_type",pay_type);
        this.queryParams.put("remark",remark);
        this.queryParams.put("order_place",order_place);

        JSONObject result = this.shareAPIModuleService.CallApiOrders("", "", this.queryParams);
        // 验证接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("201"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        String queryNewOrder = "select id,user_type,ordersn,bagsn,totalnum,totalprice,delivery_fee,coupon_sn,coupon_paid,money_paid,status,status_delivery,pay_status,paytype,remark,washing_date,washing_time,send_date,send_time,username,tel,city,area,address,city_song,area_song," +
                "address_song,courier_qu,courier_song,createtime,qujian_paidan_time,created_at,updated_at,diaodu_queren_time,fan_id,good_id,qu_week_nr,qu_from_time_mod,qu_to_time_mod,address_qu_id,address_song_id,last_six_ordersn,category_id from ims_washing_order where id = "+ body.getString("data") + ";";


        String addrSQL = "select  fan_id, city, area, address, tel, customer_lng, customer_lat from ims_washing_address where id="+order_place;
        ResultSet newOrderInfo = mysqlQaDao.execQuerySql(queryNewOrder);

        ResultSet ims_washing_address = mysqlQaDao.execQuerySql(addrSQL);
//        String fan_id = ims_washing_address.getString("fan_id");
        String fan_id = newOrderInfo.getString("fan_id");
        area = ims_washing_address.getString("area");
        address = ims_washing_address.getString("address");
        tel = ims_washing_address.getString("tel");
        customer_lng = ims_washing_address.getString("customer_lng");
        customer_lat = ims_washing_address.getString("customer_lat");


        Assert.assertEquals("返回值不符合预期",user_type,newOrderInfo.getString("user_type"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("ordersn").length() > 0);
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("bagsn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("totalprice"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("delivery_fee"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("coupon_sn").isEmpty());
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("coupon_paid"));
        Assert.assertEquals("返回值不符合预期", "0.00", newOrderInfo.getString("money_paid"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("status"));
        Assert.assertEquals("返回值不符合预期",11,newOrderInfo.getInt("status_delivery"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("pay_status"));
        Assert.assertEquals("返回值不符合预期",pay_type,newOrderInfo.getInt("paytype"));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("remark").contains(remark));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("washing_date").contains(String.valueOf(formatDate.format(nextDate))));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_date").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("send_time").isEmpty());
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("tel").contains(tel));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city").contains(city));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area").contains(area));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address").contains(address));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("city_song").contains(city));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("area_song").contains(area));
        Assert.assertTrue("返回值不符合预期",newOrderInfo.getString("address_song").contains(address));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("courier_qu"));
        Assert.assertEquals("返回值不符合预期",0,newOrderInfo.getInt("courier_song"));
        Assert.assertEquals("返回值不符合预期",623565, newOrderInfo.getInt("fan_id"));
        Assert.assertEquals("返回值不符合预期",18, newOrderInfo.getInt("good_id"));

        Assert.assertEquals("返回值不符合预期",order_place, newOrderInfo.getInt("address_qu_id"));
        Assert.assertEquals("返回值不符合预期",order_place, newOrderInfo.getInt("address_song_id"));
        String queryCategoryId = "select service_category_id from service_goods where id = "+ good + "";
        ResultSet categoryInfo = mysqlQaDao.execQuerySql(queryCategoryId);
        Assert.assertEquals("返回值不符合预期",categoryInfo.getInt("service_category_id"), newOrderInfo.getInt("category_id"));
        Assert.assertEquals("返回值不符合预期",newOrderInfo.getString("ordersn").substring(newOrderInfo.getString("ordersn").length()-6,newOrderInfo.getString("ordersn").length()), newOrderInfo.getString("last_six_ordersn"));

        String queryDispatch = "select category_id,created_at,dispatch_type,order_id,type,from_type,to_type,city_id,updated_at,status,hope_time from dispatch_tasks where order_id = " + body.getString("data") + "";
        ResultSet retDispatchInfo = mysqlQaDao.execQuerySql(queryDispatch);
        Assert.assertEquals("返回值不符合预期",categoryInfo.getInt("service_category_id"), retDispatchInfo.getInt("category_id"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("created_at").contains(formatDate.format(dt)));
        Assert.assertEquals("返回值不符合预期",0, retDispatchInfo.getInt("dispatch_type"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("type").contains("DispatchTask"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("from_type").contains("jiagongdian"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("to_type").contains("Address"));
        Assert.assertEquals("返回值不符合预期",1, retDispatchInfo.getInt("city_id"));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("hope_time").contains(formatDate.format(nextDate)));
        Assert.assertTrue("返回值不符合预期",retDispatchInfo.getString("status").contains("started"));

        String queryFans = "select last_order_time,updated_at from ims_fans where id = '"+fan_id+"'";
        ResultSet retFansInfo = mysqlQaDao.execQuerySql(queryFans);
        Assert.assertEquals("返回值不符合预期", String.valueOf(formatTime.parse(newOrderInfo.getString("created_at")).getTime()/1000), retFansInfo.getString("last_order_time"));
        Assert.assertEquals("返回值不符合预期", newOrderInfo.getString("created_at"), retFansInfo.getString("updated_at"));
    }
}
