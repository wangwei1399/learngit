package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ApiDiaodoPaidanTest {

	private static Logger logger = LoggerFactory
			.getLogger(ApiDiaodoPaidanTest.class);
	private ApiModuleService shareAPIModuleService = new ApiModuleService();
    private GeneralRongChain04Data generalDate = new GeneralRongChain04Data();
	private Map<String, Object> queryParams = null;
    private Map<String, Object> generalOrderParams = null;
    private Map<String, Object> generalCouriersParams = null;
    private Map<String, Object> generalDispatchTaskParams = null;


    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();
	Date dt = new Date();
    long time = dt.getTime();

    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
        this.generalOrderParams = new HashMap<String, Object>();
        this.generalCouriersParams = new HashMap<String, Object>();
        this.generalDispatchTaskParams = new HashMap<String, Object>();
    }


	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * http://localhost:3006/api/v1/orders
	 *
	 * @author ningyao.zn
	 */
	public void testApiDiaoduPaidan() throws SQLException{
		// 准备好接口需要的参数
		long currentTime = System.currentTimeMillis();
		int order_id = CommonTools.getLastId("select * from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1;
		String tel = "1500000" + String.valueOf(currentTime % 10000);
		String push_token = String.valueOf(currentTime % 10000) + "be1-b250-40a9-99a1-eeb2896041c4";
		String order_sn = CommonTools.getOrdersn(order_id);

        Calendar calendar = new GregorianCalendar();
        calendar.setTime(dt);
        calendar.add(calendar.DATE,1);
        String nextDate = CommonTools.getAfterDate("yyyy-MM-dd HH:mm:ss", 0);

		int uid = 0;
		int old_category_id = 1;
		int status = -1;
		int status_delivery = 11;
		int pay_status = 0;
//		int courier_id = CommonTools.getLastId("select id from ims_washing_courier order by id desc limit 1", mysqlQaDao)+1;
		int courier_id = CommonTools.get_courierId(mysqlQaDao);
        int dispatch_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao)+1;

		String washing_date = CommonTools.getToday("yyyy-MM-dd");
		String washing_time = "10:00-12:00";

        generalOrderParams.put("order_id",order_id);
        generalOrderParams.put("order_sn",order_sn);
        generalOrderParams.put("nextDate",washing_date);
        generalOrderParams.put("uid",uid);
        generalOrderParams.put("old_category_id",old_category_id);
        generalOrderParams.put("status",status);
        generalOrderParams.put("status_delivery",status_delivery);
        generalOrderParams.put("pay_status",pay_status);
        generalOrderParams.put("washing_time",washing_time);
        generalDate.GeneralOrder(generalOrderParams);

//        generalCouriersParams.put("courier_id",courier_id);
//        generalCouriersParams.put("tel",tel);
//        generalCouriersParams.put("push_token",push_token);
//        generalDate.GeneralCouriers(generalCouriersParams);

        generalDispatchTaskParams.put("id",dispatch_id);
        generalDispatchTaskParams.put("order_id",order_id);
        generalDispatchTaskParams.put("nextDate",nextDate);
        generalDate.GeneralDispatchTask(generalDispatchTaskParams);

        this.queryParams.put("courier_id",courier_id);

		JSONObject result = this.shareAPIModuleService.CallDiaoDuPaiDan("", "", String.valueOf(order_id),this.queryParams);
		// 验证接口返回的数据
		logger.info(result.toJSONString());
		Assert.assertTrue(result.getString("httpStatus").equals("201"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));

		//验证ims_washing_order 表中订单的状态和物流人员更新成功

		String queryOrderInfo = "select courier_qu,status,pay_status,qujian_paidan_time,status_delivery,updated_at from ims_washing_order where id = " + order_id + "";
		ResultSet retOrderInfo = mysqlQaDao.execQuerySql(queryOrderInfo);
		Assert.assertEquals("status返回值不符合预期",1,retOrderInfo.getInt("status"));
		Assert.assertEquals("status_delivery返回值不符合预期",9,retOrderInfo.getInt("status_delivery"));
		Assert.assertEquals("pay_status返回值不符合预期",0,retOrderInfo.getInt("pay_status"));
		Assert.assertEquals("courier_qu返回值不符合预期",courier_id,retOrderInfo.getInt("courier_qu"));

		// 验证生成的交接单的数据是否正确
		String queryTransOrder = "select id,from_id,updated_at,from_type,to_type,to_address_id,dead_line,direction,status,category_id,ordersn,washing_status,order_id,trans_group_id,trans_ttl,trans_type from " +
				"trans_tasks where order_id = " + order_id + "";
		ResultSet queryTranInfo = mysqlQaDao.execQuerySql(queryTransOrder);
		Assert.assertEquals("from_id返回值不符合预期",courier_id,queryTranInfo.getInt("from_id"));
		Assert.assertTrue("from_type返回值不符合预期",queryTranInfo.getString("from_type").contains("zhongbao"));
		Assert.assertTrue("to_type返回值不符合预期",queryTranInfo.getString("to_type").contains("customer"));
		Assert.assertEquals("to_address_id返回值不符合预期", 595975,queryTranInfo.getInt("to_address_id"));
///        Assert.assertTrue("dead_line返回值不符合预期", queryTranInfo.getString("dead_line").contains(formatTime.format(nextDate)));
        Assert.assertEquals("direction返回值不符合预期", "get", queryTranInfo.getString("direction"));
		Assert.assertTrue("status返回值不符合预期",queryTranInfo.getString("status").contains("started"));
		Assert.assertEquals("category_id返回值不符合预期", 1,queryTranInfo.getInt("category_id"));
		Assert.assertTrue("washing_status返回值不符合预期",queryTranInfo.getString("washing_status").contains("unwashed"));
		Assert.assertEquals("trans_ttl返回值不符合预期", 0,queryTranInfo.getInt("trans_ttl"));
		Assert.assertEquals("trans_type返回值不符合预期", 0,queryTranInfo.getInt("trans_type"));
        Assert.assertTrue("updated_at返回值不符合预期",CommonTools.judgeTimeDifference(retOrderInfo.getString("updated_at"), queryTranInfo.getString("updated_at"), 6));
		// 验证生成的group数据是否正确
		String queryGroup = "select id,order_id,ordersn,current_task_id,last_task_id,order_type,order_status,status_delivery,type,updated_at from trans_groups where order_id = " + order_id + "";
		ResultSet queryGroupInfo = mysqlQaDao.execQuerySql(queryGroup);
		Assert.assertEquals("current_task_id返回值不符合预期",queryTranInfo.getString("id"),queryGroupInfo.getString("current_task_id"));
		Assert.assertEquals("last_task_id返回值不符合预期",queryTranInfo.getString("id"),queryGroupInfo.getString("last_task_id"));
		Assert.assertEquals("order_status返回值不符合预期",1,queryGroupInfo.getInt("order_status"));
		Assert.assertTrue("TransGroup返回值不符合预期",queryGroupInfo.getString("type").contains("TransGroup"));
		Assert.assertEquals("trans_group_id返回值不符合预期",queryGroupInfo.getString("id"),queryTranInfo.getString("trans_group_id"));
        Assert.assertTrue("updated_at返回值不符合预期",CommonTools.judgeTimeDifference(queryGroupInfo.getString("updated_at"),queryTranInfo.getString("updated_at"),6));

    }
}
