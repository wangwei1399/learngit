package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ApiCustomersSingleTest {

	private static Logger logger = LoggerFactory
			.getLogger(ApiCustomersSingleTest.class);
	private ApiModuleService shareAPIModuleService = new ApiModuleService();
	private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
	}


	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * http://api09.edaixi.cn:3329/api/v1/customers/single?mobile=15313019855
	 *
	 * @author ningyao.zn
	 */
	public void testApiCustomersSingle() throws SQLException{
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
		int area_id = (int)(currentTime % 100);
        int user_id = 1;
		int city_id = 1;
		String area_name = "测试区";
		String mobile = "18500133948";

		this.queryParams.put("mobile",mobile);


		JSONObject result = this.shareAPIModuleService.CallApiCustomersSingle("", "", this.queryParams);
		// 验证接口返回的数据
		logger.info(result.toJSONString());
		Assert.assertTrue(result.getString("httpStatus").equals("200"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));
	}
}
