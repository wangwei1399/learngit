package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DiaoDuSongPaidanTest {

	private static Logger logger = LoggerFactory
			.getLogger(DiaoDuSongPaidanTest.class);
	private ApiModuleService shareAPIModuleService = new ApiModuleService();
	private Map<String, Object> queryParams = null;

    private Map<String, Object> httpHead = null;
	MysqlQaDao mysqlQaDao = new MysqlQaDao();

    @Before
	public void setUp() {
        this.httpHead = new HashMap<String, Object>();
		this.queryParams = new HashMap<String, Object>();
	}


	@After
	public void tearDown() {
		logger.info("in teardown!");
	}


	@Test
	/**
	 *
	 * http://localhost:3006/api/v1/logisticss/id/40/diaodu_song_paidan
	 *
	 * @author ningyao.zn
	 */
	public void testApiDiaoDuSongPaidan() throws SQLException{
		// 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
		int order_id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1;
		int trans_task_id = (int)(currentTime % 100000);
		String order_sn = CommonTools.getOrdersn(order_id);
		int uid = CommonTools.get_courierId(mysqlQaDao);
		int old_category_id = 1;
		int new_category_id = 3;
		int status = 1;
		int status_delivery = 6;
		int pay_status = 1;
		//造订单的数据
		String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
				"VALUES\n" +
				"\t(" + order_id + ", NULL, 7, '" + order_sn + "', '', 1, 0.00, 0.00, '', 0.00, 0.00, 0.00, " + status + ", " + status_delivery + ", '', NULL, " + pay_status + ", 3, '接口测试', '2016-01-16', '18:00-20:00', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', "+ uid + ", 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";


		mysqlQaDao.execUpdateSql(orderInfo);
		this.queryParams.put("courier_id",uid);


		JSONObject result = this.shareAPIModuleService.CallDiaoDuSongPaiDan("", "", order_id, this.queryParams);
		// 验证接口返回的数据
		logger.info(result.toJSONString());
		Assert.assertTrue(result.getString("httpStatus").equals("201"));
		JSONObject body = JSON.parseObject(result.getString("httpBody"));

		ResultSet resultSet = mysqlQaDao.execQuerySql("select status_delivery, courier_song from ims_washing_order where id ="+order_id);
		int result_status_delivery = resultSet.getInt("status_delivery");
		int result_courierId = resultSet.getInt("courier_song");
		resultSet.close();
		resultSet = null;
		mysqlQaDao = null;


		org.junit.Assert.assertTrue("失败", body.getBooleanValue("data"));
		org.junit.Assert.assertEquals("订单状态不正确", 15, result_status_delivery);
		org.junit.Assert.assertEquals("送件小eID不正确", uid, result_courierId);
	}
}
