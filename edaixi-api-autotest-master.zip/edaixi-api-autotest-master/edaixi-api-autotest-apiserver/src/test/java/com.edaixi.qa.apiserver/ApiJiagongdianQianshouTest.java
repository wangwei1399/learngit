package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import junit.framework.Assert;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * ApiJiagongdianQianshouTest
 *
 * @author wangting
 * @date 2016/2/4
 */
public class ApiJiagongdianQianshouTest {
    private static Logger logger = LoggerFactory
            .getLogger(ApiJiagongdianQianshouTest.class);
    private ApiModuleService shareAPIModuleService = new ApiModuleService();
    private Map<String, Object> queryParams = null;
    private Map<String, Object> httpHead = null;
    MysqlQaDao mysqlQaDao = new MysqlQaDao();
    Date dt = new Date();
    SimpleDateFormat formatDate=new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Before
    public void setUp() {
        this.httpHead = new HashMap<String, Object>();
        this.queryParams = new HashMap<String, Object>();
    }
    @After
    public void tearDown() {
        logger.info("in teardown!");
    }
    @Test
    /**
     *
     * http://localhost:3006/api/v1/orders
     *
     * @author wangting
     */
    public void testApiOrders() throws SQLException {
        // 准备好接口需要的参数
        long currentTime = System.currentTimeMillis();
//        String order_id = String.valueOf(currentTime % 1000000000);
        int order_id = CommonTools.getOrderIdNew(mysqlQaDao);
//        int trans_task_id1 = (int)((Math.random()*9+1)*100000);
        int trans_task_id1 = CommonTools.getNewIdByTableName("trans_tasks", mysqlQaDao);
        int trans_task_id2= trans_task_id1 +1;
        int trans_task_id3= trans_task_id2 +1;
//        int trans_group_id = (int)((Math.random()*9+1)*10000);
        int trans_group_id = CommonTools.getNewIdByTableName("trans_groups", mysqlQaDao);
//        int dispatch_id = (int)(currentTime % 100000);
        int dispatch_id = CommonTools.getNewIdByTableName("dispatch_tasks", mysqlQaDao);

        String tel = "1500000" + String.valueOf(currentTime % 10000);
        String push_token = String.valueOf(currentTime % 10000) + "be1-b250-40a9-99a1-eeb2896041c4";
        String order_sn = String.valueOf(currentTime);
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(dt);
        calendar.add(calendar.DATE,1);
        Date nextDate = calendar.getTime();

        int old_category_id = 1;
        int status = 1;

        //造订单的数据
        String orderInfo = "INSERT INTO `ims_washing_order` (`id`, `from_user`, `user_type`, `ordersn`, `bagsn`, `totalnum`, `totalprice`, `delivery_fee`, `coupon_sn`, `coupon_paid`, `money_paid`, `receivables_paid`, `status`, `status_delivery`, `back_reason`, `logistics_remark`, `pay_status`, `paytype`, `remark`, `washing_date`, `washing_time`, `send_date`, `send_time`, `username`, `tel`, `city`, `area`, `address`, `city_song`, `area_song`, `address_song`, `courier_qu`, `courier_song`, `shoukuan_kuaidi`, `shoukuan_kuaidi_time`, `shoukuan_store`, `shoukuan_store_time`, `shoukuan_caiwu`, `shoukuan_caiwu_time`, `createtime`, `qujian_paidan_time`, `qujian_time`, `songhui_paidan_time`, `songhui_time`, `is_xianxia`, `kehu_song_shouyidian_time`, `shouyidian_qu_id`, `dingdan_quxiao_time`, `jiagongdian_qianshou_time`, `jiagongdian_id`, `wuliu_song_qianshou_time`, `shouyidian_song_qianshou_time`, `shouyidian_song_id`, `kehu_qianshou_time`, `wuliu_qu_tuihui_time`, `wuliu_song_tuihui_time`, `wuliu_qu_yiqu_time`, `jiagongdian_fenjian_time`, `jiagongdian_shangjia_time`, `back_reason_qu`, `back_reason_song`, `created_at`, `updated_at`, `caiwu_status`, `diaodu_queren_time`, `actual_price`, `xianjin_shoukuan`, `diaodu_song_paidan_time`, `is_fanxi`, `yuandingdan_id`, `fanxidan_id`, `fan_id`, `order_commented_at`, `good_id`, `qu_week_nr`, `qu_from_time_mod`, `qu_to_time_mod`, `song_week_nr`, `song_from_time_mod`, `song_to_time_mod`, `qianshoudian_id`, `address_qu_id`, `address_song_id`, `auto_dispatched_qu_at`, `auto_dispatched_song_at`, `last_six_ordersn`, `category_id`, `cannot_wash`, `cannot_wash_reason`, `client_id`, `discount`, `original_order_id`, `fanxi_count`)\n" +
                "VALUES\n" +
                "\t(" + order_id + ", NULL, 1, '" + order_sn + "', '', 1, 29.00, 20.00, '', 0.00, 29.00, 29.00, 1, 1, '', NULL, 1, 1, '接口测试', '2016-01-16', '18:00-20:00', '', '', '杨', '12345678906', '北京', '朝阳区', '清华东路', '北京', '朝阳区', '清华东路', 3, 0, 0, NULL, 0, NULL, 0, NULL, 1452219419, 1452219432, 0, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2016-01-08 10:16:59', '2016-01-08 10:17:12', 0, 1452219419, 0, 0, NULL, 0, 0, 0, 30, NULL, 18, 2402, 138, 139, NULL, NULL, NULL, 0, 595975, 595975, NULL, NULL, '402857', " + old_category_id + "  , 0, NULL, NULL, 0.00, NULL, NULL);\n";

        //造交接单的数据
        String transOrderInfo1 = "INSERT INTO `trans_tasks` (`id`, `bagsn`, `from_id`, `from_type`, `from_address_id`, `to_id`, `to_type`, `to_address_id`, `next_task_id`, `transfer_task_id`, `transferred_by`, `dead_line`, `prority`, `status`, `direction`, `finished_at`, `created_at`, `updated_at`, `category_id`, `ordersn`, `washing_status`, `order_id`, `trans_group_id`, `trans_ttl`, `trans_type`)\n" +
                "VALUES\n" +
                "\t("+ trans_task_id1 + ", NULL, 15, 'zhongbao', NULL, NULL, 'customer', 595975, "+trans_task_id2+", NULL, NULL, '2016-01-16 20:00:00', NULL, 'finished', 'get', NULL, '2016-01-08 10:17:12', '2016-01-08 10:17:12', " + old_category_id + ", '" + order_sn + "', 'unwashed', '" + order_id + "', " + trans_group_id + ", 0, 0);\n";
        //造交接单的数据
        String transOrderInfo2 = "INSERT INTO `trans_tasks` (`id`, `bagsn`, `from_id`, `from_type`, `from_address_id`, `to_id`, `to_type`, `to_address_id`, `next_task_id`, `transfer_task_id`, `transferred_by`, `dead_line`, `prority`, `status`, `direction`, `finished_at`, `created_at`, `updated_at`, `category_id`, `ordersn`, `washing_status`, `order_id`, `trans_group_id`, `trans_ttl`, `trans_type`)\n" +
                "VALUES\n" +
                "\t("+ trans_task_id2 + ", NULL, 15, 'zhongbao', NULL, NULL, 'customer', 595975, "+trans_task_id3+", NULL, NULL, '2016-01-16 20:00:00', NULL, 'started', 'send', NULL, '2016-01-08 10:17:12', '2016-01-08 10:17:12', " + old_category_id + ", '" + order_sn + "', 'unwashed', '" + order_id + "', " + trans_group_id + ", 1, 0);\n";
        //造交接单的数据
        String transOrderInfo3 = "INSERT INTO `trans_tasks` (`id`, `bagsn`, `from_id`, `from_type`, `from_address_id`, `to_id`, `to_type`, `to_address_id`, `next_task_id`, `transfer_task_id`, `transferred_by`, `dead_line`, `prority`, `status`, `direction`, `finished_at`, `created_at`, `updated_at`, `category_id`, `ordersn`, `washing_status`, `order_id`, `trans_group_id`, `trans_ttl`, `trans_type`)\n" +
                "VALUES\n" +
                "\t("+ trans_task_id3 + ", NULL, NULL, 'zhongbao', NULL, 15, 'customer', 595975, NULL, NULL, NULL, '2016-01-16 20:00:00', NULL, 'started', 'get', NULL, '2016-01-08 10:17:12', '2016-01-08 10:17:12', " + old_category_id + ", '" + order_sn + "', 'unwashed', '" + order_id + "', " + trans_group_id + ", 1, 0);\n";

        //造交接单group的数据
        String transGroupInfo = "INSERT INTO `trans_groups` (`id`, `order_id`, `ordersn`, `bagsn`, `current_task_id`, `last_task_id`, `order_type`, `order_status`, `status_delivery`, `type`, `created_at`, `updated_at`, `propose_outlet_id`, `dispatch_task_id`)\n" +
                "VALUES\n" +
                "\t(" + trans_group_id + ", " + order_id + ", " + order_id + ", NULL, " + trans_task_id3 + ", "+trans_task_id3+", NULL, 1, NULL, 'TransGroup', '2016-01-22 17:44:25', '2016-01-25 10:14:41', NULL, "+ dispatch_id + ");\n";



        //造调度派单的数据
        String dispatchOrderInfo = "INSERT INTO `dispatch_tasks` (`id`, `order_id`, `status`, `from_type`, `from_id`, `to_type`, `to_id`, `dispatch_type`, `courier_id`, `hope_time`, `finished_at`, `category_id`, `created_at`, `updated_at`, `type`, `ordersn`, `city_id`)\n" +
                "VALUES\n" +
                "\t("+ dispatch_id + ", "+ order_id+ ", 'started', 'jiagongdian', NULL, 'Address', 595986, 15, NULL, '2016-01-25 20:00:00', NULL, 1, '2016-01-25 13:31:45', '2016-01-25 13:31:45', 'DispatchTask', NULL, 1);\n";

        mysqlQaDao.execUpdateSql(orderInfo);
        mysqlQaDao.execUpdateSql(transOrderInfo1);
        mysqlQaDao.execUpdateSql(transOrderInfo2);
        mysqlQaDao.execUpdateSql(transOrderInfo3);
        mysqlQaDao.execUpdateSql(transGroupInfo);
        mysqlQaDao.execUpdateSql(dispatchOrderInfo);

        this.queryParams.put("jiagongdian_id",3);
        JSONObject result = this.shareAPIModuleService.CallJiagongdianQianshouTest("", "",String.valueOf(order_id), this.queryParams);
        // 验证jiagongdian接口返回的数据
        logger.info(result.toJSONString());
        Assert.assertTrue(result.getString("httpStatus").equals("201"));
        JSONObject body = JSON.parseObject(result.getString("httpBody"));

        // 验证trans_tasks数据（update from_id,from_type）
        String queryTransOrder = "select from_id,from_type,status,washing_status from " +
                "trans_tasks where order_id = " + order_id + "";
        ResultSet queryTranInfo = mysqlQaDao.execQuerySql(queryTransOrder);
        System.out.print(queryTranInfo);
        Assert.assertEquals("返回值不符合预期", 0, queryTranInfo.getInt("from_id"));
        Assert.assertTrue("返回值不符合预期", queryTranInfo.getString("from_type").contains("zhongbao"));
        Assert.assertTrue("返回值不符合预期", queryTranInfo.getString("status").contains("started"));
        Assert.assertTrue("返回值不符合预期",queryTranInfo.getString("washing_status").contains("unwashed"));

        //验证dispatch_tasks数据
        String queryDispatchTask = "select * from " +
                "dispatch_tasks where order_id = " + order_id + "";
        ResultSet queryDispatchTaskInfo = mysqlQaDao.execQuerySql(queryDispatchTask);
        System.out.print(queryDispatchTaskInfo.getString("to_type"));
        Assert.assertEquals("返回值不符合预期", 0, queryDispatchTaskInfo.getInt("from_id"));
//        Assert.assertTrue("返回值不符合预期", queryDispatchTaskInfo.getString("from_type").contains("zhongbao"));
//        Assert.assertTrue("返回值不符合预期", queryDispatchTaskInfo.getString("status").contains("init"));
        Assert.assertTrue("返回值不符合预期",queryDispatchTaskInfo.getString("to_type").contains(""));
        Assert.assertTrue("返回值不符合预期",queryDispatchTaskInfo.getString("to_id").contains(""));
        Assert.assertTrue("返回值不符合预期",queryDispatchTaskInfo.getString("city_id").contains(""));

        //验证ims_washing_order数据
        String queryOrder = "select qianshoudian_id,status_delivery from ims_washing_order where id = " + order_id + "";
        ResultSet queryOrderInfo = mysqlQaDao.execQuerySql(queryOrder);
        System.out.print(queryOrderInfo);
        Assert.assertEquals("返回值不符合预期", "0", queryOrderInfo.getString("qianshoudian_id"));
        Assert.assertEquals("返回值不符合预期","1",queryOrderInfo.getString("status_delivery"));


    }

}
