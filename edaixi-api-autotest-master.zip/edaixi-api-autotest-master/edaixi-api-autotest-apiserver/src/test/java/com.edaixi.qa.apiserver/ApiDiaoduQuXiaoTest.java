package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by he_yi on 16/3/18.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ApiDiaoduQuXiaoTest {
    private static ApiModuleService shareAPIModuleService = new ApiModuleService();
    private static GeneralRongChain04Data rongchang04 = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static Logger logger = LoggerFactory.getLogger(ApiWuliuSongQianShouTest.class);
    private SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //初始化请勿赋值!!!
    private final static String order_id = String.valueOf(CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1);
    private final static String order_sn = CommonTools.getOrdersn(order_id);
    private final static String dispatch_id= String.valueOf(CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao)+1);


    private static Map<String, String> mapDispatch;
    private static Map<String, String> mapWashingOrder;


    private static String back_reason = "顾客下错订单";

    private void createOrder(){
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("order_id", order_id);
        tmp.put("order_sn", order_sn);
        tmp.put("status", 1);
        tmp.put("status_delivery", 11);
        tmp.put("pay_status", 1);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        tmp.put("washing_time", "22:00-24:00");
        tmp.put("uid", 0);
        tmp.put("old_category_id", 2);
        tmp.put("uid_song", 0);
        rongchang04.GeneralOrder(tmp);
    }

    private void createTrans(){
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("id", dispatch_id);
        tmp.put("order_id", order_id);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd 00:00:00"));
        tmp.put("category_id", 2);
        rongchang04.GeneralDispatchTask(tmp);
    }


    private void initResultMap(){
        mapWashingOrder = new HashMap<String, String>();
        String sql_order = "select back_reason, status_delivery, status, dingdan_quxiao_time, updated_at from ims_washing_order where id="+order_id;
        ResultSet r1 = mysqlQaDao.execQuerySql(sql_order);
        try {
            mapWashingOrder.put("back_reason", r1.getString("back_reason"));
            mapWashingOrder.put("status_delivery", r1.getString("status_delivery"));
            mapWashingOrder.put("status", r1.getString("status"));
            mapWashingOrder.put("dingdan_quxiao_time", r1.getString("dingdan_quxiao_time"));
            mapWashingOrder.put("updated_at", r1.getString("updated_at"));
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        mapDispatch = new HashMap<String, String>();
        String sql_dispatch = "select status, updated_at from dispatch_tasks where id="+dispatch_id;
        r1 = mysqlQaDao.execQuerySql(sql_dispatch);
        try {
            mapDispatch.put("status", r1.getString("status"));
            mapDispatch.put("updated_at", r1.getString("updated_at"));
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    /**
     * 初始化数据方法,请保证第一个运行!
     */
    @Test
    public void a_1init(){
        createOrder();
        createTrans();
        logger.info("测试数据:order_id="+order_id+", back_reason="+back_reason);
        JSONObject resultJson = shareAPIModuleService.CallApiDiaoduQuXiaoTest(order_id, back_reason);
        logger.info("result json:"+resultJson.toJSONString());
        if (!resultJson.getString("httpStatus").equals("201")){
            logger.info("链接异常,程序退出");
            System.exit(0);
        }
        initResultMap();
    }

    @Test
    public void ims_washing_order_status(){
        String mapText = mapWashingOrder.get("status");
        Assert.assertEquals("ims_washing_order表的status值不正确", "-1", mapText);
    }

    @Test
    public void ims_washing_order_status_delivery(){
        String mapText = mapWashingOrder.get("status_delivery");
        Assert.assertEquals("ims_washing_order表的status值不正确", "10", mapText);
    }

    @Test
    public void ims_washing_order_back_reason(){
        String mapText = mapWashingOrder.get("back_reason");
        Assert.assertEquals("ims_washing_order表的back_reason值不正确", back_reason, mapText);
    }

    @Test
    public void ims_washing_order_dingdan_quxiao_time(){
        String mapText = mapWashingOrder.get("dingdan_quxiao_time");
        String mapTime = fullDateFormat.format(Integer.parseInt(mapText) * 1000L);
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的dingdan_quxiao_time值不正确", CommonTools.judgeTimeDifference(now, mapTime, 6));
    }

    @Test
    public void ims_washing_order_updated_at(){
        String mapText = mapWashingOrder.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的updated_at值不正确", CommonTools.judgeTimeDifference(now, mapText, 6));
    }

    @Test
    public void dispatch_tasks_status(){
        String mapText = mapDispatch.get("status");
        Assert.assertEquals("dispatch_tasks表的status值不正确", "canceled", mapText);
    }

    @Test
    public void dispatch_tasks_updated_at(){
        String mapText = mapDispatch.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("dispatch_tasks表的updated_at值不正确", CommonTools.judgeTimeDifference(now, mapText, 6));
    }

//    UPDATE `ims_washing_order` SET `status` = -1, `status_delivery` = 10, `back_reason` = '重复订单', `dingdan_quxiao_time` = 1458283936, `updated_at` = '2016-03-18 14:52:16' WHERE `ims_washing_order`.`id` = 984882409
//    UPDATE `dispatch_tasks` SET `status` = 'canceled', `updated_at` = '2016-03-18 14:52:16' WHERE `dispatch_tasks`.`type` IN ('DispatchTask') AND `dispatch_tasks`.`id` = 99249

}
