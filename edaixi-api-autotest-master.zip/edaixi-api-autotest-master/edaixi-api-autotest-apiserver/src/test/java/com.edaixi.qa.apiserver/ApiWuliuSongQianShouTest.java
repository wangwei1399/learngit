package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by he_yi on 16/3/16.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ApiWuliuSongQianShouTest {
    private static ApiModuleService shareAPIModuleService = new ApiModuleService();
    private static GeneralRongChain04Data rongchang04 = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static Logger logger = LoggerFactory.getLogger(ApiWuliuSongQianShouTest.class);
    private SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private static String endTime = "";

    //初始化请勿赋值!!!
    private static String order_id;
    private static String order_sn;
    private static String courier_id;
    private static String group_id;
    private static int trans_task_id;

    private static Map<String, String> mapTransGroups;
    private static Map<String, String> mapWashingOrder;
    private static Map<String, String> maptransTasks1;
    private static Map<String, String> maptransTasks2;
    private static Map<String, String> maptransTasks3;

    //初始化可以赋值
    private static String bagsn = "00041921043";

    private void createOrder(){
        int id = CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao);
        order_id = String.valueOf(id+1);
        order_sn = CommonTools.getOrdersn(order_id);
        courier_id = String.valueOf(CommonTools.get_courierId(mysqlQaDao));
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("order_id", order_id);
        tmp.put("order_sn", order_sn);
        tmp.put("status", 1);
        tmp.put("status_delivery", 15);
        tmp.put("pay_status", 1);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        tmp.put("washing_time", "22:00-24:00");
        tmp.put("uid", courier_id);
        tmp.put("old_category_id", 2);
        tmp.put("uid_song", courier_id);
        tmp.put("bagsn", bagsn);
        rongchang04.GeneralOrder(tmp);
    }

    private void createTrans(){
        int tmp_dispatch_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao);
        String dispatch_id = String.valueOf(tmp_dispatch_id+1);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("id", dispatch_id);
        tmp.put("order_id", order_id);
        tmp.put("status", "finished");
        tmp.put("courier_id", courier_id);
        tmp.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd 00:00:00", 1));
        tmp.put("category_id", 2);
        rongchang04.GeneralDispatchTask(tmp);

        int tmp_group_id = CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao);
        group_id = String.valueOf(tmp_group_id+1);
        tmp.clear();
        tmp.put("id", group_id);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("current_task_id", 0);
        tmp.put("last_task_id", 0);
        tmp.put("dispatch_task_id", dispatch_id);
        tmp.put("order_id", order_id);
        rongchang04.GeneralTransGroups(tmp);


        int tmp_trans_tasks_id = CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao);
        trans_task_id = (++tmp_trans_tasks_id);
        tmp.clear();
        tmp.put("id", trans_task_id);
        tmp.put("ordersn", order_sn);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "finished");
        tmp.put("direction", "get");
        tmp.put("category_id", 2);
        tmp.put("trans_group_id", group_id);
        tmp.put("washing_status", "unwashed");
        tmp.put("finished_at", CommonTools.getToday("yyyy-MM-dd hh:mm:ss"));
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "send");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("from_id", 67);
        tmp.put("from_type", "jiagongdian");
        tmp.put("to_id", courier_id);
        tmp.put("to_type", "zhongbao");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "started");
        tmp.put("direction", "send");
        tmp.remove("finished_at");
        tmp.put("washing_status", "washed");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        trans_task_id = (++tmp_trans_tasks_id);
        tmp.put("id", trans_task_id);
        tmp.put("to_id", "NULL");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", "NULL");
        tmp.put("direction", "send");
        tmp.put("status", "init");
        rongchang04.GeneralTransTasks(tmp);


        String sql = "update trans_groups set current_task_id="+(tmp_trans_tasks_id-1)+", last_task_id="+trans_task_id+
                " where id ="+group_id;
        mysqlQaDao.execUpdateSql(sql);
    }


    private void initResultMap(){
        mapWashingOrder = new HashMap<String, String>();
        String sql = "select wuliu_song_qianshou_time, status_delivery, updated_at from ims_washing_order where id="+order_id;
        ResultSet r1 = mysqlQaDao.execQuerySql(sql);
        try {
            mapWashingOrder.put("wuliu_song_qianshou_time", r1.getString("wuliu_song_qianshou_time"));
            mapWashingOrder.put("status_delivery", r1.getString("status_delivery"));
            mapWashingOrder.put("updated_at", r1.getString("updated_at"));
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        mapTransGroups = new HashMap<String, String>();
        sql = "select current_task_id, updated_at from trans_groups where id="+group_id;
        ResultSet r2 = mysqlQaDao.execQuerySql(sql);
        try{
            mapTransGroups.put("current_task_id", r2.getString("current_task_id"));
            mapTransGroups.put("updated_at", r2.getString("updated_at"));
            r2.close();
        }catch (SQLException e){
            e.printStackTrace();
        }

        maptransTasks1 = new HashMap<String, String>();
        sql = "select status, finished_at, updated_at from trans_tasks where id=";
        ResultSet r3 = mysqlQaDao.execQuerySql(sql+(trans_task_id-2));
        try {
            maptransTasks1.put("status", r3.getString("status"));
            maptransTasks1.put("finished_at", r3.getString("finished_at"));
            maptransTasks1.put("updated_at", r3.getString("updated_at"));
            r3.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        maptransTasks2 = new HashMap<String, String>();
        ResultSet r4 = mysqlQaDao.execQuerySql(sql+(trans_task_id-1));
        try {
            maptransTasks2.put("status", r4.getString("status"));
            maptransTasks2.put("finished_at", r4.getString("finished_at"));
            maptransTasks2.put("updated_at", r4.getString("updated_at"));
            r4.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        maptransTasks3 = new HashMap<String, String>();
        r1 = mysqlQaDao.execQuerySql(sql+trans_task_id);
        try {
            maptransTasks3.put("status", r1.getString("status"));
            maptransTasks3.put("updated_at", r1.getString("updated_at"));
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }




    }

    /**
     * 初始化数据方法,请保证第一个运行!
     */
    @Test
    public void a_1init(){
        createOrder();
        createTrans();
        logger.info("测试数据:order_id="+order_id+",courier_id="+courier_id);
        JSONObject resultJson = shareAPIModuleService.CallApiWuliuSongQianShou(order_id, courier_id);
        endTime = fullDateFormat.format(System.currentTimeMillis());
        logger.info("result json:"+resultJson.toJSONString());
        if (!resultJson.getString("httpStatus").equals("201")){
            logger.info("链接异常,程序退出");
            System.exit(0);
        }
//        httpBody
        initResultMap();
    }

    @Test
    public void ims_washing_order_wuliu_song_qianshou_time(){
        //UPDATE `ims_washing_order` SET `wuliu_song_qianshou_time` = 1458107029, `status_delivery` = 2, `updated_at` = '2016-03-16 13:43:49' WHERE `ims_washing_order`.`id` = 984882475

        String mapText = mapWashingOrder.get("wuliu_song_qianshou_time");
        String mapTime = fullDateFormat.format(Integer.parseInt(mapText) * 1000L);
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的wuliu_song_qianshou_time值不正确", CommonTools.judgeTimeDifference(endTime, mapTime, 6));
    }

    @Test
    public void ims_washing_order_status_delivery(){
        String mapText = mapWashingOrder.get("status_delivery");
        Assert.assertEquals("ims_washing_order表的status_delivery值不正确", "2", mapText);
    }


    @Test
    public void ims_washing_order_updated_at(){
        String mapText = mapWashingOrder.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }


    @Test
    public void trans_groups_current_task_id(){
        //UPDATE `trans_groups` SET `current_task_id` = 984110, `updated_at` = '2016-03-16 13:43:49' WHERE `trans_groups`.`type` IN ('TransGroup') AND `trans_groups`.`id` = 97461
        String mapText = mapTransGroups.get("current_task_id");
        Assert.assertEquals("trans_groups表的current_task_id值不正确", String.valueOf(trans_task_id), mapText);
    }

    @Test
    public void trans_groups_updated_at(){
        String mapText = mapTransGroups.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_groups表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }


    @Test
    public void trans_tasks1_status(){
        //UPDATE `trans_tasks` SET `status` = 'finished', `finished_at` = '2016-03-16 13:43:49', `updated_at` = '2016-03-16 13:43:49' WHERE `trans_tasks`.`id` = 984108
        String mapText = maptransTasks1.get("status");
        Assert.assertEquals("trans_tasks表的status值不正确", "finished", mapText);
    }

    @Test
    public void trans_tasks1_updated_at(){
        String mapText = maptransTasks1.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void trans_tasks1_finished_at(){
        String mapText = maptransTasks1.get("finished_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的finished_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }


    @Test
    public void trans_tasks2_status(){
        //UPDATE `trans_tasks` SET `status` = 'finished', `finished_at` = '2016-03-16 13:43:49', `updated_at` = '2016-03-16 13:43:49' WHERE `trans_tasks`.`id` = 984109
        String mapText = maptransTasks2.get("status");
        Assert.assertEquals("trans_tasks表的status值不正确", "finished", mapText);
    }

    @Test
    public void trans_tasks2_updated_at(){
        String mapText = maptransTasks2.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void trans_tasks2_finished_at(){
        String mapText = maptransTasks2.get("finished_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的finished_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void trans_tasks3_status(){
        //UPDATE `trans_tasks` SET `status` = 'started', `updated_at` = '2016-03-16 13:43:49' WHERE `trans_tasks`.`id` = 984110
        String mapText = maptransTasks3.get("status");
        Assert.assertEquals("trans_tasks表的status值不正确", "started", mapText);
    }

    @Test
    public void trans_tasks3_updated_at(){
        String mapText = maptransTasks3.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }




}
