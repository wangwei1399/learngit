package com.edaixi.qa.apiserver;

import com.alibaba.fastjson.JSONObject;
import com.edaixi.base.qa.common.dao.MysqlQaDao;
import com.edaixi.qa.common.CommonTools;
import com.edaixi.qa.common.GeneralRongChain04Data;
import junit.framework.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by he_yi on 16/3/18.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ApiKeHuQianShouTest {
    private static ApiModuleService shareAPIModuleService = new ApiModuleService();
    private static GeneralRongChain04Data rongchang04 = new GeneralRongChain04Data();
    private static MysqlQaDao mysqlQaDao = new MysqlQaDao();
    private static Logger logger = LoggerFactory.getLogger(ApiWuliuSongQianShouTest.class);
    private SimpleDateFormat fullDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //初始化请勿赋值!!!
    private final static String order_id = String.valueOf(CommonTools.getLastId("select id from ims_washing_order order by id desc limit 1;", mysqlQaDao)+1);
    private final static String order_sn = CommonTools.getOrdersn(order_id);
    private final static String courier_id = String.valueOf(CommonTools.get_courierId(mysqlQaDao));
    private final static String group_id= String.valueOf(CommonTools.getLastId("select id from trans_groups order by id desc limit 1;", mysqlQaDao)+1);
    private final static String fan_id = String.valueOf(CommonTools.getFanId(mysqlQaDao));
    private final static int trans_task_id =CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao)+6;
    private static String endTime = "";

    private static Map<String, String> mapImsFans;
    private static Map<String, String> mapWashingOrder;
    private static Map<String, String> maptransTasks;

    //初始化可以赋值
    private static String bagsn = "00041921043";

    private void createOrder(){
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("order_id", order_id);
        tmp.put("order_sn", order_sn);
        tmp.put("status", 1);
        tmp.put("status_delivery", 2);
        tmp.put("pay_status", 1);
        tmp.put("nextDate", CommonTools.getToday("yyyy-MM-dd"));
        tmp.put("washing_time", "22:00-24:00");
        tmp.put("uid", courier_id);
        tmp.put("old_category_id", 2);
        tmp.put("uid_song", courier_id);
        tmp.put("bagsn", bagsn);
        tmp.put("wuliu_song_qianshou_time", String.valueOf(System.currentTimeMillis()).substring(0, 10));
        rongchang04.GeneralOrder(tmp);
    }

    private void createTrans(){
        int tmp_dispatch_id = CommonTools.getLastId("select id from dispatch_tasks order by id desc limit 1;", mysqlQaDao);
        String dispatch_id = String.valueOf(tmp_dispatch_id+1);
        Map<String, Object> tmp = new HashMap<String, Object>();
        tmp.put("id", dispatch_id);
        tmp.put("order_id", order_id);
        tmp.put("status", "finished");
        tmp.put("courier_id", courier_id);
        tmp.put("nextDate", CommonTools.getAfterDate("yyyy-MM-dd 00:00:00", 1));
        tmp.put("category_id", 2);
        rongchang04.GeneralDispatchTask(tmp);


        tmp.clear();
        tmp.put("id", group_id);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("current_task_id", 0);
        tmp.put("last_task_id", 0);
        tmp.put("dispatch_task_id", dispatch_id);
        tmp.put("order_id", order_id);
        rongchang04.GeneralTransGroups(tmp);


        int tmp_trans_tasks_id = CommonTools.getLastId("select * from trans_tasks order by id desc limit 1;", mysqlQaDao);
        tmp.clear();
        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("ordersn", order_sn);
        tmp.put("order_id", order_id);
        tmp.put("bagsn", bagsn);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("status", "finished");
        tmp.put("direction", "get");
        tmp.put("category_id", 2);
        tmp.put("trans_group_id", group_id);
        tmp.put("washing_status", "unwashed");
        tmp.put("finished_at", CommonTools.getToday("yyyy-MM-dd hh:mm:ss"));
        rongchang04.GeneralTransTasks(tmp);

        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "send");
        rongchang04.GeneralTransTasks(tmp);

        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("from_id", 67);
        tmp.put("from_type", "jiagongdian");
        tmp.put("to_id", courier_id);
        tmp.put("to_type", "zhongbao");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "send");
        tmp.put("washing_status", "washed");
        rongchang04.GeneralTransTasks(tmp);

        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("from_id", courier_id);
        tmp.put("from_type", "zhongbao");
        tmp.put("to_id", 67);
        tmp.put("to_type", "jiagongdian");
        tmp.put("next_task_id", tmp_trans_tasks_id+1);
        tmp.put("direction", "get");
        rongchang04.GeneralTransTasks(tmp);

        tmp.put("id", ++tmp_trans_tasks_id);
        tmp.put("to_id", "NULL");
        tmp.put("to_type", "customer");
        tmp.put("next_task_id", "NULL");
        tmp.put("direction", "send");
        tmp.remove("finished_at");
        tmp.put("status", "started");
        rongchang04.GeneralTransTasks(tmp);


        String sql = "update trans_groups set current_task_id="+tmp_trans_tasks_id+", last_task_id="+trans_task_id+
                " where id ="+group_id;
        mysqlQaDao.execUpdateSql(sql);
    }


    private void initResultMap(){
        mapWashingOrder = new HashMap<String, String>();
        String sql = "select songhui_time, status_delivery, status, kehu_qianshou_time, updated_at from ims_washing_order where id="+order_id;
        ResultSet r1 = mysqlQaDao.execQuerySql(sql);
        try {
            mapWashingOrder.put("songhui_time", r1.getString("songhui_time"));
            mapWashingOrder.put("status_delivery", r1.getString("status_delivery"));
            mapWashingOrder.put("status", r1.getString("status"));
            mapWashingOrder.put("kehu_qianshou_time", r1.getString("kehu_qianshou_time"));
            mapWashingOrder.put("updated_at", r1.getString("updated_at"));
            r1.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        mapImsFans = new HashMap<String, String>();
        sql = "select last_finish_order_time, updated_at from ims_fans where id="+fan_id;
        ResultSet r2 = mysqlQaDao.execQuerySql(sql);
        try{
            mapImsFans.put("last_finish_order_time", r2.getString("last_finish_order_time"));
            mapImsFans.put("updated_at", r2.getString("updated_at"));
            r2.close();
        }catch (SQLException e){
            e.printStackTrace();
        }

        maptransTasks = new HashMap<String, String>();
        sql = "select status, finished_at, updated_at from trans_tasks where id="+trans_task_id;
        ResultSet r3 = mysqlQaDao.execQuerySql(sql);
        try {
            maptransTasks.put("status", r3.getString("status"));
            maptransTasks.put("finished_at", r3.getString("finished_at"));
            maptransTasks.put("updated_at", r3.getString("updated_at"));
            r3.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 初始化数据方法,请保证第一个运行!
     */
    @Test
    public void a_1init(){
        createOrder();
        createTrans();
        logger.info("测试数据:order_id="+order_id);
        JSONObject resultJson = shareAPIModuleService.CallApiKeHuQianShouTest(order_id);
        endTime = fullDateFormat.format(System.currentTimeMillis());
        logger.info("result json:"+resultJson.toJSONString());
        if (!resultJson.getString("httpStatus").equals("201")){
            logger.info("链接异常,程序退出");
            System.exit(0);
        }
        initResultMap();
    }

//        UPDATE `ims_washing_order` SET `songhui_time` = 1458278292, `status` = 7, `kehu_qianshou_time` = 1458278292, `status_delivery` = 3, `updated_at` = '2016-03-18 13:18:12' WHERE `ims_washing_order`.`id` = 984882490
//        UPDATE `ims_fans` SET `last_finish_order_time` = 1458278292, `updated_at` = '2016-03-18 13:18:12' WHERE `ims_fans`.`id` = 623750
//        UPDATE `trans_tasks` SET `status` = 'finished', `finished_at` = '2016-03-18 13:18:12', `updated_at` = '2016-03-18 13:18:12' WHERE `trans_tasks`.`id` = 984195

    @Test
    public void ims_washing_order_songhui_time(){
        String mapText = mapWashingOrder.get("songhui_time");
        String mapTime = fullDateFormat.format(Integer.parseInt(mapText) * 1000L);
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的songhui_time值不正确", CommonTools.judgeTimeDifference(endTime, mapTime, 6));
    }

    @Test
    public void ims_washing_order_status(){
        String mapText = mapWashingOrder.get("status");
        Assert.assertEquals("ims_washing_order表的status值不正确", "7", mapText);
    }

    @Test
    public void ims_washing_order_kehu_qianshou_time(){
        String mapText = mapWashingOrder.get("kehu_qianshou_time");
        String mapTime = fullDateFormat.format(Integer.parseInt(mapText) * 1000L);
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_washing_order表的kehu_qianshou_time值不正确", CommonTools.judgeTimeDifference(endTime, mapTime, 6));
    }

    @Test
    public void ims_washing_order_status_delivery(){
        String mapText = mapWashingOrder.get("status");
        Assert.assertEquals("ims_washing_order表的status值不正确", "7", mapText);
    }

    @Test
    public void ims_washing_order_updated_at(){
        String mapText = mapWashingOrder.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        logger.info("ms_washing_order表的updated_at时间,endTime:"+endTime+",update_at:"+mapText);
        Assert.assertTrue("ims_washing_order表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void ims_fans_last_finish_order_time(){
        String mapText = mapImsFans.get("last_finish_order_time");
        String mapTime = fullDateFormat.format(Integer.parseInt(mapText) * 1000L);
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_fans表的last_finish_order_time值不正确", CommonTools.judgeTimeDifference(endTime, mapTime, 6));
    }

    @Test
    public void ims_fans_updated_at(){
        String mapText = mapImsFans.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("ims_fans表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void trans_tasks_status(){
        String mapText = maptransTasks.get("status");
        Assert.assertEquals("trans_tasks表的status值不正确", "finished", mapText);
    }

    @Test
    public void trans_tasks_finished_at(){
        String mapText = maptransTasks.get("finished_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的finished_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }

    @Test
    public void trans_tasks_updated_at(){
        String mapText = maptransTasks.get("updated_at");
        String now = fullDateFormat.format(System.currentTimeMillis());
        Assert.assertTrue("trans_tasks表的updated_at值不正确", CommonTools.judgeTimeDifference(endTime, mapText, 6));
    }


}
